#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SPARK_HOME:?Set SPARK_HOME to Spark 3.2.0}"
OUTPUT=${1:?Usage: bash scripts/run_small_online.sh ABSOLUTE_NEW_OUTPUT_PATH}
INPUT=$(pwd)/examples/five_points.txt
JAR=${DISMC_JAR:-target/dismc-unified-1.0.0.jar}
for suffix in '' .json .manifest .observation.json .members; do
 test ! -e "$OUTPUT$suffix" || { echo "Output exists: $OUTPUT$suffix" >&2; exit 2; }
done
"$SPARK_HOME/bin/spark-submit" --class com.DistributedSMC --master 'local[2]' \
 --conf spark.driver.memory=2G --conf spark.skyline.shardReadBudget=0.05 --conf spark.skyline.stableInputIds=true \
 --conf spark.skyline.materializeMembers=true --conf spark.skyline.memberOutputMode=partitioned \
 --conf spark.skyline.memberOutputPath="$OUTPUT.members" \
 --conf spark.skyline.experiment.enabled=true --conf spark.skyline.experiment.observe=true \
 --conf spark.skyline.experiment.outputPrefix="$OUTPUT" --conf spark.skyline.experiment.runId=small-online \
 "$JAR" hilbert_full "file://$INPUT" "$OUTPUT" 2 1 2 1 0 0
