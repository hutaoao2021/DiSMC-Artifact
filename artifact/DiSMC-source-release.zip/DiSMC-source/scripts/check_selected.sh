#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SPARK_HOME:?Set SPARK_HOME to Spark 3.2.0 / Scala 2.12}"
[[ -f target/dismc-unified-1.0.0.jar ]] || bash build.sh
mkdir -p target/check-classes
find src/test/java -name '*.java' -print > target/check-sources.list
javac -encoding UTF-8 -source 8 -target 8 -cp "target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" -d target/check-classes @target/check-sources.list
export SPARK_LOCAL_IP=${SPARK_LOCAL_IP:-127.0.0.1}
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.MicroPartitionLayoutTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.MicroPartitionPlannerTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.MicroPartitionExactSelectorTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.MicroPartitionDependencySafetyTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.LaneProbeRefinementTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.PrivateLaneProbeCostTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.PairedLaneProbeCostTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.SpatialProbeCostModelTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.ReferenceCandidateGeometryTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.BoundedProbeIdsTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.AnchorRegressionTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.BasicAnchorRegressionTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.NumericalSafetyRegressionTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.NumericalMemberSparkRegressionTest
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.FrozenReplayControlsTest
