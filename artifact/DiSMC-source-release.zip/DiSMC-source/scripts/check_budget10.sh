#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SPARK_HOME:?Set Spark 3.2.0}"
: "${JAVA_HOME:?Set JDK 8}"
export PATH="$JAVA_HOME/bin:$PATH"
export SPARK_LOCAL_IP=${SPARK_LOCAL_IP:-127.0.0.1}
bash build.sh
bash scripts/check_selected.sh
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" com.BudgetCompatibilityTest
python3 scripts/test_budget10_e2e.py "${1:?Specify NEW absolute output directory}"
