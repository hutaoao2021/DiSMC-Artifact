#!/usr/bin/env python3
"""Synthetic Micro-Partition test; creates a NEW output directory, never historical data."""
import collections, hashlib, json, os, pathlib, struct, subprocess, sys

def main():
    if len(sys.argv)!=2: raise SystemExit("usage: python3 scripts/test_budget10_e2e.py NEW_ABSOLUTE_DIRECTORY")
    b=pathlib.Path(sys.argv[1]); assert b.is_absolute(), "absolute output required"
    b.mkdir(exist_ok=False,parents=True)
    root=pathlib.Path(__file__).resolve().parents[1]
    spark=pathlib.Path(os.environ["SPARK_HOME"])
    f=b/"synthetic-240.txt"
    f.write_text("".join("%.6f %.6f\n"%((i//60)*20+(i%10)*.11,(i%60//10)*.11) for i in range(240)))
    common={"spark.ui.enabled":"false","spark.driver.host":"127.0.0.1","spark.driver.bindAddress":"127.0.0.1","spark.skyline.stableInputIds":"true","spark.skyline.materializeMembers":"true","spark.skyline.memberOutputMode":"partitioned","spark.skyline.budgetDiagnostic":"true","spark.skyline.shardReadBudget":"0.10","spark.skyline.experiment.enabled":"true","spark.skyline.experiment.partitionStrategy":"workload","spark.skyline.experiment.organization":"independent_owner","spark.skyline.experiment.shardStrategy":"none","spark.skyline.experiment.ownerThreads":"1","spark.skyline.experiment.observe":"true","spark.skyline.experiment.preparedMode":"private_owner_index","spark.skyline.experiment.geometricBounds":"true","spark.skyline.experiment.microDenseBoundaryCounting":"true"}
    for name,micro in [("micro10",True),("same-kernel-reference",False)]:
        o=b/name;d=dict(common);d["spark.skyline.memberOutputPath"]=str(o)+".members";d["spark.skyline.experiment.outputPrefix"]=str(o);d["spark.skyline.experiment.runId"]=name
        if micro:d.update({"spark.skyline.experiment.microPartition":"true","spark.skyline.experiment.microPartitionMode":"dependency","spark.skyline.experiment.microCostModel":"cell_quadratic","spark.skyline.experiment.microPlannerPolicy":"sampled_peak","spark.skyline.experiment.microTaskOrder":"cost","spark.skyline.experiment.microProbeFrontier":"true","spark.skyline.microAdaptiveAcquisition":"true","spark.skyline.probeOwnerLimit":"4","spark.skyline.microLaneProbeMaxOwners":"2","spark.skyline.microLaneProbeMaxAnchors":"16"})
        cmd=[str(spark/"bin/spark-submit"),"--master","local[2]","--driver-memory","2G","--class","com.DistributedSMC"]
        for k,v in d.items():cmd += ["--conf",k+"="+v]
        cmd += [str(root/"target/dismc-unified-1.0.0.jar"),"hilbert_full","file://"+str(f),str(o),"8","1","2","1","0","0"]
        (b/(name+".command.json")).write_text(json.dumps(cmd,indent=2))
        with (b/(name+".log")).open("w") as log:subprocess.run(cmd,cwd=str(root),check=True,stdout=log,stderr=subprocess.STDOUT)
    a=json.loads((b/"micro10.json").read_text());r=json.loads((b/"same-kernel-reference.json").read_text())
    assert a["Circles_info"]==r["Circles_info"], "frontiers differ"
    def members(n):return collections.Counter(line for part in (b/(n+".members")).rglob("*.tsv") for line in part.read_text().splitlines())
    x=members("micro10");assert x==members("same-kernel-reference"), "member multisets differ"
    points=[tuple(map(float,l.split())) for l in f.read_text().splitlines()]
    t=struct.unpack(">d",struct.pack(">Q",struct.unpack(">Q",struct.pack(">d",1.005))[0]-1))[0]
    expected=collections.Counter()
    for i,c in enumerate(a["Circles_info"]):
        count=0
        for px,py in points:
            dx=px-c["cenX"];dy=py-c["cenY"]
            if dx*dx+dy*dy<=t*t:expected[str(i)+"\t"+str(px)+"\t"+str(py)]+=1;count+=1
        assert count==c["pointsNum"], "coverage count"
    assert x==expected, "independent fixture membership check"
    q=a["diagnostics"]
    assert q["micro_mode"]=="dependency" and q["micro_physical_tasks"]>8
    assert q["micro_budget_records"]==int(q["micro_original_assigned"]*.10)
    assert q["micro_record_budget_satisfied"] and q["micro_extra_input_records"]<=q["micro_budget_records"]
    result={"status":"passed","fixture_points":240,"physical_tasks":q["micro_physical_tasks"],"original_assigned":q["micro_original_assigned"],"budget_records":q["micro_budget_records"],"extra_records":q["micro_extra_input_records"],"member_rows":sum(x.values()),"frontier_size":len(a["Circles_info"]),"frontier_and_members_equal":True,"independent_fixture_coverage_scan_equal":True,"input_sha256":hashlib.sha256(f.read_bytes()).hexdigest(),"scope":"synthetic local[2]; not Table I reproduction"}
    (b/"verification.json").write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=="__main__":main()
