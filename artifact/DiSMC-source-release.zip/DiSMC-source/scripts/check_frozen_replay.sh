#!/usr/bin/env bash
# Targeted frozen R/W regression (JDK 8 and Spark 3.2.0).
set -euo pipefail
cd "$(dirname "$0")/.."
: "${JAVA_HOME:?Set JDK 8}"
: "${SPARK_HOME:?Set Spark 3.2.0}"
export PATH="$JAVA_HOME/bin:$PATH"
[[ -f target/dismc-unified-1.0.0.jar ]] || bash build.sh
mkdir -p target/check-classes
javac -encoding UTF-8 -source 8 -target 8 \
  -cp "target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" \
  -d target/check-classes src/test/java/com/FrozenReplayControlsTest.java
java -ea -cp "target/check-classes:target/dismc-unified-1.0.0.jar:$SPARK_HOME/jars/*" \
  com.FrozenReplayControlsTest
