# Distribution packaging

This archive is based on the 2026-11-02 integrated source release. Its Java production and test sources are unchanged.

For portable execution, the absolute Spark installation default and the private-network Spark master default were replaced by explicit `SPARK_HOME` / `SPARK_MASTER` environment requirements in `build.sh` and `scripts/run_profile.sh`. The launcher also records `spark_master=not_applicable` when `single_esmc` is run without a Spark master, avoiding an unbound-variable failure after a successful standalone query. File entries in `SOURCE_MANIFEST.json` reflect the script changes.

Use the original `README.md` for source-release details and `VERIFICATION.json` for the historical build/test record. The present packaging review did not rerun the Spark workloads.

The English and Chinese usage notes clarify that the public launcher no longer embeds the private server master default. These documentation-only changes do not affect program execution.
