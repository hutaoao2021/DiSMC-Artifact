# Budget10 validated candidate, 2026-11-11

Based on the 2026-11-02 integrated release. The single production delta is the opt-in 10% allowance in ExperimentConfig; BudgetCompatibilityTest and a portable synthetic validation harness are added. See VERIFICATION_BUDGET10.json. Historical package notes and source manifest are retained under their 20261102 names. No historical results or datasets are included.
