package com;

/** Finite-candidate geometry adapter for the complete spatial-operator comparator.
 * It delegates to the existing engine; no copied circle-center formulas or pruning.
 * Reference Z-order endpoint ordering is independent of configuration identity.
 */
public final class ReferenceCandidateGeometry {
    private final MaskedIndexedEMCS geometry;
    private final double radius, qx, qy;
    public ReferenceCandidateGeometry(double radius, double qx, double qy) {
        if (!Double.isFinite(radius) || radius <= 0 || !Double.isFinite(qx) || !Double.isFinite(qy))
            throw new IllegalArgumentException("invalid query geometry");
        this.radius=radius;this.qx=qx;this.qy=qy;
        geometry=new MaskedIndexedEMCS(radius);geometry.q.x=qx;geometry.q.y=qy;
    }
    public Circle single(Point point) {
        return geometry.referenceSingleGeometry(indexed(point,0));
    }
    public Circle pair(Point first,Point second) {
        return pairPrepared(prepare(first,0),prepare(second,1));
    }
    MaskedPreparedNeighborhood.IndexedPoint prepare(Point point,int ordinal) {
        return indexed(point,ordinal);
    }
    Circle singlePrepared(MaskedPreparedNeighborhood.IndexedPoint point) {
        return geometry.referenceSingleGeometry(point);
    }
    Circle pairPrepared(MaskedPreparedNeighborhood.IndexedPoint a,
            MaskedPreparedNeighborhood.IndexedPoint b) {
        if(a.id==b.id)return null;
        double dx=a.x-b.x,dy=a.y-b.y,squared=dx*dx+dy*dy;
        if(squared<=0 || squared>4*radius*radius)return null;
        if(BaselinePointOrder.compare(a.baselineOrderX,a.baselineOrderY,a.id,
                b.baselineOrderX,b.baselineOrderY,b.id)>0) {
            MaskedPreparedNeighborhood.IndexedPoint swap=a;a=b;b=swap;
        }
        return geometry.referencePairGeometry(a,b,squared);
    }
    private MaskedPreparedNeighborhood.IndexedPoint indexed(Point point,int ordinal) {
        if(!Double.isFinite(point.x)||!Double.isFinite(point.y))
            throw new IllegalArgumentException("nonfinite source coordinate");
        return new MaskedPreparedNeighborhood.IndexedPoint(point,ordinal,qx,qy,radius);
    }
    /** Same squared-distance predicate as the reference counting path, including rounding slack. */
    public static boolean covers(Circle circle,Point point,double radius) {
        return NumericalCoverage.covers(circle.centerX,circle.centerY,point.x,point.y,radius);
    }
}
