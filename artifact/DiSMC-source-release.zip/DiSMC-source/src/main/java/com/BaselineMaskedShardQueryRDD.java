package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import org.apache.spark.Dependency;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.CollectionAccumulator;
import org.apache.spark.util.LongAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Baseline ESMC over exact owner views while preserving Full's physical shard layout. */
public final class BaselineMaskedShardQueryRDD extends RDD<HashMap<Double, Circle>> {
    private static final class QueryPartition implements Partition {
        final int id;
        final Partition parent;

        QueryPartition(int id, Partition parent) {
            this.id = id;
            this.parent = parent;
        }

        public int index() { return id; }
        public boolean org$apache$spark$Partition$$super$equals(Object other) {
            return super.equals(other);
        }
    }

    private static final class QueryDependency extends NarrowDependency<MaskedSharedBlock> {
        private final int[] groups;

        QueryDependency(RDD<MaskedSharedBlock> parent, BundleShardLayout layout) {
            super(parent);
            groups = new int[layout.taskCount()];
            for (int child = 0; child < groups.length; child++) {
                groups[child] = layout.parentGroup(child);
            }
        }

        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(
                    Collections.<Object>singletonList(groups[child])).asScala().toSeq();
        }
    }

    private static Seq<Dependency<?>> dependencies(
            RDD<MaskedSharedBlock> parent, BundleShardLayout layout) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(
                new QueryDependency(parent, layout))).asScala().toSeq();
    }

    private final RDD<MaskedSharedBlock> parent;
    private final BundleShardLayout layout;
    private final double dc;
    private final double queryX;
    private final double queryY;
    private final int density;
    private final LongAccumulator candidates;
    private final LongAccumulator singlePointCandidates;
    private final LongAccumulator pairCandidates;
    private final LongAccumulator zChecks;
    private final LongAccumulator distanceChecks;
    private final LongAccumulator maskChecks;
    private final LongAccumulator maskFiltered;
    private final CollectionAccumulator<Long> taskTimes;
    private final CollectionAccumulator<Long> bundleTimes;
    private final QueryPartition[] partitions;

    public BaselineMaskedShardQueryRDD(JavaRDD<MaskedSharedBlock> blocks,
            BundleShardLayout layout, double dc, double queryX, double queryY, int density,
            LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks,
            LongAccumulator distanceChecks, LongAccumulator maskChecks,
            LongAccumulator maskFiltered, CollectionAccumulator<Long> taskTimes,
            CollectionAccumulator<Long> bundleTimes) {
        super(blocks.context(), dependencies(blocks.rdd(), layout),
                ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
        if (blocks.getNumPartitions() != layout.groupCount()) {
            throw new IllegalArgumentException("masked block/layout group mismatch");
        }
        this.parent = blocks.rdd();
        this.layout = layout;
        this.dc = dc;
        this.queryX = queryX;
        this.queryY = queryY;
        this.density = density;
        this.candidates = candidates;
        this.singlePointCandidates = singlePointCandidates;
        this.pairCandidates = pairCandidates;
        this.zChecks = zChecks;
        this.distanceChecks = distanceChecks;
        this.maskChecks = maskChecks;
        this.maskFiltered = maskFiltered;
        this.taskTimes = taskTimes;
        this.bundleTimes = bundleTimes;
        Partition[] parents = parent.partitions();
        partitions = new QueryPartition[layout.taskCount()];
        for (int child = 0; child < partitions.length; child++) {
            partitions[child] = new QueryPartition(
                    child, parents[layout.parentGroup(child)]);
        }
    }

    public Partition[] getPartitions() { return partitions; }

    public scala.collection.Iterator<HashMap<Double, Circle>> compute(
            Partition split, TaskContext context) {
        long start = System.nanoTime();
        QueryPartition partition = (QueryPartition) split;
        scala.collection.Iterator<MaskedSharedBlock> input =
                parent.iterator(partition.parent, context);
        if (!input.hasNext()) throw new IllegalStateException("missing masked bundle block");
        MaskedSharedBlock block = input.next();
        if (input.hasNext()) throw new IllegalStateException("multiple masked bundle blocks");
        BundleShardLayout.Task task = layout.task(partition.id);
        ArrayList<HashMap<Double, Circle>> output =
                new ArrayList<HashMap<Double, Circle>>(task.owners.length);
        long checkedMasks = 0L;
        long filteredMasks = 0L;
        for (int job = 0; job < task.owners.length; job++) {
            int owner = task.owners[job];
            int slot = task.slots[job];
            ArrayList<Point> visible = new ArrayList<Point>();
            for (int ordinal = 0; ordinal < block.unionPoints.length; ordinal++) {
                checkedMasks++;
                if ((((block.visibilityMasks[ordinal] & 0xff) >>> slot) & 1) == 0) {
                    filteredMasks++;
                    continue;
                }
                Point point = new Point(block.unionPoints[ordinal]);
                point.is_core = point.ownerPartitionId == owner;
                point.is_clone = !point.is_core;
                visible.add(point);
            }
            BaselineLocalQuery.Result result = BaselineLocalQuery.execute(
                    visible, owner, task.round, task.pieces[job],
                    dc, queryX, queryY, density);
            candidates.add(result.candidateCount);
            singlePointCandidates.add(result.singlePointCandidateCount);
            pairCandidates.add(result.pairCandidateCount);
            zChecks.add(result.zWindowChecks);
            distanceChecks.add(result.pointDistanceChecks);
            output.add(result.skyline);
        }
        maskChecks.add(checkedMasks);
        maskFiltered.add(filteredMasks);
        long elapsed = (System.nanoTime() - start) / 1000000L;
        taskTimes.add(elapsed);
        bundleTimes.add(elapsed);
        return JavaConverters.asScalaIteratorConverter(output.iterator()).asScala();
    }

    public JavaRDD<HashMap<Double, Circle>> asJava() {
        return JavaRDD.fromRDD(this,
                ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
    }
}
