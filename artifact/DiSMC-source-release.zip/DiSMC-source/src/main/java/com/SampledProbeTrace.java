package com;

/** Probe-only instrumentation; formal queries continue to use MaskedLaneQuery. */
public final class SampledProbeTrace {
    public static SampledAnchorCostProbe.Probe evaluate(MaskedPreparedNeighborhood prepared,
            int owner, double radius, double cellSize, double queryX, double queryY,
            int density, EngineOptions options, long[] ids) {
        if (!options.newBounds || options.preparedReuse || options.geometricBounds
                || options.projectedDedup || options.countWindowCache || options.anchorBoundary
                || options.deferredCircleAllocation)
            throw new IllegalArgumentException("trace acquisition requires ordinary private cached probes");
        long start = System.nanoTime();
        ProbeTracingEMCS query = new ProbeTracingEMCS(radius);
        query.q.x = queryX; query.q.y = queryY; query.density_k = density;
        query.part_id = owner; query.setCellConfig(cellSize);
        query.usePrepared(prepared,0,owner,0,1,options);
        query.method(radius);
        query.probeTrace.seal();
        SampledAnchorCostProbe.Probe result = new SampledAnchorCostProbe.Probe(owner,
                ids.length, query.pointDistanceChecks, System.nanoTime()-start);
        result.countCellSize = prepared.countCellSize;
        result.anchorIds = ids.clone(); result.skyline = query.skymap;
        result.counters = new long[]{query.candidateCount,query.singlePointCandidateCount,
                query.pairCandidateCount,query.zWindowChecks,query.pointDistanceChecks,
                query.projectedCandidates,query.projectedCountHits,query.projectedBoundHits,
                query.maskChecks,query.maskFiltered};
        result.trace = query.probeTrace;
        result.generationChecks = query.pointDistanceChecks-query.recordedCountChecks;
        return result;
    }
    private SampledProbeTrace() { }
}
