package com;

import java.io.Serializable;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicIntegerArray;

/** A single immutable geometry/cell index with owner visibility masks. */
public final class MaskedPreparedNeighborhood implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final class IndexedPoint extends Point {
        final int ordinal;
        final long baselineOrderX;
        final long baselineOrderY;
        final double queryDistance;
        final double projectedX;
        final double projectedY;
        final double projectedDistance;

        IndexedPoint(Point point, int ordinal, double qx, double qy, double dc) {
            super(point);
            this.ordinal = ordinal;
            baselineOrderX = BaselinePointOrder.roundedCoordinate(point.x);
            baselineOrderY = BaselinePointOrder.roundedCoordinate(point.y);
            double dx = point.x - qx, dy = point.y - qy;
            queryDistance = Math.sqrt(dx * dx + dy * dy);
            // Keep the arithmetic and branch order identical to PreparedNeighborhood.IndexedPoint.
            if (queryDistance <= dc) projectedX = qx;
            else if (point.x > qx) projectedX = qx + ((queryDistance - dc) / queryDistance) * Math.abs(point.x - qx);
            else if (point.x == qx) projectedX = qx;
            else projectedX = qx - ((queryDistance - dc) / queryDistance) * Math.abs(point.x - qx);
            if (queryDistance <= dc) projectedY = qy;
            else if (point.y > qy) projectedY = qy + ((queryDistance - dc) / queryDistance) * Math.abs(point.y - qy);
            else if (point.y == qy) projectedY = qy;
            else projectedY = qy - ((queryDistance - dc) / queryDistance) * Math.abs(point.y - qy);
            double px = projectedX - qx, py = projectedY - qy;
            projectedDistance = (double) Math.round(Math.sqrt(px * px + py * py) * 100) / 100;
        }
    }

    public static final class MaskedCellBucket implements Serializable {
        private static final long serialVersionUID = 1L;

        final int[] ordinals;
        final byte[] masks;
        final int[] visibleCounts;
        final IndexedPoint[][] visiblePoints;
        final double minX, maxX, minY, maxY;

        MaskedCellBucket(int[] ordinals, byte[] masks, int ownerCount, IndexedPoint[] points) {
            this.ordinals = ordinals;
            this.masks = masks;
            this.visibleCounts = new int[ownerCount];
            double lowX = Double.POSITIVE_INFINITY, highX = Double.NEGATIVE_INFINITY;
            double lowY = Double.POSITIVE_INFINITY, highY = Double.NEGATIVE_INFINITY;
            for (int i = 0; i < ordinals.length; i++) {
                IndexedPoint point = points[ordinals[i]];
                lowX = Math.min(lowX, point.x);
                highX = Math.max(highX, point.x);
                lowY = Math.min(lowY, point.y);
                highY = Math.max(highY, point.y);
                int visibility = masks[i] & 0xff;
                for (int slot = 0; slot < ownerCount; slot++) {
                    if ((visibility & (1 << slot)) != 0) visibleCounts[slot]++;
                }
            }
            visiblePoints = new IndexedPoint[ownerCount][];
            for (int slot = 0; slot < ownerCount; slot++)
                visiblePoints[slot] = new IndexedPoint[visibleCounts[slot]];
            int[] positions = new int[ownerCount];
            for (int i = 0; i < ordinals.length; i++) {
                int visibility = masks[i] & 0xff;
                IndexedPoint point = points[ordinals[i]];
                for (int slot = 0; slot < ownerCount; slot++) {
                    if ((visibility & (1 << slot)) != 0)
                        visiblePoints[slot][positions[slot]++] = point;
                }
            }
            for (IndexedPoint[] lane : visiblePoints) sortPointsById(lane, 0, lane.length - 1);
            minX = lowX;
            maxX = highX;
            minY = lowY;
            maxY = highY;
        }
    }

    public static final class OwnerCache implements Serializable {
        private static final long serialVersionUID = 1L;

        final AtomicIntegerArray anchorCounts;
        final AtomicIntegerArray projectedCounts;
        final AtomicIntegerArray projectedUpperBounds;

        OwnerCache(int pointCount) {
            anchorCounts = new AtomicIntegerArray(pointCount);
            projectedCounts = new AtomicIntegerArray(pointCount);
            projectedUpperBounds = new AtomicIntegerArray(pointCount);
        }
    }

    private static final class MutableBucket {
        int[] ordinals = new int[8];
        byte[] masks = new byte[8];
        int size;

        void add(int ordinal, byte mask) {
            if (size == ordinals.length) {
                ordinals = Arrays.copyOf(ordinals, size << 1);
                masks = Arrays.copyOf(masks, size << 1);
            }
            ordinals[size] = ordinal;
            masks[size] = mask;
            size++;
        }
    }

    private static final class BuilderTable {
        long[] keys = new long[16];
        MutableBucket[] buckets = new MutableBucket[16];
        int size;

        MutableBucket getOrCreate(long key) {
            if ((size + 1) * 10 >= buckets.length * 7) rehash(buckets.length << 1);
            int at = hash(key) & (buckets.length - 1);
            while (buckets[at] != null) {
                if (keys[at] == key) return buckets[at];
                at = (at + 1) & (buckets.length - 1);
            }
            keys[at] = key;
            buckets[at] = new MutableBucket();
            size++;
            return buckets[at];
        }

        private void rehash(int capacity) {
            long[] oldKeys = keys;
            MutableBucket[] oldBuckets = buckets;
            keys = new long[capacity];
            buckets = new MutableBucket[capacity];
            size = 0;
            for (int i = 0; i < oldBuckets.length; i++) {
                if (oldBuckets[i] != null) {
                    int at = hash(oldKeys[i]) & (capacity - 1);
                    while (buckets[at] != null) at = (at + 1) & (capacity - 1);
                    keys[at] = oldKeys[i];
                    buckets[at] = oldBuckets[i];
                    size++;
                }
            }
        }
    }

    private final MaskedSharedBlock block;
    private final IndexedPoint[] points;
    private final long[] cellKeys;
    private final MaskedCellBucket[] cellBuckets;
    private long[] countCellKeys;
    private int denseMinX,denseMinY,denseWidth,denseHeight;
    private int[] sparseOffsets,sparseY;
    private int sparseMinX;
    private final long countingLookupOriginalBudget;
    private MaskedCellBucket[] countCellBuckets;
    private final OwnerCache[] caches;
    private final int[][] anchorOrdinals;
    private final int[][][] shardAnchorOrdinals;
    private final int[] shardAnchorPieces;
    private final int cellMask;
    final double dc, cellSize, countCellSize, qx, qy;
    final long preparedTaskAttemptId, preparationNanos;

    public MaskedPreparedNeighborhood(
            MaskedSharedBlock block, double dc, double cellSize, double qx, double qy) {
        this(block, dc, cellSize, qx, qy, false);
    }

    /** Refines only counting; source cells, anchor order and candidate traversal stay fixed. */
    public MaskedPreparedNeighborhood(
            MaskedSharedBlock block, double dc, double cellSize, double qx, double qy,
            boolean refinedCounting) {
        this(block,dc,cellSize,qx,qy,refinedCounting,false);
    }

    public MaskedPreparedNeighborhood(MaskedSharedBlock block,double dc,double cellSize,double qx,double qy,
            boolean refinedCounting,boolean adaptiveCountIndex) {
        this(block,dc,cellSize,qx,qy,refinedCounting,adaptiveCountIndex,1.0);
    }

    public MaskedPreparedNeighborhood(MaskedSharedBlock block,double dc,double cellSize,double qx,double qy,
            boolean refinedCounting,boolean adaptiveCountIndex,double countMultiplier) {
        if (block == null) throw new IllegalArgumentException("block is null");
        long preparationStart = System.nanoTime();
        org.apache.spark.TaskContext taskContext = org.apache.spark.TaskContext.get();
        preparedTaskAttemptId = taskContext == null ? -1 : taskContext.taskAttemptId();
        this.block = block;
        this.dc = dc;
        this.cellSize = cellSize;
        if (!Double.isFinite(countMultiplier) || countMultiplier <= 0) throw new IllegalArgumentException("invalid counting multiplier");
        double baseCountCell = refinedCounting ? safeCountingCellSize(block, dc, cellSize, qx, qy) : cellSize;
        double actualCountCell = baseCountCell;
        if (countMultiplier != 1.0) {
            double scaledCountCell = baseCountCell * countMultiplier;
            double extent = Math.max(Math.abs(qx), Math.abs(qy));
            for (Point p : block.unionPoints) extent = Math.max(extent, Math.max(Math.abs(p.x), Math.abs(p.y)));
            actualCountCell = scaledCountCell > 0 && Double.isFinite(scaledCountCell)
                    && (extent + 2*dc + 0.005)/scaledCountCell < Integer.MAX_VALUE-2.0 ? scaledCountCell : cellSize;
        }
        this.countCellSize = actualCountCell;
        this.qx = qx;
        this.qy = qy;
        points = new IndexedPoint[block.unionPoints.length];
        BuilderTable table = new BuilderTable();
        BuilderTable countTable = countCellSize != cellSize ? new BuilderTable() : null;
        for (int ordinal = 0; ordinal < points.length; ordinal++) {
            Point point = block.unionPoints[ordinal];
            points[ordinal] = new IndexedPoint(point, ordinal, qx, qy, dc);
            table.getOrCreate(point.packedCellId).add(ordinal, block.visibilityMasks[ordinal]);
            if (countTable != null) {
                int cx = (int)Math.floor(point.x / countCellSize);
                int cy = (int)Math.floor(point.y / countCellSize);
                countTable.getOrCreate(((long)cx << 32) | (cy & 0xffffffffL))
                        .add(ordinal, block.visibilityMasks[ordinal]);
            }
        }

        cellKeys = table.keys;
        cellBuckets = new MaskedCellBucket[table.buckets.length];
        cellMask = cellBuckets.length - 1;
        for (int i = 0; i < table.buckets.length; i++) {
            MutableBucket bucket = table.buckets[i];
            if (bucket != null) {
                cellBuckets[i] = new MaskedCellBucket(
                        Arrays.copyOf(bucket.ordinals, bucket.size),
                        Arrays.copyOf(bucket.masks, bucket.size),
                        block.ownerIds.length,
                        points);
            }
        }
        if (countTable == null) {
            countCellKeys = cellKeys;
            countCellBuckets = cellBuckets;
        } else {
            countCellKeys = countTable.keys;
            countCellBuckets = new MaskedCellBucket[countTable.buckets.length];
            for (int i=0;i<countTable.buckets.length;i++) {
                MutableBucket bucket=countTable.buckets[i];
                if (bucket!=null) countCellBuckets[i]=new MaskedCellBucket(
                        Arrays.copyOf(bucket.ordinals,bucket.size),
                        Arrays.copyOf(bucket.masks,bucket.size),block.ownerIds.length,points);
            }
        }

        // Coarse aliases the still-needed candidate map, so only replace an independent fine map.
        countingLookupOriginalBudget=16L*countCellBuckets.length;
        if(adaptiveCountIndex && countTable!=null){ initializeDenseCountingLookup(); if(denseHeight==0)initializeSparseCountingLookup(); }

        caches = new OwnerCache[block.ownerIds.length];
        for (int slot = 0; slot < caches.length; slot++) caches[slot] = new OwnerCache(points.length);
        anchorOrdinals = new int[block.ownerAnchorOrdinals.length][];
        shardAnchorOrdinals = new int[anchorOrdinals.length][][];
        shardAnchorPieces = new int[anchorOrdinals.length];
        for (int slot = 0; slot < anchorOrdinals.length; slot++) {
            anchorOrdinals[slot] = block.ownerAnchorOrdinals[slot].clone();
            sortOrdinalsById(anchorOrdinals[slot], 0, anchorOrdinals[slot].length - 1);
        }
        preparationNanos = System.nanoTime() - preparationStart;
    }

    private static double safeCountingCellSize(MaskedSharedBlock block, double radius,
            double sourceCell, double qx, double qy) {
        if (!(radius > 0) || !Double.isFinite(radius) || !(sourceCell > 0)
                || !Double.isFinite(sourceCell)) throw new IllegalArgumentException("invalid counting grid");
        double fine=Math.min(sourceCell,radius/4);
        double extent=Math.max(Math.abs(qx),Math.abs(qy));
        for(Point p:block.unionPoints) extent=Math.max(extent,Math.max(Math.abs(p.x),Math.abs(p.y)));
        // Candidate centers can extend one radius beyond input; reserve two radii and rounding slack.
        if (!(fine > 0) || !Double.isFinite(extent)
                || (extent+2*radius+0.005)/fine >= Integer.MAX_VALUE-2.0) return sourceCell;
        return fine;
    }

    public IndexedPoint point(int ordinal) {
        return points[ordinal];
    }

    public int pointCount() {
        return points.length;
    }

    public int[] anchorOrdinals(int slot) {
        return anchorOrdinals[slot];
    }

    synchronized int[] responsibleAnchorOrdinals(int slot, int piece, int pieces) {
        if (piece < 0 || piece >= pieces) {
            throw new IllegalArgumentException("invalid query responsibility");
        }
        int[] anchors = anchorOrdinals[slot];
        if (pieces == 1) return anchors;
        if (shardAnchorPieces[slot] != pieces) {
            int[] assignments = new int[anchors.length];
            int[] counts = new int[pieces];
            for (int i = 0; i < anchors.length; i++) {
                int shard = BudgetedQueryShards.shard(points[anchors[i]].id, pieces);
                assignments[i] = shard;
                counts[shard]++;
            }
            int[][] lanes = new int[pieces][];
            for (int shard = 0; shard < pieces; shard++) lanes[shard] = new int[counts[shard]];
            java.util.Arrays.fill(counts, 0);
            for (int i = 0; i < anchors.length; i++) {
                int shard = assignments[i];
                lanes[shard][counts[shard]++] = anchors[i];
            }
            shardAnchorOrdinals[slot] = lanes;
            shardAnchorPieces[slot] = pieces;
        }
        return shardAnchorOrdinals[slot][piece];
    }

    public int ownerId(int slot) {
        return block.ownerIds[slot];
    }

    public boolean visible(int slot, int ordinal) {
        return ((block.visibilityMasks[ordinal] & 0xff) & (1 << slot)) != 0;
    }

    public int visibleCount(int slot, MaskedCellBucket bucket) {
        return bucket.visibleCounts[slot];
    }

    public IndexedPoint[] visiblePoints(int slot, MaskedCellBucket bucket) {
        return bucket.visiblePoints[slot];
    }

    public OwnerCache cache(int slot) {
        return caches[slot];
    }

    public MaskedCellBucket bucket(long packedCell) {
        int at = hash(packedCell) & cellMask;
        while (cellBuckets[at] != null) {
            if (cellKeys[at] == packedCell) return cellBuckets[at];
            at = (at + 1) & cellMask;
        }
        return null;
    }

    public int bucketCount() {
        int count = 0;
        for (MaskedCellBucket bucket : cellBuckets) if (bucket != null) count++;
        return count;
    }

    public MaskedCellBucket countBucket(long packedCell) {
        if(denseHeight>0){
            long x=(long)(int)(packedCell>>32)-denseMinX,y=(long)(int)packedCell-denseMinY;
            if(x<0||x>=denseWidth||y<0||y>=denseHeight)return null;
            return countCellBuckets[(int)(x*denseHeight+y)];
        }
        if(sparseOffsets!=null){
            long row=(long)(int)(packedCell>>32)-sparseMinX;
            if(row<0||row>=sparseOffsets.length-1)return null;
            int low=sparseOffsets[(int)row],high=sparseOffsets[(int)row+1]-1,y=(int)packedCell;
            while(low<=high){int middle=(low+high)>>>1,v=sparseY[middle];if(v<y)low=middle+1;else if(v>y)high=middle-1;else return countCellBuckets[middle];}
            return null;
        }
        int mask=countCellBuckets.length-1;
        int at=hash(packedCell)&mask;
        while(countCellBuckets[at]!=null) {
            if(countCellKeys[at]==packedCell)return countCellBuckets[at];
            at=(at+1)&mask;
        }
        return null;
    }

    private void initializeDenseCountingLookup(){
        int minX=Integer.MAX_VALUE,minY=Integer.MAX_VALUE,maxX=Integer.MIN_VALUE,maxY=Integer.MIN_VALUE,n=0;
        for(int i=0;i<countCellBuckets.length;i++)if(countCellBuckets[i]!=null){
            int x=(int)(countCellKeys[i]>>32),y=(int)countCellKeys[i];
            minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);n++;
        }
        if(n==0)return;
        long width=(long)maxX-minX+1,height=(long)maxY-minY+1;
        // Conservative8-byte references +40-byte bounds charge, versus old8-byte keys +8-byte refs.
        long allowed=2L*countCellBuckets.length-5;
        if(width>Integer.MAX_VALUE||height>Integer.MAX_VALUE||width>allowed/height)return;
        MaskedCellBucket[] direct=new MaskedCellBucket[(int)(width*height)];
        for(int i=0;i<countCellBuckets.length;i++)if(countCellBuckets[i]!=null){
            long x=(long)(int)(countCellKeys[i]>>32)-minX,y=(long)(int)countCellKeys[i]-minY;
            direct[(int)(x*height+y)]=countCellBuckets[i];
        }
        countCellKeys=new long[0];countCellBuckets=direct;denseMinX=minX;denseMinY=minY;
        denseWidth=(int)width;denseHeight=(int)height;
    }
    private void initializeSparseCountingLookup(){
        int minX=Integer.MAX_VALUE,maxX=Integer.MIN_VALUE,n=0;
        for(int i=0;i<countCellBuckets.length;i++)if(countCellBuckets[i]!=null){int x=(int)(countCellKeys[i]>>32);minX=Math.min(minX,x);maxX=Math.max(maxX,x);n++;}
        if(n==0)return;
        long width=(long)maxX-minX+1;
        if(width>=Integer.MAX_VALUE||4L*(width+1)+12L*n+128>16L*countCellBuckets.length)return;
        long[] ordered=new long[n];int at=0;
        for(int i=0;i<countCellBuckets.length;i++)if(countCellBuckets[i]!=null){long key=countCellKeys[i];ordered[at++]=(key&0xffffffff00000000L)|(((int)key^Integer.MIN_VALUE)&0xffffffffL);}
        Arrays.sort(ordered);int[] offsets=new int[(int)width+1],ys=new int[n];MaskedCellBucket[] buckets=new MaskedCellBucket[n];
        for(int i=0;i<n;i++){int x=(int)(ordered[i]>>32),y=(int)ordered[i]^Integer.MIN_VALUE;offsets[(int)((long)x-minX)+1]++;ys[i]=y;buckets[i]=countBucket(((long)x<<32)|(y&0xffffffffL));}
        for(int i=1;i<offsets.length;i++)offsets[i]+=offsets[i-1];
        countCellKeys=new long[0];countCellBuckets=buckets;sparseMinX=minX;sparseY=ys;sparseOffsets=offsets;
    }
    public boolean sparseCountingLookup(){return sparseOffsets!=null;}
    public String countingLookupMode(){return denseHeight>0?"dense":sparseOffsets!=null?"sparse":"hash";}
    public long countingLookupOriginalBudget(){return countingLookupOriginalBudget;}
    public long countingLookupAccountedBytes(){return denseHeight>0?8L*countCellBuckets.length+40:sparseOffsets!=null?4L*sparseOffsets.length+12L*sparseY.length+128:countingLookupOriginalBudget;}

    public boolean denseCountingLookup(){return denseHeight>0;}

    public int countingBucketCount() {
        int count=0;
        for(MaskedCellBucket bucket:countCellBuckets)if(bucket!=null)count++;
        return count;
    }

    private static int hash(long value) {
        value ^= value >>> 33;
        value *= 0xff51afd7ed558ccdL;
        value ^= value >>> 33;
        value *= 0xc4ceb9fe1a85ec53L;
        value ^= value >>> 33;
        return (int) value;
    }

    private static void sortPointsById(IndexedPoint[] values, int low, int high) {
        while (low < high) {
            int left = low, right = high;
            long pivot = values[(low + high) >>> 1].id;
            while (left <= right) {
                while (Long.compare(values[left].id, pivot) < 0) left++;
                while (Long.compare(values[right].id, pivot) > 0) right--;
                if (left <= right) {
                    IndexedPoint value = values[left]; values[left] = values[right]; values[right] = value;
                    left++; right--;
                }
            }
            if (right - low < high - left) {
                if (low < right) sortPointsById(values, low, right);
                low = left;
            } else {
                if (left < high) sortPointsById(values, left, high);
                high = right;
            }
        }
    }

    private void sortOrdinalsById(int[] values, int low, int high) {
        while (low < high) {
            int left = low, right = high;
            long pivot = points[values[(low + high) >>> 1]].id;
            while (left <= right) {
                while (Long.compare(points[values[left]].id, pivot) < 0) left++;
                while (Long.compare(points[values[right]].id, pivot) > 0) right--;
                if (left <= right) {
                    int value = values[left]; values[left] = values[right]; values[right] = value;
                    left++; right--;
                }
            }
            if (right - low < high - left) {
                if (low < right) sortOrdinalsById(values, low, right);
                low = left;
            } else {
                if (left < high) sortOrdinalsById(values, left, high);
                high = right;
            }
        }
    }
}
