package com;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.LongToIntFunction;
import org.apache.spark.util.LongAccumulator;
import scala.Tuple2;

/** Bounded column batches; each map partition retains exactly the old per-group point order. */
public final class CompactPacketBatches {
    public static final int LIMIT=256;
    public static final class Batch implements Serializable {
        final long[] ids,cells; final double[] xs,ys;
        final int[] owners,masks; final byte[] flags;
        Batch(Buffer b) {
            ids=Arrays.copyOf(b.ids,b.size);cells=Arrays.copyOf(b.cells,b.size);
            xs=Arrays.copyOf(b.xs,b.size);ys=Arrays.copyOf(b.ys,b.size);
            owners=Arrays.copyOf(b.owners,b.size);masks=Arrays.copyOf(b.masks,b.size);flags=Arrays.copyOf(b.flags,b.size);
        }
        public int size(){return ids.length;}
        public int maskAt(int i){return masks[i];}
        public Point pointAt(int i) {
            Point p=new Point(xs[i],ys[i]);p.id=ids[i];p.ownerPartitionId=owners[i];
            p.setCell((int)(cells[i]>>32),(int)cells[i]);
            p.is_core=(flags[i]&1)!=0;p.is_clone=(flags[i]&2)!=0;return p;
        }
    }
    static final class Buffer {
        long[] ids=new long[16],cells=new long[16];double[] xs=new double[16],ys=new double[16];
        int[] owners=new int[16],masks=new int[16];byte[] flags=new byte[16];int size;
        void add(Point p,int owner,int mask) {
            if(size==ids.length) {
                int n=Math.min(LIMIT,size*2);ids=Arrays.copyOf(ids,n);cells=Arrays.copyOf(cells,n);
                xs=Arrays.copyOf(xs,n);ys=Arrays.copyOf(ys,n);owners=Arrays.copyOf(owners,n);
                masks=Arrays.copyOf(masks,n);flags=Arrays.copyOf(flags,n);
            }
            ids[size]=p.id;cells[size]=p.packedCellId;xs[size]=p.x;ys[size]=p.y;
            owners[size]=owner;masks[size]=mask;flags[size]=(byte)((p.is_core?1:0)|(p.is_clone?2:0));size++;
        }
        Batch take(){Batch batch=new Batch(this);size=0;return batch;}
    }
    public static Iterator<Tuple2<Integer,Batch>> route(Iterator<Point> input,NeighborhoodBundles.Routes routes,
            int[] ownerGroups,int[] ownerSlots,int groupCount,LongToIntFunction encodedOwner,LongAccumulator packets) {
        return route(input, routes, ownerGroups, ownerSlots, groupCount, encodedOwner, packets, "deduplicated_union");
    }
    static boolean ownerCopies(String encoding) {
        if ("owner_copies".equals(encoding)) return true;
        if ("deduplicated_union".equals(encoding)) return false;
        throw new IllegalArgumentException("unsupported transport encoding: " + encoding);
    }
    public static Iterator<Tuple2<Integer,Batch>> route(Iterator<Point> input,NeighborhoodBundles.Routes routes,
            int[] ownerGroups,int[] ownerSlots,int groupCount,LongToIntFunction encodedOwner,LongAccumulator packets,
            String encoding) {
        final boolean ownerCopies = ownerCopies(encoding);
        return new Iterator<Tuple2<Integer,Batch>>() {
            final Buffer[] buffers=new Buffer[groupCount];
            Point current;NeighborhoodBundles.Route route;int owner,nextTarget,targetCount,flush;
            int remainingMask;
            Tuple2<Integer,Batch> ready;
            void emit(int group) {
                ready=new Tuple2<>(group,buffers[group].take());
                if(packets!=null)packets.add(1);
            }
            void prepare() {
                if(ready!=null)return;
                while(current!=null || input.hasNext()) {
                    if(current==null) {
                        current=input.next();route=routes.get(current.packedCellId);nextTarget=0;remainingMask=0;
                        if(route==null) {
                            int encoded=encodedOwner.applyAsInt(current.packedCellId);
                            if(encoded>=-1)throw new IllegalStateException("missing boundary cell route");
                            owner=-encoded-2;targetCount=1;
                        } else {owner=route.owner;targetCount=route.groups.length;}
                    }
                    int group=route==null?ownerGroups[owner]:route.groups[nextTarget];
                    int mask=route==null?1<<ownerSlots[owner]:route.masks[nextTarget];
                    if (ownerCopies) {
                        if (remainingMask == 0) remainingMask = mask;
                        mask = Integer.lowestOneBit(remainingMask);
                        remainingMask &= ~mask;
                    }
                    Buffer buffer=buffers[group];if(buffer==null)buffers[group]=buffer=new Buffer();
                    buffer.add(current,owner,mask);
                    if (!ownerCopies || remainingMask == 0) {
                        if (++nextTarget == targetCount) current = null;
                    }
                    if(buffer.size==LIMIT){emit(group);return;}
                }
                while(flush<buffers.length) {
                    int group=flush++;
                    if(buffers[group]!=null && buffers[group].size>0){emit(group);return;}
                }
            }
            public boolean hasNext(){prepare();return ready!=null;}
            public Tuple2<Integer,Batch> next(){prepare();if(ready==null)throw new NoSuchElementException();Tuple2<Integer,Batch> result=ready;ready=null;return result;}
        };
    }
}
