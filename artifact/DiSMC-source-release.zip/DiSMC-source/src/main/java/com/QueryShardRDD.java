package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import org.apache.spark.Dependency;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import scala.Tuple2;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Each child queries disjoint core anchors using the complete cached parent neighbourhood. */
public final class QueryShardRDD extends RDD<HashMap<Double,Circle>> {
    private final RDD<Tuple2<Integer,Point>> parent;
    private final Partition[] children;
    private final double dc,cellSize,qx,qy;
    private final int density;

    private static final class ShardPartition implements Partition {
        final int id,owner,piece,pieces;
        final Partition parentPartition;
        ShardPartition(int id,int owner,int piece,int pieces,Partition parentPartition) {
            this.id=id;this.owner=owner;this.piece=piece;this.pieces=pieces;this.parentPartition=parentPartition;
        }
        public int index(){return id;}
        public boolean org$apache$spark$Partition$$super$equals(Object other){return super.equals(other);}
        public boolean equals(Object other){return other instanceof ShardPartition && ((ShardPartition)other).id==id;}
        public int hashCode(){return id;}
    }
    private static final class ShardDependency extends NarrowDependency<Tuple2<Integer,Point>> {
        private final int[] parentIds;
        ShardDependency(RDD<Tuple2<Integer,Point>> parent,int[] pieces) {
            super(parent);int count=0;for(int n:pieces)count+=n;parentIds=new int[count];
            int j=0;for(int p=0;p<pieces.length;p++)for(int s=0;s<pieces[p];s++)parentIds[j++]=p;
        }
        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(Collections.<Object>singletonList(parentIds[child])).asScala().toSeq();
        }
    }
    private static Seq<Dependency<?>> dependency(RDD<Tuple2<Integer,Point>> parent,int[] pieces) {
        ArrayList<Dependency<?>> result=new ArrayList<Dependency<?>>();result.add(new ShardDependency(parent,pieces));
        return JavaConverters.asScalaBufferConverter(result).asScala().toSeq();
    }
    public QueryShardRDD(JavaPairRDD<Integer,Point> input,int[] pieces,double dc,double cellSize,double qx,double qy,int density) {
        super(input.context(),dependency(input.rdd(),pieces),ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));
        this.parent=input.rdd();this.dc=dc;this.cellSize=cellSize;this.qx=qx;this.qy=qy;this.density=density;
        if(pieces.length!=input.getNumPartitions())throw new IllegalArgumentException("parent partition mismatch");
        int count=0;for(int n:pieces){if(n<1)throw new IllegalArgumentException("empty shard plan");count+=n;}
        children=new Partition[count];int j=0;
        Partition[] originals=parent.partitions();
        for(int p=0;p<pieces.length;p++)for(int s=0;s<pieces[p];s++)
            children[j]=new ShardPartition(j++,p,s,pieces[p],originals[p]);
    }
    public Partition[] getPartitions(){return children;}
    public scala.collection.Iterator<HashMap<Double,Circle>> compute(Partition split,TaskContext context) {
        ShardPartition s=(ShardPartition)split;
        EMCS emcs=new EMCS(dc);emcs.q.x=qx;emcs.q.y=qy;emcs.density_k=density;emcs.part_id=s.owner;emcs.setCellConfig(cellSize);
        scala.collection.Iterator<Tuple2<Integer,Point>> it=parent.iterator(s.parentPartition,context);
        while(it.hasNext()) {
            Point point=it.next()._2();
            if(s.pieces>1) {
                Point copy=new Point(point);
                copy.is_core=point.is_core && BudgetedQueryShards.shard(point.id,s.pieces)==s.piece;
                emcs.plist.add(copy);
            } else emcs.plist.add(point);
        }
        emcs.method(dc);
        return JavaConverters.asScalaIteratorConverter(Collections.singletonList(emcs.skymap).iterator()).asScala();
    }
    public JavaRDD<HashMap<Double,Circle>> asJava() {
        return JavaRDD.fromRDD(this,ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));
    }
}
