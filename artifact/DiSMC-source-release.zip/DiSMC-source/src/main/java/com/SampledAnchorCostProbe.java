package com;

import java.io.Serializable;
import java.util.*;
import org.apache.spark.HashPartitioner;
import org.apache.spark.api.java.*;
import org.apache.spark.broadcast.Broadcast;
import scala.Tuple2;

public final class SampledAnchorCostProbe {
    public static final class Probe implements Serializable {
        public final int owner, samples;
        public final long distanceChecks, kernelNanos;
        public AnchorCostObservation[] observations=new AnchorCostObservation[0];
        public long setupNanos,denseBoundaryBuildNanos,prepareNanos;
        public String inputSnapshotPath="",inputSnapshotHost="";
        public boolean privateLaneCosts;
        public long[] laneInputRecords=new long[0];
        public double[] laneFixedNanos=new double[0];
        public int indexBuilds=1;
        public double countCellSize = Double.NaN;
        public long[] anchorIds = new long[0];
        public long[] counters = new long[10];
        public HashMap<Double,Circle> skyline = new HashMap<>();
        public BoundedProbeCountTrace trace;
        public long generationChecks;
        public ProbePopulationPreparation.OwnerCounts populationCounts;
        public Probe(int owner, int samples, long distanceChecks, long kernelNanos) {
            if (owner < 0 || samples < 1 || distanceChecks < 0 || kernelNanos < 1) throw new IllegalArgumentException("invalid probe");
            this.owner = owner; this.samples = samples; this.distanceChecks = distanceChecks; this.kernelNanos = kernelNanos;
        }
    }
    public static final class Calibration {
        public final double[] work;
        public final double secondsPerWork;
        public final int informativeProbes;
        public final int[] proxyFallbackOwners;
        Calibration(double[] work, double secondsPerWork, int informativeProbes, int[] proxyFallbackOwners) {
            this.work = work; this.secondsPerWork = secondsPerWork;
            this.informativeProbes = informativeProbes; this.proxyFallbackOwners = proxyFallbackOwners.clone();
        }
    }
    public static final class Result {
        public final Calibration calibration;
        public final Probe[] probes;
        public final double wallSeconds;
        public final MicroPartitionPopulation.Statistics population;
        Result(Calibration calibration, Probe[] probes, double wallSeconds) {
            this(calibration,probes,wallSeconds,null);
        }
        Result(Calibration calibration, Probe[] probes, double wallSeconds, MicroPartitionPopulation.Statistics population) {
            this.calibration = calibration; this.probes = probes; this.wallSeconds = wallSeconds; this.population = population;
        }
    }

    public static boolean skewEligible(double[] work, int slots) {
        if (slots < 1 || work.length == 0) throw new IllegalArgumentException("invalid skew dimensions");
        double total = 0, peak = 0;
        for (double value : work) {
            if (!Double.isFinite(value) || value < 0) throw new IllegalArgumentException("invalid work");
            total += value; peak = Math.max(peak,value);
        }
        if (!Double.isFinite(total)) throw new IllegalArgumentException("work sum overflow");
        double average = total / slots;
        if (peak > average) return true;
        // Finite execution waves may have a tail even without a peak above average.
        // Use the same heavy-first task order as execution, not a peak-only test.
        double[] ordered = work.clone(); Arrays.sort(ordered);
        PriorityQueue<Double> loads = new PriorityQueue<>();
        for (int worker = 0; worker < Math.min(slots,work.length); worker++) loads.add(0.0);
        double finish = 0;
        for (int index = ordered.length-1; index >= 0; index--) {
            double end = loads.remove()+ordered[index];
            loads.add(end); finish = Math.max(finish,end);
        }
        // Ignore only summation roundoff, rather than introduce a tuned skew threshold.
        return finish > average + Math.ulp(total)*work.length;
    }

    public static long[] sampleIds(MicroPartitionLayout.Anchor[] anchors, int limit) {
        if (anchors == null || limit < 1) throw new IllegalArgumentException("invalid sample");
        MicroPartitionLayout.Anchor[] ordered = anchors.clone();
        Arrays.sort(ordered,Comparator.<MicroPartitionLayout.Anchor>comparingLong(anchor -> mix(anchor.id)).thenComparingLong(anchor -> anchor.id));
        long[] ids = new long[Math.min(limit,ordered.length)];
        for (int index = 0; index < ids.length; index++) ids[index] = ordered[index].id;
        Arrays.sort(ids); return ids;
    }

    public static Calibration calibrate(double[] proxy, long[] core, Probe[] probes) {
        if (proxy.length != core.length || probes.length == 0) throw new IllegalArgumentException("invalid calibration dimensions");
        double[] ratios = new double[probes.length], seconds = new double[probes.length], raw = new double[probes.length];
        int informative=0;List<Integer> fallback=new ArrayList<>();
        for (int index = 0; index < probes.length; index++) {
            Probe probe = probes[index];
            if (probe.owner >= proxy.length || proxy[probe.owner] <= 0 || core[probe.owner] < probe.samples)
                throw new IllegalArgumentException("invalid probe owner");
            if(probe.distanceChecks==0){fallback.add(probe.owner);continue;}
            raw[index] = (double)probe.distanceChecks * core[probe.owner] / probe.samples;
            ratios[informative] = raw[index] / proxy[probe.owner];
            seconds[informative] = probe.kernelNanos / 1e9 / probe.distanceChecks;
            informative++;
        }
        int[] fallbackOwners=fallback.stream().mapToInt(Integer::intValue).toArray();
        // Whole-bucket counts may perform zero point checks while still doing real work.
        // They cannot define seconds/check; retain the existing proxy rather than fabricate counters.
        if(informative==0)return new Calibration(proxy.clone(),CalibratedShardPlanner.COUNT,0,fallbackOwners);
        double scale = median(Arrays.copyOf(ratios,informative)), secondsPerWork = median(Arrays.copyOf(seconds,informative));
        double[] work = proxy.clone();
        for (int owner = 0; owner < work.length; owner++) work[owner] *= scale;
        for (int index = 0; index < probes.length; index++)if(probes[index].distanceChecks>0)work[probes[index].owner] = raw[index];
        return new Calibration(work,secondsPerWork,informative,fallbackOwners);
    }

    public static MicroPartitionPopulation.Statistics reweight(MicroPartitionPopulation.Statistics source,
            double[] original, double[] adjusted) {
        if (original.length != adjusted.length || source.originalAssigned.length != original.length)
            throw new IllegalArgumentException("invalid reweight dimensions");
        MicroPartitionLayout.Candidate[] candidates = new MicroPartitionLayout.Candidate[source.candidates.length];
        for (int index = 0; index < candidates.length; index++) {
            MicroPartitionLayout.Candidate candidate = source.candidates[index];
            if (original[candidate.owner] <= 0 || adjusted[candidate.owner] <= 0) throw new IllegalArgumentException("invalid owner scale");
            double scale = adjusted[candidate.owner] / original[candidate.owner];
            if(candidate.isSampledPoint()){double[] laneWork=new double[candidate.pieces];for(int l=0;l<laneWork.length;l++)laneWork[l]=candidate.work(l)*scale;candidates[index]=candidate.withPhysicalWork(laneWork);continue;}
            List<MicroPartitionLayout.Anchor> anchors = new ArrayList<>();
            for (int lane = 0; lane < candidate.pieces; lane++) for (MicroPartitionLayout.Anchor anchor : candidate.anchors(lane))
                anchors.add(new MicroPartitionLayout.Anchor(anchor.id,anchor.x,anchor.y,anchor.work*scale));
            candidates[index] = new MicroPartitionLayout.Candidate(candidate.owner,candidate.responsibility,
                    candidate.pieces,anchors.toArray(new MicroPartitionLayout.Anchor[0]),candidate.radius,candidate.splitAxis,
                    candidate.dependencyInputsEnabled);
        }
        MicroPartitionPopulation.Statistics result = new MicroPartitionPopulation.Statistics(
                source.originalAssigned,source.core,candidates,source.dependencyInputs);
        result.sourceRecordsScanned = source.sourceRecordsScanned; result.collectMs = source.collectMs;
        result.populationMs = source.populationMs; result.originalPopulationMs = source.originalPopulationMs;
        result.dependencyPopulationScans = source.dependencyPopulationScans;
        result.populationFromCells = source.populationFromCells;
        result.populationDirect = source.populationDirect;
        result.populationCollectionFused = source.populationCollectionFused;
        result.fallbacks.addAll(source.fallbacks); return result;
    }

    public static Result run(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            MicroPartitionPopulation.Statistics population, double[] proxy, double radius, double cellSize,
            double queryX, double queryY, int density, EngineOptions options, int sampleLimit) {
        return run(context,points,owners,offsetX,offsetY,population,proxy,radius,cellSize,queryX,queryY,density,options,sampleLimit,false);
    }

    public static Result run(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            MicroPartitionPopulation.Statistics population, double[] proxy, double radius, double cellSize,
            double queryX, double queryY, int density, EngineOptions options, int sampleLimit, boolean refinedCounting) {
        return run(context,points,owners,offsetX,offsetY,population,proxy,radius,cellSize,
                queryX,queryY,density,options,sampleLimit,refinedCounting,false);
    }

    public static Result run(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            MicroPartitionPopulation.Statistics population, double[] proxy, double radius, double cellSize,
            double queryX, double queryY, int density, EngineOptions options, int sampleLimit,
            boolean refinedCounting, boolean traceEnabled) {
        return run(context,points,owners,offsetX,offsetY,population,proxy,radius,cellSize,
                queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,false);
    }

    public static Result run(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            MicroPartitionPopulation.Statistics population, double[] proxy, double radius, double cellSize,
            double queryX, double queryY, int density, EngineOptions options, int sampleLimit,
            boolean refinedCounting, boolean traceEnabled, boolean selectedRouting) {
        return runInternal(context,points,owners,offsetX,offsetY,population.candidates,population.core,null,proxy,
                radius,cellSize,queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,selectedRouting);
    }

    public static Result runWithPopulation(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            ProbePopulationPreparation prepared, double[] proxy, double radius, double cellSize,
            double queryX, double queryY, int density, EngineOptions options, int sampleLimit,
            boolean refinedCounting, boolean traceEnabled, boolean selectedRouting) {
        return runInternal(context,points,owners,offsetX,offsetY,prepared.candidates(),prepared.core(),prepared,proxy,
                radius,cellSize,queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,selectedRouting);
    }

    private static Result runInternal(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            MicroPartitionLayout.Candidate[] candidates, long[] core, ProbePopulationPreparation preparation, double[] proxy,
            double radius, double cellSize, double queryX, double queryY, int density, EngineOptions options,
            int sampleLimit, boolean refinedCounting, boolean traceEnabled, boolean selectedRouting) {
        long start = System.nanoTime();
        Map<Integer,MicroPartitionLayout.Anchor[]> anchors = ownerAnchors(candidates);
        int[] selected = anchors.keySet().stream().sorted().mapToInt(Integer::intValue).toArray();
        if (selected.length == 0) throw new IllegalArgumentException("probe requires candidates");
        Map<Integer,long[]> samples = new HashMap<>();
        for (int owner : selected) samples.put(owner,sampleIds(anchors.get(owner),sampleLimit));
        return runSelected(context,points,owners,offsetX,offsetY,selected,samples,core,preparation,proxy,
                radius,cellSize,queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,selectedRouting,start);
    }

    /** Probe selected original owners without collecting their anchor coordinates on the driver. */
    public static Result runForOwners(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            int[] selectedOwners, long[] core, double[] proxy, double radius, double cellSize,
            double queryX, double queryY, int density, EngineOptions options, int sampleLimit,
            boolean refinedCounting, boolean traceEnabled, boolean selectedRouting) {
        long start = System.nanoTime();
        return runForOwners(context,points,owners,offsetX,offsetY,selectedOwners,core,proxy,radius,cellSize,
                queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,selectedRouting,ProbeDominanceFrontier.EMPTY);
    }
    public static Result runForOwners(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            int[] selectedOwners, long[] core, double[] proxy, double radius, double cellSize,
            double queryX, double queryY, int density, EngineOptions options, int sampleLimit,
            boolean refinedCounting, boolean traceEnabled, boolean selectedRouting,ProbeDominanceFrontier frontier) {
        long start=System.nanoTime();
        if (selectedOwners == null || selectedOwners.length == 0 || core == null || proxy == null
                || core.length != proxy.length || sampleLimit < 1) throw new IllegalArgumentException("invalid selected probe owners");
        int[] selected = selectedOwners.clone(); Arrays.sort(selected);
        for (int i = 0; i < selected.length; i++) {
            int owner = selected[i];
            if (owner < 0 || owner >= core.length || core[owner] < 1 || !Double.isFinite(proxy[owner]) || proxy[owner] <= 0
                    || i > 0 && selected[i - 1] == owner) throw new IllegalArgumentException("invalid selected probe owner");
        }
        return runSelected(context,points,owners,offsetX,offsetY,selected,null,core,null,proxy,
                radius,cellSize,queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,selectedRouting,start,frontier);
    }

    /** Measure exactly the discovery anchors under a frozen execution frontier. No new completion. */
    public static Result recalibrate(JavaSparkContext context,JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners,int[] offsetX,int[] offsetY,
            Probe[] discovery,long[] core,double[] proxy,double radius,double cellSize,
            double queryX,double queryY,int density,EngineOptions options,boolean refinedCounting,
            boolean selectedRouting,ProbeDominanceFrontier frontier){
        Map<Integer,long[]> samples=replaySamples(discovery,core);
        if(core.length!=proxy.length||frontier==null)throw new IllegalArgumentException("invalid replay dimensions/frontier");
        int[] selected=samples.keySet().stream().sorted().mapToInt(Integer::intValue).toArray();
        return runSelected(context,points,owners,offsetX,offsetY,selected,samples,core,null,proxy,
                radius,cellSize,queryX,queryY,density,options,1,refinedCounting,false,selectedRouting,
                System.nanoTime(),frontier);
    }
    static Map<Integer,long[]> replaySamples(Probe[] discovery,long[] core){
        if(discovery==null||discovery.length==0||core==null)throw new IllegalArgumentException("missing discovery probes");
        Map<Integer,long[]> samples=new HashMap<>();
        for(Probe p:discovery){
            if(p==null||p.owner<0||p.owner>=core.length||p.samples<1||p.samples>core[p.owner]
                    ||p.anchorIds.length!=p.samples||samples.containsKey(p.owner))
                throw new IllegalArgumentException("invalid replay probe identity");
            long[] ids=p.anchorIds.clone();Arrays.sort(ids);
            for(int i=1;i<ids.length;i++)if(ids[i]==ids[i-1])throw new IllegalArgumentException("duplicate replay anchor");
            samples.put(p.owner,ids);
        }
        return samples;
    }

    public static Result runLaneTargets(JavaSparkContext context,JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners,int[] offsetX,int[] offsetY,
            LaneProbeRefinement.Target[] targets,long[] core,double[] proxy,double radius,double cellSize,
            double queryX,double queryY,int density,EngineOptions options,boolean refinedCounting,
            boolean selectedRouting,ProbeDominanceFrontier frontier){
        if(targets.length==0||core.length!=proxy.length)throw new IllegalArgumentException("invalid lane target dimensions");
        Map<Integer,LaneProbeRefinement.Target> byOwner=new HashMap<>();
        for(LaneProbeRefinement.Target t:targets){int o=t.guide.owner;
            if(o<0||o>=core.length||t.sampleCount()<1||byOwner.put(o,t)!=null||proxy[o]<=0)throw new IllegalArgumentException("invalid lane probe owner");}
        int[] selected=byOwner.keySet().stream().sorted().mapToInt(Integer::intValue).toArray();
        return runSelected(context,points,owners,offsetX,offsetY,selected,null,core,null,proxy,radius,cellSize,
                queryX,queryY,density,options,1,refinedCounting,false,selectedRouting,System.nanoTime(),frontier,byOwner);
    }
    /** Same point-coordinate dependency and private skyline/index state as a formal child task. */
    static Probe evaluateLaneTarget(MaskedSharedBlock complete,LaneProbeRefinement.Target target,
            double radius,double cellSize,double queryX,double queryY,int density,EngineOptions options,
            boolean refinedCounting,boolean adaptiveCountIndex,double countMultiplier,ProbeDominanceFrontier frontier){
        long[] ids=LaneProbeRefinement.selectIds(complete,target);int owner=target.guide.owner;
        List<AnchorCostObservation> observations=new ArrayList<>();TreeMap<Double,Circle> circles=new TreeMap<>();
        long[] counters=new long[10],inputs=new long[target.guide.pieces];double[] fixed=new double[target.guide.pieces];
        long kernel=0,prepare=0,setup=0,dense=0;int builds=0;double countCellSize=Double.NaN;
        for(int lane=0;lane<target.guide.pieces;lane++){
            if(target.quotas[lane]==0)continue;
            List<Point> routed=new ArrayList<>();
            for(Point point:complete.unionPoints)if(MicroPartitionLayout.matches(target.guide,lane,point,target.guide.dependencyInputsEnabled))routed.add(point);
            MaskedSharedBlock block=MicroPartitionExecution.block(owner,target.guide,lane,routed);inputs[lane]=block.unionPoints.length;
            int[] ordinals=Arrays.stream(block.ownerAnchorOrdinals[0])
                    .filter(i -> Arrays.binarySearch(ids,block.unionPoints[i].id)>=0).toArray();
            if(ordinals.length!=target.quotas[lane])throw new IllegalStateException("private lane sample identity mismatch");
            MaskedSharedBlock selected=new MaskedSharedBlock(block.ownerIds,block.unionPoints,block.visibilityMasks,
                    new int[][]{ordinals},block.ownerAssignedCounts,new long[]{ordinals.length},block.ownerSourceCounts);
            long start=System.nanoTime();MaskedPreparedNeighborhood index=new MaskedPreparedNeighborhood(selected,radius,cellSize,
                    queryX,queryY,refinedCounting,adaptiveCountIndex,countMultiplier);long prep=System.nanoTime()-start;
            MaskedLaneQuery.Evaluation evaluation=MaskedLaneQuery.evaluateProfiled(index,0,owner,0,1,radius,cellSize,queryX,queryY,density,options,frontier);
            if(evaluation.anchorObservations.length!=target.quotas[lane])throw new IllegalStateException("private lane observations missing");
            long observed=0;for(AnchorCostObservation a:evaluation.anchorObservations){observations.add(a);observed=Math.addExact(observed,a.kernelNanos);}
            fixed[lane]=prep+(double)evaluation.setupNanos+evaluation.denseBoundaryBuildNanos
                    +Math.max(0,evaluation.kernelNanos-evaluation.setupNanos-observed);
            kernel=Math.addExact(kernel,evaluation.kernelNanos);prepare=Math.addExact(prepare,prep);
            setup=Math.addExact(setup,evaluation.setupNanos);dense=Math.addExact(dense,evaluation.denseBoundaryBuildNanos);
            for(int i=0;i<counters.length;i++)counters[i]=Math.addExact(counters[i],evaluation.counters[i]);
            for(Circle c:evaluation.skyline.values()){
                Circle old=circles.get(c.discenq);
                if(old==null||c.cirnum>old.cirnum||c.cirnum==old.cirnum
                        &&(Double.compare(c.centerX,old.centerX)<0||Double.compare(c.centerX,old.centerX)==0&&Double.compare(c.centerY,old.centerY)<0))circles.put(c.discenq,c);
            }
            builds++;if(builds==1)countCellSize=index.countCellSize;
        }
        Probe result=new Probe(owner,ids.length,counters[4],kernel);result.anchorIds=ids;result.observations=observations.toArray(new AnchorCostObservation[0]);
        result.counters=counters;result.setupNanos=setup;result.prepareNanos=prepare;result.denseBoundaryBuildNanos=dense;result.countCellSize=countCellSize;
        result.privateLaneCosts=true;result.laneInputRecords=inputs;result.laneFixedNanos=fixed;result.indexBuilds=builds;
        int largest=-1;for(Circle c:circles.values())if(c.cirnum>largest){result.skyline.put(c.discenq,c);largest=c.cirnum;}
        return result;
    }

    private static Result runSelected(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            int[] selected, Map<Integer,long[]> samples, long[] core, ProbePopulationPreparation preparation, double[] proxy,
            double radius, double cellSize, double queryX, double queryY, int density, EngineOptions options,
            int sampleLimit, boolean refinedCounting, boolean traceEnabled, boolean selectedRouting, long start) {
        return runSelected(context,points,owners,offsetX,offsetY,selected,samples,core,preparation,proxy,
                radius,cellSize,queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,selectedRouting,start,ProbeDominanceFrontier.EMPTY);
    }
    private static Result runSelected(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            int[] selected, Map<Integer,long[]> samples, long[] core, ProbePopulationPreparation preparation, double[] proxy,
            double radius, double cellSize, double queryX, double queryY, int density, EngineOptions options,
            int sampleLimit, boolean refinedCounting, boolean traceEnabled, boolean selectedRouting, long start,ProbeDominanceFrontier frontier) {
        return runSelected(context,points,owners,offsetX,offsetY,selected,samples,core,preparation,proxy,radius,cellSize,
                queryX,queryY,density,options,sampleLimit,refinedCounting,traceEnabled,selectedRouting,start,frontier,Collections.emptyMap());
    }
    private static Result runSelected(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            int[] selected, Map<Integer,long[]> samples, long[] core, ProbePopulationPreparation preparation, double[] proxy,
            double radius, double cellSize, double queryX, double queryY, int density, EngineOptions options,
            int sampleLimit, boolean refinedCounting, boolean traceEnabled, boolean selectedRouting, long start,ProbeDominanceFrontier frontier,
            Map<Integer,LaneProbeRefinement.Target> targets) {
        int[] ownerToSlot = new int[proxy.length]; Arrays.fill(ownerToSlot,-1);
        for (int slot = 0; slot < selected.length; slot++) ownerToSlot[selected[slot]] = slot;
        final boolean executorSampleSelection = samples == null;
        final boolean spatialCosts=context.getConf().getBoolean("spark.skyline.microSpatialCostCalibration",options.geometricBounds&&!traceEnabled);
        if(spatialCosts&&traceEnabled)throw new IllegalArgumentException("spatial timing calibration cannot use historical count trace");
        if(!targets.isEmpty()&&!spatialCosts)throw new IllegalArgumentException("lane refinement requires profiled spatial timing");
        // Share the formal micro execution's counting layout, including nondefault resolution.
        final boolean adaptiveCountIndex = context.getConf().getBoolean(
                "spark.skyline.experiment.microAdaptiveCountIndex", false);
        final double countMultiplier = context.getConf().getDouble(
                "spark.skyline.experiment.microCountingCellMultiplier", 1.0);
        if (!Double.isFinite(countMultiplier) || countMultiplier <= 0)
            throw new IllegalArgumentException("invalid probe counting multiplier");
        final String snapshotRoot=context.getConf().get("spark.skyline.microProbeSnapshotPath","");
        final Set<Integer> snapshotOwners=new HashSet<>();
        String snapshotSelection=context.getConf().get("spark.skyline.microProbeSnapshotOwners","");
        if(!snapshotRoot.isEmpty()){
            if(snapshotSelection.isEmpty())throw new IllegalArgumentException("snapshot requires explicit owner selection");
            for(String value:snapshotSelection.split(",")){
                int owner=Integer.parseInt(value.trim());
                if(owner<0||owner>=proxy.length)throw new IllegalArgumentException("invalid snapshot owner");
                snapshotOwners.add(owner);
            }
        }
        Broadcast<int[]> slots = context.broadcast(ownerToSlot);
        Broadcast<int[]> selectedOwners = context.broadcast(selected);
        Broadcast<Map<Integer,long[]>> sampledIds = context.broadcast(executorSampleSelection ? Collections.<Integer,long[]>emptyMap() : samples);
        Broadcast<Map<Integer,LaneProbeRefinement.Target>> laneTargets=targets.isEmpty()?null:context.broadcast(new HashMap<>(targets));
        Probe[] probes;
        Broadcast<ProbePopulationPreparation> populationPreparation = preparation == null ? null : context.broadcast(preparation);
        try {
            JavaPairRDD<Integer,CompactPacketBatches.Batch> packets = points.mapPartitionsToPair(input -> {
                List<Tuple2<Integer,CompactPacketBatches.Batch>> kept = new ArrayList<>();
                Iterator<Tuple2<Integer,CompactPacketBatches.Batch>> routed;
                if (selectedRouting) {
                    boolean[] selectedMask = new boolean[proxy.length];
                    for (int owner = 0; owner < selectedMask.length; owner++) selectedMask[owner] = slots.value()[owner] >= 0;
                    routed = DynamicCompactPacketBatches.routeSelected(input,offsetX,offsetY,proxy.length,selectedMask,
                            cell -> owners.value().getEncodedOrDefault(cell,-1), cell -> owners.value().getOrDefault(cell,-1));
                } else routed = MicroPartitionPopulation.route(input,owners.value(),offsetX,offsetY,proxy.length);
                while (routed.hasNext()) {
                    Tuple2<Integer,CompactPacketBatches.Batch> packet = routed.next();
                    int slot = slots.value()[packet._1()];
                    if (slot >= 0) kept.add(new Tuple2<>(slot,packet._2()));
                }
                return kept.iterator();
            });
            List<Probe> observed = packets.partitionBy(new HashPartitioner(selected.length)).mapPartitionsWithIndex((slot,input) -> {
                int owner = selectedOwners.value()[slot]; List<Point> decoded = new ArrayList<>();
                while (input.hasNext()) {
                    Tuple2<Integer,CompactPacketBatches.Batch> packet = input.next();
                    if (packet._1().intValue() != slot.intValue()) throw new IllegalStateException("probe partition mismatch");
                    for (int row = 0; row < packet._2().size(); row++) decoded.add(packet._2().pointAt(row));
                }
                MaskedBlockBuilder builder = new MaskedBlockBuilder(new int[]{owner});
                for (Point point : decoded) builder.add(point,1);
                MaskedSharedBlock complete = builder.build(); long[] ids;
                if(laneTargets!=null){
                    ids=LaneProbeRefinement.selectIds(complete,laneTargets.value().get(owner));
                }else if (executorSampleSelection) {
                    BoundedProbeIds selection = new BoundedProbeIds(sampleLimit);
                    for (int ordinal : complete.ownerAnchorOrdinals[0]) selection.add(complete.unionPoints[ordinal].id);
                    ids = selection.ids();
                    if (ids.length != Math.min((long)sampleLimit,core[owner])) throw new IllegalStateException("probe core population mismatch");
                } else ids = sampledIds.value().get(owner);
                int[] ordinals = new int[ids.length]; int count = 0;
                for (int ordinal = 0; ordinal < complete.unionPoints.length; ordinal++)
                    if (complete.unionPoints[ordinal].ownerPartitionId == owner
                            && Arrays.binarySearch(ids,complete.unionPoints[ordinal].id) >= 0) ordinals[count++] = ordinal;
                if (count != ids.length) throw new IllegalStateException("sampled anchor missing");
                MaskedSharedBlock sampled = new MaskedSharedBlock(complete.ownerIds,complete.unionPoints,complete.visibilityMasks,
                        new int[][]{ordinals},complete.ownerAssignedCounts,new long[]{count},complete.ownerSourceCounts);
                long prepareStart=System.nanoTime();
                MaskedPreparedNeighborhood prepared = laneTargets==null?new MaskedPreparedNeighborhood(sampled,radius,cellSize,queryX,queryY,refinedCounting,adaptiveCountIndex,countMultiplier):null;
                long prepareNanos=System.nanoTime()-prepareStart;
                String snapshotPath="",snapshotHost="";
                if(!snapshotRoot.isEmpty()&&snapshotOwners.contains(owner)){
                    snapshotHost=org.apache.spark.SparkEnv.get().blockManager().blockManagerId().host();
                    java.nio.file.Path directory=java.nio.file.Paths.get(snapshotRoot,snapshotHost);
                    java.nio.file.Files.createDirectories(directory);
                    java.nio.file.Path path=directory.resolve("owner-"+owner+"-attempt-"+org.apache.spark.TaskContext.get().taskAttemptId()+".bin");
                    try(java.io.ObjectOutputStream out=new java.io.ObjectOutputStream(java.nio.file.Files.newOutputStream(path,java.nio.file.StandardOpenOption.CREATE_NEW))){
                        out.writeObject(new Object[]{complete,ids.clone(),frontier,options,
                                new double[]{radius,cellSize,queryX,queryY,countMultiplier},density,refinedCounting,adaptiveCountIndex});
                    }
                    snapshotPath=path.toString();
                }
                Probe result;
                if(laneTargets!=null)result=evaluateLaneTarget(complete,laneTargets.value().get(owner),radius,cellSize,queryX,queryY,
                        density,options,refinedCounting,adaptiveCountIndex,countMultiplier,frontier);
                else if (traceEnabled) result=SampledProbeTrace.evaluate(prepared,
                        owner,radius,cellSize,queryX,queryY,density,options,ids);
                else {
                    MaskedLaneQuery.Evaluation evaluation = spatialCosts
                            ? MaskedLaneQuery.evaluateProfiled(prepared,0,owner,0,1,radius,cellSize,queryX,queryY,density,options,frontier)
                            : MaskedLaneQuery.evaluate(prepared,0,owner,0,1,radius,cellSize,queryX,queryY,density,options,frontier);
                    result = new Probe(owner,count,evaluation.counters[4],evaluation.kernelNanos);
                    result.observations=evaluation.anchorObservations;
                    result.setupNanos=evaluation.setupNanos;result.denseBoundaryBuildNanos=evaluation.denseBoundaryBuildNanos;
                    result.countCellSize = prepared.countCellSize;
                    result.anchorIds = ids.clone(); result.skyline = evaluation.skyline; result.counters = evaluation.counters;
                }
                if(laneTargets==null)result.prepareNanos=prepareNanos;
                result.inputSnapshotPath=snapshotPath;result.inputSnapshotHost=snapshotHost;
                if (populationPreparation != null) result.populationCounts=populationPreparation.value().countOwner(complete,0,owner);
                return Collections.singletonList(result).iterator();
            },true).collect();
            probes = observed.toArray(new Probe[0]);
        } finally {
            slots.destroy(); selectedOwners.destroy(); sampledIds.destroy();
            if(laneTargets!=null)laneTargets.destroy();
            if (populationPreparation != null) populationPreparation.destroy();
        }
        MicroPartitionPopulation.Statistics completed = null;
        if (preparation != null) {
            List<ProbePopulationPreparation.OwnerCounts> counts = new ArrayList<>();
            for (Probe probe : probes) counts.add(probe.populationCounts);
            completed = preparation.complete(counts);
        }
        Calibration calibration=targets.isEmpty()?(spatialCosts?SpatialProbeCostModel.calibrate(proxy,core,probes):calibrate(proxy,core,probes))
                : LaneProbeRefinement.calibrate(proxy,core,targets.values().toArray(new LaneProbeRefinement.Target[0]),probes);
        return new Result(calibration,probes,(System.nanoTime()-start)/1e9,completed);
    }

    /** Remove completed responsibility only; retain every point for pairs and counts. */
    static MaskedSharedBlock remaining(MaskedSharedBlock block, long[] completed) {
        if (completed == null || completed.length == 0) return block;
        int[] ordinals = block.ownerAnchorOrdinals[0];
        int[] kept = new int[ordinals.length]; int count = 0;
        for (int ordinal : ordinals)
            if (Arrays.binarySearch(completed,block.unionPoints[ordinal].id) < 0) kept[count++] = ordinal;
        return new MaskedSharedBlock(block.ownerIds,block.unionPoints,block.visibilityMasks,
                new int[][]{Arrays.copyOf(kept,count)},block.ownerAssignedCounts,
                new long[]{count},block.ownerSourceCounts);
    }

    private static Map<Integer,MicroPartitionLayout.Anchor[]> ownerAnchors(MicroPartitionLayout.Candidate[] candidates) {
        Map<Integer,MicroPartitionLayout.Anchor[]> result = new HashMap<>();
        for (MicroPartitionLayout.Candidate candidate : candidates) if (!result.containsKey(candidate.owner)) {
            List<MicroPartitionLayout.Anchor> anchors = new ArrayList<>();
            for (int lane = 0; lane < candidate.pieces; lane++) Collections.addAll(anchors,candidate.anchors(lane));
            result.put(candidate.owner,anchors.toArray(new MicroPartitionLayout.Anchor[0]));
        }
        return result;
    }

    private static double median(double[] values) {
        double[] ordered = values.clone(); Arrays.sort(ordered);
        int middle = ordered.length/2;
        return ordered.length%2 == 1 ? ordered[middle] : (ordered[middle-1]+ordered[middle])/2;
    }
    private static long mix(long value) {
        value ^= value >>> 33; value *= 0xff51afd7ed558ccdl;
        value ^= value >>> 33; value *= 0xc4ceb9fe1a85ec53l;
        return value ^ value >>> 33;
    }
    private SampledAnchorCostProbe() { }
}
