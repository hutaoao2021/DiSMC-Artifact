package com;
import java.util.*;
/** Experimental execution adapter; caller supplies the original owner's full parent. */
public final class ImplicitBlockBuilder {
 public static MaskedSharedBlock build(int owner,ImplicitResponsibility rule,int lane,List<Point> parent,long[] completed){
  if(owner<0||parent==null||completed==null)throw new IllegalArgumentException("invalid block request");
  Set<Long>done=new HashSet<>();for(long id:completed)if(!done.add(id))throw new IllegalArgumentException("duplicate completion");
  MaskedBlockBuilder builder=new MaskedBlockBuilder(new int[]{owner});Set<Long>ids=new HashSet<>();int expected=0;
  for(Point p:parent){if(!ids.add(p.id))throw new IllegalArgumentException("duplicate parent ID");boolean responsible=p.ownerPartitionId==owner&&(rule==null||rule.laneOf(p.id,p.cellX,p.cellY)==lane);boolean retain=rule==null||rule.retainsCell(lane,p.cellX,p.cellY);if(responsible&&!retain)throw new IllegalStateException("responsible anchor omitted");if(responsible&&!done.contains(p.id))expected++;if(retain)builder.add(p,1);}
  MaskedSharedBlock full=builder.build();int[]ordinals=new int[full.unionPoints.length];int count=0;
  for(int i=0;i<full.unionPoints.length;i++){Point p=full.unionPoints[i];if(p.ownerPartitionId==owner&&!done.contains(p.id)&&(rule==null||rule.laneOf(p.id,p.cellX,p.cellY)==lane))ordinals[count++]=i;}
  if(count!=expected)throw new IllegalStateException("missing original-owner anchor");
  return new MaskedSharedBlock(full.ownerIds,full.unionPoints,full.visibilityMasks,new int[][]{Arrays.copyOf(ordinals,count)},full.ownerAssignedCounts,new long[]{count},full.ownerSourceCounts);
 }
 private ImplicitBlockBuilder(){}
}
