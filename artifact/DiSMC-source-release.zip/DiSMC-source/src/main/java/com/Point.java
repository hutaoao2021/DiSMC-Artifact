package com;

import com.cellhalo.CellId;

import java.io.Serializable;

public class Point implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;
    public double x;
    public double y;
    public String zval;
    public String plowzval;
    public String pupperzval;
    public int pcirnum;
    public boolean is_clone = false;
    public int ownerPartitionId = -1;
    public boolean is_core = false;
    public boolean isCore;
    public boolean isClone;
    public int cellX;
    public int cellY;
    public long packedCellId;

    public Point() {
        this.is_clone = false;
    }

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Point(Point other) {
        if (other != null) {
            this.id = other.id;
            this.x = other.x;
            this.y = other.y;
            this.zval = other.zval;
            this.plowzval = other.plowzval;
            this.pupperzval = other.pupperzval;
            this.pcirnum = other.pcirnum;
            this.is_clone = other.is_clone;
            this.ownerPartitionId = other.ownerPartitionId;
            this.is_core = other.is_core;
            this.isCore = other.isCore;
            this.isClone = other.isClone;
            this.cellX = other.cellX;
            this.cellY = other.cellY;
            this.packedCellId = other.packedCellId;
        }
    }

    public void setCell(CellId cellId) {
        setCell(cellId.x, cellId.y);
    }

    public void setCell(int cellX, int cellY) {
        this.cellX = cellX;
        this.cellY = cellY;
        this.packedCellId = pack(cellX, cellY);
    }

    public Point assignmentCopy(int owner, boolean core) {
        Point copy = new Point(this);
        copy.ownerPartitionId = owner;
        copy.isCore = core;
        copy.isClone = !core;
        copy.is_core = core;
        copy.is_clone = !core;
        copy.pcirnum = 0;
        return copy;
    }

    public static long pack(int cellX, int cellY) {
        return (((long) cellX) << 32) ^ (cellY & 0xffffffffL);
    }

    public double distanceTo(Point p) {
        double dx = x - p.x;
        double dy = y - p.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
