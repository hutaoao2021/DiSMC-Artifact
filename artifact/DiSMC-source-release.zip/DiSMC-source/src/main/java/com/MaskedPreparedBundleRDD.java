package com;

import java.util.Collections;
import org.apache.spark.Dependency;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.LongAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Builds exactly one reusable masked prepared index for each bundle partition. */
public final class MaskedPreparedBundleRDD extends RDD<MaskedPreparedNeighborhood> {
    private static final class PreparedPartition implements Partition {
        final int id;
        final Partition parent;

        PreparedPartition(int id, Partition parent) {
            this.id = id;
            this.parent = parent;
        }

        public int index() { return id; }
        public boolean org$apache$spark$Partition$$super$equals(Object other) {
            return super.equals(other);
        }
        public boolean equals(Object other) {
            return other instanceof PreparedPartition && ((PreparedPartition) other).id == id;
        }
        public int hashCode() { return id; }
    }

    private static final class PreparedDependency extends NarrowDependency<MaskedSharedBlock> {
        PreparedDependency(RDD<MaskedSharedBlock> parent) { super(parent); }

        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(
                    Collections.<Object>singletonList(child)).asScala().toSeq();
        }
    }

    private static Seq<Dependency<?>> dependency(RDD<MaskedSharedBlock> parent) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(
                new PreparedDependency(parent))).asScala().toSeq();
    }

    private final RDD<MaskedSharedBlock> parent;
    private final double dc;
    private final double cellSize;
    private final double qx;
    private final double qy;
    private final LongAccumulator builds;
    private final LongAccumulator buildNanos;
    private final PreparedPartition[] partitions;

    public MaskedPreparedBundleRDD(JavaRDD<MaskedSharedBlock> blocks,
            double dc, double cellSize, double qx, double qy,
            LongAccumulator builds, LongAccumulator buildNanos) {
        super(blocks.context(), dependency(blocks.rdd()),
                ClassTag$.MODULE$.<MaskedPreparedNeighborhood>apply(
                        MaskedPreparedNeighborhood.class));
        if (blocks.getNumPartitions() < 1) {
            throw new IllegalArgumentException("prepared parent has no partitions");
        }
        this.parent = blocks.rdd();
        this.dc = dc;
        this.cellSize = cellSize;
        this.qx = qx;
        this.qy = qy;
        this.builds = builds;
        this.buildNanos = buildNanos;
        Partition[] parents = parent.partitions();
        this.partitions = new PreparedPartition[parents.length];
        for (int i = 0; i < parents.length; i++) {
            this.partitions[i] = new PreparedPartition(i, parents[i]);
        }
    }

    public Partition[] getPartitions() { return partitions; }

    public scala.collection.Iterator<MaskedPreparedNeighborhood> compute(
            Partition split, TaskContext context) {
        PreparedPartition partition = (PreparedPartition) split;
        scala.collection.Iterator<MaskedSharedBlock> input =
                parent.iterator(partition.parent, context);
        if (!input.hasNext()) throw new IllegalStateException("missing masked bundle block");
        MaskedSharedBlock block = input.next();
        if (input.hasNext()) throw new IllegalStateException("multiple masked bundle blocks");
        long start = System.nanoTime();
        MaskedPreparedNeighborhood prepared =
                new MaskedPreparedNeighborhood(block, dc, cellSize, qx, qy);
        builds.add(1L);
        buildNanos.add(System.nanoTime() - start);
        return JavaConverters.asScalaIteratorConverter(
                Collections.singletonList(prepared).iterator()).asScala();
    }

    public JavaRDD<MaskedPreparedNeighborhood> asJava() {
        return JavaRDD.fromRDD(this,
                ClassTag$.MODULE$.<MaskedPreparedNeighborhood>apply(
                        MaskedPreparedNeighborhood.class));
    }
}
