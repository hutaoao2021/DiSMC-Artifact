package com;

import java.io.Serializable;
import java.util.*;
import org.apache.spark.api.java.*;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

/** Complete spatial-operator comparator, independent of DiSMC owner planning. */
public final class SpatialOperatorPipeline {
    private SpatialOperatorPipeline() {}
    static long cell(int x,int y){return ((long)x<<32)^(y&0xffffffffL);}
    static int index(double value,double width){
        double n=Math.floor(value/width);
        if(!Double.isFinite(n)||n<=Integer.MIN_VALUE||n>=Integer.MAX_VALUE)
            throw new IllegalArgumentException("cell outside supported range");
        return (int)n;
    }
    static final class Key implements Serializable {
        final long first,second;
        Key(long a,long b){first=a;second=b;}
        public int hashCode(){return Long.hashCode(first)*31+Long.hashCode(second);}
        public boolean equals(Object o){return o instanceof Key&&first==((Key)o).first&&second==((Key)o).second;}
    }
    static final class Candidate implements Serializable {
        final Key key;final double x,y,distance;final long count;
        Candidate(Key key,Circle circle){this(key,circle.centerX,circle.centerY,circle.discenq,0);}
        Candidate(Key key,double x,double y,double distance,long count){this.key=key;this.x=x;this.y=y;this.distance=distance;this.count=count;}
        Candidate counted(long value){return new Candidate(key,x,y,distance,value);}
        Circle circle(){Circle c=new Circle(x,y);c.discenq=distance;c.cirnum=Math.toIntExact(count);return c;}
    }
    /** Exact geometry DISTINCT pushdown: equal centers have the same coverage, unlike objective ties. */
    static final class GeometryKey implements Serializable {
        final long x,y,distance;
        GeometryKey(Candidate c){x=Double.doubleToLongBits(c.x);y=Double.doubleToLongBits(c.y);distance=Double.doubleToLongBits(c.distance);}
        public int hashCode(){return (Long.hashCode(x)*31+Long.hashCode(y))*31+Long.hashCode(distance);}
        public boolean equals(Object o){if(!(o instanceof GeometryKey))return false;GeometryKey k=(GeometryKey)o;return x==k.x&&y==k.y&&distance==k.distance;}
    }
    static List<Long> cellsFor(double x,double y,double radius,double width){
        int x0=index(Math.nextDown(x-radius),width),x1=index(Math.nextUp(x+radius),width);
        int y0=index(Math.nextDown(y-radius),width),y1=index(Math.nextUp(y+radius),width);
        ArrayList<Long> result=new ArrayList<>();
        for(int cx=x0;cx<=x1;cx++)for(int cy=y0;cy<=y1;cy++)result.add(cell(cx,cy));
        return result;
    }
    static int lower(Point[] points,double x){int lo=0,hi=points.length;while(lo<hi){int mid=(lo+hi)>>>1;if(points[mid].x<x)lo=mid+1;else hi=mid;}return lo;}
    static final class Generation implements Iterator<Candidate> {
        final Iterator<Point> anchors;final MaskedPreparedNeighborhood.IndexedPoint[] neighbors;
        final ReferenceCandidateGeometry geometry;final double radius;
        MaskedPreparedNeighborhood.IndexedPoint anchor;int nextPartner;boolean single;
        Candidate next;
        Generation(Iterable<Point> anchors,Iterable<Point> neighbors,double radius,double qx,double qy){
            this.anchors=anchors.iterator();this.radius=radius;geometry=new ReferenceCandidateGeometry(radius,qx,qy);
            ArrayList<MaskedPreparedNeighborhood.IndexedPoint> points=new ArrayList<>();int ordinal=0;
            for(Point p:neighbors)points.add(geometry.prepare(p,ordinal++));
            this.neighbors=points.toArray(new MaskedPreparedNeighborhood.IndexedPoint[0]);Arrays.sort(this.neighbors,Comparator.comparingDouble(p->p.x));
        }
        public boolean hasNext(){
            if(next!=null)return true;
            while(true){
                if(anchor==null){if(!anchors.hasNext())return false;anchor=geometry.prepare(anchors.next(),0);nextPartner=lower(neighbors,Math.nextDown(anchor.x-2*radius));single=true;}
                if(single){single=false;next=new Candidate(new Key(anchor.id,-1),geometry.singlePrepared(anchor));return true;}
                while(nextPartner<neighbors.length){
                    MaskedPreparedNeighborhood.IndexedPoint partner=neighbors[nextPartner++];
                    if(partner.x>Math.nextUp(anchor.x+2*radius)){nextPartner=neighbors.length;break;}
                    if(anchor.id>=partner.id)continue;
                    Circle circle=geometry.pairPrepared(anchor,partner);
                    if(circle!=null){next=new Candidate(new Key(anchor.id,partner.id),circle);return true;}
                }
                anchor=null;
            }
        }
        public Candidate next(){if(!hasNext())throw new NoSuchElementException();Candidate c=next;next=null;return c;}
    }
    static final class Coverage implements Iterator<Tuple2<Key,Candidate>> {
        final Iterator<Candidate> candidates;final Point[] points;final double radius;
        Coverage(Iterable<Candidate> candidates,Iterable<Point> input,double radius){
            this.candidates=candidates.iterator();this.radius=radius;ArrayList<Point> list=new ArrayList<>();for(Point p:input)list.add(p);
            points=list.toArray(new Point[0]);Arrays.sort(points,Comparator.comparingDouble(p->p.x));
        }
        public boolean hasNext(){return candidates.hasNext();}
        public Tuple2<Key,Candidate> next(){
            Candidate c=candidates.next();double effective=Math.nextDown(radius+0.005),squared=effective*effective;
            int start=lower(points,Math.nextDown(c.x-effective));long count=0;
            for(int i=start;i<points.length&&points[i].x<=Math.nextUp(c.x+effective);i++){
                Point p=points[i];double dx=c.x-p.x,dy=c.y-p.y;if(dx*dx+dy*dy<=squared)count++;
            }
            return new Tuple2<>(c.key,c.counted(count));
        }
    }
    static ArrayList<Circle> frontier(ArrayList<Circle> input,double radius,int density){
        input.sort(Comparator.comparingDouble(c->c.discenq));
        return new ArrayList<>(new EMCSBaseline(radius,density).skylineCircle(input).values());
    }
    public static List<Circle> evaluate(JavaRDD<Point> source,double radius,double qx,double qy,int density,int partitions){
        if(!Double.isFinite(radius)||radius<=0||partitions<1||density<0)throw new IllegalArgumentException("invalid query");
        JavaPairRDD<Long,Point> core=source.mapToPair(p->new Tuple2<>(cell(index(p.x,radius),index(p.y,radius)),p)).persist(StorageLevel.MEMORY_AND_DISK());
        try{
            JavaPairRDD<Long,Point> halo=source.flatMapToPair(p->{ArrayList<Tuple2<Long,Point>> rows=new ArrayList<>();for(long key:cellsFor(p.x,p.y,2*radius,radius))rows.add(new Tuple2<>(key,p));return rows.iterator();});
            JavaRDD<Candidate> generated=core.cogroup(halo,partitions).values().flatMap(group->new Generation(group._1(),group._2(),radius,qx,qy));
            JavaRDD<Candidate> distinct=generated.mapToPair(c->new Tuple2<>(new GeometryKey(c),c))
                    .reduceByKey((a,b)->a.key.first<b.key.first||a.key.first==b.key.first&&a.key.second<=b.key.second?a:b,partitions).values();
            JavaPairRDD<Long,Candidate> routed=distinct.flatMapToPair(c->{ArrayList<Tuple2<Long,Candidate>> rows=new ArrayList<>();for(long key:cellsFor(c.x,c.y,Math.nextUp(radius+0.005),radius))rows.add(new Tuple2<>(key,c));return rows.iterator();});
            JavaPairRDD<Key,Candidate> partial=routed.cogroup(core,partitions).values().flatMapToPair(group->new Coverage(group._1(),group._2(),radius));
            JavaRDD<Candidate> counted=partial.reduceByKey((a,b)->a.counted(Math.addExact(a.count,b.count)),partitions).values().filter(c->c.count>=density);
            List<Circle> locals=counted.mapPartitions(iterator->{ArrayList<Circle> buffer=new ArrayList<>();while(iterator.hasNext()){buffer.add(iterator.next().circle());if(buffer.size()>=4096)buffer=frontier(buffer,radius,density);}return frontier(buffer,radius,density).iterator();}).collect();
            ArrayList<Circle> result=frontier(new ArrayList<>(locals),radius,density);result.sort(Comparator.comparingDouble(c->c.discenq));return result;
        }finally{core.unpersist(false);}
    }
    /** Full source member export, with the same squared-distance membership rule as coverage counting. */
    public static void materializeMembers(JavaSparkContext sc,JavaRDD<Point> source,List<Circle> result,double radius){
        if(result.isEmpty())return;
        Map<Long,List<Integer>> routing=new HashMap<>();
        for(int i=0;i<result.size();i++){Circle c=result.get(i);c.p=new ArrayList<>();for(long key:cellsFor(c.centerX,c.centerY,Math.nextUp(radius+0.005),radius))routing.computeIfAbsent(key,k->new ArrayList<>()).add(i);}
        Broadcast<Map<Long,List<Integer>>> routes=sc.broadcast(routing);Broadcast<List<Circle>> circles=sc.broadcast(result);
        try{
            Map<Integer,ArrayList<Point>> members=source.mapPartitionsToPair(iterator->{Map<Integer,ArrayList<Point>> local=new HashMap<>();Map<Long,List<Integer>> mapping=routes.value();List<Circle> specs=circles.value();
                while(iterator.hasNext()){Point p=iterator.next();List<Integer> ids=mapping.get(cell(index(p.x,radius),index(p.y,radius)));if(ids==null)continue;Point exported=null;for(int id:ids){Circle c=specs.get(id);if(NumericalCoverage.covers(c.centerX,c.centerY,p.x,p.y,radius)){if(exported==null)exported=new Point(p.x,p.y);local.computeIfAbsent(id,k->new ArrayList<>()).add(exported);}}}
                ArrayList<Tuple2<Integer,ArrayList<Point>>> rows=new ArrayList<>();for(Map.Entry<Integer,ArrayList<Point>> e:local.entrySet())rows.add(new Tuple2<>(e.getKey(),e.getValue()));return rows.iterator();
            }).reduceByKey((a,b)->{a.addAll(b);return a;}).collectAsMap();
            for(Map.Entry<Integer,ArrayList<Point>> e:members.entrySet()){result.get(e.getKey()).p=e.getValue();}
        }finally{routes.destroy();circles.destroy();}
    }
}
