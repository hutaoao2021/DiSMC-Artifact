package com;

import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;
import org.apache.spark.TaskContext;

public final class TransportObservation implements Serializable {
    public final int groupId, stageId, stageAttempt, partitionId, attempt;
    public final long taskAttemptId, physicalRecords, unionRecords, decodeNanos, signatureNanos;
    public final String restoredSignature;

    public TransportObservation(int groupId, long physicalRecords, MaskedSharedBlock block, long decodeNanos) {
        TaskContext context = TaskContext.get();
        this.groupId = groupId;
        stageId = context.stageId();
        stageAttempt = context.stageAttemptNumber();
        partitionId = context.partitionId();
        attempt = context.attemptNumber();
        taskAttemptId = context.taskAttemptId();
        this.physicalRecords = physicalRecords;
        unionRecords = block.unionPoints.length;
        this.decodeNanos = decodeNanos;
        long start = System.nanoTime();
        restoredSignature = ExperimentLayouts.blockSignature(block);
        signatureNanos = System.nanoTime() - start;
    }

    public Map<String, Object> metadata() {
        Map<String, Object> result = new TreeMap<String, Object>();
        result.put("group_id", groupId);
        result.put("stage_id", stageId);
        result.put("stage_attempt", stageAttempt);
        result.put("partition_id", partitionId);
        result.put("attempt", attempt);
        result.put("task_attempt_id", taskAttemptId);
        result.put("physical_records", physicalRecords);
        result.put("union_records", unionRecords);
        result.put("decode_ns", decodeNanos);
        result.put("signature_ns", signatureNanos);
        result.put("restored_sha256", restoredSignature);
        return result;
    }
}
