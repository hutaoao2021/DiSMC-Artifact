package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import org.apache.spark.Dependency;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.CollectionAccumulator;
import org.apache.spark.util.LongAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** One masked index build and owner-specific exact queries per bundle. */
public final class MaskedBundleQueryRDD extends RDD<HashMap<Double, Circle>> {
    private static final ThreadLocal<ExecutorService> OWNER_POOL =
            new ThreadLocal<ExecutorService>() {
                protected ExecutorService initialValue() {
                    return Executors.newFixedThreadPool(2, new ThreadFactory() {
                        public Thread newThread(Runnable runnable) {
                            Thread thread = new Thread(runnable, "masked-owner-query");
                            thread.setDaemon(true);
                            return thread;
                        }
                    });
                }
            };
    public static final class ExecutionResult {
        public final List<HashMap<Double, Circle>> maps;
        public final int preparedBuilds;
        ExecutionResult(List<HashMap<Double, Circle>> maps, int preparedBuilds) {
            this.maps = maps; this.preparedBuilds = preparedBuilds;
        }
    }

    private static final class BundlePartition implements Partition {
        final int id;
        final Partition parent;
        BundlePartition(int id, Partition parent) { this.id = id; this.parent = parent; }
        public int index() { return id; }
        public boolean org$apache$spark$Partition$$super$equals(Object other) { return super.equals(other); }
        public boolean equals(Object other) { return other instanceof BundlePartition && ((BundlePartition) other).id == id; }
        public int hashCode() { return id; }
    }

    private static final class BundleDependency extends NarrowDependency<MaskedSharedBlock> {
        BundleDependency(RDD<MaskedSharedBlock> parent) { super(parent); }
        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(
                    Collections.<Object>singletonList(child)).asScala().toSeq();
        }
    }

    private static Seq<Dependency<?>> dependency(RDD<MaskedSharedBlock> parent) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(
                new BundleDependency(parent))).asScala().toSeq();
    }

    private final RDD<MaskedSharedBlock> parent;
    private final BundleQueryLayout layout;
    private final double dc, cellSize, qx, qy;
    private final int density;
    private final LongAccumulator builds, buildNanos, candidates, singlePointCandidates,
            pairCandidates, zChecks, distanceChecks;
    private final LongAccumulator projectedCandidates, projectedCountHits, projectedBoundHits;
    private final LongAccumulator maskChecks, maskFiltered;
    private final CollectionAccumulator<Long> taskTimesMs, bundleTaskTimesMs;
    private final BundlePartition[] partitions;
    private final EngineOptions options;

    public MaskedBundleQueryRDD(JavaRDD<MaskedSharedBlock> blocks, BundleQueryLayout layout,
            double dc, double cellSize, double qx, double qy, int density,
            LongAccumulator builds, LongAccumulator buildNanos,
            LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks, LongAccumulator distanceChecks,
            CollectionAccumulator<Long> taskTimesMs, CollectionAccumulator<Long> bundleTaskTimesMs,
            LongAccumulator projectedCandidates, LongAccumulator projectedCountHits,
            LongAccumulator projectedBoundHits, LongAccumulator maskChecks,
            LongAccumulator maskFiltered) {
        this(blocks, layout, dc, cellSize, qx, qy, density, builds, buildNanos,
                candidates, singlePointCandidates, pairCandidates, zChecks, distanceChecks,
                taskTimesMs, bundleTaskTimesMs,
                projectedCandidates, projectedCountHits, projectedBoundHits,
                maskChecks, maskFiltered, EngineOptions.FULL);
    }

    public MaskedBundleQueryRDD(JavaRDD<MaskedSharedBlock> blocks, BundleQueryLayout layout,
            double dc, double cellSize, double qx, double qy, int density,
            LongAccumulator builds, LongAccumulator buildNanos,
            LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks, LongAccumulator distanceChecks,
            CollectionAccumulator<Long> taskTimesMs, CollectionAccumulator<Long> bundleTaskTimesMs,
            LongAccumulator projectedCandidates, LongAccumulator projectedCountHits,
            LongAccumulator projectedBoundHits, LongAccumulator maskChecks,
            LongAccumulator maskFiltered, EngineOptions options) {
        super(blocks.context(), dependency(blocks.rdd()),
                ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
        if (blocks.getNumPartitions() != layout.taskCount())
            throw new IllegalArgumentException("masked block/task count mismatch");
        this.parent = blocks.rdd(); this.layout = layout; this.dc = dc; this.cellSize = cellSize;
        this.qx = qx; this.qy = qy; this.density = density; this.builds = builds;
        this.buildNanos = buildNanos; this.candidates = candidates; this.zChecks = zChecks;
        this.singlePointCandidates = singlePointCandidates;
        this.pairCandidates = pairCandidates;
        this.distanceChecks = distanceChecks; this.taskTimesMs = taskTimesMs;
        this.bundleTaskTimesMs = bundleTaskTimesMs; this.projectedCandidates = projectedCandidates;
        this.projectedCountHits = projectedCountHits; this.projectedBoundHits = projectedBoundHits;
        this.maskChecks = maskChecks; this.maskFiltered = maskFiltered;
        this.options = options;
        Partition[] parents = parent.partitions();
        partitions = new BundlePartition[layout.taskCount()];
        for (int i = 0; i < partitions.length; i++) partitions[i] = new BundlePartition(i, parents[i]);
    }

    public Partition[] getPartitions() { return partitions; }

    public scala.collection.Iterator<HashMap<Double, Circle>> compute(Partition split, TaskContext context) {
        long taskStart = System.nanoTime();
        BundlePartition bundle = (BundlePartition) split;
        scala.collection.Iterator<MaskedSharedBlock> input = parent.iterator(bundle.parent, context);
        if (!input.hasNext()) throw new IllegalStateException("missing masked bundle block");
        MaskedSharedBlock block = input.next();
        if (input.hasNext()) throw new IllegalStateException("multiple masked bundle blocks");
        long buildStart = System.nanoTime();
        MaskedPreparedNeighborhood prepared =
                new MaskedPreparedNeighborhood(block, dc, cellSize, qx, qy);
        builds.add(1);
        buildNanos.add(System.nanoTime() - buildStart);
        List<HashMap<Double, Circle>> results = execute(
                prepared, layout.task(bundle.id), dc, cellSize, qx, qy, density, true);
        long elapsed = (System.nanoTime() - taskStart) / 1000000L;
        taskTimesMs.add(elapsed);
        bundleTaskTimesMs.add(elapsed);
        return JavaConverters.asScalaIteratorConverter(results.iterator()).asScala();
    }

    private List<HashMap<Double, Circle>> execute(MaskedPreparedNeighborhood prepared,
            BundleQueryLayout.Task task, double dc, double cellSize,
            double qx, double qy, int density, boolean collectMetrics) {
        List<List<BundleQueryExecution.Job>> batches = BundleQueryExecution.ownerBatches(task);
        ArrayList<HashMap<Double, Circle>> output = new ArrayList<HashMap<Double, Circle>>();
        if (batches.size() <= 1) {
            for (BundleQueryExecution.Job job : batches.get(0))
                output.add(executeJob(prepared, job, dc, cellSize, qx, qy, density, collectMetrics));
            return output;
        }
        ExecutorService pool = OWNER_POOL.get();
        try {
            ArrayList<Future<List<HashMap<Double, Circle>>>> futures =
                    new ArrayList<Future<List<HashMap<Double, Circle>>>>();
            for (final List<BundleQueryExecution.Job> batch : batches) {
                futures.add(pool.submit(new Callable<List<HashMap<Double, Circle>>>() {
                    public List<HashMap<Double, Circle>> call() {
                        ArrayList<HashMap<Double, Circle>> ownerResults =
                                new ArrayList<HashMap<Double, Circle>>();
                        for (BundleQueryExecution.Job job : batch)
                            ownerResults.add(executeJob(prepared, job, dc, cellSize, qx, qy, density, collectMetrics));
                        return ownerResults;
                    }
                }));
            }
            for (Future<List<HashMap<Double, Circle>>> future : futures) output.addAll(future.get());
            return output;
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("masked bundle query interrupted", exception);
        } catch (ExecutionException exception) {
            Throwable cause = exception.getCause();
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            throw new RuntimeException("masked bundle query failed", cause);
        }
    }

    private HashMap<Double, Circle> executeJob(MaskedPreparedNeighborhood prepared,
            BundleQueryExecution.Job job, double dc, double cellSize,
            double qx, double qy, int density, boolean collectMetrics) {
        MaskedIndexedEMCS emcs = new MaskedIndexedEMCS(dc);
        emcs.q.x = qx; emcs.q.y = qy; emcs.density_k = density; emcs.part_id = job.owner;
        emcs.setCellConfig(cellSize);
        emcs.usePrepared(prepared, job.slot, job.owner, job.piece, job.pieces, options);
        emcs.method(dc);
        if (collectMetrics) {
            addMetrics(emcs, candidates, singlePointCandidates, pairCandidates,
                    zChecks, distanceChecks,
                    projectedCandidates, projectedCountHits, projectedBoundHits,
                    maskChecks, maskFiltered);
        }
        return emcs.skymap;
    }

    static void addMetrics(MaskedIndexedEMCS emcs,
            LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks,
            LongAccumulator distanceChecks, LongAccumulator projectedCandidates,
            LongAccumulator projectedCountHits, LongAccumulator projectedBoundHits,
            LongAccumulator maskChecks, LongAccumulator maskFiltered) {
        candidates.add(emcs.candidateCount);
        singlePointCandidates.add(emcs.singlePointCandidateCount);
        pairCandidates.add(emcs.pairCandidateCount);
        zChecks.add(emcs.zWindowChecks);
        distanceChecks.add(emcs.pointDistanceChecks);
        projectedCandidates.add(emcs.projectedCandidates);
        projectedCountHits.add(emcs.projectedCountHits);
        projectedBoundHits.add(emcs.projectedBoundHits);
        maskChecks.add(emcs.maskChecks);
        maskFiltered.add(emcs.maskFiltered);
    }

    public JavaRDD<HashMap<Double, Circle>> asJava() {
        return JavaRDD.fromRDD(this, ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
    }

    public static ExecutionResult executeForTest(MaskedSharedBlock block,
            BundleQueryLayout.Task task, double dc, double cellSize,
            double qx, double qy, int density) {
        MaskedPreparedNeighborhood prepared =
                new MaskedPreparedNeighborhood(block, dc, cellSize, qx, qy);
        ArrayList<HashMap<Double, Circle>> maps = new ArrayList<HashMap<Double, Circle>>();
        for (BundleQueryExecution.Job job : BundleQueryExecution.expand(task)) {
            MaskedIndexedEMCS emcs = new MaskedIndexedEMCS(dc);
            emcs.q.x = qx; emcs.q.y = qy; emcs.density_k = density;
            emcs.setCellConfig(cellSize);
            emcs.usePrepared(prepared, job.slot, job.owner, job.piece, job.pieces);
            emcs.method(dc);
            maps.add(emcs.skymap);
        }
        return new ExecutionResult(maps, 1);
    }
}
