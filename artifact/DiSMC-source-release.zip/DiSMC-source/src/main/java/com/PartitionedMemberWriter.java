package com;

import java.io.*;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.*;
import org.apache.spark.broadcast.Broadcast;

/** Stream full memberships on executors; collect only committed-part metadata. */
public final class PartitionedMemberWriter {
    private PartitionedMemberWriter() { }
    public static final class Part implements Serializable {
        public final String host,path,sha256;
        public final long records;
        public final Map<Integer,Long> counts;
        Part(String h,String p,String s,long r,Map<Integer,Long> c) {
            host=h;path=p;sha256=s;records=r;counts=c;
        }
    }
    public static final class Result {
        public final long records;
        public final int parts;
        public final String manifest;
        Result(long r,int p,String m) {records=r;parts=p;manifest=m;}
    }
    public static Result write(JavaSparkContext sc,JavaRDD<Point> points,
            Map<Long,List<double[]>> lookup,double radius,List<Circle> circles,
            String root,String manifestPath) {
        if(root.isEmpty() || !Paths.get(root).isAbsolute())
            throw new IllegalArgumentException("partitioned member output requires absolute executor-local root");
        Path manifest=Paths.get(manifestPath);
        if(Files.exists(manifest))throw new IllegalStateException("member manifest already exists: "+manifest);
        Broadcast<Map<Long,List<double[]>>> index=sc.broadcast(lookup);
        try {
            List<Part> parts=points.mapPartitions(iterator -> {
                String host=org.apache.spark.SparkEnv.get().blockManager().blockManagerId().host();
                TaskContext task=TaskContext.get();
                Path directory=Paths.get(root,host);Files.createDirectories(directory);
                String name="part-"+task.partitionId()+"-stage-"+task.stageId()+"-attempt-"+task.taskAttemptId()+".tsv";
                Path destination=directory.resolve(name),temporary=directory.resolve(name+".tmp");
                MessageDigest hash=MessageDigest.getInstance("SHA-256");
                Map<Integer,Long> counts=new HashMap<>();long records=0;
                try {
                    try(BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(
                            new DigestOutputStream(Files.newOutputStream(temporary,StandardOpenOption.CREATE_NEW),hash),StandardCharsets.UTF_8))) {
                        Map<Long,List<double[]>> cells=index.value();
                        while(iterator.hasNext()) {
                            Point point=iterator.next();List<double[]> specs=cells.get(point.packedCellId);
                            if(specs==null)continue;
                            for(double[] spec:specs) {
                                if(!NumericalCoverage.covers(spec[1],spec[2],point.x,point.y,radius))continue;
                                int circle=(int)spec[0];
                                writer.write(Integer.toString(circle));writer.write('\t');
                                writer.write(Double.toString(point.x));writer.write('\t');
                                writer.write(Double.toString(point.y));writer.write('\n');
                                counts.put(circle,counts.getOrDefault(circle,0L)+1);records++;
                            }
                        }
                    }
                    Files.move(temporary,destination,StandardCopyOption.ATOMIC_MOVE);
                } catch(Exception e) {
                    Files.deleteIfExists(temporary);throw e;
                }
                StringBuilder digest=new StringBuilder();
                for(byte b:hash.digest())digest.append(String.format(Locale.ROOT,"%02x",b&255));
                return Collections.singletonList(new Part(host,destination.toString(),digest.toString(),records,counts)).iterator();
            }).collect(); // O(partitions x result-circle counts), never member records.
            long total=0;long[] counts=new long[circles.size()];
            for(Part part:parts) {
                total+=part.records;
                for(Map.Entry<Integer,Long> entry:part.counts.entrySet())counts[entry.getKey()]+=entry.getValue();
            }
            for(int i=0;i<circles.size();i++)
                if(counts[i]!=circles.get(i).cirnum)throw new IllegalStateException("member count mismatch for circle "+i+": "+counts[i]+" != "+circles.get(i).cirnum);
            if(manifest.getParent()!=null)Files.createDirectories(manifest.getParent());
            try(BufferedWriter writer=Files.newBufferedWriter(manifest,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW)) {
                writer.write("host\tpath\tsha256\trecords\n");
                for(Part part:parts)writer.write(part.host+"\t"+part.path+"\t"+part.sha256+"\t"+part.records+"\n");
            }
            for(Circle circle:circles)circle.p=null;
            return new Result(total,parts.size(),manifest.toString());
        } catch(IOException e) {throw new IllegalStateException("cannot commit member manifest",e);}
        finally {index.destroy();}
    }
}
