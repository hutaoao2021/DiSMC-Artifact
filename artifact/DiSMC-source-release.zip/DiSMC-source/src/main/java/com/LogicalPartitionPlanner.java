package com;

public final class LogicalPartitionPlanner {
    private LogicalPartitionPlanner() {}

    public static ExecutionAwareCuts.Plan plan(String strategy, double[] work, long[] counts,
            int[] minimum, int[] maximum, int partitions) {
        label(strategy);
        if (partitions < 1 || counts.length != work.length || minimum.length != work.length || maximum.length != work.length) {
            throw new IllegalArgumentException("invalid partition dimensions");
        }
        for (int index = 0; index < work.length; index++) {
            if (!Double.isFinite(work[index]) || work[index] <= 0 || counts[index] < 1
                    || minimum[index] < 0 || minimum[index] > index || maximum[index] < index || maximum[index] >= work.length) {
                throw new IllegalArgumentException("invalid partition statistics");
            }
        }
        if (strategy.equals("dependency")) {
            return ExecutionAwareCuts.plan(work, counts, minimum, maximum, partitions);
        }
        double[] weights = work.clone();
        if (strategy.equals("point_count")) {
            for (int index = 0; index < counts.length; index++) weights[index] = counts[index];
        }
        int[] owners = ExecutionAwareCuts.baseline(weights, partitions);
        long boundary = ExecutionAwareCuts.boundaryPoints(owners, counts, minimum, maximum);
        double span = ExecutionAwareCuts.span(owners, counts, minimum, maximum);
        return new ExecutionAwareCuts.Plan(owners, boundary, boundary, span, span, 0);
    }

    public static String label(String strategy) {
        if ("point_count".equals(strategy)) return "point_count_grid";
        if ("workload".equals(strategy)) return "workload_aware_hilbert_grid";
        if ("dependency".equals(strategy)) return "dependency_aware_hilbert_grid";
        throw new IllegalArgumentException("unsupported partition strategy: " + strategy);
    }
}
