package com;

import java.util.*;
import org.apache.spark.HashPartitioner;
import org.apache.spark.Partitioner;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.*;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.apache.spark.util.CollectionAccumulator;
import scala.Tuple2;

public final class MicroPartitionExecution {
    static final class TaskOrderPartitioner extends Partitioner {
        final int[] logicalByPhysical, physicalByLogical;
        TaskOrderPartitioner(double[] costs, String order) {
            if (!order.equals("owner") && !order.equals("cost")) throw new IllegalArgumentException("invalid task order");
            Integer[] tasks = new Integer[costs.length];
            for (int task = 0; task < tasks.length; task++) {
                if (!Double.isFinite(costs[task]) || costs[task] < 0) throw new IllegalArgumentException("invalid task cost");
                tasks[task] = task;
            }
            if (order.equals("cost")) Arrays.sort(tasks, Comparator.<Integer>comparingDouble(task -> -costs[task]).thenComparingInt(task -> task));
            logicalByPhysical = new int[tasks.length]; physicalByLogical = new int[tasks.length];
            for (int rank = 0; rank < tasks.length; rank++) {
                logicalByPhysical[rank] = tasks[rank]; physicalByLogical[tasks[rank]] = rank;
            }
        }
        public int numPartitions() { return logicalByPhysical.length; }
        public int getPartition(Object key) { return physicalByLogical[(Integer)key]; }
        public boolean equals(Object other) {
            return other instanceof TaskOrderPartitioner && Arrays.equals(logicalByPhysical, ((TaskOrderPartitioner)other).logicalByPhysical);
        }
        public int hashCode() { return Arrays.hashCode(logicalByPhysical); }
    }
    public static final class Prepared implements AutoCloseable {
        public final JavaRDD<MaskedSharedBlock> blocks;
        public final MicroPartitionPlanner.Plan plan;
        public final long childInputRecords;
        public final CollectionAccumulator<TransportObservation> transport;
        public final CollectionAccumulator<MicroPartitionObservation> observations;
        private final Broadcast<MicroPartitionPlanner.Plan> broadcast;
        private final int[] logicalByPhysical;
        Prepared(JavaRDD<MaskedSharedBlock> blocks, MicroPartitionPlanner.Plan plan, long records,
                Broadcast<MicroPartitionPlanner.Plan> broadcast, CollectionAccumulator<TransportObservation> transport,
                CollectionAccumulator<MicroPartitionObservation> observations, int[] logicalByPhysical) {
            this.blocks = blocks; this.plan = plan; childInputRecords = records; this.broadcast = broadcast;
            this.transport = transport; this.observations = observations;
            this.logicalByPhysical = logicalByPhysical.clone();
        }
        public void close() { blocks.unpersist(false); broadcast.destroy(); }
    }

    static MaskedSharedBlock block(int owner, MicroPartitionLayout.Candidate candidate, int lane, Iterable<Point> input) {
        MaskedBlockBuilder builder = new MaskedBlockBuilder(new int[]{owner});
        for (Point point : input) builder.add(point, 1);
        MaskedSharedBlock complete = builder.build();
        if (candidate == null) return complete;
        int[] ordinals = new int[complete.unionPoints.length]; int count = 0;
        for (int index = 0; index < complete.unionPoints.length; index++) {
            Point point = complete.unionPoints[index];
            if (point.ownerPartitionId == owner && candidate.laneOf(point) == lane) ordinals[count++] = index;
        }
        if (count != candidate.anchorCount(lane)) throw new IllegalStateException("missing responsible anchor");
        return new MaskedSharedBlock(complete.ownerIds,complete.unionPoints,complete.visibilityMasks,
                new int[][]{Arrays.copyOf(ordinals,count)},complete.ownerAssignedCounts,new long[]{count},complete.ownerSourceCounts);
    }

    static Iterator<Tuple2<Integer,CompactPacketBatches.Batch>> childPackets(
            Iterator<Tuple2<Integer,CompactPacketBatches.Batch>> source, MicroPartitionPlanner.Plan plan) {
        final int tasks = plan.taskCount(); final int[] starts = new int[plan.selected.length]; int next = 0;
        for (int owner = 0; owner < starts.length; owner++) { starts[owner] = next; next += plan.selected[owner] == null ? 1 : plan.selected[owner].pieces; }
        return new Iterator<Tuple2<Integer,CompactPacketBatches.Batch>>() {
            final CompactPacketBatches.Buffer[] buffers = new CompactPacketBatches.Buffer[tasks];
            final Deque<Tuple2<Integer,CompactPacketBatches.Batch>> ready = new ArrayDeque<>();
            boolean finished;
            void emit(int task) { ready.add(new Tuple2<>(task,buffers[task].take())); }
            void fill() {
                while (ready.isEmpty() && !finished) {
                    if (!source.hasNext()) {
                        finished = true;
                        for (int task = 0; task < tasks; task++) if (buffers[task] != null && buffers[task].size > 0) emit(task);
                        break;
                    }
                    Tuple2<Integer,CompactPacketBatches.Batch> packet = source.next(); int owner = packet._1();
                    MicroPartitionLayout.Candidate candidate = plan.selected[owner]; int pieces = candidate == null ? 1 : candidate.pieces;
                    for (int row = 0; row < packet._2().size(); row++) {
                        Point point = packet._2().pointAt(row);
                        for (int lane = 0; lane < pieces; lane++) {
                            if (candidate != null && !MicroPartitionLayout.matches(candidate,lane,point,plan.mode.equals("dependency"))) continue;
                            int task = starts[owner] + lane;
                            if (buffers[task] == null) buffers[task] = new CompactPacketBatches.Buffer();
                            buffers[task].add(point,point.ownerPartitionId,1);
                            if (buffers[task].size == CompactPacketBatches.LIMIT) emit(task);
                        }
                    }
                }
            }
            public boolean hasNext() { fill(); return !ready.isEmpty(); }
            public Tuple2<Integer,CompactPacketBatches.Batch> next() {
                if (!hasNext()) throw new NoSuchElementException(); return ready.remove();
            }
        };
    }

    public static Prepared prepare(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            MicroPartitionPlanner.Plan plan) {
        return prepare(context,points,owners,offsetX,offsetY,plan,"owner");
    }

    public static Prepared prepare(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            MicroPartitionPlanner.Plan plan, String order) {
        TaskOrderPartitioner ordering = new TaskOrderPartitioner(plan.work(),order);
        final int[] logicalByPhysical = ordering.logicalByPhysical.clone();
        Broadcast<MicroPartitionPlanner.Plan> description = context.broadcast(plan);
        CollectionAccumulator<TransportObservation> transport = context.sc().collectionAccumulator("micro_transport");
        CollectionAccumulator<MicroPartitionObservation> observations = context.sc().collectionAccumulator("micro_tasks");
        JavaPairRDD<Integer,CompactPacketBatches.Batch> packets = points.mapPartitionsToPair(input ->
                childPackets(MicroPartitionPopulation.route(input,owners.value(),offsetX,offsetY,description.value().selected.length),description.value()));
        JavaRDD<MaskedSharedBlock> blocks = packets.partitionBy(order.equals("owner") ? new HashPartitioner(plan.taskCount()) : ordering).mapPartitionsWithIndex((task,input) -> {
            long start = System.nanoTime(), records = 0; MicroPartitionPlanner.Plan local = description.value();
            int logicalTask = logicalByPhysical[task];
            List<Point> decoded = new ArrayList<>();
            while (input.hasNext()) {
                Tuple2<Integer,CompactPacketBatches.Batch> packet = input.next();
                if (packet._1().intValue() != logicalTask) throw new IllegalStateException("task partition mismatch");
                for (int row = 0; row < packet._2().size(); row++) decoded.add(packet._2().pointAt(row));
                records = Math.addExact(records,packet._2().size());
            }
            int owner = local.owner(logicalTask), lane = local.lane(logicalTask);
            MaskedSharedBlock block = block(owner,local.selected[owner],lane,decoded);
            if (block.unionPoints.length != local.taskInputs[owner][lane]) throw new IllegalStateException("planned/actual child population mismatch");
            transport.add(new TransportObservation(task,records,block,System.nanoTime()-start));
            return Collections.singletonList(block).iterator();
        },false).persist(StorageLevel.MEMORY_AND_DISK());
        try {
            long count = 0; for (Long records : blocks.map(block -> (long)block.unionPoints.length).collect()) count = Math.addExact(count,records);
            return new Prepared(blocks,plan,count,description,transport,observations,logicalByPhysical);
        } catch (RuntimeException error) { blocks.unpersist(false); description.destroy(); throw error; }
    }

    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared, double radius, double cellSize,
            double qx, double qy, int density, EngineOptions options, MaskedLaneQuery.Metrics metrics) {
        return query(prepared,radius,cellSize,qx,qy,density,options,metrics,Collections.emptyMap());
    }

    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared, double radius, double cellSize,
            double qx, double qy, int density, EngineOptions options, MaskedLaneQuery.Metrics metrics,
            Map<Integer,long[]> completedAnchors) {
        return query(prepared,radius,cellSize,qx,qy,density,options,metrics,completedAnchors,false);
    }

    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared, double radius, double cellSize,
            double qx, double qy, int density, EngineOptions options, MaskedLaneQuery.Metrics metrics,
            Map<Integer,long[]> completedAnchors, boolean refinedCounting) {
        return query(prepared,radius,cellSize,qx,qy,density,options,metrics,completedAnchors,refinedCounting,ProbeDominanceFrontier.EMPTY);
    }

    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared, double radius, double cellSize,
            double qx, double qy, int density, EngineOptions options, MaskedLaneQuery.Metrics metrics,
            Map<Integer,long[]> completedAnchors, boolean refinedCounting, ProbeDominanceFrontier frontier) {
        return query(prepared,radius,cellSize,qx,qy,density,options,metrics,completedAnchors,refinedCounting,frontier,false);
    }

    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared, double radius, double cellSize,
            double qx, double qy, int density, EngineOptions options, MaskedLaneQuery.Metrics metrics,
            Map<Integer,long[]> completedAnchors, boolean refinedCounting, ProbeDominanceFrontier frontier,
            boolean probeAnchorBounds) {
        return query(prepared,radius,cellSize,qx,qy,density,options,metrics,completedAnchors,refinedCounting,frontier,probeAnchorBounds,false);
    }

    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared, double radius, double cellSize,
            double qx, double qy, int density, EngineOptions options, MaskedLaneQuery.Metrics metrics,
            Map<Integer,long[]> completedAnchors, boolean refinedCounting, ProbeDominanceFrontier frontier,
            boolean probeAnchorBounds, boolean coarseAnchorBounds) {
        return query(prepared,radius,cellSize,qx,qy,density,options,metrics,completedAnchors,refinedCounting,frontier,probeAnchorBounds,coarseAnchorBounds,false);
    }
    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared,double radius,double cellSize,
            double qx,double qy,int density,EngineOptions options,MaskedLaneQuery.Metrics metrics,
            Map<Integer,long[]> completedAnchors,boolean refinedCounting,ProbeDominanceFrontier frontier,
            boolean probeAnchorBounds,boolean coarseAnchorBounds,boolean adaptiveCountIndex) {
        return query(prepared,radius,cellSize,qx,qy,density,options,metrics,completedAnchors,refinedCounting,frontier,probeAnchorBounds,coarseAnchorBounds,adaptiveCountIndex,1.0);
    }
    public static JavaRDD<HashMap<Double,Circle>> query(Prepared prepared,double radius,double cellSize,
            double qx,double qy,int density,EngineOptions options,MaskedLaneQuery.Metrics metrics,
            Map<Integer,long[]> completedAnchors,boolean refinedCounting,ProbeDominanceFrontier frontier,
            boolean probeAnchorBounds,boolean coarseAnchorBounds,boolean adaptiveCountIndex,double countMultiplier) {
        if(adaptiveCountIndex && (!refinedCounting || options.spatialCountTree))throw new IllegalArgumentException("unsupported adaptive counting combination");
        if(frontier==null)throw new IllegalArgumentException("missing probe frontier");
        final Broadcast<MicroPartitionPlanner.Plan> description = prepared.broadcast;
        final CollectionAccumulator<MicroPartitionObservation> observations = prepared.observations;
        final int[] logicalByPhysical = prepared.logicalByPhysical.clone();
        return prepared.blocks.mapPartitionsWithIndex((task,input) -> {
            long start = System.nanoTime();
            if (!input.hasNext()) throw new IllegalStateException("missing micro block");
            MaskedSharedBlock block = input.next(); if (input.hasNext()) throw new IllegalStateException("multiple micro blocks");
            block = SampledAnchorCostProbe.remaining(block,completedAnchors.get(block.ownerIds[0]));
            long access = System.nanoTime()-start, prepareStart = System.nanoTime();
            MaskedPreparedNeighborhood index = new MaskedPreparedNeighborhood(block,radius,cellSize,qx,qy,refinedCounting,adaptiveCountIndex,countMultiplier);
            long prepareNanos = System.nanoTime()-prepareStart; MicroPartitionPlanner.Plan local = description.value();
            int owner = local.owner(logicalByPhysical[task]), lane = local.lane(logicalByPhysical[task]);
            MaskedLaneQuery.Evaluation result = MaskedLaneQuery.evaluate(index,0,owner,0,1,radius,cellSize,qx,qy,density,options,frontier,probeAnchorBounds,coarseAnchorBounds);
            if (metrics != null) metrics.add(result);
            observations.add(new MicroPartitionObservation(task,owner,lane,block,access,prepareNanos,result,System.nanoTime()-start,index));
            return Collections.singletonList(result.skyline).iterator();
        },false);
    }
    private MicroPartitionExecution() { }
}
