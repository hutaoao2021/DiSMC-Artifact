package com;

final class BaselinePointOrder {
    private BaselinePointOrder() {
    }

    static long roundedCoordinate(double value) {
        double rounded = Math.floor(value + 0.5d);
        if (!Double.isFinite(rounded) || rounded < 0 || rounded > Long.MAX_VALUE) {
            throw new IllegalArgumentException("coordinate is outside baseline Z-order range: " + value);
        }
        return (long) rounded;
    }

    static int compare(long leftX, long leftY, long leftId,
            long rightX, long rightY, long rightId) {
        long differingX = leftX ^ rightX;
        long differingY = leftY ^ rightY;
        if (differingX != 0 || differingY != 0) {
            int xBit = differingX == 0 ? -1 : 63 - Long.numberOfLeadingZeros(differingX);
            int yBit = differingY == 0 ? -1 : 63 - Long.numberOfLeadingZeros(differingY);
            if (xBit >= yBit) {
                return ((leftX >>> xBit) & 1L) == 0L ? -1 : 1;
            }
            return ((leftY >>> yBit) & 1L) == 0L ? -1 : 1;
        }
        return Long.compare(leftId, rightId);
    }
}
