package com;
import java.io.Serializable;
import java.util.*;
/** Bounded samples choose point-coordinate cuts; full input determines populations and envelopes. */
public final class SampledPointRule implements Serializable {
 private static final class Node implements Serializable {int axis,leaf;MicroPartitionLayout.Anchor pivot;Node left,right;}
 private final Node root;public final int pieces;
 private SampledPointRule(MicroPartitionLayout.Anchor[] sample,int pieces,int axis){this.pieces=pieces;root=split(sample.clone(),0,pieces,axis);}
 public static SampledPointRule build(MicroPartitionLayout.Anchor[] sample,int pieces,int axis){
  if(sample==null||sample.length<pieces||(pieces<2||pieces>64||(pieces&(pieces-1))!=0)||axis< -1||axis>1||axis>=0&&pieces!=2)throw new IllegalArgumentException("invalid sampled point split");
  return new SampledPointRule(sample,pieces,axis);
 }
 private static int compare(double x,double y,long id,MicroPartitionLayout.Anchor p,int axis){int c=Double.compare(axis==0?x:y,axis==0?p.x:p.y);if(c==0)c=Double.compare(axis==0?y:x,axis==0?p.y:p.x);if(c==0)c=Long.compare(id,p.id);return c;}
 private static Node split(MicroPartitionLayout.Anchor[] a,int start,int n,int forced){Node node=new Node();if(n==1){node.leaf=start;return node;}
  double minX=Double.POSITIVE_INFINITY,minY=minX,maxX=Double.NEGATIVE_INFINITY,maxY=maxX;
  for(MicroPartitionLayout.Anchor p:a){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}
  final int axis=forced>=0?forced:maxX-minX>=maxY-minY?0:1;node.axis=axis;
  Arrays.sort(a,(u,v)->compare(u.x,u.y,u.id,v,axis));int middle=a.length/2;node.pivot=a[middle];
  node.left=split(Arrays.copyOfRange(a,0,middle),start,n/2,forced);node.right=split(Arrays.copyOfRange(a,middle,a.length),start+n/2,n/2,forced);return node;
 }
 public int lane(long id,double x,double y){Node n=root;while(n.pivot!=null)n=compare(x,y,id,n.pivot,n.axis)<0?n.left:n.right;return n.leaf;}
 private static void signature(Node n,StringBuilder s){if(n.pivot==null){s.append("L").append(n.leaf);return;}s.append("N").append(n.axis).append(':').append(Double.toHexString(n.pivot.x)).append(':').append(Double.toHexString(n.pivot.y)).append(':').append(n.pivot.id).append('(');signature(n.left,s);s.append(',');signature(n.right,s);s.append(')');}
 public String signature(){StringBuilder s=new StringBuilder("sampled-point-v1:");signature(root,s);return s.toString();}
}
