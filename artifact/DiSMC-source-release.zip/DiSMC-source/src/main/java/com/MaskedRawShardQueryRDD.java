package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import org.apache.spark.Dependency;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.CollectionAccumulator;
import org.apache.spark.util.LongAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

public final class MaskedRawShardQueryRDD extends RDD<HashMap<Double, Circle>> {
    private static final class RawPartition implements Partition {
        final int id;
        final Partition parent;

        RawPartition(int id, Partition parent) {
            this.id = id;
            this.parent = parent;
        }

        public int index() { return id; }
        public boolean org$apache$spark$Partition$$super$equals(Object other) { return super.equals(other); }
        public boolean equals(Object other) { return other instanceof RawPartition && ((RawPartition) other).id == id; }
        public int hashCode() { return id; }
    }

    private static final class RawDependency extends NarrowDependency<MaskedSharedBlock> {
        final BundleShardLayout layout;

        RawDependency(RDD<MaskedSharedBlock> parent, BundleShardLayout layout) {
            super(parent);
            this.layout = layout;
        }

        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(Collections.<Object>singletonList(layout.parentGroup(child))).asScala().toSeq();
        }
    }

    private static Seq<Dependency<?>> dependency(RDD<MaskedSharedBlock> parent, BundleShardLayout layout) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(new RawDependency(parent, layout))).asScala().toSeq();
    }

    private final RDD<MaskedSharedBlock> parent;
    private final BundleShardLayout layout;
    private final RawPartition[] partitions;
    private final double radius, cellSize, queryX, queryY;
    private final int density;
    private final LongAccumulator builds, buildNanos, reads;
    private final CollectionAccumulator<Long> taskTimes, bundleTimes;
    private final MaskedLaneQuery.Metrics metrics;
    private final EngineOptions options;
    private final TaskObservation.Collector observer;

    public MaskedRawShardQueryRDD(JavaRDD<MaskedSharedBlock> blocks, BundleShardLayout layout,
            double radius, double cellSize, double queryX, double queryY, int density,
            LongAccumulator builds, LongAccumulator buildNanos, LongAccumulator reads,
            CollectionAccumulator<Long> taskTimes, CollectionAccumulator<Long> bundleTimes,
            MaskedLaneQuery.Metrics metrics, EngineOptions options) {
        this(blocks, layout, radius, cellSize, queryX, queryY, density, builds, buildNanos,
                reads, taskTimes, bundleTimes, metrics, options, null);
    }

    public MaskedRawShardQueryRDD(JavaRDD<MaskedSharedBlock> blocks, BundleShardLayout layout,
            double radius, double cellSize, double queryX, double queryY, int density,
            LongAccumulator builds, LongAccumulator buildNanos, LongAccumulator reads,
            CollectionAccumulator<Long> taskTimes, CollectionAccumulator<Long> bundleTimes,
            MaskedLaneQuery.Metrics metrics, EngineOptions options, TaskObservation.Collector observer) {
        super(blocks.context(), dependency(blocks.rdd(), layout), ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
        if (blocks.getNumPartitions() != layout.groupCount()) throw new IllegalArgumentException("raw parent/group count mismatch");
        this.parent = blocks.rdd();
        this.layout = layout;
        this.radius = radius;
        this.cellSize = cellSize;
        this.queryX = queryX;
        this.queryY = queryY;
        this.density = density;
        this.builds = builds;
        this.buildNanos = buildNanos;
        this.reads = reads;
        this.taskTimes = taskTimes;
        this.bundleTimes = bundleTimes;
        this.metrics = metrics;
        this.options = options;
        this.observer = observer;
        Partition[] parents = parent.partitions();
        partitions = new RawPartition[layout.taskCount()];
        for (int child = 0; child < partitions.length; child++) partitions[child] = new RawPartition(child, parents[layout.parentGroup(child)]);
    }

    public Partition[] getPartitions() { return partitions; }

    public scala.collection.Iterator<HashMap<Double, Circle>> compute(Partition split, TaskContext context) {
        long start = System.nanoTime();
        RawPartition partition = (RawPartition) split;
        scala.collection.Iterator<MaskedSharedBlock> input = parent.iterator(partition.parent, context);
        if (!input.hasNext()) throw new IllegalStateException("missing masked bundle block");
        MaskedSharedBlock block = input.next();
        if (input.hasNext()) throw new IllegalStateException("multiple masked bundle blocks");
        long accessNanos = System.nanoTime() - start;
        reads.add(1);
        BundleShardLayout.Task task = layout.task(partition.id);
        ArrayList<HashMap<Double, Circle>> results = new ArrayList<HashMap<Double, Circle>>(task.owners.length);
        long prepareNanos = 0, kernelNanos = 0, preparedRecords = 0;
        long[] observedCounters = new long[10];
        for (int lane = 0; lane < task.owners.length; lane++) {
            long prepareStart = System.nanoTime();
            MaskedSharedBlock view = MaskedOwnerViews.singleOwner(block, task.slots[lane]);
            MaskedPreparedNeighborhood prepared = new MaskedPreparedNeighborhood(view, radius, cellSize, queryX, queryY);
            builds.add(1);
            long prepareElapsed = System.nanoTime() - prepareStart;
            buildNanos.add(prepareElapsed);
            prepareNanos = Math.addExact(prepareNanos, prepareElapsed);
            preparedRecords = Math.addExact(preparedRecords, view.unionPoints.length);
            MaskedLaneQuery.Evaluation evaluation = MaskedLaneQuery.evaluate(prepared, 0, task.owners[lane],
                    task.round, task.pieces[lane], radius, cellSize, queryX, queryY, density, options);
            metrics.add(evaluation);
            results.add(evaluation.skyline);
            kernelNanos = Math.addExact(kernelNanos, evaluation.kernelNanos);
            for (int index = 0; index < observedCounters.length; index++) observedCounters[index] = Math.addExact(observedCounters[index], evaluation.counters[index]);
        }
        if (observer != null) observer.record(context, task, accessNanos, prepareNanos, kernelNanos,
                System.nanoTime() - start, block.unionPoints.length, preparedRecords, task.owners.length, observedCounters);
        long elapsed = (System.nanoTime() - start) / 1000000;
        taskTimes.add(elapsed);
        bundleTimes.add(elapsed);
        return JavaConverters.asScalaIteratorConverter(results.iterator()).asScala();
    }

    public JavaRDD<HashMap<Double, Circle>> asJava() {
        return JavaRDD.fromRDD(this, ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
    }
}
