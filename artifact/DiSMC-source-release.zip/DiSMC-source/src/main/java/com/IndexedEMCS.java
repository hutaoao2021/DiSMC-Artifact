package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class IndexedEMCS {
    private static final int LOCAL_SKYLINE_BATCH_SIZE = 4096;

    Point q = new Point(100, 101);
    double dc = 0;
    double dc2 = 0;
    double twoDc = 0;
    double twoDc2 = 0;
    int density_k = 0;
    int part_id = 0;
    double cellSize = 1.0;

    public ArrayList<Circle> circles = new ArrayList<Circle>();
    public ArrayList<Point> plist = new ArrayList<Point>();
    HashMap<Double, Circle> skymap = new HashMap<Double, Circle>();
    private double[] skylineDistances = new double[0];
    private int[] skylineCounts = new int[0];
    private PreparedNeighborhood.CellBucket[] countBuckets = new PreparedNeighborhood.CellBucket[64];


    public IndexedEMCS(double dc) {
        this.dc = dc;
        this.dc2 = dc * dc;
        this.twoDc = 2 * dc;
        this.twoDc2 = 4 * dc * dc;
    }

    public void setCellConfig(double cellSize) {
        this.cellSize = cellSize;
    }

    private PreparedNeighborhood.View prepared;
    private int queryPiece,queryPieces;
    private int projectedOrdinal=-1;
    long candidateCount,singlePointCandidateCount,pairCandidateCount,zWindowChecks,pointDistanceChecks;
    long projectedCandidates,projectedCountHits,projectedBoundHits;
    private int lastCountUpperBound=-1;
    public void usePrepared(PreparedNeighborhood.View view,int piece,int pieces) {
        if(piece<0||piece>=pieces)throw new IllegalArgumentException("invalid query responsibility");
        prepared=view;queryPiece=piece;queryPieces=pieces;
        plist=new ArrayList<Point>(java.util.Arrays.asList(view.points));
    }
    private PreparedNeighborhood.CellBucket bucketAt(long key) { return prepared.bucket(key); }
    private double queryDistance(Point p) { return ((PreparedNeighborhood.IndexedPoint)p).queryDistance; }

    public void method(double dc) {
        if (prepared == null) throw new IllegalStateException("prepared index required");
        for (int i = 0; i < plist.size(); i++) {
            Point p1 = plist.get(i);
            if (p1.ownerPartitionId != this.part_id || (queryPieces > 1
                    && BudgetedQueryShards.shard(p1.id, queryPieces) != queryPiece)) {
                continue;
            }

            Circle anchorCircle = buildAnchorCircle(p1);
            // Use actual candidate centers before applying anchor upper bounds.

            int p1AnchorUpperBound = anchorCircle.cirnum;
            PreparedNeighborhood.IndexedPoint indexedAnchor = (PreparedNeighborhood.IndexedPoint) p1;
            Circle singlePointCandidate = buildSinglePointCircle(indexedAnchor);
            candidateCount++;
            singlePointCandidateCount++;
            int singleRequiredCount = minimumRequiredCount(singlePointCandidate.discenq);
            if (p1AnchorUpperBound >= singleRequiredCount || !anchorContains(p1,singlePointCandidate.centerX,singlePointCandidate.centerY)) {
                int singlePointCount = countProjectedCircle(indexedAnchor, singleRequiredCount);
                if (singlePointCount >= singleRequiredCount && singlePointCount >= density_k) {
                    singlePointCandidate.cirnum = singlePointCount;
                    circles.add(singlePointCandidate);
                    if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) flushCandidateCircles();
                }
            }
            int minCellX = (int) Math.floor((p1.x - twoDc) / cellSize);
            int maxCellX = (int) Math.floor((p1.x + twoDc) / cellSize);
            int minCellY = (int) Math.floor((p1.y - twoDc) / cellSize);
            int maxCellY = (int) Math.floor((p1.y + twoDc) / cellSize);

            for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
                for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                    PreparedNeighborhood.CellBucket bucket = bucketAt(pack(cellX, cellY));
                    if (bucket == null) {
                        continue;
                    }

                    for (Point p2 : bucket.points) {
                        if (p1.id >= p2.id) {
                            continue;
                        }

                        pointDistanceChecks++;
                        double d12Squared = squaredDistance(p1.x, p1.y, p2.x, p2.y);
                        if (d12Squared <= 0 || d12Squared > twoDc2) {
                            continue;
                        }

                        PreparedNeighborhood.IndexedPoint first = (PreparedNeighborhood.IndexedPoint) p1;
                        PreparedNeighborhood.IndexedPoint second = (PreparedNeighborhood.IndexedPoint) p2;
                        if (BaselinePointOrder.compare(
                                first.baselineOrderX, first.baselineOrderY, first.id,
                                second.baselineOrderX, second.baselineOrderY, second.id) > 0) {
                            first = (PreparedNeighborhood.IndexedPoint) p2;
                            second = (PreparedNeighborhood.IndexedPoint) p1;
                        }
                        Circle candidate = buildCandidateCircle(first, second, d12Squared);
                        candidateCount++;
                        pairCandidateCount++;
                        if (candidate == null) {
                            continue;
                        }

                        int requiredCount = minimumRequiredCount(candidate.discenq);
                        if (p1AnchorUpperBound < requiredCount && anchorContains(p1,candidate.centerX,candidate.centerY)) continue;
                        if (getAnchorCount(p2) < requiredCount && anchorContains(p2,candidate.centerX,candidate.centerY)) continue;

                        int candidateCount;
                        int cachedProjection = projectedOrdinal < 0 ? 0 : prepared.projectedCounts.get(projectedOrdinal);
                        if (projectedOrdinal >= 0) projectedCandidates++;
                        if (cachedProjection != 0) {
                            projectedCountHits++;
                            candidateCount = cachedProjection - 1;
                        } else {
                            int knownBound = projectedOrdinal < 0 ? 0 : prepared.projectedUpperBounds.get(projectedOrdinal);
                            if (knownBound != 0 && knownBound - 1 < requiredCount) {
                                projectedBoundHits++;
                                continue;
                            }
                            candidateCount = countPointsNear(candidate.centerX, candidate.centerY, dc2, dc, requiredCount);
                            if (projectedOrdinal >= 0) {
                                if (lastCountUpperBound < 0) prepared.projectedCounts.set(projectedOrdinal, candidateCount + 1);
                                else {
                                    int bound=lastCountUpperBound+1;
                                    for (;;) {
                                        int old=prepared.projectedUpperBounds.get(projectedOrdinal);
                                        if (old!=0 && old<=bound) break;
                                        if (prepared.projectedUpperBounds.compareAndSet(projectedOrdinal,old,bound)) break;
                                    }
                                }
                            }
                        }
                        if (candidateCount < requiredCount || candidateCount < density_k) {
                            continue;
                        }

                        candidate.cirnum = candidateCount;
                        circles.add(candidate);
                        if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) {
                            flushCandidateCircles();
                        }
                    }
                }
            }
        }

        flushCandidateCircles();
    }

    private Circle buildAnchorCircle(Point p1) {
        Circle circle = new Circle();
        circle.discenq = Math.max(0.0, queryDistance(p1) - dc);
        circle.cirnum = getAnchorCount(p1);
        return circle;
    }

    private Circle buildSinglePointCircle(PreparedNeighborhood.IndexedPoint point) {
        Circle circle = new Circle();
        circle.centerX = point.projectedX;
        circle.centerY = point.projectedY;
        circle.discenq = point.projectedDistance;
        return circle;
    }

    private int countProjectedCircle(PreparedNeighborhood.IndexedPoint point, int requiredCount) {
        projectedCandidates++;
        int cached = prepared.projectedCounts.get(point.ordinal);
        if (cached != 0) {
            projectedCountHits++;
            return cached - 1;
        }
        int knownBound = prepared.projectedUpperBounds.get(point.ordinal);
        if (knownBound != 0 && knownBound - 1 < requiredCount) {
            projectedBoundHits++;
            return knownBound - 1;
        }
        int count = countPointsNear(point.projectedX, point.projectedY, dc2, dc, requiredCount);
        if (lastCountUpperBound < 0) prepared.projectedCounts.set(point.ordinal, count + 1);
        else prepared.projectedUpperBounds.set(point.ordinal, lastCountUpperBound + 1);
        return count;
    }

    private boolean anchorContains(Point p,double x,double y) {
        return NumericalCoverage.containsCandidate(p.x,p.y,x,y,dc,NumericalCoverage.anchorRadius(dc));
    }

    private int getAnchorCount(Point point) {
        int ordinal = ((PreparedNeighborhood.IndexedPoint)point).ordinal;
        int cached = prepared.anchorCounts.get(ordinal);
        if (cached != 0) return cached - 1;
        double safeRadius=NumericalCoverage.anchorRadius(dc);
        int count = countPointsNear(point.x, point.y, safeRadius*safeRadius, safeRadius, 0);
        prepared.anchorCounts.set(ordinal, count + 1);
        return count;
    }

    private int lowerSkylineIndex(double distance) {
        if (skylineDistances.length == 0 && skymap != null && !skymap.isEmpty()) rebuildSkylineIndex();
        int lo=0,hi=skylineDistances.length;
        while(lo<hi) {int mid=(lo+hi)>>>1;if(Double.compare(skylineDistances[mid],distance)<0)lo=mid+1;else hi=mid;}
        return lo-1;
    }

    private boolean isDominatedByCurrentSkyline(Circle candidate) {
        int lower=lowerSkylineIndex(candidate.discenq);
        return lower>=0 && skylineCounts[lower]>candidate.cirnum;
    }

    private int minimumRequiredCount(double discenq) {
        int lower=lowerSkylineIndex(discenq);
        return lower<0 ? density_k : Math.max(density_k,skylineCounts[lower]+1);
    }

    private Circle buildCandidateCircle(Point p1, Point p2, double d12Squared) {
        double qp1 = queryDistance(p1);
        double qp2 = queryDistance(p2);
        projectedOrdinal = -1;
        PreparedNeighborhood.IndexedPoint anchor = (PreparedNeighborhood.IndexedPoint)(qp1 > qp2 ? p1 : p2);
        Circle candidate = new Circle();

        if (qp1 > qp2) {
            if (squaredDistance(p2.x, p2.y, anchor.projectedX, anchor.projectedY) <= dc2) {
                candidate.centerX = anchor.projectedX;
                candidate.centerY = anchor.projectedY;
                projectedOrdinal = anchor.ordinal;
            } else {
                Point center = circleCenter(p1.x, p1.y, p2.x, p2.y, d12Squared);
                if (center == null) {
                    return null;
                }
                candidate.centerX = center.x;
                candidate.centerY = center.y;
            }
        } else {
            if (squaredDistance(p1.x, p1.y, anchor.projectedX, anchor.projectedY) <= dc2) {
                candidate.centerX = anchor.projectedX;
                candidate.centerY = anchor.projectedY;
                projectedOrdinal = anchor.ordinal;
            } else {
                Point center = circleCenter(p1.x, p1.y, p2.x, p2.y, d12Squared);
                if (center == null) {
                    return null;
                }
                candidate.centerX = center.x;
                candidate.centerY = center.y;
            }
        }

        candidate.discenq = projectedOrdinal < 0 ? round2(distance(candidate.centerX, candidate.centerY, q.x, q.y)) : anchor.projectedDistance;
        return candidate;
    }

    private void projectTowardQuery(Point anchor, double queryDistance, Point projected) {
        if (queryDistance <= dc) {
            projected.x=q.x; projected.y=q.y; return;
        }
        if (anchor.x > q.x) {
            projected.x = q.x + ((queryDistance - dc) / queryDistance) * Math.abs(anchor.x - q.x);
        } else if (anchor.x == q.x) {
            projected.x = q.x;
        } else {
            projected.x = q.x - ((queryDistance - dc) / queryDistance) * Math.abs(anchor.x - q.x);
        }

        if (anchor.y > q.y) {
            projected.y = q.y + ((queryDistance - dc) / queryDistance) * Math.abs(anchor.y - q.y);
        } else if (anchor.y == q.y) {
            projected.y = q.y;
        } else {
            projected.y = q.y - ((queryDistance - dc) / queryDistance) * Math.abs(anchor.y - q.y);
        }
    }

    private int countPointsNear(double centerX, double centerY, double radiusSquared, double radius, int requiredCount) {
        lastCountUpperBound = -1;
        double roundedRadius = Math.nextDown(radius + 0.005);
        double roundedRadiusSquared = roundedRadius * roundedRadius;
        int minCellX = (int) Math.floor((centerX - roundedRadius) / cellSize);
        int maxCellX = (int) Math.floor((centerX + roundedRadius) / cellSize);
        int minCellY = (int) Math.floor((centerY - roundedRadius) / cellSize);
        int maxCellY = (int) Math.floor((centerY + roundedRadius) / cellSize);

        if (requiredCount <= 0) {
            int count = 0;
            for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
                for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                    PreparedNeighborhood.CellBucket bucket = bucketAt(pack(cellX, cellY));
                    if (bucket == null) {
                        continue;
                    }
                    count += countBucket(centerX, centerY, roundedRadiusSquared, bucket);
                }
            }
            return count;
        }

        int remainingPotential = 0, used = 0;
        for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
            for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                PreparedNeighborhood.CellBucket bucket = bucketAt(pack(cellX, cellY));
                if (bucket != null) {
                    remainingPotential += bucket.points.length;
                    if (used == countBuckets.length) countBuckets=java.util.Arrays.copyOf(countBuckets,used*2);
                    countBuckets[used++]=bucket;
                }
            }
        }

        int count = 0;
        for (int i=0;i<used;i++) {
            PreparedNeighborhood.CellBucket bucket=countBuckets[i];
            remainingPotential -= bucket.points.length;
            count += countBucket(centerX, centerY, roundedRadiusSquared, bucket);
            if (count + remainingPotential < requiredCount) {
                lastCountUpperBound=count+remainingPotential;
                return count;
            }
        }
        return count;
    }

    private int countBucket(double x, double y, double radiusSquared, PreparedNeighborhood.CellBucket bucket) {
        // Exact box tests; keep the original search-cell range and rounded-radius threshold.
        // Sparse buckets scan directly to avoid paying for bounds when little work can be saved.
        if (bucket.points.length >= 8) {
            double fx=Math.max(Math.abs(x-bucket.minX),Math.abs(x-bucket.maxX));
            double fy=Math.max(Math.abs(y-bucket.minY),Math.abs(y-bucket.maxY));
            if (fx*fx+fy*fy <= radiusSquared) return bucket.points.length;
            double nx=x<bucket.minX ? bucket.minX-x : x>bucket.maxX ? x-bucket.maxX : 0;
            double ny=y<bucket.minY ? bucket.minY-y : y>bucket.maxY ? y-bucket.maxY : 0;
            if (nx*nx+ny*ny > radiusSquared) return 0;
        }
        int count=0;
        for(Point p:bucket.points) { pointDistanceChecks++; if(squaredDistance(x,y,p.x,p.y)<=radiusSquared)count++; }
        return count;
    }

    private boolean isWithinRoundedRadius(double centerX, double centerY, double pointX, double pointY, double radius) {
        return round2(distance(centerX, centerY, pointX, pointY)) <= radius;
    }

    private void flushCandidateCircles() {
        if (circles.isEmpty() && (skymap == null || skymap.isEmpty())) {
            return;
        }
        ArrayList<Circle> merged = new ArrayList<Circle>(circles.size() + (skymap == null ? 0 : skymap.size()));
        merged.addAll(circles);
        if (skymap != null && !skymap.isEmpty()) {
            merged.addAll(skymap.values());
        }
        Collections.sort(merged, new Comparator<Circle>() {
            @Override
            public int compare(Circle left, Circle right) {
                return Double.compare(left.discenq, right.discenq);
            }
        });
        skymap = skylineCircle(merged);
        rebuildSkylineIndex();
        circles.clear();
    }

    private void rebuildSkylineIndex() {
        int size=skymap==null?0:skymap.size();
        skylineDistances=new double[size];skylineCounts=new int[size];
        if(size==0)return;
        int i=0;for(double distance:skymap.keySet())skylineDistances[i++]=distance;
        java.util.Arrays.sort(skylineDistances);
        for(i=0;i<size;i++)skylineCounts[i]=skymap.get(skylineDistances[i]).cirnum;
    }

    private long pack(int cellX, int cellY) {
        return (((long) cellX) << 32) ^ (cellY & 0xffffffffL);
    }

    private double squaredDistance(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2;
        double dy = y1 - y2;
        return dx * dx + dy * dy;
    }

    private double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(squaredDistance(x1, y1, x2, y2));
    }

    private double round2(double value) {
        return (double) Math.round(value * 100) / 100;
    }

    private Point circleCenter(double x1, double y1, double x2, double y2, double d12Squared) {
        Point p1 = new Point();
        Point p2 = new Point();
        Point p = new Point();
        if (d12Squared > twoDc2) {
            return null;
        }
        if (Math.abs(d12Squared - twoDc2) < 1e-9) {
            p.x = (x1 + x2) / 2;
            p.y = (y1 + y2) / 2;
            return p;
        }
        if (x1 != x2) {
            double c1 = (x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1) / (2 * (x2 - x1));
            double c2 = (y2 - y1) / (x2 - x1);
            double A = c2 * c2 + 1;
            double B = 2 * x1 * c2 - 2 * c1 * c2 - 2 * y1;
            double C = x1 * x1 - 2 * x1 * c1 + c1 * c1 + y1 * y1 - dc2;
            double delta = B * B - 4 * A * C;
            if (delta < 0) {
                return null;
            }
            if (y1 == y2) {
                double middleX = (x1 + x2) / 2;
                double vertical = Math.sqrt(Math.max(0, dc2 - ((x1 - x2) / 2) * ((x1 - x2) / 2)));
                p1.x = middleX;
                p1.y = y1 + vertical;
                p2.x = middleX;
                p2.y = y1 - vertical;
            } else {
                p1.y = (-B + Math.sqrt(delta)) / (2 * A);
                p1.x = c1 - c2 * p1.y;
                p2.y = (-B - Math.sqrt(delta)) / (2 * A);
                p2.x = c1 - c2 * p2.y;
            }
        } else {
            double middleY = (y1 + y2) / 2;
            double horizontal = Math.sqrt(Math.max(0, dc2 - ((y1 - y2) / 2) * ((y1 - y2) / 2)));
            p1.y = middleY;
            p1.x = x1 + horizontal;
            p2.y = middleY;
            p2.x = x1 - horizontal;
        }

        double dispc1 = distance(p1.x, p1.y, q.x, q.y);
        double dispc2 = distance(p2.x, p2.y, q.x, q.y);
        return dispc1 < dispc2 ? p1 : p2;
    }

    public HashMap<Double, Circle> skylineCircle(ArrayList<Circle> circles) {
        HashMap<Double, Circle> map = new HashMap<Double, Circle>();
        int max = -1;

        for (Circle circle : circles) {
            if (map.containsKey(circle.discenq)) {
                if (isPreferredAtSameDistance(circle, map.get(circle.discenq))) {
                    map.put(circle.discenq, circle);
                    max = circle.getCirnum();
                }
            } else if (circle.getCirnum() > max) {
                map.put(circle.discenq, circle);
                max = circle.getCirnum();
            }
        }
        return map;
    }

    private boolean isPreferredAtSameDistance(Circle candidate, Circle current) {
        if (candidate.getCirnum() != current.getCirnum()) {
            return candidate.getCirnum() > current.getCirnum();
        }
        int centerXOrder = Double.compare(candidate.centerX, current.centerX);
        return centerXOrder < 0
                || (centerXOrder == 0 && Double.compare(candidate.centerY, current.centerY) < 0);
    }
}
