package com;

import java.util.Arrays;
import java.util.BitSet;

/** Builds a deduplicated physical point union for a one- or two-owner bundle. */
public final class MaskedBlockBuilder {
    private final int[] ownerIds;
    private final int validMask;
    private final LongOrdinalIndex ordinals = new LongOrdinalIndex(64);
    private final long[] assignedCounts;
    private final BitSet[] sourceOwners;

    private Point[] points = new Point[64];
    private byte[] masks = new byte[64];
    private int size;
    private boolean built;

    public MaskedBlockBuilder(int[] ownerIds) {
        if (ownerIds == null || ownerIds.length < 1 || ownerIds.length > 2) {
            throw new IllegalArgumentException("masked block requires one or two owners");
        }
        this.ownerIds = ownerIds.clone();
        if (ownerIds.length == 2 && ownerIds[0] == ownerIds[1]) {
            throw new IllegalArgumentException("duplicate bundle owner");
        }
        this.validMask = (1 << ownerIds.length) - 1;
        this.assignedCounts = new long[ownerIds.length];
        this.sourceOwners = new BitSet[ownerIds.length];
        for (int slot = 0; slot < ownerIds.length; slot++) {
            sourceOwners[slot] = new BitSet();
        }
    }

    public void add(Point point, int visibilityMask) {
        if (built) {
            throw new IllegalStateException("builder already consumed");
        }
        if (point == null) {
            throw new IllegalArgumentException("point is null");
        }
        if (visibilityMask == 0 || (visibilityMask & ~validMask) != 0) {
            throw new IllegalArgumentException("invalid visibility mask " + visibilityMask
                    + " for " + ownerIds.length + " owners");
        }

        int ordinal = ordinals.get(point.id);
        if (ordinal >= 0) {
            requireSameIdentity(points[ordinal], point);
            int newBits = visibilityMask & ~(masks[ordinal] & 0xff);
            masks[ordinal] = (byte) ((masks[ordinal] & 0xff) | visibilityMask);
            addLogicalMembership(point.ownerPartitionId, newBits);
            return;
        }

        ensureCapacity(size + 1);
        ordinal = size++;
        points[ordinal] = point;
        masks[ordinal] = (byte) visibilityMask;
        ordinals.put(point.id, ordinal);
        addLogicalMembership(point.ownerPartitionId, visibilityMask);
    }

    public MaskedSharedBlock build() {
        if (built) {
            throw new IllegalStateException("builder already consumed");
        }
        built = true;

        int[] anchorSizes = new int[ownerIds.length];
        long[] coreCounts = new long[ownerIds.length];
        for (int ordinal = 0; ordinal < size; ordinal++) {
            int coreSlot = ownerSlot(points[ordinal].ownerPartitionId);
            if (coreSlot >= 0) {
                if (((masks[ordinal] & 0xff) & (1 << coreSlot)) == 0) {
                    throw new IllegalArgumentException("core owner " + ownerIds[coreSlot]
                            + " is not visible for point " + points[ordinal].id);
                }
                anchorSizes[coreSlot]++;
                coreCounts[coreSlot]++;
            }
        }

        int[][] anchors = new int[ownerIds.length][];
        for (int slot = 0; slot < ownerIds.length; slot++) {
            anchors[slot] = new int[anchorSizes[slot]];
        }
        int[] positions = new int[ownerIds.length];
        for (int ordinal = 0; ordinal < size; ordinal++) {
            int coreSlot = ownerSlot(points[ordinal].ownerPartitionId);
            if (coreSlot >= 0) {
                anchors[coreSlot][positions[coreSlot]++] = ordinal;
            }
        }

        int[] sourceCounts = new int[ownerIds.length];
        for (int slot = 0; slot < ownerIds.length; slot++) {
            sourceCounts[slot] = sourceOwners[slot].cardinality();
        }
        return new MaskedSharedBlock(
                ownerIds.clone(),
                Arrays.copyOf(points, size),
                Arrays.copyOf(masks, size),
                anchors,
                assignedCounts.clone(),
                coreCounts,
                sourceCounts);
    }

    private void addLogicalMembership(int sourceOwner, int bits) {
        if (sourceOwner < 0) {
            throw new IllegalArgumentException("negative source owner: " + sourceOwner);
        }
        for (int slot = 0; slot < ownerIds.length; slot++) {
            if ((bits & (1 << slot)) != 0) {
                assignedCounts[slot]++;
                sourceOwners[slot].set(sourceOwner);
            }
        }
    }

    private int ownerSlot(int ownerId) {
        for (int slot = 0; slot < ownerIds.length; slot++) {
            if (ownerIds[slot] == ownerId) {
                return slot;
            }
        }
        return -1;
    }

    private void ensureCapacity(int needed) {
        if (needed <= points.length) {
            return;
        }
        int capacity = points.length << 1;
        while (capacity < needed) {
            capacity <<= 1;
        }
        points = Arrays.copyOf(points, capacity);
        masks = Arrays.copyOf(masks, capacity);
    }

    private static void requireSameIdentity(Point first, Point next) {
        if (Double.doubleToLongBits(first.x) != Double.doubleToLongBits(next.x)
                || Double.doubleToLongBits(first.y) != Double.doubleToLongBits(next.y)
                || first.packedCellId != next.packedCellId
                || first.ownerPartitionId != next.ownerPartitionId) {
            throw new IllegalArgumentException("inconsistent records for point id " + first.id);
        }
    }
}
