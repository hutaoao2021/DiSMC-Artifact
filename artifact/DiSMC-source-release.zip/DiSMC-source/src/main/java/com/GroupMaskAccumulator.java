package com;

import java.util.Arrays;

/** Allocation-free owner-to-group mask collapse for one routed point. */
public final class GroupMaskAccumulator {
    private final int[] groupByOwner;
    private final int[] slotByOwner;
    private final int[] masksByGroup;
    private final int[] touchedGroups;
    private int size;

    public GroupMaskAccumulator(int[] groupByOwner, int[] slotByOwner, int groupCount) {
        if (groupByOwner == null || slotByOwner == null || groupCount < 1
                || groupByOwner.length != slotByOwner.length) {
            throw new IllegalArgumentException("invalid owner-to-group mapping");
        }
        int[] slotsSeen = new int[groupCount];
        int[] members = new int[groupCount];
        for (int owner = 0; owner < groupByOwner.length; owner++) {
            int group = groupByOwner[owner];
            int slot = slotByOwner[owner];
            if (group < 0 || group >= groupCount || slot < 0 || slot > 1) {
                throw new IllegalArgumentException("invalid mapping for owner " + owner);
            }
            int bit = 1 << slot;
            if ((slotsSeen[group] & bit) != 0 || ++members[group] > 2) {
                throw new IllegalArgumentException("duplicate or oversized group " + group);
            }
            slotsSeen[group] |= bit;
        }
        this.groupByOwner = Arrays.copyOf(groupByOwner, groupByOwner.length);
        this.slotByOwner = Arrays.copyOf(slotByOwner, slotByOwner.length);
        this.masksByGroup = new int[groupCount];
        this.touchedGroups = new int[groupCount];
    }

    public void clear() {
        for (int index = 0; index < size; index++) masksByGroup[touchedGroups[index]] = 0;
        size = 0;
    }

    public void addOwner(int owner) {
        if (owner < 0 || owner >= groupByOwner.length) {
            throw new IllegalArgumentException("invalid owner " + owner);
        }
        int group = groupByOwner[owner];
        int oldMask = masksByGroup[group];
        int newMask = oldMask | (1 << slotByOwner[owner]);
        if (oldMask == 0) touchedGroups[size++] = group;
        masksByGroup[group] = newMask;
    }

    public void sortGroups() {
        Arrays.sort(touchedGroups, 0, size);
    }

    public int size() {
        return size;
    }

    public int groupAt(int index) {
        checkIndex(index);
        return touchedGroups[index];
    }

    public int maskAt(int index) {
        checkIndex(index);
        return masksByGroup[touchedGroups[index]];
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("index " + index);
    }
}
