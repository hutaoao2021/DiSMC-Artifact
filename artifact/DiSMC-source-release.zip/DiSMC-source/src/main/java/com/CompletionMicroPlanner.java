package com;

import java.util.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public final class CompletionMicroPlanner {
    public static final class Costs {
        public final double workSeconds, recordSeconds, taskSeconds, planningSeconds;
        public Costs(double workSeconds, double recordSeconds, double taskSeconds, double planningSeconds) {
            for (double value : new double[]{workSeconds,recordSeconds,taskSeconds,planningSeconds})
                if (!Double.isFinite(value) || value < 0) throw new IllegalArgumentException("invalid completion cost");
            if (workSeconds == 0) throw new IllegalArgumentException("positive work coefficient required");
            this.workSeconds = workSeconds; this.recordSeconds = recordSeconds;
            this.taskSeconds = taskSeconds; this.planningSeconds = planningSeconds;
        }
    }
    public static final class Decision {
        public final MicroPartitionPlanner.Plan plan;
        public final double baselineSeconds, candidateSeconds, executionSeconds, searchSeconds;
        public final long evaluatedPlans;
        public final String reason;
        Decision(MicroPartitionPlanner.Plan plan, double baseline, double candidate, double execution,
                double search, long evaluated, String reason) {
            this.plan = plan; baselineSeconds = baseline; candidateSeconds = candidate;
            executionSeconds = execution; searchSeconds = search; evaluatedPlans = evaluated; this.reason = reason;
        }
    }
    private static final class Search {
        final double[] work;
        final MicroPartitionPopulation.Statistics population;
        final Costs costs;
        final int slots;
        final String mode;
        final long budget;
        final List<List<Integer>> groups;
        final MicroPartitionLayout.Candidate[] selected;
        final long[][] inputs;
        MicroPartitionPlanner.Plan best;
        double bestSeconds;
        long evaluated;
        Search(MicroPartitionPlanner.Plan base, MicroPartitionPopulation.Statistics population, Costs costs,
                List<List<Integer>> groups) {
            work = base.originalWork; this.population = population; this.costs = costs;
            slots = base.slots; mode = base.mode; budget = base.budgetRecords; this.groups = groups;
            selected = base.selected.clone(); inputs = base.taskInputs.clone(); best = base;
            bestSeconds = predict(base,costs);
        }
        void visit(int depth, long charged) {
            if (depth == groups.size()) {
                MicroPartitionPlanner.Plan plan = new MicroPartitionPlanner.Plan(selected,population.originalAssigned,inputs,work,mode,budget,slots);
                double seconds = predict(plan,costs); evaluated++;
                if (seconds < bestSeconds || seconds == bestSeconds && (plan.extraRecords < best.extraRecords
                        || plan.extraRecords == best.extraRecords && plan.taskCount() < best.taskCount())) {
                    best = plan; bestSeconds = seconds;
                }
                return;
            }
            List<Integer> group = groups.get(depth);
            int owner = population.candidates[group.get(0)].owner;
            selected[owner] = null; inputs[owner] = new long[]{population.originalAssigned[owner]};
            visit(depth+1,charged);
            for (int index : group) {
                MicroPartitionLayout.Candidate candidate = population.candidates[index];
                long[] child = mode.equals("dependency") ? population.dependencyInputs[index].clone() : new long[candidate.pieces];
                if (!mode.equals("dependency")) Arrays.fill(child,population.originalAssigned[owner]);
                long next = Math.addExact(charged,MicroPartitionPlanner.extra(child,population.originalAssigned[owner]));
                if (next > budget) continue;
                selected[owner] = candidate; inputs[owner] = child;
                visit(depth+1,next);
            }
            selected[owner] = null; inputs[owner] = new long[]{population.originalAssigned[owner]};
        }
    }
    public static double predict(MicroPartitionPlanner.Plan plan, Costs costs) {
        double[] work = plan.work();
        long[] inputRecords = new long[work.length]; int inputIndex = 0;
        for (long[] lanes : plan.taskInputs) for (long records : lanes) inputRecords[inputIndex++] = records;
        Integer[] order = new Integer[work.length];
        for (int task = 0; task < order.length; task++) order[task] = task;
        Arrays.sort(order,Comparator.<Integer>comparingDouble(task -> -work[task]).thenComparingInt(task -> task));
        PriorityQueue<Double> workers = new PriorityQueue<>();
        for (int slot = 0; slot < Math.min(plan.slots,work.length); slot++) workers.add(0.0);
        double finish = 0;
        for (int task : order) {
            long records = inputRecords[task];
            double duration = work[task]*costs.workSeconds + records*costs.recordSeconds + costs.taskSeconds;
            if (!Double.isFinite(duration) || duration < 0) throw new IllegalArgumentException("invalid predicted duration");
            double end = workers.remove()+duration;
            if (!Double.isFinite(end)) throw new IllegalArgumentException("prediction overflow");
            workers.add(end); finish = Math.max(finish,end);
        }
        return finish;
    }
    public static void writeCandidates(Path path, MicroPartitionPopulation.Statistics population, double[] work, String mode) throws IOException {
        List<String> rows = new ArrayList<>();
        rows.add("kind,owner,pieces,lane,anchors,input_records,work,extra_records,signature");
        for (int owner = 0; owner < work.length; owner++)
            rows.add("original,"+owner+",1,0,"+population.core[owner]+","+population.originalAssigned[owner]+","+work[owner]+",0,unsplit");
        for (int index = 0; index < population.candidates.length; index++) {
            MicroPartitionLayout.Candidate candidate = population.candidates[index];
            if (mode.equals("none") || !candidate.responsibility.equals(mode.equals("hash_full") ? "hash" : "spatial")) continue;
            long[] child = mode.equals("dependency") ? population.dependencyInputs[index].clone() : new long[candidate.pieces];
            if (!mode.equals("dependency")) Arrays.fill(child,population.originalAssigned[candidate.owner]);
            long extra = MicroPartitionPlanner.extra(child,population.originalAssigned[candidate.owner]);
            String signature = candidate.signature();
            for (int lane = 0; lane < candidate.pieces; lane++)
                rows.add("candidate,"+candidate.owner+","+candidate.pieces+","+lane+","+candidate.anchorIds(lane).length
                        +","+child[lane]+","+candidate.work(lane)+","+extra+","+signature);
        }
        Files.write(path,rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
    }
    public static Decision select(double[] work, MicroPartitionPopulation.Statistics population,
            double budgetFraction, int slots, String mode, Costs costs) {
        long start = System.nanoTime();
        MicroPartitionPlanner.Plan none = MicroPartitionPlanner.select(work,population,budgetFraction,slots,"none");
        if (!Arrays.asList("none","dependency","spatial_full","hash_full").contains(mode))
            throw new IllegalArgumentException("invalid completion mode");
        MicroPartitionPlanner.Plan base = new MicroPartitionPlanner.Plan(none.selected,none.originalInputs,none.taskInputs,work,mode,none.budgetRecords,slots);
        double baseline = predict(base,costs);
        if (mode.equals("none")) return new Decision(base,baseline,baseline,baseline,0,1,"disabled");
        Map<Integer,List<Integer>> byOwner = new TreeMap<>();
        Set<String> signatures = new HashSet<>();
        for (int index = 0; index < population.candidates.length; index++) {
            MicroPartitionLayout.Candidate candidate = population.candidates[index];
            if (!candidate.responsibility.equals(mode.equals("hash_full") ? "hash" : "spatial")) continue;
            if (candidate.owner >= work.length || candidate.pieces != 2 && candidate.pieces != 4)
                throw new IllegalArgumentException("invalid bounded candidate");
            List<Integer> group = byOwner.computeIfAbsent(candidate.owner,owner -> new ArrayList<>());
            if (!signatures.add(candidate.signature())) throw new IllegalArgumentException("duplicate candidate responsibility");
            group.add(index);
        }
        if (byOwner.size() > 8) throw new IllegalArgumentException("completion search capped at eight owners");
        Search search = new Search(base,population,costs,new ArrayList<>(byOwner.values()));
        search.visit(0,0);
        double searchSeconds = (System.nanoTime()-start)/1e9;
        boolean improves = search.bestSeconds + costs.planningSeconds + searchSeconds < baseline;
        String reason = improves ? "selected" : search.bestSeconds < baseline ? "overhead_exceeds_gain" : "no_completion_gain";
        return new Decision(improves ? search.best : base,baseline,search.bestSeconds,
                improves ? search.bestSeconds : baseline,searchSeconds,search.evaluated,reason);
    }
    private CompletionMicroPlanner() { }
}
