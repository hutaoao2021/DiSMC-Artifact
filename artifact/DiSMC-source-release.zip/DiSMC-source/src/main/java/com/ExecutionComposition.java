package com;

public final class ExecutionComposition {
    public final String partitioning;
    public final String routing;
    public final String engine;
    public final String layout;
    public final boolean newBounds;
    public final boolean preparedReuse;
    public final String cellOrder;

    private ExecutionComposition(String partitioning, String routing, String engine,
            String layout, boolean newBounds, boolean preparedReuse, String cellOrder) {
        this.partitioning = partitioning;
        this.routing = routing;
        this.engine = engine;
        this.layout = layout;
        this.newBounds = newBounds;
        this.preparedReuse = preparedReuse;
        this.cellOrder = cellOrder;
    }

    public static ExecutionComposition forProfile(MethodProfile profile) {
        if (profile.isStandaloneBaseline()) {
            throw new IllegalArgumentException("standalone baseline has no Full composition: "
                    + profile.id());
        }
        return new ExecutionComposition(
                profile.dependencyPartition ? "dependency" : "point_count",
                profile.sharedNeighborhood ? "shared_masked" : "independent",
                profile.reusableEngine ? "reusable" : "baseline",
                profile.refinement ? "budgeted_shards" : "one_owner",
                profile.newBounds,
                profile.preparedReuse,
                profile.usesHilbertCellOrder() ? "hilbert" : "morton");
    }

    @Override
    public String toString() {
        return "partition=" + partitioning + ",routing=" + routing
                + ",engine=" + engine + ",layout=" + layout
                + ",bounds=" + (newBounds ? "enabled" : "disabled")
                + ",prepared_reuse=" + (preparedReuse ? "enabled" : "disabled")
                + ",cell_order=" + cellOrder;
    }
}
