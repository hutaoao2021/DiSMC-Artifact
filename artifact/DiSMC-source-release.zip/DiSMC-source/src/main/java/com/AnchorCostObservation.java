package com;
import java.io.Serializable;

/** Probe-only observation of actual anchor execution, including bucket and candidate work. */
public final class AnchorCostObservation implements Serializable {
    public final Point anchor;
    public final long kernelNanos, pointChecks, candidates, buckets;
    public final long indexBuildNanos;
    public AnchorCostObservation(Point anchor,long kernelNanos,long pointChecks,long candidates,long buckets) {
        this(anchor,kernelNanos,pointChecks,candidates,buckets,0);
    }
    public AnchorCostObservation(Point anchor,long kernelNanos,long pointChecks,long candidates,long buckets,long indexBuildNanos) {
        if(anchor==null || kernelNanos<0 || pointChecks<0 || candidates<0 || buckets<0)
            throw new IllegalArgumentException("invalid anchor work observation");
        this.anchor=new Point(anchor);this.kernelNanos=kernelNanos;
        if(indexBuildNanos<0)throw new IllegalArgumentException("invalid index build time");
        this.pointChecks=pointChecks;this.candidates=candidates;this.buckets=buckets;this.indexBuildNanos=indexBuildNanos;
    }
}
