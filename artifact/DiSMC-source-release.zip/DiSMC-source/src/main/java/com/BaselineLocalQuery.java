package com;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public final class BaselineLocalQuery {
    public static final String KERNEL = "com.EMCSBaseline";

    public static final class Result implements Serializable {
        private static final long serialVersionUID = 1L;
        public final HashMap<Double, Circle> skyline;
        public final long candidateCount;
        public final long singlePointCandidateCount;
        public final long pairCandidateCount;
        public final long zWindowChecks;
        public final long pointDistanceChecks;

        Result(HashMap<Double, Circle> skyline, long candidateCount,
                long singlePointCandidateCount, long pairCandidateCount,
                long zWindowChecks, long pointDistanceChecks) {
            this.skyline = skyline;
            this.candidateCount = candidateCount;
            this.singlePointCandidateCount = singlePointCandidateCount;
            this.pairCandidateCount = pairCandidateCount;
            this.zWindowChecks = zWindowChecks;
            this.pointDistanceChecks = pointDistanceChecks;
        }
    }

    private BaselineLocalQuery() {
    }

    static boolean isResponsibleAnchor(Point point, int owner, int piece, int pieces) {
        return point.is_core && point.ownerPartitionId == owner
                && BudgetedQueryShards.shard(point.id, pieces) == piece;
    }

    public static Result execute(Iterable<Point> input, int owner, int piece, int pieces,
            double dc, double queryX, double queryY, int density) {
        if (piece < 0 || piece >= pieces) throw new IllegalArgumentException("invalid shard piece");
        EMCSBaseline baseline = new EMCSBaseline(dc, density);
        baseline.setQueryPoint(queryX, queryY);
        for (Point source : input) {
            Point point = new Point(source);
            point.isCore = isResponsibleAnchor(source, owner, piece, pieces);
            point.isClone = !point.isCore;
            prepareZValues(point, dc);
            baseline.plist.add(point);
        }
        Collections.sort(baseline.plist, new Comparator<Point>() {
            @Override
            public int compare(Point left, Point right) {
                int byZ = left.zval.compareTo(right.zval);
                return byZ != 0 ? byZ : Long.compare(left.id, right.id);
            }
        });
        baseline.methodForPartition(owner);
        return new Result(baseline.skymap, baseline.candidateCount,
                baseline.singlePointCandidateCount, baseline.pairCandidateCount,
                baseline.zWindowChecks, baseline.pointDistanceChecks);
    }

    private static void prepareZValues(Point point, double dc) {
        long x = roundedCoordinate(point.x, "x");
        long y = roundedCoordinate(point.y, "y");
        point.zval = Zorder.valueOf(2, new long[]{x, y});
        point.pupperzval = Zorder.valueOf(2, new long[]{
                ceilingCoordinate(point.x + 2 * dc, "upper x"),
                ceilingCoordinate(point.y + 2 * dc, "upper y")});
        point.plowzval = Zorder.valueOf(2, new long[]{
                point.x - 2 * dc > 0 ? floorCoordinate(point.x - 2 * dc, "lower x") : 0L,
                point.y - 2 * dc > 0 ? floorCoordinate(point.y - 2 * dc, "lower y") : 0L});
    }

    private static long roundedCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value + 0.5d), label);
    }

    private static long ceilingCoordinate(double value, String label) {
        return checkedCoordinate(Math.ceil(value), label);
    }

    private static long floorCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value), label);
    }

    private static long checkedCoordinate(double value, String label) {
        if (!Double.isFinite(value) || value < 0 || value > Long.MAX_VALUE) {
            throw new IllegalArgumentException("coordinate is outside long range for "
                    + label + ": " + value);
        }
        return (long) value;
    }
}
