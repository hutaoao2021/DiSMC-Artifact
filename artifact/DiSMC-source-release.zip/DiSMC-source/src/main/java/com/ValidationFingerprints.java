package com;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import org.apache.spark.api.java.JavaPairRDD;

/** Expensive validation-only owner-neighbourhood and anchor coverage fingerprints. */
public final class ValidationFingerprints {
    public static final class Result {
        public final String neighborhood;
        public final String anchors;
        public final long anchorCount;
        Result(String neighborhood,String anchors,long anchorCount){this.neighborhood=neighborhood;this.anchors=anchors;this.anchorCount=anchorCount;}
    }
    private ValidationFingerprints(){ }
    public static Result of(JavaPairRDD<Integer,Point> points){
        List<String> neighborhood=new ArrayList<String>();
        List<String> anchors=new ArrayList<String>();
        HashSet<String> uniqueDestPoint=new HashSet<String>();
        for(String record:points.map(tuple->{
            Point point=tuple._2();
            return tuple._1()+"|"+point.id+"|"+point.ownerPartitionId+"|"+(point.is_core?1:0);
        }).collect()){
            String[] fields=record.split("\\|");
            String key=fields[0]+"|"+fields[1];
            if(!uniqueDestPoint.add(key))throw new IllegalStateException("duplicate owner/point delivery: "+key);
            neighborhood.add(record);
            if("1".equals(fields[3]))anchors.add(key);
        }
        Collections.sort(neighborhood);Collections.sort(anchors);
        return new Result(hash(neighborhood),hash(anchors),anchors.size());
    }
    private static String hash(List<String> records){
        try{
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            for(String record:records){digest.update(record.getBytes(StandardCharsets.UTF_8));digest.update((byte)'\n');}
            StringBuilder out=new StringBuilder();for(byte value:digest.digest())out.append(String.format("%02x",value&255));return out.toString();
        }catch(Exception error){throw new IllegalStateException("cannot hash validation records",error);}
    }
}
