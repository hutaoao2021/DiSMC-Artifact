package com;

import java.io.Serializable;
import java.util.*;
import org.apache.spark.*;
import org.apache.spark.api.java.*;
import org.apache.spark.rdd.RDD;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Cached union per bundle; owner views preserve complete inputs and copy all mutable Points. */
public final class SharedNeighborhoodRDD extends RDD<Tuple2<Integer,Point>> {
    public static final class Packet implements Serializable {
        public final Point point;public final int mask;
        public Packet(Point point,int mask){this.point=point;this.mask=mask;}
    }
    public static final class Block implements Serializable {
        public final Point[][] bySlot;
        transient PreparedNeighborhood prepared;
        Block(Point[][] bySlot){this.bySlot=bySlot;}
    }
    private static final class OwnerPartition implements Partition {
        final int owner,slot;final Partition parent;
        OwnerPartition(int owner,int slot,Partition parent){this.owner=owner;this.slot=slot;this.parent=parent;}
        public int index(){return owner;}
        public boolean org$apache$spark$Partition$$super$equals(Object o){return super.equals(o);}
    }
    private static final class BundleDependency extends NarrowDependency<Block> {
        final int[] groups;
        BundleDependency(RDD<Block> parent,int[] groups){super(parent);this.groups=groups.clone();}
        public Seq<Object> getParents(int child){return JavaConverters.asScalaBufferConverter(Collections.<Object>singletonList(groups[child])).asScala().toSeq();}
    }
    private static Seq<Dependency<?>> deps(RDD<Block> parent,int[] groups) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(new BundleDependency(parent,groups))).asScala().toSeq();
    }
    private final RDD<Block> blocks;
    private final Partition[] owners;
    public SharedNeighborhoodRDD(JavaRDD<Block> blocks,NeighborhoodBundles.Plan plan) {
        super(blocks.context(),deps(blocks.rdd(),plan.group),ClassTag$.MODULE$.<Tuple2<Integer,Point>>apply(Tuple2.class));
        this.blocks=blocks.rdd();owners=new Partition[plan.group.length];Partition[] p=this.blocks.partitions();
        for(int i=0;i<owners.length;i++)owners[i]=new OwnerPartition(i,plan.slot[i],p[plan.group[i]]);
    }
    public Partition[] getPartitions(){return owners;}
    public scala.collection.Iterator<Tuple2<Integer,Point>> compute(Partition split,TaskContext context) {
        OwnerPartition p=(OwnerPartition)split;
        scala.collection.Iterator<Block> it=blocks.iterator(p.parent,context);
        if(!it.hasNext())throw new IllegalStateException("missing shared block");
        Point[] points=it.next().bySlot[p.slot];
        if(it.hasNext())throw new IllegalStateException("multiple shared blocks");
        Iterator<Tuple2<Integer,Point>> result=new Iterator<Tuple2<Integer,Point>>() {
            int next;
            public boolean hasNext(){return next<points.length;}
            public Tuple2<Integer,Point> next(){if(!hasNext())throw new NoSuchElementException();Point c=new Point(points[next++]);c.is_core=c.ownerPartitionId==p.owner;c.is_clone=!c.is_core;return new Tuple2<>(p.owner,c);}
        };
        return JavaConverters.asScalaIteratorConverter(result).asScala();
    }
    public JavaPairRDD<Integer,Point> asPairs() {
        return JavaPairRDD.fromJavaRDD(JavaRDD.fromRDD(this,ClassTag$.MODULE$.<Tuple2<Integer,Point>>apply(Tuple2.class)));
    }
    public static JavaRDD<Block> cache(JavaPairRDD<Integer,Packet> packets,NeighborhoodBundles.Plan plan) {
        final int[][] members=plan.members;
        return packets.partitionBy(new HashPartitioner(members.length)).mapPartitionsWithIndex((id,it)->{
            ArrayList<ArrayList<Point>> slots=new ArrayList<>();for(int p:members[id])slots.add(new ArrayList<Point>());
            while(it.hasNext()) {
                Packet packet=it.next()._2();
                for(int s=0;s<slots.size();s++)if((packet.mask&(1<<s))!=0)slots.get(s).add(packet.point);
            }
            Point[][] points=new Point[slots.size()][];
            for(int s=0;s<points.length;s++)points[s]=slots.get(s).toArray(new Point[0]);
            return Collections.singletonList(new Block(points)).iterator();
        },false).persist(StorageLevel.MEMORY_AND_DISK());
    }
    public static JavaRDD<Block> cacheBatches(JavaPairRDD<Integer,CompactPacketBatches.Batch> batches,NeighborhoodBundles.Plan plan) {
        final int[][] members=plan.members;
        return batches.partitionBy(new HashPartitioner(members.length)).mapPartitionsWithIndex((id,it)->{
            ArrayList<ArrayList<Point>> slots=new ArrayList<>();for(int p:members[id])slots.add(new ArrayList<Point>());
            while(it.hasNext()) {
                CompactPacketBatches.Batch batch=it.next()._2();
                for(int i=0;i<batch.size();i++) {
                    Point point=batch.pointAt(i);int mask=batch.maskAt(i);
                    for(int s=0;s<slots.size();s++)if((mask&(1<<s))!=0)slots.get(s).add(point);
                }
            }
            Point[][] points=new Point[slots.size()][];
            for(int s=0;s<points.length;s++)points[s]=slots.get(s).toArray(new Point[0]);
            return Collections.singletonList(new Block(points)).iterator();
        },false).persist(StorageLevel.MEMORY_AND_DISK());
    }
}
