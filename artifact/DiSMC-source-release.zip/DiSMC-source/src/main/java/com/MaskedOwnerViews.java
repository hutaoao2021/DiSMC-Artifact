package com;

public final class MaskedOwnerViews {
    private MaskedOwnerViews() {
    }

    public static MaskedSharedBlock singleOwner(MaskedSharedBlock block, int slot) {
        if (block == null || slot < 0 || slot >= block.ownerIds.length) {
            throw new IllegalArgumentException("invalid owner slot");
        }
        MaskedBlockBuilder builder = new MaskedBlockBuilder(new int[]{block.ownerIds[slot]});
        int bit = 1 << slot;
        for (int ordinal = 0; ordinal < block.unionPoints.length; ordinal++) {
            if ((block.visibilityMasks[ordinal] & bit) != 0) builder.add(block.unionPoints[ordinal], 1);
        }
        return builder.build();
    }
}
