package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Deterministic, benefit-gated owner pairing for adaptive M2 v1.
 *
 * The model estimates wire savings and index-build savings, then subtracts
 * only the extra shared-block management cost. The payload itself is not
 * charged twice as overhead.
 */
public final class M2AdaptivePlanner {
    private M2AdaptivePlanner() { }

    public static final class Config {
        public final int maxOwners;
        public final long minOverlapRecords;
        public final long maxGroupRecords;
        public final double pointBytes;
        public final double independentRecordBytes;
        public final double batchHeaderBytes;
        public final double sharedBlockOverheadRatio;
        public final double indexSavedWeight;
        public final double minBenefit;

        public Config(int maxOwners, long minOverlapRecords, long maxGroupRecords,
                double pointBytes, double independentRecordBytes, double batchHeaderBytes,
                double sharedBlockOverheadRatio, double indexSavedWeight, double minBenefit) {
            if (maxOwners != 2) throw new IllegalArgumentException("adaptive v1 supports maxOwners=2");
            if (minOverlapRecords < 1L || maxGroupRecords < 1L) throw new IllegalArgumentException("invalid record limits");
            if (!finitePositive(pointBytes) || !finitePositive(independentRecordBytes)
                    || !finitePositive(batchHeaderBytes) || sharedBlockOverheadRatio < 0.0
                    || !Double.isFinite(sharedBlockOverheadRatio) || !Double.isFinite(indexSavedWeight)
                    || !Double.isFinite(minBenefit)) {
                throw new IllegalArgumentException("invalid adaptive M2 cost model");
            }
            this.maxOwners = maxOwners;
            this.minOverlapRecords = minOverlapRecords;
            this.maxGroupRecords = maxGroupRecords;
            this.pointBytes = pointBytes;
            this.independentRecordBytes = independentRecordBytes;
            this.batchHeaderBytes = batchHeaderBytes;
            this.sharedBlockOverheadRatio = sharedBlockOverheadRatio;
            this.indexSavedWeight = indexSavedWeight;
            this.minBenefit = minBenefit;
        }

        public static Config defaults() {
            return new Config(2, 1L, 1000000L, 48.0, 96.0,
                    4096.0, 0.05, 1.0, 0.0);
        }

        private static boolean finitePositive(double value) {
            return Double.isFinite(value) && value > 0.0;
        }
    }

    public static final class Plan {
        public final int[] group;
        public final int[] slot;
        public final int[][] members;
        public final long originalRecords;
        public final long sharedRecords;
        public final int acceptedPairs;
        public final int rejectedPairs;
        public final int rejectedLowOverlap;
        public final int rejectedMemoryCap;
        public final int rejectedNegativeBenefit;
        public final long estimatedSavedRecords;
        public final double estimatedSavedBytes;
        public final double estimatedIndexSaved;
        public final double estimatedBundleCost;
        public final long maxGroupRecords;
        public final int maxGroupOwners;

        private Plan(int[] group, int[] slot, int[][] members, long originalRecords,
                long sharedRecords, int acceptedPairs, int rejectedPairs,
                int rejectedLowOverlap, int rejectedMemoryCap, int rejectedNegativeBenefit,
                long estimatedSavedRecords, double estimatedSavedBytes,
                double estimatedIndexSaved, double estimatedBundleCost,
                long maxGroupRecords, int maxGroupOwners) {
            this.group = group;
            this.slot = slot;
            this.members = members;
            this.originalRecords = originalRecords;
            this.sharedRecords = sharedRecords;
            this.acceptedPairs = acceptedPairs;
            this.rejectedPairs = rejectedPairs;
            this.rejectedLowOverlap = rejectedLowOverlap;
            this.rejectedMemoryCap = rejectedMemoryCap;
            this.rejectedNegativeBenefit = rejectedNegativeBenefit;
            this.estimatedSavedRecords = estimatedSavedRecords;
            this.estimatedSavedBytes = estimatedSavedBytes;
            this.estimatedIndexSaved = estimatedIndexSaved;
            this.estimatedBundleCost = estimatedBundleCost;
            this.maxGroupRecords = maxGroupRecords;
            this.maxGroupOwners = maxGroupOwners;
        }
    }

    private static final class Candidate {
        final int left;
        final int right;
        final long overlap;
        final double savedBytes;
        final double indexSaved;
        final double bundleCost;
        final double benefit;

        Candidate(int left, int right, long overlap, double savedBytes,
                double indexSaved, double bundleCost, double benefit) {
            this.left = left;
            this.right = right;
            this.overlap = overlap;
            this.savedBytes = savedBytes;
            this.indexSaved = indexSaved;
            this.bundleCost = bundleCost;
            this.benefit = benefit;
        }
    }

    public static Plan plan(double[] work, long[] core, long[] assigned,
            long[][] overlap, int slots, Config config) {
        validateInputs(work, core, assigned, overlap, slots, config);
        final int n = assigned.length;
        long original = 0L;
        for (long value : assigned) original = Math.addExact(original, value);

        List<Candidate> candidates = new ArrayList<Candidate>();
        int rejectedLowOverlap = 0;
        int rejectedMemoryCap = 0;
        int rejectedNegativeBenefit = 0;
        for (int left = 0; left < n; left++) {
            for (int right = left + 1; right < n; right++) {
                long shared = overlap[left][right];
                if (shared < config.minOverlapRecords) {
                    rejectedLowOverlap++;
                    continue;
                }
                long groupRecords = Math.addExact(assigned[left], assigned[right]);
                if (groupRecords > config.maxGroupRecords) {
                    rejectedMemoryCap++;
                    continue;
                }
                double savedBytes = shared * (config.independentRecordBytes - config.pointBytes)
                        - config.batchHeaderBytes;
                double indexSaved = config.indexSavedWeight * Math.max(1L, groupRecords);
                double bundleCost = config.batchHeaderBytes
                        + config.pointBytes * groupRecords * config.sharedBlockOverheadRatio;
                double benefit = savedBytes + indexSaved - bundleCost;
                if (benefit <= config.minBenefit) {
                    rejectedNegativeBenefit++;
                    continue;
                }
                candidates.add(new Candidate(left, right, shared, savedBytes,
                        indexSaved, bundleCost, benefit));
            }
        }
        Collections.sort(candidates, new Comparator<Candidate>() {
            @Override
            public int compare(Candidate left, Candidate right) {
                int result = Double.compare(right.benefit, left.benefit);
                if (result != 0) return result;
                result = Integer.compare(left.left, right.left);
                return result != 0 ? result : Integer.compare(left.right, right.right);
            }
        });

        int[] mate = new int[n];
        Arrays.fill(mate, -1);
        int groups = n;
        int acceptedPairs = 0;
        int rejectedPairs = rejectedLowOverlap + rejectedMemoryCap + rejectedNegativeBenefit;
        long savedRecords = 0L;
        double savedBytes = 0.0;
        double indexSaved = 0.0;
        double bundleCost = 0.0;
        for (Candidate candidate : candidates) {
            if (groups <= 2 * slots || mate[candidate.left] >= 0 || mate[candidate.right] >= 0) {
                rejectedPairs++;
                continue;
            }
            mate[candidate.left] = candidate.right;
            mate[candidate.right] = candidate.left;
            groups--;
            acceptedPairs++;
            savedRecords = Math.addExact(savedRecords, candidate.overlap);
            savedBytes += candidate.savedBytes;
            indexSaved += candidate.indexSaved;
            bundleCost += candidate.bundleCost;
        }

        int[] group = new int[n];
        int[] slot = new int[n];
        Arrays.fill(group, -1);
        int[][] members = new int[groups][];
        int nextGroup = 0;
        long largestGroup = 0L;
        int largestOwners = 0;
        for (int owner = 0; owner < n; owner++) {
            if (group[owner] >= 0) continue;
            int partner = mate[owner];
            if (partner < 0) {
                members[nextGroup] = new int[]{owner};
                group[owner] = nextGroup;
                slot[owner] = 0;
            } else {
                members[nextGroup] = new int[]{owner, partner};
                group[owner] = nextGroup;
                group[partner] = nextGroup;
                slot[owner] = 0;
                slot[partner] = 1;
            }
            long records = assigned[owner] + (partner < 0 ? 0L : assigned[partner]);
            largestGroup = Math.max(largestGroup, records);
            largestOwners = Math.max(largestOwners, partner < 0 ? 1 : 2);
            nextGroup++;
        }
        return new Plan(group, slot, members, original, original - savedRecords,
                acceptedPairs, rejectedPairs, rejectedLowOverlap, rejectedMemoryCap,
                rejectedNegativeBenefit, savedRecords, savedBytes, indexSaved,
                bundleCost, largestGroup, largestOwners);
    }

    private static void validateInputs(double[] work, long[] core, long[] assigned,
            long[][] overlap, int slots, Config config) {
        if (config == null || slots < 1 || work == null || core == null || assigned == null
                || overlap == null || work.length != assigned.length || core.length != assigned.length
                || overlap.length != assigned.length) {
            throw new IllegalArgumentException("invalid adaptive planner inputs");
        }
        for (int i = 0; i < assigned.length; i++) {
            if (!Double.isFinite(work[i]) || work[i] < 0.0 || core[i] < 0L || assigned[i] < 0L
                    || overlap[i] == null || overlap[i].length != assigned.length) {
                throw new IllegalArgumentException("invalid adaptive planner statistics");
            }
            for (int j = 0; j < assigned.length; j++) {
                if (overlap[i][j] < 0L) throw new IllegalArgumentException("negative overlap");
            }
        }
    }
}
