package com;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class ExperimentLayouts {
    private ExperimentLayouts() {
    }

    public static NeighborhoodBundles.Plan independentOwners(long[] assigned, double cap) {
        int[] group = new int[assigned.length];
        int[] slot = new int[assigned.length];
        int[][] members = new int[assigned.length][];
        long records = 0;
        for (int owner = 0; owner < assigned.length; owner++) {
            if (assigned[owner] < 0) throw new IllegalArgumentException("negative assigned count");
            group[owner] = owner;
            members[owner] = new int[]{owner};
            records = Math.addExact(records, assigned[owner]);
        }
        return new NeighborhoodBundles.Plan(group, slot, members, records, records, cap);
    }

    public static String ownerSignature(long[] cells, int[] owners, String order) {
        if (cells.length != owners.length || order == null) throw new IllegalArgumentException("invalid ownership");
        List<String> rows = new ArrayList<String>();
        Set<Long> seen = new HashSet<Long>();
        for (int index = 0; index < cells.length; index++) {
            if (!seen.add(cells[index])) throw new IllegalArgumentException("duplicate cell");
            rows.add(cells[index] + ":" + owners[index]);
        }
        return digest("owners-v1:" + order, rows);
    }

    public static String bundleSignature(int[][] members) {
        List<String> rows = new ArrayList<String>();
        Set<Integer> seen = new HashSet<Integer>();
        for (int[] group : members) {
            if (group.length == 0) throw new IllegalArgumentException("empty bundle");
            int[] copied = group.clone();
            Arrays.sort(copied);
            for (int owner : copied) {
                if (owner < 0 || !seen.add(owner)) throw new IllegalArgumentException("invalid bundle membership");
            }
            rows.add(Arrays.toString(copied));
        }
        return digest("bundles-v1", rows);
    }

    public static String shardSignature(BundleShardLayout layout) {
        List<String> rows = new ArrayList<String>();
        for (int index = 0; index < layout.taskCount(); index++) {
            BundleShardLayout.Task task = layout.task(index);
            int[] members = task.owners.clone();
            Arrays.sort(members);
            String group = Arrays.toString(members);
            for (int lane = 0; lane < task.owners.length; lane++) {
                rows.add(task.groupId + ":" + group + ":" + task.round + ":"
                        + task.owners[lane] + ":" + task.pieces[lane]);
            }
        }
        return digest("shards-v1", rows);
    }

    public static String blockSignature(MaskedSharedBlock block) {
        if (block.unionPoints.length != block.visibilityMasks.length
                || block.ownerIds.length != block.ownerAnchorOrdinals.length) {
            throw new IllegalArgumentException("invalid block dimensions");
        }
        List<String> rows = new ArrayList<String>();
        Set<Integer> owners = new HashSet<Integer>();
        for (int owner : block.ownerIds) {
            if (!owners.add(owner)) throw new IllegalArgumentException("duplicate owner");
            rows.add("owner:" + owner);
        }
        Set<Long> points = new HashSet<Long>();
        for (int ordinal = 0; ordinal < block.unionPoints.length; ordinal++) {
            Point point = block.unionPoints[ordinal];
            if (!points.add(point.id)) throw new IllegalArgumentException("duplicate point identity");
            int mask = block.visibilityMasks[ordinal] & 255;
            if (mask == 0 || (mask >>> block.ownerIds.length) != 0) throw new IllegalArgumentException("invalid visibility mask");
            List<Integer> visible = new ArrayList<Integer>();
            for (int slot = 0; slot < block.ownerIds.length; slot++) {
                if ((mask & (1 << slot)) != 0) visible.add(block.ownerIds[slot]);
            }
            Collections.sort(visible);
            rows.add("point:" + point.id + ":" + Double.doubleToLongBits(point.x) + ":"
                    + Double.doubleToLongBits(point.y) + ":" + point.ownerPartitionId + ":"
                    + point.cellX + ":" + point.cellY + ":" + point.packedCellId + ":" + visible);
        }
        for (int slot = 0; slot < block.ownerIds.length; slot++) {
            Set<Long> anchors = new HashSet<Long>();
            for (int ordinal : block.ownerAnchorOrdinals[slot]) {
                if (ordinal < 0 || ordinal >= block.unionPoints.length) throw new IllegalArgumentException("invalid anchor ordinal");
                Point point = block.unionPoints[ordinal];
                if (point.ownerPartitionId != block.ownerIds[slot]
                        || (block.visibilityMasks[ordinal] & (1 << slot)) == 0 || !anchors.add(point.id)) {
                    throw new IllegalArgumentException("invalid anchor responsibility");
                }
                rows.add("anchor:" + block.ownerIds[slot] + ":" + point.id);
            }
        }
        return digest("blocks-v1", rows);
    }

    private static String digest(String domain, List<String> rows) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            Collections.sort(rows);
            digest.update(domain.getBytes(StandardCharsets.UTF_8));
            for (String row : rows) {
                byte[] bytes = row.getBytes(StandardCharsets.UTF_8);
                digest.update(ByteBuffer.allocate(4).putInt(bytes.length).array());
                digest.update(bytes);
            }
            StringBuilder result = new StringBuilder(64);
            for (byte value : digest.digest()) result.append(String.format("%02x", value & 255));
            return result.toString();
        } catch (NoSuchAlgorithmException error) {
            throw new IllegalStateException(error);
        }
    }
}
