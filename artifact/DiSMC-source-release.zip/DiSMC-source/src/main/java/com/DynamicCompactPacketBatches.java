package com;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.LongToIntFunction;
import org.apache.spark.util.LongAccumulator;
import scala.Tuple2;

/** Exact recipient discovery fused into compact Executor-side packet routing. */
public final class DynamicCompactPacketBatches {
    private DynamicCompactPacketBatches() { }

    public static Iterator<Tuple2<Integer, CompactPacketBatches.Batch>> route(
            Iterator<Point> input, int[] offsetX, int[] offsetY,
            int[] ownerGroups, int[] ownerSlots, int groupCount,
            LongToIntFunction encodedOwnerAt, LongToIntFunction decodedOwnerAt,
            LongAccumulator routingBatches, LongAccumulator neighborLookups) {
        return route(input, offsetX, offsetY, ownerGroups, ownerSlots, groupCount,
                encodedOwnerAt, decodedOwnerAt, routingBatches, neighborLookups, "deduplicated_union");
    }

    public static Iterator<Tuple2<Integer, CompactPacketBatches.Batch>> route(
            Iterator<Point> input, int[] offsetX, int[] offsetY,
            int[] ownerGroups, int[] ownerSlots, int groupCount,
            LongToIntFunction encodedOwnerAt, LongToIntFunction decodedOwnerAt,
            LongAccumulator routingBatches, LongAccumulator neighborLookups, String encoding) {
        final boolean ownerCopies = CompactPacketBatches.ownerCopies(encoding);
        if (input == null || offsetX == null || offsetY == null
                || offsetX.length != offsetY.length || encodedOwnerAt == null
                || decodedOwnerAt == null) {
            throw new IllegalArgumentException("invalid dynamic-route inputs");
        }
        final DestinationAccumulator targetOwners =
                new DestinationAccumulator(ownerGroups == null ? -1 : ownerGroups.length);
        final GroupMaskAccumulator groupMasks =
                new GroupMaskAccumulator(ownerGroups, ownerSlots, groupCount);

        return new Iterator<Tuple2<Integer, CompactPacketBatches.Batch>>() {
            final CompactPacketBatches.Buffer[] buffers =
                    new CompactPacketBatches.Buffer[groupCount];
            Point current;
            int coreOwner;
            int nextGroup;
            int remainingMask;
            int flush;
            Tuple2<Integer, CompactPacketBatches.Batch> ready;

            private void emit(int group) {
                ready = new Tuple2<Integer, CompactPacketBatches.Batch>(
                        group, buffers[group].take());
                if (routingBatches != null) routingBatches.add(1L);
            }

            private void loadPoint() {
                current = input.next();
                int encoded = encodedOwnerAt.applyAsInt(current.packedCellId);
                if (encoded == -1) throw new IllegalStateException("missing core owner");
                coreOwner = encoded < -1 ? -encoded - 2 : encoded;
                targetOwners.clear();
                targetOwners.add(coreOwner);
                if (encoded >= 0) {
                    for (int index = 0; index < offsetX.length; index++) {
                        if (neighborLookups != null) neighborLookups.add(1L);
                        int owner = decodedOwnerAt.applyAsInt(pack(
                                current.cellX + offsetX[index],
                                current.cellY + offsetY[index]));
                        if (owner >= 0) targetOwners.add(owner);
                    }
                }
                targetOwners.sortInPlace();
                groupMasks.clear();
                for (int index = 0; index < targetOwners.size(); index++) {
                    groupMasks.addOwner(targetOwners.valueAt(index));
                }
                groupMasks.sortGroups();
                int coreGroup = ownerGroups[coreOwner];
                int coreBit = 1 << ownerSlots[coreOwner];
                boolean coreVisible = false;
                for (int index = 0; index < groupMasks.size(); index++) {
                    if (groupMasks.groupAt(index) == coreGroup
                            && (groupMasks.maskAt(index) & coreBit) != 0) {
                        coreVisible = true;
                        break;
                    }
                }
                if (!coreVisible) throw new IllegalStateException("core owner missing from group mask");
                nextGroup = 0;
                remainingMask = 0;
            }

            private void prepare() {
                if (ready != null) return;
                while (current != null || input.hasNext()) {
                    if (current == null) loadPoint();
                    int group = groupMasks.groupAt(nextGroup);
                    int mask = groupMasks.maskAt(nextGroup);
                    if (ownerCopies) {
                        if (remainingMask == 0) remainingMask = mask;
                        mask = Integer.lowestOneBit(remainingMask);
                        remainingMask &= ~mask;
                    }
                    CompactPacketBatches.Buffer buffer = buffers[group];
                    if (buffer == null) buffers[group] = buffer = new CompactPacketBatches.Buffer();
                    buffer.add(current, coreOwner, mask);
                    if (!ownerCopies || remainingMask == 0) nextGroup++;
                    if (nextGroup == groupMasks.size()) current = null;
                    if (buffer.size == CompactPacketBatches.LIMIT) {
                        emit(group);
                        return;
                    }
                }
                while (flush < buffers.length) {
                    int group = flush++;
                    if (buffers[group] != null && buffers[group].size > 0) {
                        emit(group);
                        return;
                    }
                }
            }

            @Override
            public boolean hasNext() {
                prepare();
                return ready != null;
            }

            @Override
            public Tuple2<Integer, CompactPacketBatches.Batch> next() {
                prepare();
                if (ready == null) throw new NoSuchElementException();
                Tuple2<Integer, CompactPacketBatches.Batch> result = ready;
                ready = null;
                return result;
            }
        };
    }

    /** Probe-only route: discover the same recipients, allocate packets only for selected owners. */
    public static Iterator<Tuple2<Integer, CompactPacketBatches.Batch>> routeSelected(
            Iterator<Point> input, int[] offsetX, int[] offsetY, int ownerCount,
            boolean[] selected, LongToIntFunction encodedOwnerAt, LongToIntFunction decodedOwnerAt) {
        if (input == null || offsetX == null || offsetY == null || offsetX.length != offsetY.length
                || selected == null || selected.length != ownerCount || ownerCount < 1
                || encodedOwnerAt == null || decodedOwnerAt == null)
            throw new IllegalArgumentException("invalid selected-route inputs");
        final boolean[] recipients = selected.clone();
        return new Iterator<Tuple2<Integer, CompactPacketBatches.Batch>>() {
            final CompactPacketBatches.Buffer[] buffers = new CompactPacketBatches.Buffer[ownerCount];
            final DestinationAccumulator targets = new DestinationAccumulator(ownerCount);
            Point current; int coreOwner, nextOwner, flush;
            Tuple2<Integer, CompactPacketBatches.Batch> ready;
            private void load() {
                current = input.next(); int encoded = encodedOwnerAt.applyAsInt(current.packedCellId);
                if (encoded == -1) throw new IllegalStateException("missing core owner");
                coreOwner = encoded < -1 ? -encoded - 2 : encoded;
                targets.clear(); targets.add(coreOwner);
                if (encoded >= 0) for (int i = 0; i < offsetX.length; i++) {
                    int owner = decodedOwnerAt.applyAsInt(pack(current.cellX + offsetX[i], current.cellY + offsetY[i]));
                    if (owner >= 0) targets.add(owner);
                }
                targets.sortInPlace(); nextOwner = 0;
            }
            private void prepare() {
                if (ready != null) return;
                while (current != null || input.hasNext()) {
                    if (current == null) load();
                    while (nextOwner < targets.size()) {
                        int owner = targets.valueAt(nextOwner++);
                        if (!recipients[owner]) continue;
                        CompactPacketBatches.Buffer b = buffers[owner];
                        if (b == null) buffers[owner] = b = new CompactPacketBatches.Buffer();
                        b.add(current, coreOwner, 1);
                        if (b.size == CompactPacketBatches.LIMIT) {
                            ready = new Tuple2<>(owner, b.take()); return;
                        }
                    }
                    current = null;
                }
                while (flush < ownerCount) {
                    int owner = flush++;
                    if (buffers[owner] != null && buffers[owner].size > 0) {
                        ready = new Tuple2<>(owner, buffers[owner].take()); return;
                    }
                }
            }
            public boolean hasNext() { prepare(); return ready != null; }
            public Tuple2<Integer, CompactPacketBatches.Batch> next() {
                prepare(); if (ready == null) throw new NoSuchElementException();
                Tuple2<Integer, CompactPacketBatches.Batch> result = ready; ready = null; return result;
            }
        };
    }

    private static long pack(int cellX, int cellY) {
        return (((long) cellX) << 32) ^ (cellY & 0xffffffffL);
    }
}
