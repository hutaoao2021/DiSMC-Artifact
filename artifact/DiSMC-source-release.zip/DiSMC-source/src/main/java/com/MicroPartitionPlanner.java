package com;

import java.io.Serializable;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class MicroPartitionPlanner {
    public static final class Plan implements Serializable {
        public final MicroPartitionLayout.Candidate[] selected;
        public final long[] originalInputs;
        public final long[][] taskInputs;
        public final double[] originalWork;
        public final String mode;
        public final long originalAssigned, budgetRecords, extraRecords;
        public final double peak, makespan;
        public final int slots;
        Plan(MicroPartitionLayout.Candidate[] selected, long[] originalInputs, long[][] taskInputs,
                double[] work, String mode, long budget, int slots) {
            this.selected = selected.clone(); this.originalInputs = originalInputs.clone(); this.originalWork = work.clone();
            this.taskInputs = new long[taskInputs.length][];
            long assigned = 0, extra = 0;
            for (int owner = 0; owner < originalInputs.length; owner++) {
                assigned = Math.addExact(assigned, originalInputs[owner]); this.taskInputs[owner] = taskInputs[owner].clone();
                extra = Math.addExact(extra, extra(taskInputs[owner], originalInputs[owner]));
            }
            originalAssigned = assigned; extraRecords = extra; budgetRecords = budget; this.mode = mode; this.slots = slots;
            double[] tasks = work(); peak = maximum(tasks); makespan = lpt(tasks, slots);
        }
        public int taskCount() { int total = 0; for (MicroPartitionLayout.Candidate candidate : selected) total += candidate == null ? 1 : candidate.pieces; return total; }
        public double[] work() {
            double[] values = new double[taskCount()]; int index = 0;
            for (int owner = 0; owner < selected.length; owner++) {
                MicroPartitionLayout.Candidate candidate = selected[owner];
                if (candidate == null) values[index++] = originalWork[owner];
                else for (int lane = 0; lane < candidate.pieces; lane++) values[index++] = candidate.work(lane);
            }
            return values;
        }
        public int owner(int task) {
            for (int owner = 0; owner < selected.length; owner++) {
                int pieces = selected[owner] == null ? 1 : selected[owner].pieces;
                if (task < pieces) return owner; task -= pieces;
            }
            throw new IllegalArgumentException("task outside plan");
        }
        public int lane(int task) {
            for (MicroPartitionLayout.Candidate candidate : selected) {
                int pieces = candidate == null ? 1 : candidate.pieces;
                if (task < pieces) return task; task -= pieces;
            }
            throw new IllegalArgumentException("task outside plan");
        }
        public String signature() {
            StringBuilder text = new StringBuilder("micro-plan-v1:").append(mode).append(':').append(budgetRecords);
            for (int owner = 0; owner < selected.length; owner++) text.append('|').append(owner).append(':')
                    .append(selected[owner] == null ? "unsplit" : selected[owner].signature());
            return MicroPartitionLayout.digest(text.toString());
        }
        public String responsibilitySignature() {
            StringBuilder text = new StringBuilder("micro-responsibility-v1");
            for (int owner = 0; owner < selected.length; owner++) text.append('|').append(owner).append(':')
                    .append(selected[owner] == null ? "unsplit" : selected[owner].signature());
            return MicroPartitionLayout.digest(text.toString());
        }
        public void writeCosts(Path path) throws IOException {
            List<String> rows = new ArrayList<>();
            rows.add("logical_task,owner,lane,predicted_work,input_records");
            double[] costs = work();
            for (int task=0;task<costs.length;task++) {
                int owner=owner(task),lane=lane(task);
                rows.add(task+","+owner+","+lane+","+Double.toString(costs[task])+","+taskInputs[owner][lane]);
            }
            Files.write(path,rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
        }
        public void write(Path path, String context) throws IOException {
            List<String> rows = new ArrayList<>(); rows.add("micro-responsibility-v1\t" + context);
            for (int owner = 0; owner < selected.length; owner++) rows.add(owner + "\t" +
                    (selected[owner] == null ? "unsplit" : selected[owner].signature()));
            Files.write(path,rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
        }
    }

    public static long extra(long[] children, long parent) {
        if (parent < 0) throw new IllegalArgumentException("negative parent population");
        long sum = 0; for (long count : children) { if (count < 0) throw new IllegalArgumentException("negative child population"); sum = Math.addExact(sum, count); }
        return Math.max(0, sum - parent);
    }
    static double maximum(double[] values) { double result = 0; for (double value : values) result = Math.max(result, value); return result; }
    static double lpt(double[] values, int slots) {
        double[] sorted = values.clone(); Arrays.sort(sorted);
        PriorityQueue<Double> workers = new PriorityQueue<>(); for (int slot = 0; slot < slots; slot++) workers.add(0.0);
        for (int index = sorted.length - 1; index >= 0; index--) workers.add(workers.remove() + sorted[index]);
        return Collections.max(workers);
    }
    public static Plan select(double[] work, MicroPartitionPopulation.Statistics population, double budgetFraction, int slots, String mode) {
        return select(work,population,budgetFraction,slots,mode,Collections.<Integer>emptySet());
    }
    /** Private-cost owner evidence gates only the secondary budget allocation. */
    public static Plan select(double[] work, MicroPartitionPopulation.Statistics population,
            double budgetFraction, int slots, String mode, Set<Integer> calibratedOwners) {
        if (calibratedOwners == null) throw new IllegalArgumentException("private calibration evidence missing");
        for (Integer owner : calibratedOwners) if (owner == null || owner < 0 || owner >= work.length)
            throw new IllegalArgumentException("calibrated owner outside plan");
        if (work.length != population.originalAssigned.length || slots < 1 || !Double.isFinite(budgetFraction)
                || budgetFraction < 0 || budgetFraction > 1 || !Arrays.asList("none","hash_full","spatial_full","dependency").contains(mode))
            throw new IllegalArgumentException("invalid micro planning configuration");
        for (double value : work) if (!Double.isFinite(value) || value < 0) throw new IllegalArgumentException("invalid work proxy");
        long assigned = 0; for (long count : population.originalAssigned) assigned = Math.addExact(assigned, count);
        long budget = (long) Math.floor(assigned * budgetFraction);
        MicroPartitionLayout.Candidate[] selected = new MicroPartitionLayout.Candidate[work.length];
        long[][] inputs = new long[work.length][]; for (int owner = 0; owner < inputs.length; owner++) inputs[owner] = new long[]{population.originalAssigned[owner]};
        Plan current = new Plan(selected, population.originalAssigned, inputs, work, mode, budget, slots);
        if (mode.equals("none")) return current;
        // Each event makes one owner alternative eligible at its peak threshold.
        List<Alternative> events = new ArrayList<>();
        for (int owner = 0; owner < work.length; owner++)
            events.add(new Alternative(owner, null, new long[]{population.originalAssigned[owner]},
                    work[owner], 0));
        for (int index = 0; index < population.candidates.length; index++) {
            MicroPartitionLayout.Candidate candidate = population.candidates[index];
            if (candidate.owner < 0 || candidate.owner >= work.length)
                throw new IllegalArgumentException("candidate owner outside plan");
            if (!candidate.responsibility.equals(mode.equals("hash_full") ? "hash" : "spatial")) continue;
            long[] childInputs;
            if (mode.equals("dependency")) childInputs = population.dependencyInputs[index].clone();
            else { childInputs = new long[candidate.pieces]; Arrays.fill(childInputs, population.originalAssigned[candidate.owner]); }
            double peak = 0;
            for (int lane = 0; lane < candidate.pieces; lane++) {
                double laneWork = candidate.work(lane);
                if (!Double.isFinite(laneWork) || laneWork < 0)
                    throw new IllegalArgumentException("invalid candidate work proxy");
                peak = Math.max(peak, laneWork);
            }
            events.add(new Alternative(candidate.owner, candidate, childInputs, peak,
                    extra(childInputs, population.originalAssigned[candidate.owner])));
        }
        events.sort(Comparator.comparingDouble((Alternative a) -> a.peak)
                .thenComparingInt(a -> a.owner).thenComparing(a -> a.key));
        Alternative[] eligible = new Alternative[work.length];
        int uncovered = work.length;
        // Qualifying charge totals can exceed long before a cheaper alternative appears.
        java.math.BigInteger charge = java.math.BigInteger.ZERO;
        java.math.BigInteger cap = java.math.BigInteger.valueOf(budget);
        if (uncovered == 0) return current;
        for (int start = 0; start < events.size();) {
            int end = start + 1;
            while (end < events.size() && events.get(end).peak == events.get(start).peak) end++;
            for (int index = start; index < end; index++) {
                Alternative next = events.get(index), old = eligible[next.owner];
                if (old != null && !next.cheaperThan(old)) continue;
                if (old == null) uncovered--;
                else charge = charge.subtract(java.math.BigInteger.valueOf(old.charge));
                charge = charge.add(java.math.BigInteger.valueOf(next.charge));
                eligible[next.owner] = next;
            }
            if (uncovered == 0 && charge.compareTo(cap) <= 0) {
                for (int owner = 0; owner < eligible.length; owner++) {
                    selected[owner] = eligible[owner].candidate;
                    inputs[owner] = eligible[owner].inputs;
                }
                return refineSplitTails(new Plan(selected, population.originalAssigned, inputs, work, mode, budget, slots), events, calibratedOwners);
            }
            start = end;
        }
        throw new IllegalStateException("no-split alternatives must make the finite family feasible");
    }

    /** Retain the minimax solution, then protect its already-split long tails.
     * This secondary pass is greedy, not an optimum for scheduling or E2E.
     * An unsplit owner needs native calibration before speculative fragmentation.
     */
    private static Plan refineSplitTails(Plan initial, List<Alternative> alternatives, Set<Integer> calibratedOwners) {
        if (!initial.mode.equals("dependency") || calibratedOwners.isEmpty()) return initial;
        Plan current = initial;
        double initialCpu = 0;
        for (double value : initial.work()) initialCpu += value;
        // LPT is an ordering heuristic: a constant-CPU subdivision can change its
        // estimate slightly. Bound the deviation against the initial schedule,
        // not the previous iteration, so repeated upgrades cannot compound slack.
        final double scheduleLimit = initial.makespan * 1.01;
        final double cpuLimit = initialCpu * 1.001;
        if (!Double.isFinite(initialCpu) || !Double.isFinite(scheduleLimit) || !Double.isFinite(cpuLimit)) return initial;
        while (true) {
            Alternative best = null;
            Plan bestPlan = null;
            double bestOwnerPeak = -1;
            for (Alternative next : alternatives) {
                int owner = next.owner;
                MicroPartitionLayout.Candidate previous = current.selected[owner];
                if (!calibratedOwners.contains(owner) || previous == null || next.candidate == null || next.pieces <= previous.pieces) continue;
                double ownerPeak = 0;
                for (int lane = 0; lane < previous.pieces; lane++) ownerPeak = Math.max(ownerPeak, previous.work(lane));
                // A substantial local gain, restricted to the predicted long tail,
                // avoids spending residual reads on short tasks or tiny noisy gains.
                if (ownerPeak < initial.peak * .5 || !(next.peak < ownerPeak)
                        || next.peak > ownerPeak * .75) continue;
                long otherCharge = current.extraRecords - extra(current.taskInputs[owner], current.originalInputs[owner]);
                if (next.charge > current.budgetRecords - otherCharge) continue;
                MicroPartitionLayout.Candidate[] choices = current.selected.clone();
                long[][] childInputs = current.taskInputs.clone();
                choices[owner] = next.candidate; childInputs[owner] = next.inputs;
                Plan trial = new Plan(choices, current.originalInputs, childInputs, current.originalWork,
                        current.mode, current.budgetRecords, current.slots);
                double trialCpu = 0;
                for (double value : trial.work()) trialCpu += value;
                if (!Double.isFinite(trialCpu) || !Double.isFinite(trial.makespan)
                        || trial.peak > initial.peak || trial.makespan > scheduleLimit || trialCpu > cpuLimit) continue;
                // Prioritize the largest residual split tail. Prefer the cheapest
                // qualifying deeper layout so another long tail retains headroom.
                if (best == null || ownerPeak > bestOwnerPeak
                        || ownerPeak == bestOwnerPeak && (owner < best.owner
                        || owner == best.owner && (next.cheaperThan(best)
                        || next.charge == best.charge && next.pieces == best.pieces
                        && next.peak < best.peak))) {
                    best = next; bestPlan = trial; bestOwnerPeak = ownerPeak;
                }
            }
            if (best == null) return current;
            current = bestPlan;
        }
    }

    /** Work-aware sequential splitting control. Shares alternatives, weights and record cap with select(). */
    /** Experiment control: upstream acquisition/refinement remains unchanged. */
    public static Plan selectFinal(String selector,double[] work,MicroPartitionPopulation.Statistics population,
            double budgetFraction,int slots,String mode) {
        if ("joint_peak".equals(selector)) return select(work,population,budgetFraction,slots,mode);
        if ("work_greedy".equals(selector)) return selectGreedy(work,population,budgetFraction,slots,mode);
        throw new IllegalArgumentException("unknown final selector");
    }
    public static Plan selectGreedy(double[] work, MicroPartitionPopulation.Statistics population,
            double budgetFraction, int slots, String mode) {
        Plan base = select(work, population, budgetFraction, slots, "none");
        if (!Arrays.asList("none","hash_full","spatial_full","dependency").contains(mode))
            throw new IllegalArgumentException("invalid greedy micro mode");
        MicroPartitionLayout.Candidate[] selected = base.selected.clone();
        long[][] inputs = base.taskInputs.clone();
        if (mode.equals("none")) return base;
        List<Alternative> alternatives = new ArrayList<>();
        for (int index=0; index<population.candidates.length; index++) {
            MicroPartitionLayout.Candidate candidate = population.candidates[index];
            if (candidate.owner < 0 || candidate.owner >= work.length)
                throw new IllegalArgumentException("candidate owner outside greedy plan");
            if (!candidate.responsibility.equals(mode.equals("hash_full") ? "hash" : "spatial")) continue;
            long[] child;
            if (mode.equals("dependency")) child=population.dependencyInputs[index].clone();
            else { child=new long[candidate.pieces]; Arrays.fill(child,population.originalAssigned[candidate.owner]); }
            if (child.length!=candidate.pieces) throw new IllegalArgumentException("greedy input dimensions");
            double peak=0;
            for (int lane=0; lane<candidate.pieces; lane++) {
                double value=candidate.work(lane);
                if (!Double.isFinite(value) || value<0) throw new IllegalArgumentException("invalid greedy work");
                peak=Math.max(peak,value);
            }
            alternatives.add(new Alternative(candidate.owner,candidate,child,peak,
                    extra(child,population.originalAssigned[candidate.owner])));
        }
        double[] ownerPeak=work.clone();
        long[] ownerCharge=new long[work.length];
        long charged=0;
        while (true) {
            Alternative best=null;
            for (Alternative next:alternatives) {
                int owner=next.owner;
                // Strict LOCAL improvement permits progress when several owners tie globally.
                if (!(next.peak<ownerPeak[owner])) continue;
                long other=charged-ownerCharge[owner];
                if (next.charge>base.budgetRecords-other) continue;
                if (best==null || ownerPeak[owner]>ownerPeak[best.owner]
                        || ownerPeak[owner]==ownerPeak[best.owner] && (owner<best.owner
                        || owner==best.owner && (next.peak<best.peak
                        || next.peak==best.peak && next.cheaperThan(best)))) best=next;
            }
            if (best==null) break;
            charged=charged-ownerCharge[best.owner]+best.charge;
            ownerCharge[best.owner]=best.charge;
            ownerPeak[best.owner]=best.peak;
            selected[best.owner]=best.candidate;
            inputs[best.owner]=best.inputs;
        }
        return new Plan(selected,population.originalAssigned,inputs,work,mode,base.budgetRecords,slots);
    }

    private static final class Alternative {
        final int owner, pieces;
        final MicroPartitionLayout.Candidate candidate;
        final long[] inputs;
        final double peak;
        final long charge;
        final String key;
        Alternative(int owner, MicroPartitionLayout.Candidate candidate, long[] inputs, double peak, long charge) {
            this.owner=owner; this.candidate=candidate; this.inputs=inputs;
            this.peak=peak; this.charge=charge; this.pieces=candidate==null?1:candidate.pieces;
            double[] laneWork=new double[pieces];
            if(candidate==null) laneWork[0]=peak;
            else for(int lane=0;lane<pieces;lane++) laneWork[lane]=candidate.work(lane);
            key=(candidate==null?"unsplit":candidate.signature())+":"+Arrays.toString(inputs)+":"+Arrays.toString(laneWork);
        }
        boolean cheaperThan(Alternative other) {
            return charge<other.charge || charge==other.charge &&
                    (pieces<other.pieces || pieces==other.pieces && key.compareTo(other.key)<0);
        }
    }
    public static Plan replay(Path path, String context, MicroPartitionPopulation.Statistics population,
            double[] work, double budgetFraction, int slots, String mode) throws IOException {
        return replay(path,context,population,work,budgetFraction,slots,mode,null);
    }
    public static Plan replay(Path path, String context, MicroPartitionPopulation.Statistics population,
            double[] work, double budgetFraction, int slots, String mode, String expectedHash) throws IOException {
        if (!mode.equals("spatial_full") && !mode.equals("dependency")) throw new IllegalArgumentException("invalid replay mode");
        String text = new String(Files.readAllBytes(path),StandardCharsets.UTF_8);
        if (expectedHash != null && !MicroPartitionLayout.digest(text).equals(expectedHash)) throw new IllegalArgumentException("replay artifact changed");
        List<String> rows = Arrays.asList(text.split("\\r?\\n"));
        if (rows.size() != work.length + 1 || !rows.get(0).equals("micro-responsibility-v1\t" + context))
            throw new IllegalArgumentException("responsibility context mismatch");
        Plan base = select(work,population,budgetFraction,slots,"none");
        MicroPartitionLayout.Candidate[] selected = base.selected.clone(); long[][] inputs = base.taskInputs.clone();
        for (int owner = 0; owner < work.length; owner++) {
            String[] fields = rows.get(owner+1).split("\t");
            if (fields.length != 2 || Integer.parseInt(fields[0]) != owner) throw new IllegalArgumentException("invalid responsibility owner");
            if (fields[1].equals("unsplit")) continue;
            int found = -1;
            for (int index = 0; index < population.candidates.length; index++) {
                MicroPartitionLayout.Candidate candidate = population.candidates[index];
                if (candidate.owner == owner && candidate.responsibility.equals("spatial") && candidate.signature().equals(fields[1])) found = index;
            }
            if (found < 0) throw new IllegalArgumentException("responsibility anchors/layout mismatch");
            selected[owner] = population.candidates[found]; inputs[owner] = population.dependencyInputs[found].clone();
            if (mode.equals("spatial_full")) Arrays.fill(inputs[owner],population.originalAssigned[owner]);
        }
        return new Plan(selected,population.originalAssigned,inputs,work,mode,base.budgetRecords,slots);
    }
    private MicroPartitionPlanner() { }
}
