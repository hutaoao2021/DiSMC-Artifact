package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;

/** Exact IndexedEMCS kernel over one masked union index. */
public final class MaskedIndexedEMCS {
    java.util.ArrayList<AnchorCostObservation> anchorObservations;
    private long anchorStart,anchorChecksBefore,anchorCandidatesBefore,anchorBucketsBefore,anchorBuildBefore;
    void enableAnchorObservations(){anchorObservations=new java.util.ArrayList<>();}
    private void beginAnchorObservation(){if(anchorObservations==null)return;anchorStart=System.nanoTime();anchorChecksBefore=pointDistanceChecks;anchorCandidatesBefore=candidateCount;anchorBucketsBefore=geometricBucketClassifications;anchorBuildBefore=denseBoundaryBuildNanos;}
    private void endAnchorObservation(int ordinal){if(anchorObservations!=null)anchorObservations.add(new AnchorCostObservation(prepared.point(ordinal),System.nanoTime()-anchorStart,pointDistanceChecks-anchorChecksBefore,candidateCount-anchorCandidatesBefore,geometricBucketClassifications-anchorBucketsBefore,denseBoundaryBuildNanos-anchorBuildBefore));}
    private static final int LOCAL_SKYLINE_BATCH_SIZE = 4096;

    Point q = new Point(100, 101);
    double dc, dc2, twoDc, twoDc2;
    private double pairCountRadiusSquared;
    private boolean trivialPairAnchorBound=true;
    long trivialPairAnchorBoundsUsed;
    int density_k, part_id;
    double cellSize = 1.0;
    public ArrayList<Circle> circles = new ArrayList<Circle>();
    HashMap<Double, Circle> skymap = new HashMap<Double, Circle>();
    private double[] skylineDistances = new double[0];
    private int[] skylineCounts = new int[0];
    private MaskedPreparedNeighborhood.MaskedCellBucket[] countBuckets =
            new MaskedPreparedNeighborhood.MaskedCellBucket[64];

    private SpatialCountTree spatialCountTree;
    long spatialCountQueries, spatialCountNodeVisits, spatialCountBuildNanos;
    private MaskedPreparedNeighborhood prepared;
    private MaskedPreparedNeighborhood.OwnerCache cache;
    private int slot, projectedOrdinal = -1;
    private int[] responsibleAnchors;
    private int lastCountUpperBound = -1;
    private ProbeDominanceFrontier probeFrontier = ProbeDominanceFrontier.EMPTY;
    private boolean newBounds = true;
    private boolean geometricBounds;
    private java.util.IdentityHashMap<MaskedPreparedNeighborhood.MaskedCellBucket,DenseBoundaryCounter> denseBoundaryCounters;
    long denseBoundaryIndexBuilds,denseBoundaryBuildNanos,denseBoundaryQueries;
    private boolean[] rejectedProjections;
    long projectionDuplicatesSkipped;
    long anchorBoundaryCalls;
    private boolean anchorBoundary;
    private boolean deferredCircleAllocation;
    private double candidateGeometryX,candidateGeometryY,candidateGeometryDistance;
    long pairCirclesCreated,candidateBatchFlushes;
    private long pairFactorySkipsBeforeConstruction;
    long countWindowRequests, countWindowHits, countWindowBucketLookups;
    long countWindowEntriesPeak, countWindowReferencesPeak, countWindowEvictions;
    private LinkedHashMap<WindowKey,CountWindow> countWindows;
    private WindowKey windowLookup;
    private int countWindowLimit;
    private long retainedWindowReferences;
    private static final int MAX_CACHED_WINDOW_SPAN=32;
    private static final class WindowKey {
        int x0,x1,y0,y1;
        WindowKey(int x0,int x1,int y0,int y1){this.x0=x0;this.x1=x1;this.y0=y0;this.y1=y1;}
        public int hashCode(){int h=x0;h=31*h+x1;h=31*h+y0;return 31*h+y1;}
        public boolean equals(Object object){if(!(object instanceof WindowKey))return false;
            WindowKey other=(WindowKey)object;return x0==other.x0&&x1==other.x1&&y0==other.y0&&y1==other.y1;}
    }
    private static final class CountWindow {
        final MaskedPreparedNeighborhood.MaskedCellBucket[] buckets;
        final int visiblePopulation;
        CountWindow(MaskedPreparedNeighborhood.MaskedCellBucket[] buckets,int visiblePopulation){
            this.buckets=buckets;this.visiblePopulation=visiblePopulation;}
    }

    long frontierPrunedAnchors, frontierBoundLookups;
    long candidateCount, singlePointCandidateCount, pairCandidateCount, zWindowChecks, pointDistanceChecks;
    long projectedCandidates, projectedCountHits, projectedBoundHits;
    long maskChecks, maskFiltered;
    long geometricBucketClassifications, geometricEarlyRejects;

    public MaskedIndexedEMCS(double dc) {
        this.dc = dc;
        dc2 = dc * dc;
        twoDc = 2 * dc;
        twoDc2 = 4 * dc * dc;
        double countDiameter=Math.nextDown(twoDc+.005);
        pairCountRadiusSquared=countDiameter>=0?countDiameter*countDiameter:Double.NaN;
    }

    public void setCellConfig(double cellSize) {
        this.cellSize = cellSize;
    }

    public void usePrepared(MaskedPreparedNeighborhood prepared,
            int slot, int owner, int piece, int pieces) {
        usePrepared(prepared, slot, owner, piece, pieces, EngineOptions.FULL);
    }

    public void usePrepared(MaskedPreparedNeighborhood prepared,
            int slot, int owner, int piece, int pieces, EngineOptions options) {
        if (prepared == null) throw new IllegalArgumentException("prepared index is null");
        if (options == null) throw new IllegalArgumentException("engine options are null");
        if (piece < 0 || piece >= pieces) throw new IllegalArgumentException("invalid query responsibility");
        if (prepared.ownerId(slot) != owner) throw new IllegalArgumentException("owner/slot mismatch");
        this.prepared = prepared;
        // Split shards can execute in different Spark tasks at the same time.
        // Their anchor lanes are disjoint, so a private cache preserves exactness
        // while avoiding races on the shared per-owner cache.
        this.cache = options.preparedReuse && pieces == 1
                ? prepared.cache(slot)
                : new MaskedPreparedNeighborhood.OwnerCache(prepared.pointCount());
        this.newBounds = options.newBounds;
        this.anchorBoundary=options.anchorBoundary;
        this.deferredCircleAllocation=options.deferredCircleAllocation;
        this.geometricBounds = options.geometricBounds;
        denseBoundaryCounters=options.denseBoundaryCounting?new java.util.IdentityHashMap<>():null;
        // Private to this evaluation: rejection is recorded only after actual evaluation, never a contextual geometry guard.
        this.rejectedProjections=options.projectedDedup ? new boolean[prepared.pointCount()] : null;
        countWindowLimit=options.countWindowCache ? prepared.countingBucketCount() : 0;
        countWindows=countWindowLimit==0 ? null : new LinkedHashMap<WindowKey,CountWindow>(16,.75f,true);
        windowLookup=countWindows==null ? null : new WindowKey(0,0,0,0);
        retainedWindowReferences=0;

        this.slot = slot;
        this.part_id = owner;
        this.responsibleAnchors = prepared.responsibleAnchorOrdinals(slot, piece, pieces);
        spatialCountTree=null;
        spatialCountQueries=spatialCountNodeVisits=spatialCountBuildNanos=0;
        if (options.spatialCountTree) {
            if (!Double.isFinite(dc) || dc <= 0)
                throw new IllegalArgumentException("spatial tree requires a finite positive radius");
            long buildStart=System.nanoTime();
            int visible=0;
            for (int i=0;i<prepared.pointCount();i++) if (prepared.visible(slot,i)) visible++;
            double[] xs=new double[visible], ys=new double[visible]; int at=0;
            for (int i=0;i<prepared.pointCount();i++) if (prepared.visible(slot,i)) {
                xs[at]=prepared.point(i).x; ys[at++]=prepared.point(i).y;
            }
            spatialCountTree=new SpatialCountTree(xs,ys);
            spatialCountBuildNanos=System.nanoTime()-buildStart;
        }

    }

    public void useProbeFrontier(ProbeDominanceFrontier frontier) {
        if(frontier==null)throw new IllegalArgumentException("missing probe frontier");
        this.probeFrontier=frontier;
    }

    /** Prepass only: no changes to the existing candidate loop, count caches or input visibility.
     * Safety inherits the same supported-domain candidate/count closure as dependency trimming.
     * Whole intersecting count buckets bound coverage; a prefix >= threshold only means keep.
     */
    public void pruneProbeDominatedAnchors() {
        pruneProbeDominatedAnchors(false);
    }

    public void pruneProbeDominatedAnchors(boolean coarseGrid) {
        if(prepared==null)throw new IllegalStateException("prepared index required");
        if(probeFrontier.witnessDistances()==0 || !Double.isFinite(dc) || dc<.01 || dc>1e5
                || !Double.isFinite(q.x) || !Double.isFinite(q.y) || Math.abs(q.x)>1e7 || Math.abs(q.y)>1e7)return;
        for(int i=0;i<prepared.pointCount();i++){
            MaskedPreparedNeighborhood.IndexedPoint p=prepared.point(i);
            if(!Double.isFinite(p.x)||!Double.isFinite(p.y)||Math.abs(p.x)>1e7||Math.abs(p.y)>1e7)return;
        }
        int[] kept=new int[responsibleAnchors.length];int used=0;
        for(int ordinal:responsibleAnchors){
            MaskedPreparedNeighborhood.IndexedPoint p=prepared.point(ordinal);
            double lower=conservativeCandidateDistance(p);
            int required=probeFrontier.minimumRequiredCount(lower,density_k);
            if(required>density_k && bucketBoxUpperBelow(p,required,coarseGrid))frontierPrunedAnchors++;
            else kept[used++]=ordinal;
        }
        responsibleAnchors=java.util.Arrays.copyOf(kept,used);
    }

    private double conservativeCandidateDistance(MaskedPreparedNeighborhood.IndexedPoint p) {
        double extent=Math.nextUp(dc+.02);
        double dx=Math.max(0,Math.nextDown(Math.nextDown(Math.abs(p.x-q.x))-extent));
        double dy=Math.max(0,Math.nextDown(Math.nextDown(Math.abs(p.y-q.y))-extent));
        double xx=Math.max(0,Math.nextDown(dx*dx)),yy=Math.max(0,Math.nextDown(dy*dy));
        double squared=Math.max(0,Math.nextDown(xx+yy));
        // Outward arithmetic and a full objective quantum keep rounded-distance ties eligible.
        return Math.max(0,Math.nextDown(Math.nextDown(Math.sqrt(squared))-.01));
    }

    private boolean bucketBoxUpperBelow(MaskedPreparedNeighborhood.IndexedPoint p,int required,boolean coarseGrid) {
        double extent=Math.nextUp(twoDc+.02),grid=coarseGrid?prepared.cellSize:prepared.countCellSize;
        if(!(grid>0)||!Double.isFinite(grid))return false;
        double x0=Math.floor(Math.nextDown(Math.nextDown(p.x-extent)/grid)),x1=Math.floor(Math.nextUp(Math.nextUp(p.x+extent)/grid));
        double y0=Math.floor(Math.nextDown(Math.nextDown(p.y-extent)/grid)),y1=Math.floor(Math.nextUp(Math.nextUp(p.y+extent)/grid));
        if(!Double.isFinite(x0)||!Double.isFinite(x1)||!Double.isFinite(y0)||!Double.isFinite(y1)
                || x0<=Integer.MIN_VALUE || y0<=Integer.MIN_VALUE || x1>=Integer.MAX_VALUE || y1>=Integer.MAX_VALUE
                || x1-x0>128 || y1-y0>128)return false;
        int upper=0;
        for(int x=(int)x0;x<=(int)x1;x++)for(int y=(int)y0;y<=(int)y1;y++){
            frontierBoundLookups++;
            MaskedPreparedNeighborhood.MaskedCellBucket bucket=coarseGrid?prepared.bucket(pack(x,y)):prepared.countBucket(pack(x,y));
            if(bucket!=null){upper+=prepared.visibleCount(slot,bucket);if(upper>=required)return false;}
        }
        return true;
    }

    public void method(double dc) {
        if (prepared == null) throw new IllegalStateException("prepared index required");
        if(anchorBoundary) methodWithAnchorBoundary(dc);
        else methodWithoutAnchorBoundary(dc);
    }

    private void methodWithAnchorBoundary(double dc) {
        for(int anchorOrdinal:responsibleAnchors){beginAnchorObservation();try{processAnchor(anchorOrdinal,dc);}finally{endAnchorObservation(anchorOrdinal);}}
        flushCandidateCircles();
    }

    // Experiment executor JVMs explicitly keep this body out of the outer loop.
    // This copy preserves the original operation/order; OFF retains the original loop.
    private void processAnchor(int anchorOrdinal,double dc) {
        anchorBoundaryCalls++;
        MaskedPreparedNeighborhood.IndexedPoint p1 = prepared.point(anchorOrdinal);

        Circle anchorCircle = buildAnchorCircle(p1);
        // Ideal anchor distance is not a certified lower bound for rounded candidate centers.

        int p1AnchorUpperBound = anchorCircle.cirnum;
        Circle singlePointCandidate = buildSinglePointCircle(p1);
        candidateCount++;
        singlePointCandidateCount++;
        int localSingleRequiredCount = minimumRequiredCount(singlePointCandidate.discenq);
        int singleRequiredCount = Math.max(localSingleRequiredCount,
                probeFrontier.minimumRequiredCount(singlePointCandidate.discenq,density_k));
        // External witnesses must not strengthen inherited 2r geometric bounds.
        if (p1AnchorUpperBound >= localSingleRequiredCount
                || !anchorContains(p1,singlePointCandidate.centerX,singlePointCandidate.centerY)) {
            if(rejectedProjections!=null && rejectedProjections[p1.ordinal]) {
                projectionDuplicatesSkipped++;
            } else {
            int singlePointCount = countProjectedCircle(p1, singleRequiredCount);
            if(rejectedProjections!=null && (singlePointCount<singleRequiredCount || singlePointCount<density_k))
                rejectedProjections[p1.ordinal]=true;
            if (singlePointCount >= singleRequiredCount && singlePointCount >= density_k) {
                singlePointCandidate.cirnum = singlePointCount;
                circles.add(singlePointCandidate);
                if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) flushCandidateCircles();
            }
            }
        }
        int minCellX = (int) Math.floor((p1.x - twoDc) / cellSize);
        int maxCellX = (int) Math.floor((p1.x + twoDc) / cellSize);
        int minCellY = (int) Math.floor((p1.y - twoDc) / cellSize);
        int maxCellY = (int) Math.floor((p1.y + twoDc) / cellSize);

        for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
            for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                MaskedPreparedNeighborhood.MaskedCellBucket bucket = prepared.bucket(pack(cellX, cellY));
                if (bucket == null) continue;
                for (MaskedPreparedNeighborhood.IndexedPoint p2
                        : prepared.visiblePoints(slot, bucket)) {
                    if (p1.id >= p2.id) continue;

                    pointDistanceChecks++;
                    double d12Squared = squaredDistance(p1.x, p1.y, p2.x, p2.y);
                    if (d12Squared <= 0 || d12Squared > twoDc2) continue;

                    MaskedPreparedNeighborhood.IndexedPoint first = p1;
                    MaskedPreparedNeighborhood.IndexedPoint second = p2;
                    if (BaselinePointOrder.compare(
                            first.baselineOrderX, first.baselineOrderY, first.id,
                            second.baselineOrderX, second.baselineOrderY, second.id) > 0) {
                        first = p2;
                        second = p1;
                    }
                    Circle candidate=null;
                        boolean validGeometry;
                        if(deferredCircleAllocation)validGeometry=prepareCandidateGeometry(first,second,d12Squared);
                        else {candidate=buildCandidateCircle(first,second,d12Squared);validGeometry=candidate!=null;}
                    candidateCount++;
                    pairCandidateCount++;
                    if (!validGeometry) continue;
                        double candidateDistance=deferredCircleAllocation?candidateGeometryDistance:candidate.discenq;
                        double candidateX=deferredCircleAllocation?candidateGeometryX:candidate.centerX;
                        double candidateY=deferredCircleAllocation?candidateGeometryY:candidate.centerY;

                    int localRequiredCount = minimumRequiredCount(candidateDistance);
                    int requiredCount = Math.max(localRequiredCount,
                            probeFrontier.minimumRequiredCount(candidateDistance,density_k));
                    if (p1AnchorUpperBound < localRequiredCount && anchorContains(p1,candidateX,candidateY)) continue;
                    if (anchorContains(p2,candidateX,candidateY) && pairAnchorBoundBelow(p2,d12Squared,localRequiredCount)) continue;

                    int candidateDensity;
                    int cachedProjection = !newBounds || projectedOrdinal < 0
                            ? 0 : cache.projectedCounts.get(projectedOrdinal);
                    if (projectedOrdinal >= 0) projectedCandidates++;
                    if (cachedProjection != 0) {
                        projectedCountHits++;
                        candidateDensity = cachedProjection - 1;
                    } else {
                        int knownBound = !newBounds || projectedOrdinal < 0 ? 0
                                : cache.projectedUpperBounds.get(projectedOrdinal);
                        if (knownBound != 0 && knownBound - 1 < requiredCount) {
                            projectedBoundHits++;
                            if(rejectedProjections!=null)rejectedProjections[projectedOrdinal]=true;
                            continue;
                        }
                        candidateDensity = countPointsNear(
                                candidateX, candidateY, dc2, dc, requiredCount);
                        if (newBounds && projectedOrdinal >= 0) {
                            if (lastCountUpperBound < 0) {
                                cache.projectedCounts.set(projectedOrdinal, candidateDensity + 1);
                            } else {
                                int bound = lastCountUpperBound + 1;
                                for (;;) {
                                    int old = cache.projectedUpperBounds.get(projectedOrdinal);
                                    if (old != 0 && old <= bound) break;
                                    if (cache.projectedUpperBounds.compareAndSet(projectedOrdinal, old, bound)) break;
                                }
                            }
                        }
                    }
                    // Only failed candidates are terminal: thresholds never decrease.
                    // Keep accepted duplicates to preserve the baseline batch-flush schedule.
                    // Contextual p1/p2 geometry guards above must never mark rejection.
                    if (candidateDensity < requiredCount || candidateDensity < density_k) {
                        if(rejectedProjections!=null && projectedOrdinal>=0)rejectedProjections[projectedOrdinal]=true;
                        continue;
                    }
                    if(deferredCircleAllocation)candidate=materializeCandidateGeometry();
                        candidate.cirnum = candidateDensity;
                    circles.add(candidate);
                    if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) flushCandidateCircles();
                }
            }
        }
    }

    private void methodWithoutAnchorBoundary(double dc) {
        if (prepared == null) throw new IllegalStateException("prepared index required");
        for (int anchorOrdinal : responsibleAnchors) {
            beginAnchorObservation();try{
            MaskedPreparedNeighborhood.IndexedPoint p1 = prepared.point(anchorOrdinal);

            Circle anchorCircle = buildAnchorCircle(p1);
            // Candidate-specific certificates below replace ideal-anchor dominance.

            int p1AnchorUpperBound = anchorCircle.cirnum;
            Circle singlePointCandidate = buildSinglePointCircle(p1);
            candidateCount++;
            singlePointCandidateCount++;
            int localSingleRequiredCount = minimumRequiredCount(singlePointCandidate.discenq);
            int singleRequiredCount = Math.max(localSingleRequiredCount,
                    probeFrontier.minimumRequiredCount(singlePointCandidate.discenq,density_k));
            // External witnesses must not strengthen inherited 2r geometric bounds.
            if (p1AnchorUpperBound >= localSingleRequiredCount
                || !anchorContains(p1,singlePointCandidate.centerX,singlePointCandidate.centerY)) {
                if(rejectedProjections!=null && rejectedProjections[p1.ordinal]) {
                    projectionDuplicatesSkipped++;
                } else {
                int singlePointCount = countProjectedCircle(p1, singleRequiredCount);
                if(rejectedProjections!=null && (singlePointCount<singleRequiredCount || singlePointCount<density_k))
                    rejectedProjections[p1.ordinal]=true;
                if (singlePointCount >= singleRequiredCount && singlePointCount >= density_k) {
                    singlePointCandidate.cirnum = singlePointCount;
                    circles.add(singlePointCandidate);
                    if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) flushCandidateCircles();
                }
                }
            }
            int minCellX = (int) Math.floor((p1.x - twoDc) / cellSize);
            int maxCellX = (int) Math.floor((p1.x + twoDc) / cellSize);
            int minCellY = (int) Math.floor((p1.y - twoDc) / cellSize);
            int maxCellY = (int) Math.floor((p1.y + twoDc) / cellSize);

            for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
                for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                    MaskedPreparedNeighborhood.MaskedCellBucket bucket = prepared.bucket(pack(cellX, cellY));
                    if (bucket == null) continue;
                    for (MaskedPreparedNeighborhood.IndexedPoint p2
                            : prepared.visiblePoints(slot, bucket)) {
                        if (p1.id >= p2.id) continue;

                        pointDistanceChecks++;
                        double d12Squared = squaredDistance(p1.x, p1.y, p2.x, p2.y);
                        if (d12Squared <= 0 || d12Squared > twoDc2) continue;

                        MaskedPreparedNeighborhood.IndexedPoint first = p1;
                        MaskedPreparedNeighborhood.IndexedPoint second = p2;
                        if (BaselinePointOrder.compare(
                                first.baselineOrderX, first.baselineOrderY, first.id,
                                second.baselineOrderX, second.baselineOrderY, second.id) > 0) {
                            first = p2;
                            second = p1;
                        }
                        Circle candidate=null;
                        boolean validGeometry;
                        if(deferredCircleAllocation)validGeometry=prepareCandidateGeometry(first,second,d12Squared);
                        else {candidate=buildCandidateCircle(first,second,d12Squared);validGeometry=candidate!=null;}
                        candidateCount++;
                        pairCandidateCount++;
                        if (!validGeometry) continue;
                        double candidateDistance=deferredCircleAllocation?candidateGeometryDistance:candidate.discenq;
                        double candidateX=deferredCircleAllocation?candidateGeometryX:candidate.centerX;
                        double candidateY=deferredCircleAllocation?candidateGeometryY:candidate.centerY;

                        int localRequiredCount = minimumRequiredCount(candidateDistance);
                        int requiredCount = Math.max(localRequiredCount,
                                probeFrontier.minimumRequiredCount(candidateDistance,density_k));
                        if (p1AnchorUpperBound < localRequiredCount && anchorContains(p1,candidateX,candidateY)) continue;
                        if (anchorContains(p2,candidateX,candidateY) && pairAnchorBoundBelow(p2,d12Squared,localRequiredCount)) continue;

                        int candidateDensity;
                        int cachedProjection = !newBounds || projectedOrdinal < 0
                                ? 0 : cache.projectedCounts.get(projectedOrdinal);
                        if (projectedOrdinal >= 0) projectedCandidates++;
                        if (cachedProjection != 0) {
                            projectedCountHits++;
                            candidateDensity = cachedProjection - 1;
                        } else {
                            int knownBound = !newBounds || projectedOrdinal < 0 ? 0
                                    : cache.projectedUpperBounds.get(projectedOrdinal);
                            if (knownBound != 0 && knownBound - 1 < requiredCount) {
                                projectedBoundHits++;
                                if(rejectedProjections!=null)rejectedProjections[projectedOrdinal]=true;
                                continue;
                            }
                            candidateDensity = countPointsNear(
                                    candidateX, candidateY, dc2, dc, requiredCount);
                            if (newBounds && projectedOrdinal >= 0) {
                                if (lastCountUpperBound < 0) {
                                    cache.projectedCounts.set(projectedOrdinal, candidateDensity + 1);
                                } else {
                                    int bound = lastCountUpperBound + 1;
                                    for (;;) {
                                        int old = cache.projectedUpperBounds.get(projectedOrdinal);
                                        if (old != 0 && old <= bound) break;
                                        if (cache.projectedUpperBounds.compareAndSet(projectedOrdinal, old, bound)) break;
                                    }
                                }
                            }
                        }
                        // Only failed candidates are terminal: thresholds never decrease.
                        // Keep accepted duplicates to preserve the baseline batch-flush schedule.
                        // Contextual p1/p2 geometry guards above must never mark rejection.
                        if (candidateDensity < requiredCount || candidateDensity < density_k) {
                            if(rejectedProjections!=null && projectedOrdinal>=0)rejectedProjections[projectedOrdinal]=true;
                            continue;
                        }
                        if(deferredCircleAllocation)candidate=materializeCandidateGeometry();
                        candidate.cirnum = candidateDensity;
                        circles.add(candidate);
                        if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) flushCandidateCircles();
                    }
                }
            }
            }finally{endAnchorObservation(anchorOrdinal);}
        }
        flushCandidateCircles();
    }

    /** Operator comparator only: reuse reference geometry without running local search. */
    Circle referenceSingleGeometry(MaskedPreparedNeighborhood.IndexedPoint point) {
        return buildSinglePointCircle(point);
    }

    Circle referencePairGeometry(MaskedPreparedNeighborhood.IndexedPoint first,
            MaskedPreparedNeighborhood.IndexedPoint second, double pairDistanceSquared) {
        return buildCandidateCircle(first, second, pairDistanceSquared);
    }

    private Circle buildAnchorCircle(MaskedPreparedNeighborhood.IndexedPoint point) {
        Circle circle = new Circle();
        circle.discenq = Math.max(0.0, point.queryDistance - dc);
        circle.cirnum = getAnchorCount(point);
        return circle;
    }

    private Circle buildSinglePointCircle(MaskedPreparedNeighborhood.IndexedPoint point) {
        Circle circle = new Circle();
        circle.centerX = point.projectedX;
        circle.centerY = point.projectedY;
        circle.discenq = point.projectedDistance;
        return circle;
    }

    private int countProjectedCircle(MaskedPreparedNeighborhood.IndexedPoint point, int requiredCount) {
        projectedCandidates++;
        int cached = !newBounds ? 0 : cache.projectedCounts.get(point.ordinal);
        if (cached != 0) {
            projectedCountHits++;
            return cached - 1;
        }
        int knownBound = !newBounds ? 0 : cache.projectedUpperBounds.get(point.ordinal);
        if (knownBound != 0 && knownBound - 1 < requiredCount) {
            projectedBoundHits++;
            return knownBound - 1;
        }
        int count = countPointsNear(point.projectedX, point.projectedY, dc2, dc, requiredCount);
        if (newBounds) {
            if (lastCountUpperBound < 0) cache.projectedCounts.set(point.ordinal, count + 1);
            else cache.projectedUpperBounds.set(point.ordinal, lastCountUpperBound + 1);
        }
        return count;
    }

    /** Paired visible records already certify a count of at least two.
     * This certificate only bypasses a bound rejection; it is never cached as an exact count.
     * The rounded count-radius guard preserves the reference predicate at numeric boundaries.
     */
    public void useTrivialPairAnchorBound(boolean enabled){trivialPairAnchorBound=enabled;}
    private boolean pairAnchorBoundBelow(MaskedPreparedNeighborhood.IndexedPoint partner,double pairDistanceSquared,int required){
        if(trivialPairAnchorBound && required<=2 && Double.isFinite(pairCountRadiusSquared)
                && pairDistanceSquared<=pairCountRadiusSquared){trivialPairAnchorBoundsUsed++;return false;}
        return getAnchorCount(partner)<required;
    }

    private boolean anchorContains(MaskedPreparedNeighborhood.IndexedPoint p,double x,double y) {
        return NumericalCoverage.containsCandidate(p.x,p.y,x,y,dc,NumericalCoverage.anchorRadius(dc));
    }

    private int getAnchorCount(MaskedPreparedNeighborhood.IndexedPoint point) {
        int cached = cache.anchorCounts.get(point.ordinal);
        if (cached != 0) return cached - 1;
        double safeRadius=NumericalCoverage.anchorRadius(dc);
        int count = countPointsNear(point.x, point.y, safeRadius*safeRadius, safeRadius, 0);
        cache.anchorCounts.set(point.ordinal, count + 1);
        return count;
    }

    private int lowerSkylineIndex(double distance) {
        if (skylineDistances.length == 0 && skymap != null && !skymap.isEmpty()) rebuildSkylineIndex();
        int low = 0, high = skylineDistances.length;
        while (low < high) {
            int middle = (low + high) >>> 1;
            if (Double.compare(skylineDistances[middle], distance) < 0) low = middle + 1;
            else high = middle;
        }
        return low - 1;
    }

    private boolean isDominatedByCurrentSkyline(Circle candidate) {
        int lower = lowerSkylineIndex(candidate.discenq);
        return lower >= 0 && skylineCounts[lower] > candidate.cirnum;
    }

    private int minimumRequiredCount(double distance) {
        int lower = lowerSkylineIndex(distance);
        return lower < 0 ? density_k : Math.max(density_k, skylineCounts[lower] + 1);
    }

    private Circle buildCandidateCircle(MaskedPreparedNeighborhood.IndexedPoint p1,
            MaskedPreparedNeighborhood.IndexedPoint p2, double d12Squared) {
        double qp1 = p1.queryDistance, qp2 = p2.queryDistance;
        projectedOrdinal = -1;
        MaskedPreparedNeighborhood.IndexedPoint anchor = qp1 > qp2 ? p1 : p2;
        MaskedPreparedNeighborhood.IndexedPoint other = qp1 > qp2 ? p2 : p1;
        boolean projected=squaredDistance(other.x,other.y,anchor.projectedX,anchor.projectedY)<=dc2;
        if(projected) {
            projectedOrdinal=anchor.ordinal;
            if(rejectedProjections!=null && rejectedProjections[projectedOrdinal]) {
                projectionDuplicatesSkipped++;pairFactorySkipsBeforeConstruction++;
                return null;
            }
        }
        Circle candidate = new Circle();
        if(projected) {
            candidate.centerX=anchor.projectedX;
            candidate.centerY=anchor.projectedY;
        } else {
            Point center = circleCenter(p1.x,p1.y,p2.x,p2.y,d12Squared);
            if(center==null)return null;
            candidate.centerX=center.x;
            candidate.centerY=center.y;
        }
        candidate.discenq = projectedOrdinal < 0
                ? round2(distance(candidate.centerX, candidate.centerY, q.x, q.y))
                : anchor.projectedDistance;
        return candidate;
    }

    /** Private scratch geometry only; no candidate/count/emission decision is skipped. */
    private boolean prepareCandidateGeometry(MaskedPreparedNeighborhood.IndexedPoint p1,
            MaskedPreparedNeighborhood.IndexedPoint p2,double d12Squared) {
        double qp1=p1.queryDistance,qp2=p2.queryDistance;
        projectedOrdinal=-1;
        MaskedPreparedNeighborhood.IndexedPoint anchor=qp1>qp2?p1:p2;
        MaskedPreparedNeighborhood.IndexedPoint other=qp1>qp2?p2:p1;
        boolean projected=squaredDistance(other.x,other.y,anchor.projectedX,anchor.projectedY)<=dc2;
        if(projected){
            projectedOrdinal=anchor.ordinal;
            if(rejectedProjections!=null && rejectedProjections[projectedOrdinal]){
                projectionDuplicatesSkipped++;return false;
            }
            candidateGeometryX=anchor.projectedX;candidateGeometryY=anchor.projectedY;
        }else{
            Point center=circleCenter(p1.x,p1.y,p2.x,p2.y,d12Squared);
            if(center==null)return false;
            candidateGeometryX=center.x;candidateGeometryY=center.y;
        }
        candidateGeometryDistance=projectedOrdinal<0
                ?round2(distance(candidateGeometryX,candidateGeometryY,q.x,q.y)):anchor.projectedDistance;
        return true;
    }

    // OFF: each attempted pair constructs once, except the explicit pre-factory rejection.
    // Derive its logical constructor count without adding a write to every baseline pair.
    long logicalPairCirclesCreated(){
        return deferredCircleAllocation?pairCirclesCreated:pairCandidateCount-pairFactorySkipsBeforeConstruction;
    }

    private Circle materializeCandidateGeometry(){
        pairCirclesCreated++;
        Circle candidate=new Circle();candidate.centerX=candidateGeometryX;candidate.centerY=candidateGeometryY;
        candidate.discenq=candidateGeometryDistance;return candidate;
    }

    private int countPointsNear(double centerX, double centerY,
            double radiusSquared, double radius, int requiredCount) {
        lastCountUpperBound = -1;
        double roundedRadius = Math.nextDown(radius + 0.005);
        double roundedRadiusSquared = roundedRadius * roundedRadius;
        if (spatialCountTree != null) {
            // Tree certificates follow the same exact/partial cache distinction as grid counting.
            spatialCountQueries++;
            int count=spatialCountTree.count(centerX,centerY,roundedRadiusSquared,requiredCount);
            lastCountUpperBound=spatialCountTree.lastUpperBound;
            pointDistanceChecks+=spatialCountTree.lastPointChecks;
            spatialCountNodeVisits+=spatialCountTree.lastNodeVisits;
            return count;
        }

        // The cell envelope must contain the same radius used by the point predicate.
        int minCellX = (int) Math.floor((centerX - roundedRadius) / prepared.countCellSize);
        int maxCellX = (int) Math.floor((centerX + roundedRadius) / prepared.countCellSize);
        int minCellY = (int) Math.floor((centerY - roundedRadius) / prepared.countCellSize);
        int maxCellY = (int) Math.floor((centerY + roundedRadius) / prepared.countCellSize);

        countWindowRequests++;
        long windowCells=Math.max(0L,(long)maxCellX-minCellX+1)*Math.max(0L,(long)maxCellY-minCellY+1);
        if (geometricBounds && requiredCount > 0) {
            countWindowBucketLookups+=windowCells;
            return countWithGeometricBounds(centerX, centerY, roundedRadiusSquared,
                    minCellX, maxCellX, minCellY, maxCellY, requiredCount);
        }

        CountWindow window=countWindows==null ? null : countWindow(minCellX,maxCellX,minCellY,maxCellY);
        if(window==null)countWindowBucketLookups+=windowCells;
        if (requiredCount <= 0) {
            int count = 0;
            if(window!=null){
                for(MaskedPreparedNeighborhood.MaskedCellBucket bucket:window.buckets)
                    count+=countBucket(centerX,centerY,roundedRadiusSquared,bucket);
                return count;
            }
            for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
                for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                    MaskedPreparedNeighborhood.MaskedCellBucket bucket = prepared.countBucket(pack(cellX, cellY));
                    if (bucket != null) count += countBucket(centerX, centerY, roundedRadiusSquared, bucket);
                }
            }
            return count;
        }

        int remainingPotential = 0, used = 0;
        MaskedPreparedNeighborhood.MaskedCellBucket[] buckets=countBuckets;
        if(window!=null){buckets=window.buckets;used=buckets.length;remainingPotential=window.visiblePopulation;}
        else {
        for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
            for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                MaskedPreparedNeighborhood.MaskedCellBucket bucket = prepared.countBucket(pack(cellX, cellY));
                if (bucket != null) {
                    remainingPotential += prepared.visibleCount(slot, bucket);
                    if (used == countBuckets.length) {
                        countBuckets = java.util.Arrays.copyOf(countBuckets, used * 2);
                    }
                    countBuckets[used++] = bucket;
                }
            }
        }
        buckets=countBuckets;
        }
        int count = 0;
        for (int i = 0; i < used; i++) {
            MaskedPreparedNeighborhood.MaskedCellBucket bucket = buckets[i];
            remainingPotential -= prepared.visibleCount(slot, bucket);
            count += countBucket(centerX, centerY, roundedRadiusSquared, bucket);
            if (count + remainingPotential < requiredCount) {
                lastCountUpperBound = count + remainingPotential;
                return count;
            }
        }
        return count;
    }

    /** Reuse only immutable dependency metadata, never a circle count or partial certificate. */
    private CountWindow countWindow(int x0,int x1,int y0,int y1) {
        long width=(long)x1-x0+1,height=(long)y1-y0+1;
        if(width<=0 || height<=0 || width>MAX_CACHED_WINDOW_SPAN || height>MAX_CACHED_WINDOW_SPAN
                || x1==Integer.MAX_VALUE || y1==Integer.MAX_VALUE)return null;
        // The mutable lookup key is never inserted; stored keys and arrays remain unchanged.
        windowLookup.x0=x0;windowLookup.x1=x1;windowLookup.y0=y0;windowLookup.y1=y1;
        CountWindow hit=countWindows.get(windowLookup);
        if(hit!=null){countWindowHits++;return hit;}
        countWindowBucketLookups+=width*height;
        int used=0,population=0;
        for(int x=x0;x<=x1;x++)for(int y=y0;y<=y1;y++){
            MaskedPreparedNeighborhood.MaskedCellBucket bucket=prepared.countBucket(pack(x,y));
            if(bucket!=null){
                population+=prepared.visibleCount(slot,bucket);
                if(used==countBuckets.length)countBuckets=java.util.Arrays.copyOf(countBuckets,used*2);
                countBuckets[used++]=bucket;
            }
        }
        CountWindow result=new CountWindow(java.util.Arrays.copyOf(countBuckets,used),population);
        if(countWindows.size()==countWindowLimit){
            java.util.Iterator<CountWindow> oldest=countWindows.values().iterator();
            CountWindow removed=oldest.next();oldest.remove();
            retainedWindowReferences-=removed.buckets.length;countWindowEvictions++;
        }
        countWindows.put(new WindowKey(x0,x1,y0,y1),result);
        retainedWindowReferences+=used;
        countWindowEntriesPeak=Math.max(countWindowEntriesPeak,countWindows.size());
        countWindowReferencesPeak=Math.max(countWindowReferencesPeak,retainedWindowReferences);
        return result;
    }

    private int countWithGeometricBounds(double centerX, double centerY, double radiusSquared,
            int minCellX, int maxCellX, int minCellY, int maxCellY, int requiredCount) {
        int count = 0, remainingPotential = 0, used = 0;
        for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
            for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                MaskedPreparedNeighborhood.MaskedCellBucket bucket = prepared.countBucket(pack(cellX, cellY));
                if (bucket == null) continue;
                int visible = prepared.visibleCount(slot, bucket);
                if (visible == 0) continue;
                geometricBucketClassifications++;
                double nearX = centerX < bucket.minX ? bucket.minX - centerX
                        : centerX > bucket.maxX ? centerX - bucket.maxX : 0;
                double nearY = centerY < bucket.minY ? bucket.minY - centerY
                        : centerY > bucket.maxY ? centerY - bucket.maxY : 0;
                if (nearX * nearX + nearY * nearY > radiusSquared) continue;
                double farX = Math.max(Math.abs(centerX - bucket.minX), Math.abs(centerX - bucket.maxX));
                double farY = Math.max(Math.abs(centerY - bucket.minY), Math.abs(centerY - bucket.maxY));
                if (farX * farX + farY * farY <= radiusSquared) {
                    count += visible;
                } else {
                    remainingPotential += visible;
                    if (used == countBuckets.length) {
                        countBuckets = java.util.Arrays.copyOf(countBuckets, used * 2);
                    }
                    countBuckets[used++] = bucket;
                }
            }
        }
        if (remainingPotential == 0) return count;
        if (count + remainingPotential < requiredCount) {
            lastCountUpperBound = count + remainingPotential;
            geometricEarlyRejects++;
            return count;
        }
        for (int index = 0; index < used; index++) {
            MaskedPreparedNeighborhood.MaskedCellBucket bucket = countBuckets[index];
            remainingPotential -= prepared.visibleCount(slot, bucket);
            count += countVisiblePoints(centerX, centerY, radiusSquared, bucket);
            if (remainingPotential > 0 && count + remainingPotential < requiredCount) {
                lastCountUpperBound = count + remainingPotential;
                return count;
            }
        }
        return count;
    }

    private int countBucket(double x, double y, double radiusSquared,
            MaskedPreparedNeighborhood.MaskedCellBucket bucket) {
        int visible = prepared.visibleCount(slot, bucket);
        if (bucket.ordinals.length >= 8) {
            double farX = Math.max(Math.abs(x - bucket.minX), Math.abs(x - bucket.maxX));
            double farY = Math.max(Math.abs(y - bucket.minY), Math.abs(y - bucket.maxY));
            if (farX * farX + farY * farY <= radiusSquared) return visible;
            double nearX = x < bucket.minX ? bucket.minX - x : x > bucket.maxX ? x - bucket.maxX : 0;
            double nearY = y < bucket.minY ? bucket.minY - y : y > bucket.maxY ? y - bucket.maxY : 0;
            if (nearX * nearX + nearY * nearY > radiusSquared) return 0;
        }
        return countVisiblePoints(x, y, radiusSquared, bucket);
    }

    private int countVisiblePoints(double x, double y, double radiusSquared,
            MaskedPreparedNeighborhood.MaskedCellBucket bucket) {
        if(denseBoundaryCounters!=null && prepared.visibleCount(slot,bucket)>=256){
            DenseBoundaryCounter counter=denseBoundaryCounters.get(bucket);
            if(counter==null){
                long start=System.nanoTime();counter=new DenseBoundaryCounter(prepared.visiblePoints(slot,bucket));
                denseBoundaryCounters.put(bucket,counter);denseBoundaryIndexBuilds++;denseBoundaryBuildNanos+=System.nanoTime()-start;
            }
            int result=counter.count(x,y,radiusSquared);denseBoundaryQueries++;
            pointDistanceChecks+=counter.lastPointChecks;geometricBucketClassifications+=counter.lastNodeVisits;
            return result;
        }
        int count = 0;
        for (MaskedPreparedNeighborhood.IndexedPoint point : prepared.visiblePoints(slot, bucket)) {
            pointDistanceChecks++;
            if (squaredDistance(x, y, point.x, point.y) <= radiusSquared) count++;
        }
        return count;
    }

    private void flushCandidateCircles() {
        if (circles.isEmpty() && (skymap == null || skymap.isEmpty())) return;
        candidateBatchFlushes++;
        ArrayList<Circle> merged = new ArrayList<Circle>(
                circles.size() + (skymap == null ? 0 : skymap.size()));
        merged.addAll(circles);
        if (skymap != null && !skymap.isEmpty()) merged.addAll(skymap.values());
        Collections.sort(merged, new Comparator<Circle>() {
            public int compare(Circle left, Circle right) {
                return Double.compare(left.discenq, right.discenq);
            }
        });
        skymap = skylineCircle(merged);
        rebuildSkylineIndex();
        circles.clear();
    }

    private void rebuildSkylineIndex() {
        int size = skymap == null ? 0 : skymap.size();
        skylineDistances = new double[size];
        skylineCounts = new int[size];
        if (size == 0) return;
        int i = 0;
        for (double distance : skymap.keySet()) skylineDistances[i++] = distance;
        java.util.Arrays.sort(skylineDistances);
        for (i = 0; i < size; i++) skylineCounts[i] = skymap.get(skylineDistances[i]).cirnum;
    }

    private static long pack(int cellX, int cellY) {
        return (((long) cellX) << 32) ^ (cellY & 0xffffffffL);
    }

    private static double squaredDistance(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2, dy = y1 - y2;
        return dx * dx + dy * dy;
    }

    private static double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(squaredDistance(x1, y1, x2, y2));
    }

    private static double round2(double value) {
        return (double) Math.round(value * 100) / 100;
    }

    private Point circleCenter(double x1, double y1, double x2, double y2, double d12Squared) {
        if (!MicroPartitionLayout.safeCoordinate(x1) || !MicroPartitionLayout.safeCoordinate(y1)
                || !MicroPartitionLayout.safeCoordinate(x2) || !MicroPartitionLayout.safeCoordinate(y2) || dc < 0.01 || dc > 100000)
            return legacyCircleCenter(x1,y1,x2,y2,d12Squared);
        if (d12Squared <= 0 || d12Squared > twoDc2) return null;
        double dx = x2-x1, dy = y2-y1;
        double middleX = x1+dx/2, middleY = y1+dy/2;
        Point result = new Point();
        if (Math.abs(d12Squared-twoDc2) < 1e-9) {
            result.x = middleX; result.y = middleY; return result;
        }
        // Work in the pair's local frame; global squared coordinates lose precision.
        // Subnormal squared distances can lose a large fraction of the pair norm.
        // Keep ordinary-input arithmetic unchanged; hypot scales tiny components safely.
        double pairNorm = d12Squared < Double.MIN_NORMAL ? Math.hypot(dx,dy) : Math.sqrt(d12Squared);
        double scale = Math.sqrt(Math.max(0,dc2-d12Squared/4))/pairNorm;
        double offsetX = -dy*scale, offsetY = dx*scale;
        // Preserve the reference upper-Y (or right-X for vertical pairs) tie order.
        if (offsetY < 0 || offsetY == 0 && offsetX < 0) {
            offsetX = -offsetX; offsetY = -offsetY;
        }
        double firstX = middleX+offsetX, firstY = middleY+offsetY;
        double secondX = middleX-offsetX, secondY = middleY-offsetY;
        boolean first = distance(firstX,firstY,q.x,q.y) < distance(secondX,secondY,q.x,q.y);
        result.x = first ? firstX : secondX;
        result.y = first ? firstY : secondY;
        return result;
    }

    private Point legacyCircleCenter(double x1, double y1, double x2, double y2, double d12Squared) {
        Point p1 = new Point(), p2 = new Point(), result = new Point();
        if (d12Squared > twoDc2) return null;
        if (Math.abs(d12Squared - twoDc2) < 1e-9) {
            result.x = (x1 + x2) / 2;
            result.y = (y1 + y2) / 2;
            return result;
        }
        if (x1 != x2) {
            double c1 = (x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1) / (2 * (x2 - x1));
            double c2 = (y2 - y1) / (x2 - x1);
            double a = c2 * c2 + 1;
            double b = 2 * x1 * c2 - 2 * c1 * c2 - 2 * y1;
            double c = x1 * x1 - 2 * x1 * c1 + c1 * c1 + y1 * y1 - dc2;
            double delta = b * b - 4 * a * c;
            if (delta < 0) return null;
            if (y1 == y2) {
                double middleX = (x1 + x2) / 2;
                double vertical = Math.sqrt(Math.max(0, dc2 - ((x1 - x2) / 2) * ((x1 - x2) / 2)));
                p1.x = middleX; p1.y = y1 + vertical;
                p2.x = middleX; p2.y = y1 - vertical;
            } else {
                p1.y = (-b + Math.sqrt(delta)) / (2 * a);
                p1.x = c1 - c2 * p1.y;
                p2.y = (-b - Math.sqrt(delta)) / (2 * a);
                p2.x = c1 - c2 * p2.y;
            }
        } else {
            double middleY = (y1 + y2) / 2;
            double horizontal = Math.sqrt(Math.max(0, dc2 - ((y1 - y2) / 2) * ((y1 - y2) / 2)));
            p1.y = middleY; p1.x = x1 + horizontal;
            p2.y = middleY; p2.x = x1 - horizontal;
        }
        double first = distance(p1.x, p1.y, q.x, q.y);
        double second = distance(p2.x, p2.y, q.x, q.y);
        return first < second ? p1 : p2;
    }

    public HashMap<Double, Circle> skylineCircle(ArrayList<Circle> candidates) {
        HashMap<Double, Circle> map = new HashMap<Double, Circle>();
        int max = -1;
        for (Circle circle : candidates) {
            if (map.containsKey(circle.discenq)) {
                if (isPreferredAtSameDistance(circle, map.get(circle.discenq))) {
                    map.put(circle.discenq, circle);
                    max = circle.getCirnum();
                }
            } else if (circle.getCirnum() > max) {
                map.put(circle.discenq, circle);
                max = circle.getCirnum();
            }
        }
        return map;
    }

    private boolean isPreferredAtSameDistance(Circle candidate, Circle current) {
        if (candidate.getCirnum() != current.getCirnum()) {
            return candidate.getCirnum() > current.getCirnum();
        }
        int centerXOrder = Double.compare(candidate.centerX, current.centerX);
        return centerXOrder < 0
                || (centerXOrder == 0 && Double.compare(candidate.centerY, current.centerY) < 0);
    }
}
