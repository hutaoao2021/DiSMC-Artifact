package com;

public final class DistributedSMCHilbertMBRBaseline {
    private DistributedSMCHilbertMBRBaseline() {
    }

    public static void main(String[] args) throws Exception {
        DistributedSMCZOrderDPBoundBaseline.run(args, true);
    }
}
