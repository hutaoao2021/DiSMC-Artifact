package com;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;

/** Writer-local, bounded memoization of the existing two-decimal text representation. */
public final class MemberTextFormatter {
    private static final int MAX_VALUES = 65536;
    private final HashMap<Double,String> cache;
    private final int capacity;

    public MemberTextFormatter(boolean enabled) { this(enabled, MAX_VALUES); }
    MemberTextFormatter(boolean enabled, int capacity) {
        if (capacity < 0) throw new IllegalArgumentException("negative text cache capacity");
        this.capacity = capacity;
        cache = enabled ? new HashMap<Double,String>() : null;
    }
    public String format(double value) {
        if (cache == null) return legacy(value);
        String text = cache.get(value);
        if (text == null) {
            text = legacy(value);
            if (cache.size() < capacity) cache.put(value, text);
        }
        return text;
    }
    int cachedValues() { return cache == null ? 0 : cache.size(); }
    private String legacy(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }
    public static void appendOutputTiming(String output, long elapsedNanos) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(output, true))) {
            writer.write("result_text_output_time_s: "
                    + String.format(Locale.ROOT, "%.3f", elapsedNanos / 1e9) + "\r\n");
        }
    }
}
