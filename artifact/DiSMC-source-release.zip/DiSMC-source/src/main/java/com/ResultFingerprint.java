package com;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;

public final class ResultFingerprint {
    private ResultFingerprint() { }
    public static String of(HashMap<Double, Circle> skyline) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            List<Circle> circles = new ArrayList<Circle>(skyline.values());
            circles.sort(Comparator.comparingDouble(circle -> circle.discenq));
            for (Circle circle : circles) {
                update(digest, scaled2(circle.discenq));
                update(digest, circle.cirnum);
                update(digest, scaled2(circle.centerX));
                update(digest, scaled2(circle.centerY));
                List<Point> members = circle.p == null ? new ArrayList<Point>() : new ArrayList<Point>(circle.p);
                members.sort(Comparator.comparingDouble((Point point) -> point.x).thenComparingDouble(point -> point.y));
                update(digest, members.size());
                for (Point point : members) {
                    update(digest, scaled2(point.x));
                    update(digest, scaled2(point.y));
                }
            }
            Formatter formatter = new Formatter();
            for (byte value : digest.digest()) formatter.format("%02x", value & 0xff);
            String result = formatter.toString();
            formatter.close();
            return result;
        } catch (Exception error) {
            throw new IllegalStateException("cannot fingerprint skyline", error);
        }
    }
    private static long scaled2(double value) {
        return Math.round(value * 100.0d);
    }
    private static void update(MessageDigest digest, long value) {
        digest.update(Long.toString(value).getBytes(StandardCharsets.UTF_8));
        digest.update((byte) '\n');
    }
}
