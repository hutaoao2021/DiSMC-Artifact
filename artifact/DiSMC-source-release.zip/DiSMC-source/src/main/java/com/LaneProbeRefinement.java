package com;
import java.io.Serializable;
import java.util.*;

/** Bounded fresh observations in a fixed candidate's responsibility strata. */
public final class LaneProbeRefinement {
 public static final class Target implements Serializable {
  public final MicroPartitionLayout.Candidate guide;
  public final int[] quotas;
  public final long[] excludedIds;
  public Target(MicroPartitionLayout.Candidate guide,int[] quotas,long[] excluded){
   if(guide==null||quotas.length!=guide.pieces)throw new IllegalArgumentException("invalid lane probe target");
   this.guide=guide;this.quotas=quotas.clone();excludedIds=excluded.clone();Arrays.sort(excludedIds);
   for(int i=0;i<excludedIds.length;i++)if(i>0&&excludedIds[i]==excludedIds[i-1])throw new IllegalArgumentException("duplicate completed ID");
   for(int l=0;l<quotas.length;l++)if(quotas[l]<0||quotas[l]>guide.anchorCount(l))throw new IllegalArgumentException("invalid stratum quota");
  }
  public int sampleCount(){return Arrays.stream(quotas).sum();}
 }
 private static final class Proposal {
  final MicroPartitionLayout.Candidate guide;final SampledAnchorCostProbe.Probe observed;
  final boolean selected;final double uncertainty,priority;
  Proposal(MicroPartitionLayout.Candidate c,SampledAnchorCostProbe.Probe p,boolean selected,double uncertainty,double priority){guide=c;observed=p;this.selected=selected;this.uncertainty=uncertainty;this.priority=priority;}
 }
 public static Target[] targets(MicroPartitionPopulation.Statistics source,MicroPartitionPlanner.Plan plan,
   SampledAnchorCostProbe.Probe[] probes,int budget,int ownerLimit,int minimum,int maximum){
  if(budget<0||ownerLimit<1||minimum<4||maximum<minimum||maximum>32)throw new IllegalArgumentException("invalid lane probe budget");
  Map<Integer,SampledAnchorCostProbe.Probe> observed=new HashMap<>();for(SampledAnchorCostProbe.Probe p:probes)observed.put(p.owner,p);
  // One owner per round: reserve equal shares for owners exposed by subsequent calibration.
  int batchBudget=ownerLimit==1?budget:budget/ownerLimit;
  List<Proposal> candidates=new ArrayList<>();
  for(int o=0;o<source.core.length;o++){
   SampledAnchorCostProbe.Probe p=observed.get(o);if(p==null||p.observations.length==0||p.samples>=source.core[o])continue;
   MicroPartitionLayout.Candidate chosen=plan.selected[o],guide=null;
   double uncertainty=variance(p.observations),taskPeak=plan.originalWork[o];
   if(chosen!=null){taskPeak=0;for(int l=0;l<chosen.pieces;l++)taskPeak=Math.max(taskPeak,chosen.work(l));}
   double priority=chosen!=null&&!p.privateLaneCosts?taskPeak*chosen.pieces:taskPeak;
   if(priority<plan.peak*.25)continue;
   for(int i=0;i<source.candidates.length;i++){
    MicroPartitionLayout.Candidate c=source.candidates[i];int requested=0;
    for(int l=0;l<c.pieces;l++)requested+=Math.min(minimum,c.anchorCount(l));
    if(c.owner==o&&c.responsibility.equals("spatial")&&requested<=batchBudget
      &&MicroPartitionPlanner.extra(source.dependencyInputs[i],source.originalAssigned[o])<=plan.budgetRecords
      &&eligible(c,p,minimum)&&(guide==null||c.pieces>guide.pieces||c.pieces==guide.pieces&&c.signature().compareTo(guide.signature())<0))guide=c;
   }
   // Private skyline/cache costs depend on the exact geometry, not just regional coverage.
   // Measure the selected physical candidate when it fits, before projecting other depths.
   if(chosen!=null&&chosen.responsibility.equals("spatial")&&eligible(chosen,p,minimum)){
    int requested=0;for(int l=0;l<chosen.pieces;l++)requested+=Math.min(minimum,chosen.anchorCount(l));
    if(requested<=batchBudget)guide=chosen;
   }
   if(guide==null)continue;
   int[] counts=counts(guide,p.observations);int missing=0,nonempty=0;
   for(int l=0;l<guide.pieces;l++)if(guide.anchorCount(l)>0){nonempty++;if(counts[l]<Math.min(minimum,guide.anchorCount(l)))missing++;}
   if(missing==0&&uncertainty<1&&(chosen==null||p.privateLaneCosts))continue;
   // A deep split measured with one shared owner skyline has an unverified apparent gain.
   // Until private-state coverage exists, rank its risk by the full selected wave of tasks.
   candidates.add(new Proposal(guide,p,chosen!=null,uncertainty,priority));
  }
  // Current physical tail, rather than prior selected status, determines observation priority.
  candidates.sort(Comparator.<Proposal>comparingDouble(p -> -p.priority)
      .thenComparingDouble(p -> -p.uncertainty).thenComparingInt(p -> p.guide.owner));
  // If reserved shares cannot fund any guide, try the whole remainder before giving up.
  // Owner allowance is an upper bound, not a requirement to observe that many owners.
  if(candidates.isEmpty())return ownerLimit>1?targets(source,plan,probes,budget,1,minimum,maximum):new Target[0];
  Proposal p=candidates.get(0);int[] quota=new int[p.guide.pieces];
  for(int l=0;l<quota.length;l++)quota[l]=(int)Math.min(minimum,p.guide.anchorCount(l));
  int remaining=batchBudget-Arrays.stream(quota).sum();int[] old=counts(p.guide,p.observed.observations);
  // Top-up only within this owner's reserved share; other rounds keep their allowance.
  for(int round=minimum;round<maximum&&remaining>0&&p.uncertainty>=1;round++)
   for(int l=0;l<quota.length&&remaining>0;l++)if(quota[l]<p.guide.anchorCount(l)-old[l]){quota[l]++;remaining--;}
  return new Target[]{new Target(p.guide,quota,p.observed.anchorIds)};
 }
 private static boolean eligible(MicroPartitionLayout.Candidate c,SampledAnchorCostProbe.Probe p,int minimum){
  int[] old=counts(c,p.observations);
  for(int l=0;l<c.pieces;l++)if(c.anchorCount(l)>0&&c.anchorCount(l)-old[l]<Math.min(minimum,c.anchorCount(l)))return false;
  return true;
 }
 static int[] counts(MicroPartitionLayout.Candidate c,AnchorCostObservation[] observations){
  int[] result=new int[c.pieces];for(AnchorCostObservation a:observations){int l=c.laneOf(a.anchor);if(l<0||l>=c.pieces)throw new IllegalArgumentException("observed anchor not in candidate");result[l]++;}return result;
 }
 private static double variance(AnchorCostObservation[] observations){
  double sum=0,squares=0;for(AnchorCostObservation a:observations){double ns=Math.max(0,a.kernelNanos-a.indexBuildNanos);sum+=ns;squares+=ns*ns;}
  if(sum==0)return 0;double mean=sum/observations.length;return Math.max(0,squares/observations.length/(mean*mean)-1);
 }
 public static long[] selectIds(MaskedSharedBlock complete,Target target){
  if(complete.ownerIds.length!=1||complete.ownerIds[0]!=target.guide.owner)throw new IllegalArgumentException("probe owner mismatch");
  BoundedProbeIds[] selection=new BoundedProbeIds[target.guide.pieces];for(int l=0;l<selection.length;l++)if(target.quotas[l]>0)selection[l]=new BoundedProbeIds(target.quotas[l]);
  long[] population=new long[selection.length];
  for(int ordinal:complete.ownerAnchorOrdinals[0]){
   Point p=complete.unionPoints[ordinal];int lane=target.guide.laneOf(p);if(lane<0||lane>=selection.length)throw new IllegalStateException("candidate responsibility missing");population[lane]++;
   if(selection[lane]!=null&&Arrays.binarySearch(target.excludedIds,p.id)<0)selection[lane].add(p.id);
  }
  long[] ids=new long[target.sampleCount()];int position=0;
  for(int l=0;l<selection.length;l++){
   if(population[l]!=target.guide.anchorCount(l))throw new IllegalStateException("stratified guide differs from complete responsibility population");
   if(selection[l]==null)continue;long[] local=selection[l].ids();if(local.length!=target.quotas[l])throw new IllegalStateException("fresh stratum sample incomplete");System.arraycopy(local,0,ids,position,local.length);position+=local.length;
  }
  Arrays.sort(ids);return ids;
 }
 public static long[] unionCompleted(long[] initial,long[] fresh){
  if(initial==null)initial=new long[0];long[] combined=Arrays.copyOf(initial,initial.length+fresh.length);System.arraycopy(fresh,0,combined,initial.length,fresh.length);Arrays.sort(combined);
  for(int i=1;i<combined.length;i++)if(combined[i]==combined[i-1])throw new IllegalArgumentException("anchor initiation repeated in refinement");return combined;
 }
 public static final class Update {
  public final MicroPartitionPopulation.Statistics population;public final double[] ownerWork;
  Update(MicroPartitionPopulation.Statistics p,double[] w){population=p;ownerWork=w;}
 }
 public static SampledAnchorCostProbe.Calibration calibrate(double[] proxy,long[] core,Target[] targets,SampledAnchorCostProbe.Probe[] fresh){
  MicroPartitionPopulation.Statistics empty=new MicroPartitionPopulation.Statistics(core,core,new MicroPartitionLayout.Candidate[0],new long[0][]);
  Update update=update(empty,empty,proxy,targets,fresh);double[] ratios=new double[fresh.length];
  double[] measuredWork=new double[fresh.length];Map<Integer,Target> byOwner=new HashMap<>();for(Target t:targets)byOwner.put(t.guide.owner,t);
  for(int i=0;i<ratios.length;i++){
   SampledAnchorCostProbe.Probe p=fresh[i];measuredWork[i]=update.ownerWork[p.owner];
   if(p.privateLaneCosts){Target t=byOwner.get(p.owner);int[] n=counts(t.guide,p.observations);double total=Arrays.stream(p.laneFixedNanos).sum();
    for(AnchorCostObservation a:p.observations){int l=t.guide.laneOf(a.anchor);total+=(double)t.guide.anchorCount(l)/n[l]*Math.max(0,a.kernelNanos-a.indexBuildNanos);}measuredWork[i]=total;
   }
   ratios[i]=measuredWork[i]/proxy[p.owner];
  }Arrays.sort(ratios);
  double scale=ratios.length%2==1?ratios[ratios.length/2]:(ratios[ratios.length/2-1]+ratios[ratios.length/2])/2;
  double[] work=proxy.clone();for(int o=0;o<work.length;o++)work[o]*=scale;
  for(int i=0;i<fresh.length;i++)work[fresh[i].owner]=measuredWork[i];
  return new SampledAnchorCostProbe.Calibration(work,1e-9,fresh.length,new int[0]);
 }
 /** Compare private lanes against a full-owner replay of exactly the same fresh identities. */
 public static Update updateWithParentReplay(boolean paired,MicroPartitionPopulation.Statistics base,MicroPartitionPopulation.Statistics fallback,
   double[] oldWork,Target[] targets,SampledAnchorCostProbe.Probe[] fresh,SampledAnchorCostProbe.Probe[] parents){
  return paired?updatePaired(base,fallback,oldWork,targets,fresh,parents):update(base,fallback,oldWork,targets,fresh);
 }
 public static Update updatePaired(MicroPartitionPopulation.Statistics base,MicroPartitionPopulation.Statistics fallback,
   double[] oldWork,Target[] targets,SampledAnchorCostProbe.Probe[] fresh,SampledAnchorCostProbe.Probe[] parents){
  if(fresh.length!=parents.length)throw new IllegalArgumentException("paired probe owner count differs");
  Map<Integer,SampledAnchorCostProbe.Probe> full=new HashMap<>();
  for(SampledAnchorCostProbe.Probe p:parents)
   if(p==null||p.privateLaneCosts||full.put(p.owner,p)!=null)throw new IllegalArgumentException("invalid full-owner replay context");
  for(SampledAnchorCostProbe.Probe p:fresh){
   SampledAnchorCostProbe.Probe parent=full.get(p.owner);
   if(!p.privateLaneCosts||parent==null||p.samples!=parent.samples)throw new IllegalArgumentException("paired owner context differs");
   long[] a=p.anchorIds.clone(),b=parent.anchorIds.clone();Arrays.sort(a);Arrays.sort(b);
   if(!Arrays.equals(a,b))throw new IllegalArgumentException("paired fresh identities differ");
  }
  Update lanes=update(base,fallback,oldWork,targets,fresh);
  MicroPartitionPopulation.Statistics empty=new MicroPartitionPopulation.Statistics(base.originalAssigned,base.core,new MicroPartitionLayout.Candidate[0],new long[0][]);
  Update parentCosts=update(empty,empty,oldWork,targets,parents);
  return new Update(lanes.population,parentCosts.ownerWork);
 }
 public static Update update(MicroPartitionPopulation.Statistics base,MicroPartitionPopulation.Statistics fallback,
   double[] oldWork,Target[] targets,SampledAnchorCostProbe.Probe[] fresh){
  Map<Integer,Target> guides=new HashMap<>();for(Target t:targets)if(guides.put(t.guide.owner,t)!=null)throw new IllegalArgumentException("duplicate target owner");
  Map<Integer,SampledAnchorCostProbe.Probe> measured=new HashMap<>();Map<Integer,double[]> weights=new HashMap<>();
  double[] ownerWork=oldWork.clone();Map<Integer,Double> fixed=new HashMap<>(),recurring=new HashMap<>();
  for(SampledAnchorCostProbe.Probe p:fresh){
   Target t=guides.get(p.owner);if(t==null||measured.put(p.owner,p)!=null||p.samples!=p.observations.length||p.samples!=p.anchorIds.length)throw new IllegalArgumentException("invalid fresh probe identity");
   Set<Long> seen=new HashSet<>();for(AnchorCostObservation a:p.observations)
    if(!seen.add(a.anchor.id)||Arrays.binarySearch(t.excludedIds,a.anchor.id)>=0)throw new IllegalArgumentException("repeated fresh initiation");
   Set<Long> requested=new HashSet<>();
   for(long id:p.anchorIds)if(!seen.contains(id)||!requested.add(id))throw new IllegalArgumentException("fresh identity missing or repeated");
   int[] n=counts(t.guide,p.observations);if(!Arrays.equals(n,t.quotas))throw new IllegalStateException("requested stratum coverage not observed");
   double[] w=new double[p.samples];double estimate=0,observedNs=0;
   for(int i=0;i<w.length;i++){
    AnchorCostObservation a=p.observations[i];int l=t.guide.laneOf(a.anchor);w[i]=(double)t.guide.anchorCount(l)/n[l];
    estimate+=w[i]*Math.max(0,a.kernelNanos-a.indexBuildNanos);observedNs+=a.kernelNanos;
   }
   double setup=p.prepareNanos+p.setupNanos+(double)p.denseBoundaryBuildNanos+Math.max(0,p.kernelNanos-p.setupNanos-observedNs);
   if(p.privateLaneCosts){
    if(p.laneInputRecords.length!=t.guide.pieces||p.laneFixedNanos.length!=t.guide.pieces)throw new IllegalArgumentException("private guide fixed costs missing");
    for(int i=0;i<base.candidates.length;i++)if(base.candidates[i].signature().equals(t.guide.signature())
      &&!Arrays.equals(p.laneInputRecords,base.dependencyInputs[i]))
     throw new IllegalStateException("private guide input counts differ from exact planned dependencies");
    double inputSum=0,fixedSum=0;for(int l=0;l<t.guide.pieces;l++){
     if(p.laneInputRecords[l]<0||!Double.isFinite(p.laneFixedNanos[l])||p.laneFixedNanos[l]<0)throw new IllegalArgumentException("invalid private guide preparation cost");
     inputSum+=p.laneInputRecords[l];fixedSum+=p.laneFixedNanos[l];
    }
    if(inputSum<=0)throw new IllegalArgumentException("private guide has no complete input");
    setup=fixedSum/inputSum*base.originalAssigned[p.owner];
   }else ownerWork[p.owner]=estimate+setup;
   weights.put(p.owner,w);fixed.put(p.owner,setup);recurring.put(p.owner,estimate);
  }
  if(measured.size()!=guides.size())throw new IllegalStateException("target owner absent from fresh measurements");
  if(base.candidates.length!=fallback.candidates.length)throw new IllegalArgumentException("candidate family changed during observation");
  MicroPartitionLayout.Candidate[] adjusted=fallback.candidates.clone();
  for(int index=0;index<adjusted.length;index++){
   MicroPartitionLayout.Candidate c=base.candidates[index];SampledAnchorCostProbe.Probe p=measured.get(c.owner);if(p==null)continue;
   double[] sampleWeight=weights.get(c.owner);int[] n=new int[c.pieces];double[] weightedNs=new double[c.pieces],population=new double[c.pieces],squares=new double[c.pieces],weightSquares=new double[c.pieces];
   for(int i=0;i<p.observations.length;i++){
    AnchorCostObservation a=p.observations[i];int l=c.laneOf(a.anchor);if(l<0||l>=c.pieces)throw new IllegalStateException("fresh observation outside candidate");
    double ns=Math.max(0,a.kernelNanos-a.indexBuildNanos),w=sampleWeight[i];n[l]++;weightedNs[l]+=w*ns;population[l]+=w;squares[l]+=w*ns*ns;weightSquares[l]+=w*w;
   }
   double priorTotal=0;for(int l=0;l<c.pieces;l++)priorTotal+=c.work(l);
   double[] work=new double[c.pieces];double sum=0,ownerRecurring=recurring.get(c.owner);
   for(int l=0;l<c.pieces;l++){
    double prior=priorTotal>0?c.work(l)/priorTotal*ownerRecurring:0;
    double effective=population[l]>0?population[l]*population[l]/weightSquares[l]:0;
    if(n[l]>=Math.min(4,c.anchorCount(l))&&effective+1e-9>=Math.min(4,c.anchorCount(l))&&population[l]>0){
     double mean=weightedNs[l]/population[l];double cvSquared=mean>0?Math.max(0,squares[l]/population[l]/(mean*mean)-1):0;
     // Consistent regions retain their estimate; noisy regions shrink toward the original spatial proxy.
     double confidence=effective/(effective+4*cvSquared);
     work[l]=confidence*mean*c.anchorCount(l)+(1-confidence)*prior;
    }else work[l]=prior;
    sum+=work[l];
   }
   for(int l=0;l<c.pieces;l++){
    if(p.privateLaneCosts&&c.signature().equals(guides.get(c.owner).guide.signature()))work[l]=weightedNs[l];
    else if(sum>0)work[l]*=ownerRecurring/sum;
    double charge=p.privateLaneCosts&&c.signature().equals(guides.get(c.owner).guide.signature())
      ?p.laneFixedNanos[l]:fixed.get(c.owner)*(double)base.dependencyInputs[index][l]/Math.max(1L,base.originalAssigned[c.owner]);
    work[l]+=charge;
   }
   adjusted[index]=c.withPhysicalWork(work);
  }
  MicroPartitionPopulation.Statistics result=new MicroPartitionPopulation.Statistics(base.originalAssigned,base.core,adjusted,base.dependencyInputs);
  result.sourceRecordsScanned=fallback.sourceRecordsScanned;result.collectMs=fallback.collectMs;result.populationMs=fallback.populationMs;result.originalPopulationMs=fallback.originalPopulationMs;
  result.dependencyPopulationScans=fallback.dependencyPopulationScans;result.populationFromCells=fallback.populationFromCells;result.populationDirect=fallback.populationDirect;result.populationCollectionFused=fallback.populationCollectionFused;
  result.fallbacks.addAll(fallback.fallbacks);return new Update(result,ownerWork);
 }
 private LaneProbeRefinement(){ }
}
