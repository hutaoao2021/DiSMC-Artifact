package com;
import java.io.Serializable;
import java.util.*;
/** Experimental implicit rule. Not wired to the production planner. */
public final class ImplicitResponsibility implements Serializable {
 private final int pieces;private final double radius,cellSize;private final boolean hash;
 private final Map<Long,Integer> lanes=new HashMap<>();private final long[] counts;private final double[][] boxes;
 private ImplicitResponsibility(int pieces,double radius,boolean hash){this(pieces,radius,radius,hash);}
 private ImplicitResponsibility(int pieces,double radius,double cellSize,boolean hash){
  if(!Double.isFinite(cellSize)||cellSize<=0)throw new IllegalArgumentException("invalid cell size");
  if((pieces!=2&&pieces!=4)||!Double.isFinite(radius)||radius<.01||radius>100000)throw new IllegalArgumentException("unsupported rule");
  this.pieces=pieces;this.radius=radius;this.cellSize=cellSize;this.hash=hash;counts=new long[pieces];boxes=new double[pieces][4];
 }
 public static ImplicitResponsibility hash(int pieces,double radius){return new ImplicitResponsibility(pieces,radius,true);}
 public static ImplicitResponsibility cells(long[][] source,int pieces,double radius){return cells(source,pieces,radius,radius);}
 public static ImplicitResponsibility cells(long[][] source,int pieces,double radius,double cellSize){
  ImplicitResponsibility rule=new ImplicitResponsibility(pieces,radius,cellSize,false);if(source==null||source.length<pieces)throw new IllegalArgumentException("insufficient cells");
  List<long[]> cells=new ArrayList<>();Set<Long> seen=new HashSet<>();
  for(long[] cell:source){if(cell==null||cell.length!=3||cell[0]!=(int)cell[0]||cell[1]!=(int)cell[1]||cell[2]<=0)throw new IllegalArgumentException("invalid cell");if(!seen.add(key((int)cell[0],(int)cell[1])))throw new IllegalArgumentException("duplicate cell");cells.add(cell.clone());}
  rule.split(cells,0,pieces);return rule;
 }
 private void split(List<long[]> cells,int start,int n){
  if(n==1){double[] b=boxes[start];b[0]=b[1]=Double.POSITIVE_INFINITY;b[2]=b[3]=Double.NEGATIVE_INFINITY;
   for(long[] c:cells){lanes.put(key((int)c[0],(int)c[1]),start);counts[start]=Math.addExact(counts[start],c[2]);b[0]=Math.min(b[0],Math.nextDown(c[0]*cellSize));b[1]=Math.min(b[1],Math.nextDown(c[1]*cellSize));b[2]=Math.max(b[2],Math.nextUp((c[0]+1)*cellSize));b[3]=Math.max(b[3],Math.nextUp((c[1]+1)*cellSize));}return;}
  long minX=Long.MAX_VALUE,minY=minX,maxX=Long.MIN_VALUE,maxY=maxX,total=0;
  for(long[] c:cells){minX=Math.min(minX,c[0]);maxX=Math.max(maxX,c[0]);minY=Math.min(minY,c[1]);maxY=Math.max(maxY,c[1]);total=Math.addExact(total,c[2]);}
  final int axis=maxX-minX>=maxY-minY?0:1;
  cells.sort(Comparator.<long[]>comparingLong(c->c[axis]).thenComparingLong(c->c[1-axis]));
  long prefix=0,best=Long.MAX_VALUE;int cut=-1;
  for(int i=1;i<cells.size();i++){prefix=Math.addExact(prefix,cells.get(i-1)[2]);if(i<n/2||cells.size()-i<n/2)continue;
   // Avoid 2*prefix overflow while retaining exact integer nearest-half ordering.
   long delta=Math.abs(prefix-(total-prefix));if(delta<best){best=delta;cut=i;}}
  if(cut<0)throw new IllegalArgumentException("insufficient cells");
  split(new ArrayList<>(cells.subList(0,cut)),start,n/2);split(new ArrayList<>(cells.subList(cut,cells.size())),start+n/2,n/2);
 }
 public int pieces(){return pieces;}
 public boolean isHash(){return hash;}
 public int laneOf(long id,int cellX,int cellY){return hash?BudgetedQueryShards.shard(id,pieces):lanes.getOrDefault(key(cellX,cellY),-1);}
 public long[] coreCounts(){if(hash)throw new IllegalStateException("hash cardinalities require aggregated counters");return counts.clone();}
 public boolean retainsCell(int lane,int x,int y){
  if(lane<0||lane>=pieces)throw new IllegalArgumentException("invalid lane");if(hash)return true;
  double[] b=boxes[lane];if(!safe(b[0])||!safe(b[1])||!safe(b[2])||!safe(b[3])||!safe(x*cellSize)||!safe(y*cellSize)||!safe(((long)x+1)*cellSize)||!safe(((long)y+1)*cellSize))return true;double dx=Math.max(0,Math.max(b[0]-Math.nextUp(((long)x+1)*cellSize),Math.nextDown(x*cellSize)-b[2]));double dy=Math.max(0,Math.max(b[1]-Math.nextUp(((long)y+1)*cellSize),Math.nextDown(y*cellSize)-b[3]));return Math.hypot(dx,dy)<=Math.nextUp(2*radius+.02);
 }
 public String signature(){StringBuilder s=new StringBuilder("implicit-v2:").append(hash).append(':').append(pieces).append(':').append(Double.toHexString(radius)).append(':').append(Double.toHexString(cellSize));TreeMap<Long,Integer> sorted=new TreeMap<>(lanes);for(Map.Entry<Long,Integer> e:sorted.entrySet())s.append('|').append(e.getKey()).append(':').append(e.getValue());return MicroPartitionLayout.digest(s.toString());}
 private static boolean safe(double value){return Double.isFinite(value)&&Math.abs(value)<=10000000;}
 private static long key(int x,int y){return ((long)x<<32)|(y&0xffffffffL);}
}
