package com;

import java.util.Collections;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.apache.spark.Dependency;
import org.apache.spark.HashPartitioner;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Logical owner views backed by one physical masked point union per bundle. */
public final class MaskedSharedNeighborhoodRDD extends RDD<Tuple2<Integer, Point>> {
    private static final class OwnerPartition implements Partition {
        final int owner, slot;
        final Partition parent;
        OwnerPartition(int owner, int slot, Partition parent) {
            this.owner = owner; this.slot = slot; this.parent = parent;
        }
        public int index() { return owner; }
        public boolean org$apache$spark$Partition$$super$equals(Object value) { return super.equals(value); }
    }

    private static final class BundleDependency extends NarrowDependency<MaskedSharedBlock> {
        final int[] groups;
        BundleDependency(RDD<MaskedSharedBlock> parent, int[] groups) {
            super(parent); this.groups = groups.clone();
        }
        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(
                    Collections.<Object>singletonList(groups[child])).asScala().toSeq();
        }
    }

    private static Seq<Dependency<?>> dependencies(RDD<MaskedSharedBlock> parent, int[] groups) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(
                new BundleDependency(parent, groups))).asScala().toSeq();
    }

    private final RDD<MaskedSharedBlock> blocks;
    private final Partition[] owners;

    public MaskedSharedNeighborhoodRDD(JavaRDD<MaskedSharedBlock> blocks, NeighborhoodBundles.Plan plan) {
        super(blocks.context(), dependencies(blocks.rdd(), plan.group),
                ClassTag$.MODULE$.<Tuple2<Integer, Point>>apply(Tuple2.class));
        this.blocks = blocks.rdd();
        this.owners = new Partition[plan.group.length];
        Partition[] parents = this.blocks.partitions();
        for (int owner = 0; owner < owners.length; owner++) {
            owners[owner] = new OwnerPartition(owner, plan.slot[owner], parents[plan.group[owner]]);
        }
    }

    public Partition[] getPartitions() { return owners; }

    public scala.collection.Iterator<Tuple2<Integer, Point>> compute(Partition split, TaskContext context) {
        OwnerPartition owner = (OwnerPartition) split;
        scala.collection.Iterator<MaskedSharedBlock> input = blocks.iterator(owner.parent, context);
        if (!input.hasNext()) throw new IllegalStateException("missing masked block");
        MaskedSharedBlock block = input.next();
        if (input.hasNext()) throw new IllegalStateException("multiple masked blocks");
        Iterator<Tuple2<Integer, Point>> output = new Iterator<Tuple2<Integer, Point>>() {
            int nextOrdinal = findNext(0);
            private int findNext(int start) {
                int ordinal = start;
                while (ordinal < block.unionPoints.length
                        && ((block.visibilityMasks[ordinal] & 0xff) & (1 << owner.slot)) == 0) ordinal++;
                return ordinal;
            }
            public boolean hasNext() { return nextOrdinal < block.unionPoints.length; }
            public Tuple2<Integer, Point> next() {
                if (!hasNext()) throw new NoSuchElementException();
                Point copy = new Point(block.unionPoints[nextOrdinal]);
                nextOrdinal = findNext(nextOrdinal + 1);
                copy.is_core = copy.ownerPartitionId == owner.owner;
                copy.is_clone = !copy.is_core;
                return new Tuple2<Integer, Point>(owner.owner, copy);
            }
        };
        return JavaConverters.asScalaIteratorConverter(output).asScala();
    }

    public JavaPairRDD<Integer, Point> asPairs() {
        return JavaPairRDD.fromJavaRDD(JavaRDD.fromRDD(this,
                ClassTag$.MODULE$.<Tuple2<Integer, Point>>apply(Tuple2.class)));
    }

    public static JavaRDD<MaskedSharedBlock> cacheBatches(
            JavaPairRDD<Integer, CompactPacketBatches.Batch> batches,
            NeighborhoodBundles.Plan plan) {
        return cacheBatches(batches, plan, null);
    }

    public static JavaRDD<MaskedSharedBlock> cacheBatches(
            JavaPairRDD<Integer, CompactPacketBatches.Batch> batches,
            NeighborhoodBundles.Plan plan, org.apache.spark.util.CollectionAccumulator<TransportObservation> observations) {
        final int[][] members = plan.members;
        return batches.partitionBy(new HashPartitioner(members.length)).mapPartitionsWithIndex((groupId, input) -> {
            MaskedBlockBuilder builder = new MaskedBlockBuilder(members[groupId]);
            long records = 0, decodeNanos = 0;
            while (input.hasNext()) {
                CompactPacketBatches.Batch batch = input.next()._2();
                long start = System.nanoTime();
                for (int i = 0; i < batch.size(); i++) builder.add(batch.pointAt(i), batch.maskAt(i));
                if (observations != null) {
                    records = Math.addExact(records, batch.size());
                    decodeNanos = Math.addExact(decodeNanos, System.nanoTime() - start);
                }
            }
            long start = System.nanoTime();
            MaskedSharedBlock block = builder.build();
            if (observations != null) observations.add(new TransportObservation(groupId, records, block,
                    Math.addExact(decodeNanos, System.nanoTime() - start)));
            return Collections.singletonList(block).iterator();
        }, false).persist(StorageLevel.MEMORY_AND_DISK());
    }
}
