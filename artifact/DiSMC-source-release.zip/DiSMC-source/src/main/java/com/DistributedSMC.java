package com;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.Arrays;

public final class DistributedSMC {
    private DistributedSMC() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            throw new IllegalArgumentException("usage: DistributedSMC PROFILE INPUT OUTPUT "
                    + "PARTITIONS RADIUS DENSITY CELL_FACTOR");
        }
        MethodProfile profile = MethodProfile.parse(args[0]);
        String[] queryArgs = invocationArguments(profile, Arrays.copyOfRange(args, 1, args.length));
        System.setProperty("spark.skyline.profile", profile.id());
        org.apache.spark.SparkConf conf = new org.apache.spark.SparkConf();
        ExperimentConfig experiment = ExperimentConfig.from(conf, profile);
        experiment.requireSupportedExecution();
        if (profile == MethodProfile.SINGLE_ESMC) {
            boolean queryCompleted = false;
            try {
                invoke("com.singlebaseline.SingleSMCQBaseline", queryArgs);
                queryCompleted = true;
            } finally {
                if (experiment.observe) {
                    try {
                        ExperimentSparkListener.writeStandalone(conf, queryCompleted);
                    } catch (java.io.IOException error) {
                        if (queryCompleted) throw error;
                        System.err.println("Failed-reference observation write failed: " + error);
                    }
                }
            }
        } else if (profile == MethodProfile.Z_D0) {
            invoke("com.DistributedSMCZOrderDPBoundBaseline", queryArgs);
        } else if (profile == MethodProfile.HILBERT_D0) {
            invoke("com.DistributedSMCHilbertMBRBaseline", queryArgs);
        } else if (profile == MethodProfile.GRID_D0) {
            invoke("com.DistributedSMCGridBoundBaseline", queryArgs);
        } else {
            invoke("com.DistributedSMCGridbaseRebuilt", queryArgs);
        }
    }

    static String[] invocationArguments(MethodProfile profile, String[] queryArgs) {
        if (queryArgs.length != 6 && queryArgs.length != 8) {
            throw new IllegalArgumentException("requires INPUT OUTPUT PARTITIONS RADIUS DENSITY CELL_FACTOR [QUERY_X QUERY_Y]");
        }
        String queryX = queryArgs.length == 8 ? queryArgs[6] : "15.0";
        String queryY = queryArgs.length == 8 ? queryArgs[7] : "15.0";
        if (!Double.isFinite(Double.parseDouble(queryX)) || !Double.isFinite(Double.parseDouble(queryY))) {
            throw new IllegalArgumentException("query coordinates must be finite");
        }
        if (profile == MethodProfile.SINGLE_ESMC) {
            return new String[]{singleMachineInput(queryArgs[0]), queryArgs[1], queryArgs[3],
                    queryArgs[4], queryX, queryY, "true"};
        }
        return queryArgs.clone();
    }

    static String singleMachineInput(String input) {
        if (input == null || !input.startsWith("file:")) return input;
        try {
            return new File(URI.create(input)).getPath();
        } catch (IllegalArgumentException error) {
            throw new IllegalArgumentException("invalid file URI: " + input, error);
        }
    }

    private static void invoke(String className, String[] args) throws Exception {
        try {
            Class<?> entry = Class.forName(className);
            Method main = entry.getMethod("main", String[].class);
            main.invoke(null, (Object) args);
        } catch (InvocationTargetException error) {
            Throwable cause = error.getCause();
            if (cause instanceof Exception) throw (Exception) cause;
            if (cause instanceof Error) throw (Error) cause;
            throw error;
        }
    }
}
