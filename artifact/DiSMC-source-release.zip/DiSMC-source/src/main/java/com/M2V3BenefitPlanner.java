package com;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/** Deterministic M2 pairing whose score is expressed entirely in milliseconds. */
public final class M2V3BenefitPlanner {
    public static final class Config implements Serializable {
        public final long maxGroupRecords;
        public final double maxGroupWork;
        public final double shuffleMsPerRecord;
        public final double indexMsPerRecord;
        public final double queryMsPerWork;
        public final double blockBuildMsPerRecord;
        public final double longTailMsPerWork;
        public final double minBenefitMs;

        public Config(long maxGroupRecords, double maxGroupWork,
                double shuffleMsPerRecord, double indexMsPerRecord,
                double queryMsPerWork, double blockBuildMsPerRecord,
                double longTailMsPerWork, double minBenefitMs) {
            if (maxGroupRecords < 1 || !finiteNonnegative(maxGroupWork)
                    || !finiteNonnegative(shuffleMsPerRecord)
                    || !finiteNonnegative(indexMsPerRecord)
                    || !finiteNonnegative(queryMsPerWork)
                    || !finiteNonnegative(blockBuildMsPerRecord)
                    || !finiteNonnegative(longTailMsPerWork)
                    || !Double.isFinite(minBenefitMs)) {
                throw new IllegalArgumentException("invalid M2-v3 benefit configuration");
            }
            this.maxGroupRecords = maxGroupRecords;
            this.maxGroupWork = maxGroupWork;
            this.shuffleMsPerRecord = shuffleMsPerRecord;
            this.indexMsPerRecord = indexMsPerRecord;
            this.queryMsPerWork = queryMsPerWork;
            this.blockBuildMsPerRecord = blockBuildMsPerRecord;
            this.longTailMsPerWork = longTailMsPerWork;
            this.minBenefitMs = minBenefitMs;
        }
    }

    public static final class Plan implements Serializable {
        public final int[] group, slot;
        public final int[][] members;
        public final long originalRecords, sharedRecords;
        public final int candidatePairs, acceptedPairs;
        public final int rejectedRecords, rejectedWork, rejectedNegativeBenefit;
        public final double predictedBenefitMs, predictedShuffleSavedMs;
        public final double predictedIndexSavedMs, predictedQuerySavedMs;
        public final double predictedBlockBuildMs, predictedLongTailMs;

        Plan(int[] group, int[] slot, int[][] members, long originalRecords,
                long sharedRecords, int candidatePairs, int acceptedPairs,
                int rejectedRecords, int rejectedWork, int rejectedNegativeBenefit,
                double predictedBenefitMs, double predictedShuffleSavedMs,
                double predictedIndexSavedMs, double predictedQuerySavedMs,
                double predictedBlockBuildMs, double predictedLongTailMs) {
            this.group = group; this.slot = slot; this.members = members;
            this.originalRecords = originalRecords; this.sharedRecords = sharedRecords;
            this.candidatePairs = candidatePairs; this.acceptedPairs = acceptedPairs;
            this.rejectedRecords = rejectedRecords; this.rejectedWork = rejectedWork;
            this.rejectedNegativeBenefit = rejectedNegativeBenefit;
            this.predictedBenefitMs = predictedBenefitMs;
            this.predictedShuffleSavedMs = predictedShuffleSavedMs;
            this.predictedIndexSavedMs = predictedIndexSavedMs;
            this.predictedQuerySavedMs = predictedQuerySavedMs;
            this.predictedBlockBuildMs = predictedBlockBuildMs;
            this.predictedLongTailMs = predictedLongTailMs;
        }
    }

    private static final class Edge {
        final int left, right;
        final long savedRecords, unionRecords;
        final double benefit, shuffle, index, query, build, tail;
        Edge(int left, int right, long savedRecords, long unionRecords,
                double benefit, double shuffle, double index, double query,
                double build, double tail) {
            this.left = left; this.right = right; this.savedRecords = savedRecords;
            this.unionRecords = unionRecords; this.benefit = benefit;
            this.shuffle = shuffle; this.index = index; this.query = query;
            this.build = build; this.tail = tail;
        }
    }

    private M2V3BenefitPlanner() { }

    public static Plan plan(double[] work, long[] core, long[] assigned,
            long[][] overlap, int executionSlots, Config config) {
        int owners = work == null ? -1 : work.length;
        if (owners < 0 || core == null || assigned == null || overlap == null
                || core.length != owners || assigned.length != owners
                || overlap.length != owners || executionSlots < 1 || config == null) {
            throw new IllegalArgumentException("invalid M2-v3 planner inputs");
        }
        long originalRecords = 0L;
        double totalWork = 0.0;
        for (int owner = 0; owner < owners; owner++) {
            if (!finiteNonnegative(work[owner]) || core[owner] < 0
                    || assigned[owner] < core[owner] || overlap[owner] == null
                    || overlap[owner].length != owners) {
                throw new IllegalArgumentException("invalid owner statistics");
            }
            originalRecords = Math.addExact(originalRecords, assigned[owner]);
            totalWork += work[owner];
        }
        double balancedWork = totalWork / executionSlots;
        ArrayList<Edge> candidates = new ArrayList<Edge>();
        int rejectedRecords = 0, rejectedWork = 0, rejectedNegative = 0;
        for (int left = 0; left < owners; left++) {
            for (int right = left + 1; right < owners; right++) {
                long saved = overlap[left][right];
                if (saved <= 0) continue;
                long union = Math.subtractExact(Math.addExact(assigned[left], assigned[right]), saved);
                double combinedWork = work[left] + work[right];
                if (union > config.maxGroupRecords) { rejectedRecords++; continue; }
                if (combinedWork > config.maxGroupWork) { rejectedWork++; continue; }
                double leftSharedWork = assigned[left] == 0 ? 0.0 : work[left] * saved / assigned[left];
                double rightSharedWork = assigned[right] == 0 ? 0.0 : work[right] * saved / assigned[right];
                double sharedWork = Math.min(leftSharedWork, rightSharedWork);
                double shuffle = saved * config.shuffleMsPerRecord;
                double index = saved * config.indexMsPerRecord;
                double query = sharedWork * config.queryMsPerWork;
                double build = union * config.blockBuildMsPerRecord;
                double tail = Math.max(0.0, combinedWork - balancedWork) * config.longTailMsPerWork;
                double benefit = shuffle + index + query - build - tail;
                if (benefit <= config.minBenefitMs) { rejectedNegative++; continue; }
                candidates.add(new Edge(left, right, saved, union,
                        benefit, shuffle, index, query, build, tail));
            }
        }
        candidates.sort(new Comparator<Edge>() {
            public int compare(Edge first, Edge second) {
                int value = Double.compare(second.benefit, first.benefit);
                if (value != 0) return value;
                value = Integer.compare(first.left, second.left);
                return value != 0 ? value : Integer.compare(first.right, second.right);
            }
        });

        int[] mate = new int[owners];
        Arrays.fill(mate, -1);
        int accepted = 0;
        long savedTotal = 0L;
        double benefitTotal = 0.0, shuffleTotal = 0.0, indexTotal = 0.0;
        double queryTotal = 0.0, buildTotal = 0.0, tailTotal = 0.0;
        for (Edge edge : candidates) {
            if (mate[edge.left] >= 0 || mate[edge.right] >= 0) continue;
            mate[edge.left] = edge.right;
            mate[edge.right] = edge.left;
            accepted++;
            savedTotal = Math.addExact(savedTotal, edge.savedRecords);
            benefitTotal += edge.benefit; shuffleTotal += edge.shuffle;
            indexTotal += edge.index; queryTotal += edge.query;
            buildTotal += edge.build; tailTotal += edge.tail;
        }

        int groupCount = owners - accepted;
        int[] group = new int[owners], slot = new int[owners];
        Arrays.fill(group, -1);
        int[][] members = new int[groupCount][];
        int next = 0;
        for (int owner = 0; owner < owners; owner++) {
            if (group[owner] >= 0) continue;
            int other = mate[owner];
            if (other < 0) {
                members[next] = new int[]{owner};
                group[owner] = next;
            } else {
                int left = Math.min(owner, other), right = Math.max(owner, other);
                members[next] = new int[]{left, right};
                group[left] = next; group[right] = next; slot[right] = 1;
            }
            next++;
        }
        return new Plan(group, slot, members, originalRecords,
                originalRecords - savedTotal, candidates.size() + rejectedRecords
                        + rejectedWork + rejectedNegative,
                accepted, rejectedRecords, rejectedWork, rejectedNegative,
                benefitTotal, shuffleTotal, indexTotal, queryTotal, buildTotal, tailTotal);
    }

    private static boolean finiteNonnegative(double value) {
        return Double.isFinite(value) && value >= 0.0;
    }
}
