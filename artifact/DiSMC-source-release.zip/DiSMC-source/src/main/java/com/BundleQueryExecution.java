package com;

import java.util.ArrayList;
import java.util.List;

/** Deterministic expansion of one bundle into owner/shard query jobs. */
public final class BundleQueryExecution {
    private BundleQueryExecution() { }

    public static final class Job {
        public final int groupId;
        public final int owner;
        public final int slot;
        public final int piece;
        public final int pieces;

        private Job(int groupId, int owner, int slot, int piece, int pieces) {
            this.groupId = groupId;
            this.owner = owner;
            this.slot = slot;
            this.piece = piece;
            this.pieces = pieces;
        }
    }

    public static List<Job> expand(BundleQueryLayout.Task task) {
        if (task == null) throw new IllegalArgumentException("missing bundle task");
        ArrayList<Job> result = new ArrayList<Job>();
        for (int i = 0; i < task.owners.length; i++) {
            int pieces = task.pieces[i];
            for (int piece = 0; piece < pieces; piece++)
                result.add(new Job(task.groupId, task.owners[i], task.slots[i], piece, pieces));
        }
        return result;
    }

    public static int preparedBuildsPerBundle() { return 1; }

    public static String ownerIds(List<Job> jobs) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < jobs.size(); i++) {
            if (i > 0) result.append(',');
            result.append(jobs.get(i).owner);
        }
        return result.toString();
    }

    public static List<List<Job>> ownerBatches(BundleQueryLayout.Task task) {
        if (task == null) throw new IllegalArgumentException("missing bundle task");
        ArrayList<List<Job>> result = new ArrayList<List<Job>>();
        for (int i = 0; i < task.owners.length; i++) {
            ArrayList<Job> ownerJobs = new ArrayList<Job>();
            for (int piece = 0; piece < task.pieces[i]; piece++)
                ownerJobs.add(new Job(task.groupId, task.owners[i], task.slots[i], piece, task.pieces[i]));
            result.add(ownerJobs);
        }
        return result;
    }
}
