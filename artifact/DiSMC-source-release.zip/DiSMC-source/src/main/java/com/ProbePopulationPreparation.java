package com;

import java.io.Serializable;
import java.util.*;
import org.apache.spark.api.java.*;
import org.apache.spark.broadcast.Broadcast;

/** Responsibilities and original populations, without speculative lane population values. */
public final class ProbePopulationPreparation implements Serializable {
    private static final long serialVersionUID = 1L;
    private final long[] assigned, core;
    private final MicroPartitionLayout.Candidate[] candidates;
    private transient MicroPartitionPopulation.Statistics originalMetadata;
    private boolean sourcePrepared;

    public static final class OwnerCounts implements Serializable {
        private static final long serialVersionUID = 1L;
        public final int owner;
        public final long parentPopulation, populationNanos;
        private final String[] signatures;
        private final long[][] counts;
        public OwnerCounts(int owner, long parentPopulation, String[] signatures, long[][] counts, long populationNanos) {
            if (owner < 0 || parentPopulation < 0 || populationNanos < 0 || signatures == null || counts == null
                    || signatures.length != counts.length) throw new IllegalArgumentException("invalid probe populations");
            this.owner = owner; this.parentPopulation = parentPopulation; this.populationNanos = populationNanos;
            this.signatures = signatures.clone(); this.counts = new long[counts.length][];
            for (int i = 0; i < counts.length; i++) {
                if (signatures[i] == null || counts[i] == null) throw new IllegalArgumentException("missing population row");
                this.counts[i] = counts[i].clone();
            }
        }
    }

    public ProbePopulationPreparation(long[] assigned, long[] core, MicroPartitionLayout.Candidate[] candidates) {
        if (assigned == null || core == null || candidates == null) throw new IllegalArgumentException("missing preparation");
        MicroPartitionPopulation.Statistics validated = new MicroPartitionPopulation.Statistics(assigned, core,
                new MicroPartitionLayout.Candidate[0], new long[0][]);
        this.assigned = validated.originalAssigned; this.core = validated.core; this.candidates = candidates.clone();
        Set<String> signatures = new HashSet<>();
        for (MicroPartitionLayout.Candidate c : candidates) {
            if (c == null || c.owner >= core.length || !c.dependencyInputsEnabled || !signatures.add(c.signature()))
                throw new IllegalArgumentException("invalid or duplicate dependency responsibility");
            long anchors = 0;
            for (int lane = 0; lane < c.pieces; lane++) anchors = Math.addExact(anchors, c.anchors(lane).length);
            if (anchors != core[c.owner]) throw new IllegalArgumentException("incomplete core responsibility");
        }
    }

    /** One fused source action, deliberately using full-input accounting only as original metadata. */
    public static ProbePopulationPreparation prepare(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            double[] work, Map<Long,Double> weights, double radius, long[] knownCore) {
        long start = System.nanoTime();
        MicroPartitionPopulation.Statistics full = MicroPartitionPopulation.observe(context, points, owners,
                offsetX, offsetY, work, weights, radius, "spatial_full", knownCore);
        MicroPartitionLayout.Candidate[] dependencies = new MicroPartitionLayout.Candidate[full.candidates.length];
        for (int i = 0; i < dependencies.length; i++) {
            MicroPartitionLayout.Candidate c = full.candidates[i]; List<MicroPartitionLayout.Anchor> anchors = new ArrayList<>();
            for (int lane = 0; lane < c.pieces; lane++) Collections.addAll(anchors, c.anchors(lane));
            dependencies[i] = new MicroPartitionLayout.Candidate(c.owner, c.responsibility, c.pieces,
                    anchors.toArray(new MicroPartitionLayout.Anchor[0]), c.radius, c.splitAxis, true);
            if (!dependencies[i].signature().equals(c.signature())) throw new IllegalStateException("reconstructed responsibility changed");
        }
        ProbePopulationPreparation result = new ProbePopulationPreparation(full.originalAssigned, full.core, dependencies);
        full.populationMs = (System.nanoTime() - start) / 1e6;
        result.originalMetadata = full;
        result.sourcePrepared = true;
        return result;
    }

    public long[] originalAssigned() { return assigned.clone(); }
    public long[] core() { return core.clone(); }
    public MicroPartitionLayout.Candidate[] candidates() { return candidates.clone(); }

    /** Count from the complete parent without touching probe query state. Timing excludes transport. */
    public OwnerCounts countOwner(MaskedSharedBlock block, int slot, int owner) {
        if (owner < 0 || owner >= assigned.length) throw new IllegalArgumentException("invalid population owner");
        long start = System.nanoTime();
        long[][] all = ProbePopulationCounter.count(block, slot, owner, assigned[owner], candidates);
        List<String> signatures = new ArrayList<>(); List<long[]> values = new ArrayList<>();
        for (int i = 0; i < candidates.length; i++) if (candidates[i].owner == owner) {
            signatures.add(candidates[i].signature()); values.add(all[i]);
        }
        return new OwnerCounts(owner, assigned[owner], signatures.toArray(new String[0]),
                values.toArray(new long[0][]), System.nanoTime() - start);
    }

    /** Accept each owner exactly once; return only complete, signature-bound exact population vectors. */
    public MicroPartitionPopulation.Statistics complete(Collection<OwnerCounts> results) {
        if (sourcePrepared && originalMetadata == null) throw new IllegalStateException("transported preparation cannot finalize driver accounting");
        if (results == null) throw new IllegalArgumentException("missing probe results");
        Set<Integer> expected = new HashSet<>();
        for (MicroPartitionLayout.Candidate c : candidates) expected.add(c.owner);
        Map<Integer, Map<String,long[]>> byOwner = new HashMap<>();
        for (OwnerCounts r : results) {
            if (r == null || !expected.contains(r.owner) || byOwner.containsKey(r.owner)
                    || r.parentPopulation != assigned[r.owner]) throw new IllegalStateException("missing, duplicate or stale probe owner");
            Map<String,long[]> rows = new HashMap<>();
            for (int i = 0; i < r.signatures.length; i++)
                if (rows.put(r.signatures[i], r.counts[i]) != null) throw new IllegalStateException("duplicate candidate population");
            byOwner.put(r.owner, rows);
        }
        if (!byOwner.keySet().equals(expected)) throw new IllegalStateException("incomplete probe owner coverage");
        long[][] inputs = new long[candidates.length][];
        for (int i = 0; i < candidates.length; i++) {
            MicroPartitionLayout.Candidate c = candidates[i]; long[] row = byOwner.get(c.owner).remove(c.signature());
            if (row == null || row.length != c.pieces) throw new IllegalStateException("missing or mismatched lane population");
            for (int lane = 0; lane < row.length; lane++)
                if (row[lane] < c.anchors(lane).length || row[lane] > assigned[c.owner])
                    throw new IllegalStateException("invalid lane population bound");
            inputs[i] = row;
        }
        for (Map<String,long[]> rows : byOwner.values()) if (!rows.isEmpty()) throw new IllegalStateException("unexpected candidate population");
        MicroPartitionPopulation.Statistics result = new MicroPartitionPopulation.Statistics(assigned, core, candidates, inputs);
        if (originalMetadata != null) {
            result.sourceRecordsScanned = originalMetadata.sourceRecordsScanned;
            result.dependencyPopulationScans = 0;
            result.populationCollectionFused = originalMetadata.populationCollectionFused;
            result.originalPopulationMs = originalMetadata.originalPopulationMs;
            result.populationMs = originalMetadata.populationMs;
            result.collectMs = originalMetadata.collectMs;
            result.fallbacks.addAll(originalMetadata.fallbacks);
        }
        return result;
    }
}
