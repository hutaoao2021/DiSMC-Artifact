package com;

import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Controlled comparison baseline: exact Z-order quantile partitions plus the
 * replication interval from Theorem 3 of Distributed Density Peaks Clustering
 * Revisited.  For SMCQ the dependency radius is 2 * dc.
 */
public class DistributedSMCZOrderDPBoundBaseline {
    private static final class ZSortKey implements Comparable<ZSortKey>, Serializable {
        private static final long serialVersionUID = 1L;
        final String z;
        final long id;

        ZSortKey(String z, long id) {
            this.z = z;
            this.id = id;
        }

        @Override
        public int compareTo(ZSortKey other) {
            int byZ = z.compareTo(other.z);
            return byZ != 0 ? byZ : Long.compare(id, other.id);
        }
    }

    private static final class PartitionBound implements Serializable {
        private static final long serialVersionUID = 1L;
        final int partitionId;
        final String coreMin;
        final String coreMax;
        final String lower;
        final String upper;
        final double minX;
        final double maxX;
        final double minY;
        final double maxY;
        final long coreCount;

        PartitionBound(
                int partitionId,
                String coreMin,
                String coreMax,
                String lower,
                String upper,
                double minX,
                double maxX,
                double minY,
                double maxY,
                long coreCount) {
            this.partitionId = partitionId;
            this.coreMin = coreMin;
            this.coreMax = coreMax;
            this.lower = lower;
            this.upper = upper;
            this.minX = minX;
            this.maxX = maxX;
            this.minY = minY;
            this.maxY = maxY;
            this.coreCount = coreCount;
        }

        boolean isEmpty() {
            return coreCount == 0L;
        }

        boolean contains(Point point, boolean hilbert, double dependencyRadius) {
            if (isEmpty()) return false;
            if (!hilbert) {
                return lower.compareTo(point.zval) <= 0 && point.zval.compareTo(upper) <= 0;
            }
            return point.x >= minX - dependencyRadius && point.x <= maxX + dependencyRadius
                    && point.y >= minY - dependencyRadius && point.y <= maxY + dependencyRadius;
        }
    }

    private static final class PartitionStats implements Serializable {
        private static final long serialVersionUID = 1L;
        final int partitionId;
        final long coreCount;
        final long cloneCount;

        PartitionStats(int partitionId, long coreCount, long cloneCount) {
            this.partitionId = partitionId;
            this.coreCount = coreCount;
            this.cloneCount = cloneCount;
        }
    }

    private static final class LocalResult implements Serializable {
        private static final long serialVersionUID = 1L;
        final int partitionId;
        final ArrayList<Circle> skyline;
        final long candidateCount;
        final long singlePointCandidateCount;
        final long pairCandidateCount;
        final long zWindowChecks;
        final long pointDistanceChecks;
        final long computeTimeMs;

        LocalResult(
                int partitionId,
                ArrayList<Circle> skyline,
                long candidateCount,
                long singlePointCandidateCount,
                long pairCandidateCount,
                long zWindowChecks,
                long pointDistanceChecks,
                long computeTimeMs) {
            this.partitionId = partitionId;
            this.skyline = skyline;
            this.candidateCount = candidateCount;
            this.singlePointCandidateCount = singlePointCandidateCount;
            this.pairCandidateCount = pairCandidateCount;
            this.zWindowChecks = zWindowChecks;
            this.pointDistanceChecks = pointDistanceChecks;
            this.computeTimeMs = computeTimeMs;
        }
    }

    private static final class FinalCircleSpec implements Serializable {
        private static final long serialVersionUID = 1L;
        final int index;
        final double centerX;
        final double centerY;

        FinalCircleSpec(int index, double centerX, double centerY) {
            this.index = index;
            this.centerX = centerX;
            this.centerY = centerY;
        }
    }

    public static void main(String[] args) throws Exception {
        run(args, false);
    }

    static void run(String[] args, boolean hilbert) throws Exception {
        long endToEndStartMs = System.currentTimeMillis();
        if (args.length < 2) {
            printUsageAndExit();
        }

        String inputPath = args[0];
        String outputPath = localPath(args[1]);
        int partitionCount = args.length >= 3 ? Integer.parseInt(args[2]) : 10;
        double dc = args.length >= 4 ? Double.parseDouble(args[3]) : 2.0;
        int densityK = args.length >= 5 ? Integer.parseInt(args[4]) : 0;
        double cellSizeMultiplier = args.length >= 6 ? Double.parseDouble(args[5]) : 1.0;
        double queryX = args.length >= 7 ? Double.parseDouble(args[6]) : 15.0;
        double queryY = args.length >= 8 ? Double.parseDouble(args[7]) : 15.0;
        boolean deduplicate = args.length >= 9 ? Boolean.parseBoolean(args[8]) : true;

        validateArguments(partitionCount, dc, densityK, cellSizeMultiplier);
        final double cellSize = dc * cellSizeMultiplier;
        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");

        SparkConf conf = new SparkConf()
                .setAppName(hilbert ? "SkylineMCQHilbertMBRBaseline" : "SkylineMCQZOrderDPBoundBaseline")
                .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .registerKryoClasses(new Class[]{
                        Point.class, Circle.class, ZSortKey.class, PartitionBound.class,
                        PartitionStats.class, LocalResult.class, FinalCircleSpec.class
                })
                .set("spark.default.parallelism", String.valueOf(partitionCount))
                .set("spark.ui.showConsoleProgress", "false");
        if (!conf.contains("spark.master")) {
            conf.setMaster("local[*]");
        }

        ExperimentConfig experiment = ExperimentConfig.from(conf, hilbert ? MethodProfile.HILBERT_D0 : MethodProfile.Z_D0);
        experiment.requireSupportedExecution();
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");
        ExperimentSparkListener observer = ExperimentSparkListener.attach(sc, experiment);
        boolean queryCompleted = false;
        Broadcast<PartitionBound[]> boundsBroadcast = null;
        JavaRDD<Point> points = null;
        JavaPairRDD<Integer, Point> coreByOwner = null;
        JavaPairRDD<Integer, Point> assignedPoints = null;

        long s1ReadPrepareMs;
        long s2PartitionPlanMs;
        long s3ReplicateShuffleMs;
        long s4LocalComputeMs;
        long s5GlobalReduceMs;
        long s6MaterializeMs;
        long originalPointCount;
        long assignedPointCount;
        long clonePointCount;
        long maxCore = 0L;
        long minCore = Long.MAX_VALUE;
        long maxAssigned = 0L;
        long minAssigned = Long.MAX_VALUE;
        long localCandidateCount = 0L;
        long localSinglePointCandidateCount = 0L;
        long localPairCandidateCount = 0L;
        long localZWindowChecks = 0L;
        long localPointDistanceChecks = 0L;
        long localTaskComputeSumMs = 0L;
        long localTaskComputeMaxMs = 0L;
        EMCSBaseline finalResult;

        try {
            long s1Start = System.currentTimeMillis();
            points = readAndPreparePoints(sc, inputPath, dc, cellSize, partitionCount, deduplicate)
                    .persist(StorageLevel.MEMORY_AND_DISK());
            originalPointCount = points.count();
            if (originalPointCount == 0L) {
                throw new IllegalArgumentException("Input contains no points");
            }
            s1ReadPrepareMs = System.currentTimeMillis() - s1Start;

            long s2Start = System.currentTimeMillis();
            JavaRDD<Point> globallySorted = points.sortBy(
                    point -> new ZSortKey(hilbert ? hilbertValue(point) : point.zval, point.id),
                    true,
                    partitionCount
            ).persist(StorageLevel.MEMORY_AND_DISK());
            globallySorted.count();

            final long totalPointsForOwner = originalPointCount;
            final int partitionsForOwner = partitionCount;
            coreByOwner = globallySorted.zipWithIndex().mapToPair(tuple -> {
                Point point = tuple._1();
                long sortedIndex = tuple._2();
                int owner = (int) Math.min(
                        partitionsForOwner - 1L,
                        (sortedIndex * partitionsForOwner) / totalPointsForOwner
                );
                point.ownerPartitionId = owner;
                point.isCore = true;
                point.isClone = false;
                return new Tuple2<Integer, Point>(owner, point);
            }).partitionBy(new HashPartitioner(partitionCount)).persist(StorageLevel.MEMORY_AND_DISK());
            coreByOwner.count();
            globallySorted.unpersist();

            List<PartitionBound> boundList = coreByOwner.mapPartitionsWithIndex((partitionId, iterator) -> {
                String coreMin = null;
                String coreMax = null;
                String lower = null;
                String upper = null;
                double minX = Double.POSITIVE_INFINITY;
                double maxX = Double.NEGATIVE_INFINITY;
                double minY = Double.POSITIVE_INFINITY;
                double maxY = Double.NEGATIVE_INFINITY;
                long count = 0L;
                while (iterator.hasNext()) {
                    Point point = iterator.next()._2();
                    coreMin = minString(coreMin, point.zval);
                    coreMax = maxString(coreMax, point.zval);
                    lower = minString(lower, point.plowzval);
                    upper = maxString(upper, point.pupperzval);
                    minX = Math.min(minX, point.x);
                    maxX = Math.max(maxX, point.x);
                    minY = Math.min(minY, point.y);
                    maxY = Math.max(maxY, point.y);
                    count++;
                }
                return Collections.singletonList(new PartitionBound(
                        partitionId, coreMin, coreMax, lower, upper,
                        minX, maxX, minY, maxY, count
                )).iterator();
            }, true).collect();

            PartitionBound[] bounds = buildBounds(boundList, partitionCount);
            boundsBroadcast = sc.broadcast(bounds);
            s2PartitionPlanMs = System.currentTimeMillis() - s2Start;

            long s3Start = System.currentTimeMillis();
            final Broadcast<PartitionBound[]> taskBounds = boundsBroadcast;
            assignedPoints = coreByOwner.flatMapToPair(tuple -> {
                int sourceOwner = tuple._1();
                Point point = tuple._2();
                ArrayList<Tuple2<Integer, Point>> output = new ArrayList<Tuple2<Integer, Point>>();
                output.add(new Tuple2<Integer, Point>(sourceOwner, point.assignmentCopy(sourceOwner, true)));
                PartitionBound[] partitionBounds = taskBounds.value();
                for (int target = 0; target < partitionBounds.length; target++) {
                    if (target != sourceOwner
                            && partitionBounds[target].contains(point, hilbert, 2.0 * dc)) {
                        output.add(new Tuple2<Integer, Point>(target, point.assignmentCopy(sourceOwner, false)));
                    }
                }
                return output.iterator();
            }).partitionBy(new HashPartitioner(partitionCount)).persist(StorageLevel.MEMORY_AND_DISK());

            List<PartitionStats> partitionStats = assignedPoints.mapPartitionsWithIndex((partitionId, iterator) -> {
                long core = 0L;
                long clone = 0L;
                while (iterator.hasNext()) {
                    Point point = iterator.next()._2();
                    if (point.isCore) {
                        core++;
                    } else {
                        clone++;
                    }
                }
                return Collections.singletonList(new PartitionStats(partitionId, core, clone)).iterator();
            }, true).collect();

            assignedPointCount = 0L;
            clonePointCount = 0L;
            for (PartitionStats stats : partitionStats) {
                long assigned = stats.coreCount + stats.cloneCount;
                assignedPointCount += assigned;
                clonePointCount += stats.cloneCount;
                maxCore = Math.max(maxCore, stats.coreCount);
                minCore = Math.min(minCore, stats.coreCount);
                maxAssigned = Math.max(maxAssigned, assigned);
                minAssigned = Math.min(minAssigned, assigned);
            }
            if (minCore == Long.MAX_VALUE) minCore = 0L;
            if (minAssigned == Long.MAX_VALUE) minAssigned = 0L;
            s3ReplicateShuffleMs = System.currentTimeMillis() - s3Start;

            long s4Start = System.currentTimeMillis();
            final double localDc = dc;
            final int localDensityK = densityK;
            final double localQueryX = queryX;
            final double localQueryY = queryY;
            JavaRDD<LocalResult> localResultsRdd = assignedPoints.mapPartitionsWithIndex((partitionId, iterator) -> {
                ArrayList<Point> localPoints = new ArrayList<Point>();
                while (iterator.hasNext()) {
                    localPoints.add(iterator.next()._2());
                }
                sortPoints(localPoints);
                EMCSBaseline local = new DiSMCGeometryBaseline(localDc, localDensityK);
                local.setQueryPoint(localQueryX, localQueryY);
                local.plist = localPoints;
                long taskStart = System.currentTimeMillis();
                local.methodForPartition(partitionId);
                long taskTime = System.currentTimeMillis() - taskStart;
                ArrayList<Circle> skyline = new ArrayList<Circle>(local.skymap.values());
                sortCircles(skyline);
                return Collections.singletonList(new LocalResult(
                        partitionId,
                        skyline,
                        local.candidateCount,
                        local.singlePointCandidateCount,
                        local.pairCandidateCount,
                        local.zWindowChecks,
                        local.pointDistanceChecks,
                        taskTime
                )).iterator();
            }, true);

            List<LocalResult> localResults = new ArrayList<LocalResult>(localResultsRdd.collect());
            s4LocalComputeMs = System.currentTimeMillis() - s4Start;

            long s5Start = System.currentTimeMillis();
            Collections.sort(localResults, Comparator.comparingInt(result -> result.partitionId));
            ArrayList<Circle> skylineUnion = new ArrayList<Circle>();
            for (LocalResult result : localResults) {
                skylineUnion.addAll(result.skyline);
                localCandidateCount += result.candidateCount;
                localSinglePointCandidateCount += result.singlePointCandidateCount;
                localPairCandidateCount += result.pairCandidateCount;
                localZWindowChecks += result.zWindowChecks;
                localPointDistanceChecks += result.pointDistanceChecks;
                localTaskComputeSumMs += result.computeTimeMs;
                localTaskComputeMaxMs = Math.max(localTaskComputeMaxMs, result.computeTimeMs);
            }
            sortCircles(skylineUnion);
            finalResult = new DiSMCGeometryBaseline(dc, densityK);
            finalResult.setQueryPoint(queryX, queryY);
            finalResult.skymap = finalResult.skylineCircle(skylineUnion);
            s5GlobalReduceMs = System.currentTimeMillis() - s5Start;

            long s6Start = System.currentTimeMillis();
            materializeFinalMembers(sc, points, finalResult, dc, cellSize);
            s6MaterializeMs = System.currentTimeMillis() - s6Start;

            int countMismatches = countMismatches(finalResult);
            if (countMismatches != 0) {
                throw new IllegalStateException("Final circle/member count mismatches: " + countMismatches);
            }

            long algorithmTotalMs = s1ReadPrepareMs + s2PartitionPlanMs + s3ReplicateShuffleMs
                    + s4LocalComputeMs + s5GlobalReduceMs + s6MaterializeMs;
            long comparableQueryMs = s2PartitionPlanMs + s3ReplicateShuffleMs + s4LocalComputeMs + s5GlobalReduceMs;
            writeOutput(
                    outputPath,
                    finalResult,
                    algorithmTotalMs,
                    comparableQueryMs,
                    s1ReadPrepareMs,
                    s2PartitionPlanMs,
                    s3ReplicateShuffleMs,
                    s4LocalComputeMs,
                    s5GlobalReduceMs,
                    s6MaterializeMs,
                    partitionCount,
                    dc,
                    densityK,
                    cellSizeMultiplier,
                    queryX,
                    queryY,
                    deduplicate,
                    originalPointCount,
                    assignedPointCount,
                    clonePointCount,
                    minCore,
                    maxCore,
                    minAssigned,
                    maxAssigned,
                    localCandidateCount,
                    localSinglePointCandidateCount,
                    localPairCandidateCount,
                    localZWindowChecks,
                    localPointDistanceChecks,
                    localTaskComputeSumMs,
                    localTaskComputeMaxMs,
                    countMismatches,
                    hilbert,
                    conf.getBoolean("spark.skyline.cacheMemberText",true)
            );

            printSummary(
                    outputPath,
                    finalResult.skymap.size(),
                    originalPointCount,
                    assignedPointCount,
                    clonePointCount,
                    comparableQueryMs,
                    algorithmTotalMs,
                    hilbert
            );
            queryCompleted = true;
        } finally {
            // Stopping the context releases all persisted RDDs and broadcasts.
            // Explicit asynchronous cleanup here races Spark's local shutdown pool.
            try {
                if (observer != null) observer.finish(sc, queryCompleted);
            } finally {
                sc.stop();
            }
        }

        long endToEndMs = System.currentTimeMillis() - endToEndStartMs;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath, true))) {
            writer.write("end_to_end_time_s: " + formatSeconds(endToEndMs) + "\r\n");
        }
        System.out.println("end_to_end_time_s=" + formatSeconds(endToEndMs));
    }

    private static JavaRDD<Point> readAndPreparePoints(
            JavaSparkContext sc,
            String inputPath,
            double dc,
            double cellSize,
            int partitionCount,
            boolean deduplicate) {
        JavaRDD<Tuple2<Double, Double>> coordinates = sc.textFile(inputPath, partitionCount).mapPartitions(iterator -> {
            ArrayList<Tuple2<Double, Double>> parsed = new ArrayList<Tuple2<Double, Double>>();
            HashSet<String> localSeen = deduplicate ? new HashSet<String>() : null;
            while (iterator.hasNext()) {
                String line = iterator.next().trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\s+");
                if (parts.length < 2) {
                    throw new IllegalArgumentException("Invalid point line: " + line);
                }
                double x = Double.parseDouble(parts[0]);
                double y = Double.parseDouble(parts[1]);
                if (deduplicate && !localSeen.add(x + "," + y)) continue;
                parsed.add(new Tuple2<Double, Double>(x, y));
            }
            return parsed.iterator();
        });

        if (deduplicate) {
            coordinates = coordinates.mapToPair(coord -> new Tuple2<Tuple2<Double, Double>, Integer>(coord, 1))
                    .reduceByKey((left, right) -> left, partitionCount)
                    .keys();
        }

        if (sc.getConf().getBoolean("spark.skyline.stableInputIds", false)) {
            coordinates = StablePointIdentity.coordinates(coordinates);
        }
        final double dependencyRadius = 2.0 * dc;
        return coordinates.zipWithUniqueId().map(tuple -> {
            Tuple2<Double, Double> coordinate = tuple._1();
            Point point = new Point(coordinate._1(), coordinate._2());
            point.id = tuple._2();
            point.zval = zValue(roundCoordinate(point.x, "x"), roundCoordinate(point.y, "y"));
            point.plowzval = zValue(
                    point.x - dependencyRadius > 0.0 ? floorCoordinate(point.x - dependencyRadius, "lower x") : 0L,
                    point.y - dependencyRadius > 0.0 ? floorCoordinate(point.y - dependencyRadius, "lower y") : 0L
            );
            point.pupperzval = zValue(
                    ceilCoordinate(point.x + dependencyRadius, "upper x"),
                    ceilCoordinate(point.y + dependencyRadius, "upper y")
            );
            int cellX = checkedCellCoordinate(Math.floor(point.x / cellSize), "cell x");
            int cellY = checkedCellCoordinate(Math.floor(point.y / cellSize), "cell y");
            point.setCell(cellX, cellY);
            return point;
        });
    }

    private static PartitionBound[] buildBounds(List<PartitionBound> boundList, int partitionCount) {
        PartitionBound[] bounds = new PartitionBound[partitionCount];
        for (PartitionBound bound : boundList) {
            bounds[bound.partitionId] = bound;
        }
        for (int partitionId = 0; partitionId < partitionCount; partitionId++) {
            if (bounds[partitionId] == null) {
                bounds[partitionId] = new PartitionBound(
                        partitionId, null, null, null, null,
                        Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY,
                        Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0L);
            }
        }

        return bounds;
    }

    private static void materializeFinalMembers(
            JavaSparkContext sc,
            JavaRDD<Point> originalPoints,
            EMCSBaseline result,
            double dc,
            double cellSize) {
        ArrayList<Circle> circles = new ArrayList<Circle>(result.skymap.values());
        sortCircles(circles);
        if (circles.isEmpty()) return;

        HashMap<Long, List<FinalCircleSpec>> byCell = new HashMap<Long, List<FinalCircleSpec>>();
        for (int index = 0; index < circles.size(); index++) {
            Circle circle = circles.get(index);
            circle.p = new ArrayList<Point>();
            FinalCircleSpec spec = new FinalCircleSpec(index, circle.centerX, circle.centerY);
            // round2(distance) <= dc can admit points just outside the raw radius.
            // Index the conservative envelope; the unchanged predicate filters its edge.
            double memberRadius = Math.nextUp(dc + 0.005);
            int minX = checkedCellCoordinate(Math.floor((circle.centerX - memberRadius) / cellSize), "circle cell min x");
            int maxX = checkedCellCoordinate(Math.floor((circle.centerX + memberRadius) / cellSize), "circle cell max x");
            int minY = checkedCellCoordinate(Math.floor((circle.centerY - memberRadius) / cellSize), "circle cell min y");
            int maxY = checkedCellCoordinate(Math.floor((circle.centerY + memberRadius) / cellSize), "circle cell max y");
            for (int cellX = minX; cellX <= maxX; cellX++) {
                for (int cellY = minY; cellY <= maxY; cellY++) {
                    byCell.computeIfAbsent(Point.pack(cellX, cellY), ignored -> new ArrayList<FinalCircleSpec>())
                            .add(spec);
                }
            }
        }

        Broadcast<Map<Long, List<FinalCircleSpec>>> circleIndex = sc.broadcast(byCell);
        Map<Integer, List<Point>> members = originalPoints.mapPartitionsToPair(iterator -> {
            HashMap<Integer, List<Point>> local = new HashMap<Integer, List<Point>>();
            Map<Long, List<FinalCircleSpec>> index = circleIndex.value();
            while (iterator.hasNext()) {
                Point point = iterator.next();
                List<FinalCircleSpec> candidates = index.get(point.packedCellId);
                if (candidates == null) continue;
                for (FinalCircleSpec spec : candidates) {
                    if (round2(distance(spec.centerX, spec.centerY, point.x, point.y)) <= dc) {
                        local.computeIfAbsent(spec.index, ignored -> new ArrayList<Point>())
                                .add(new Point(point.x, point.y));
                    }
                }
            }
            ArrayList<Tuple2<Integer, List<Point>>> output = new ArrayList<Tuple2<Integer, List<Point>>>();
            for (Map.Entry<Integer, List<Point>> entry : local.entrySet()) {
                output.add(new Tuple2<Integer, List<Point>>(entry.getKey(), entry.getValue()));
            }
            return output.iterator();
        }).reduceByKey((left, right) -> {
            left.addAll(right);
            return left;
        }).collectAsMap();

        for (int index = 0; index < circles.size(); index++) {
            List<Point> points = members.get(index);
            circles.get(index).p = points == null ? new ArrayList<Point>() : new ArrayList<Point>(points);
        }
        result.skymap = new HashMap<Double, Circle>();
        for (Circle circle : circles) result.skymap.put(circle.discenq, circle);
    }

    private static void writeOutput(
            String outputPath,
            EMCSBaseline result,
            long totalMs,
            long comparableQueryMs,
            long s1,
            long s2,
            long s3,
            long s4,
            long s5,
            long s6,
            int partitions,
            double dc,
            int densityK,
            double cellSizeMultiplier,
            double queryX,
            double queryY,
            boolean deduplicate,
            long originalPoints,
            long assignedPoints,
            long clonePoints,
            long minCore,
            long maxCore,
            long minAssigned,
            long maxAssigned,
            long candidateCount,
            long singlePointCandidateCount,
            long pairCandidateCount,
            long zWindowChecks,
            long pointDistanceChecks,
            long taskComputeSum,
            long taskComputeMax,
            int countMismatches,
            boolean hilbert, boolean cacheMemberText) throws IOException {
        long outputStartNanos=System.nanoTime();
        File outputFile = new File(outputPath);
        File parent = outputFile.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("Cannot create output directory: " + parent);
        }
        ArrayList<Circle> circles = new ArrayList<Circle>(result.skymap.values());
        sortCircles(circles);
        MemberTextFormatter memberText=new MemberTextFormatter(cacheMemberText);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            writer.write("member_text_cache_enabled: " + cacheMemberText + "\r\n");
            writer.write("method_profile: " + (hilbert ? "hilbert_d0" : "z_d0") + "\r\n");
            writer.write("method_composition: " + (hilbert
                    ? "hilbert_interval+mbr_halo+baseline+single_task"
                    : "z_interval+independent+baseline+single_task") + "\r\n");
            writer.write("routing_strategy: " + (hilbert
                    ? "single_expanded_mbr_per_hilbert_owner"
                    : "single_z_interval_envelope_per_owner") + "\r\n");
            writer.write("strategy: " + (hilbert
                    ? "HILBERT_EQUAL_COUNT_MBR_2DC_BOUND"
                    : "ZORDER_DP_THEOREM3_BOUND") + "\r\n");
            writer.write("dependency_radius: 2dc\r\n");
            writer.write("time_s: " + formatSeconds(totalMs) + "\r\n");
            writer.write("comparable_query_time_s: " + formatSeconds(comparableQueryMs) + "\r\n");
            writer.write("s1_read_prepare_s: " + formatSeconds(s1) + "\r\n");
            writer.write("s2_partition_plan_s: " + formatSeconds(s2) + "\r\n");
            writer.write("s3_replicate_shuffle_s: " + formatSeconds(s3) + "\r\n");
            writer.write("s4_local_compute_s: " + formatSeconds(s4) + "\r\n");
            writer.write("s5_global_reduce_s: " + formatSeconds(s5) + "\r\n");
            writer.write("s6_materialize_s: " + formatSeconds(s6) + "\r\n");
            writer.write("partition_count: " + partitions + "\r\n");
            writer.write("dc: " + dc + "\r\n");
            writer.write("density_k: " + densityK + "\r\n");
            writer.write("cell_size_multiplier_materialize_only: " + cellSizeMultiplier + "\r\n");
            writer.write("query_x: " + queryX + "\r\n");
            writer.write("query_y: " + queryY + "\r\n");
            writer.write("deduplicate: " + deduplicate + "\r\n");
            writer.write("original_points: " + originalPoints + "\r\n");
            writer.write("assigned_points: " + assignedPoints + "\r\n");
            writer.write("clone_points: " + clonePoints + "\r\n");
            writer.write("clone_ratio: " + formatRatio(clonePoints, originalPoints) + "\r\n");
            writer.write("replication_multiplier: " + formatRatio(assignedPoints, originalPoints) + "\r\n");
            writer.write("routing_bound_checks: "
                    + originalPoints * Math.max(0L, (long) partitions - 1L) + "\r\n");
            writer.write("min_core_points: " + minCore + "\r\n");
            writer.write("max_core_points: " + maxCore + "\r\n");
            writer.write("min_assigned_points: " + minAssigned + "\r\n");
            writer.write("max_assigned_points: " + maxAssigned + "\r\n");
            writer.write("candidate_count: " + candidateCount + "\r\n");
            writer.write("single_point_candidates: " + singlePointCandidateCount + "\r\n");
            writer.write("pair_candidates: " + pairCandidateCount + "\r\n");
            writer.write("z_window_checks: " + zWindowChecks + "\r\n");
            writer.write("point_distance_checks: " + pointDistanceChecks + "\r\n");
            writer.write("local_task_compute_sum_s: " + formatSeconds(taskComputeSum) + "\r\n");
            writer.write("local_task_compute_max_s: " + formatSeconds(taskComputeMax) + "\r\n");
            writer.write("count_mismatches: " + countMismatches + "\r\n");
            writer.write("skyline_count: " + circles.size() + "\r\n");
            for (Circle circle : circles) {
                writer.write(format2(circle.discenq) + " = " + circle.cirnum + " "
                        + format2(circle.centerX) + " " + format2(circle.centerY) + "\r\n");
                if (circle.p != null) {
                    for (Point point : circle.p) {
                        writer.write("   " + memberText.format(point.x) + "   " + memberText.format(point.y) + "\r\n");
                    }
                }
            }
        }
        MemberTextFormatter.appendOutputTiming(outputPath,System.nanoTime()-outputStartNanos);
    }

    private static int countMismatches(EMCSBaseline result) {
        int mismatches = 0;
        for (Circle circle : result.skymap.values()) {
            int size = circle.p == null ? 0 : circle.p.size();
            if (circle.cirnum != size) mismatches++;
        }
        return mismatches;
    }

    private static void printSummary(
            String outputPath,
            int skylineCount,
            long originalPoints,
            long assignedPoints,
            long clonePoints,
            long comparableQueryMs,
            long totalMs,
            boolean hilbert) {
        System.out.println("method_profile=" + (hilbert ? "hilbert_d0" : "z_d0"));
        System.out.println("strategy=" + (hilbert
                ? "HILBERT_EQUAL_COUNT_MBR_2DC_BOUND"
                : "ZORDER_DP_THEOREM3_BOUND"));
        System.out.println("dependency_radius=2dc");
        System.out.println("original_points=" + originalPoints);
        System.out.println("assigned_points=" + assignedPoints);
        System.out.println("clone_points=" + clonePoints);
        System.out.println("clone_ratio=" + formatRatio(clonePoints, originalPoints));
        System.out.println("replication_multiplier=" + formatRatio(assignedPoints, originalPoints));
        System.out.println("comparable_query_time_s=" + formatSeconds(comparableQueryMs));
        System.out.println("total_time_s=" + formatSeconds(totalMs));
        System.out.println("skyline_count=" + skylineCount);
        System.out.println("output=" + new File(outputPath).getAbsolutePath());
    }

    private static void sortPoints(ArrayList<Point> points) {
        Collections.sort(points, new Comparator<Point>() {
            @Override
            public int compare(Point left, Point right) {
                int byZ = left.zval.compareTo(right.zval);
                return byZ != 0 ? byZ : Long.compare(left.id, right.id);
            }
        });
    }

    private static void sortCircles(List<Circle> circles) {
        Collections.sort(circles, new Comparator<Circle>() {
            @Override
            public int compare(Circle left, Circle right) {
                return Double.compare(left.discenq, right.discenq);
            }
        });
    }

    private static String minString(String current, String value) {
        return current == null || value.compareTo(current) < 0 ? value : current;
    }

    private static String maxString(String current, String value) {
        return current == null || value.compareTo(current) > 0 ? value : current;
    }

    private static String zValue(long x, long y) {
        return Zorder.valueOf(2, new long[]{x, y});
    }

    private static String hilbertValue(Point point) {
        return HilbertOrder.valueOf(
                roundCoordinate(point.x, "Hilbert x"),
                roundCoordinate(point.y, "Hilbert y"));
    }

    private static long roundCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value + 0.5d), label);
    }

    private static long ceilCoordinate(double value, String label) {
        return checkedCoordinate(Math.ceil(value), label);
    }

    private static long floorCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value), label);
    }

    private static long checkedCoordinate(double value, String label) {
        if (Double.isNaN(value) || Double.isInfinite(value) || value < 0.0 || value > Long.MAX_VALUE) {
            throw new IllegalArgumentException("Invalid " + label + " coordinate: " + value);
        }
        return (long) value;
    }

    private static int checkedCellCoordinate(double value, String label) {
        if (Double.isNaN(value) || Double.isInfinite(value) || value < Integer.MIN_VALUE || value > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("Invalid " + label + ": " + value);
        }
        return (int) value;
    }

    private static double distance(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2;
        double dy = y1 - y2;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private static double round2(double value) {
        return (double) Math.round(value * 100.0) / 100.0;
    }

    private static String formatSeconds(long millis) {
        return String.format(Locale.ROOT, "%.3f", millis / 1000.0);
    }

    private static String formatRatio(long numerator, long denominator) {
        return String.format(Locale.ROOT, "%.6f", denominator == 0L ? 0.0 : (double) numerator / denominator);
    }

    private static String format2(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    private static String localPath(String argument) throws URISyntaxException {
        URI uri = new URI(argument);
        if (uri.getScheme() == null) return argument;
        if (!"file".equalsIgnoreCase(uri.getScheme())) {
            throw new IllegalArgumentException("Output must be a local path or file:// URI: " + argument);
        }
        return new File(uri).getPath();
    }

    private static void validateArguments(int partitions, double dc, int densityK, double cellSizeMultiplier) {
        if (partitions <= 0) throw new IllegalArgumentException("partitions must be positive");
        if (!(dc > 0.0) || Double.isNaN(dc) || Double.isInfinite(dc)) {
            throw new IllegalArgumentException("dc must be finite and positive");
        }
        if (densityK < 0) throw new IllegalArgumentException("densityK cannot be negative");
        if (!(cellSizeMultiplier > 0.0) || Double.isNaN(cellSizeMultiplier)
                || Double.isInfinite(cellSizeMultiplier)) {
            throw new IllegalArgumentException("cellSizeMultiplier must be finite and positive");
        }
    }

    private static void printUsageAndExit() {
        System.err.println("Usage: DistributedSMCZOrderDPBoundBaseline input output partitions dc densityK "
                + "cellSizeMultiplier [queryX queryY deduplicate]");
        System.exit(2);
    }
}
