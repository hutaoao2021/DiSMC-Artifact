package com;

import java.io.Serializable;
import java.util.Arrays;

/** Primitive long-to-ordinal map used while compacting routed point records. */
public final class LongOrdinalIndex implements Serializable {
    private static final float LOAD_FACTOR = 0.65f;

    private long[] keys;
    private int[] encodedOrdinals;
    private int size;
    private int resizeAt;

    public LongOrdinalIndex(int expectedSize) {
        int capacity = 16;
        int needed = Math.max(1, expectedSize);
        while (capacity * LOAD_FACTOR < needed) {
            capacity <<= 1;
        }
        keys = new long[capacity];
        encodedOrdinals = new int[capacity];
        resizeAt = (int) (capacity * LOAD_FACTOR);
    }

    public int get(long key) {
        int slot = slot(key, encodedOrdinals.length);
        while (encodedOrdinals[slot] != 0) {
            if (keys[slot] == key) {
                return encodedOrdinals[slot] - 1;
            }
            slot = (slot + 1) & (encodedOrdinals.length - 1);
        }
        return -1;
    }

    public void put(long key, int ordinal) {
        if (ordinal < 0 || ordinal == Integer.MAX_VALUE) {
            throw new IllegalArgumentException("invalid ordinal: " + ordinal);
        }
        if (size >= resizeAt) {
            rehash(encodedOrdinals.length << 1);
        }
        insert(key, ordinal);
    }

    private void insert(long key, int ordinal) {
        int slot = slot(key, encodedOrdinals.length);
        while (encodedOrdinals[slot] != 0) {
            if (keys[slot] == key) {
                int oldOrdinal = encodedOrdinals[slot] - 1;
                if (oldOrdinal != ordinal) {
                    throw new IllegalArgumentException("point id mapped to two ordinals: " + key);
                }
                return;
            }
            slot = (slot + 1) & (encodedOrdinals.length - 1);
        }
        keys[slot] = key;
        encodedOrdinals[slot] = ordinal + 1;
        size++;
    }

    private void rehash(int capacity) {
        long[] oldKeys = keys;
        int[] oldValues = encodedOrdinals;
        keys = new long[capacity];
        encodedOrdinals = new int[capacity];
        size = 0;
        resizeAt = (int) (capacity * LOAD_FACTOR);
        for (int i = 0; i < oldValues.length; i++) {
            if (oldValues[i] != 0) {
                insert(oldKeys[i], oldValues[i] - 1);
            }
        }
        Arrays.fill(oldValues, 0);
    }

    private static int slot(long key, int capacity) {
        long mixed = key;
        mixed ^= mixed >>> 33;
        mixed *= 0xff51afd7ed558ccdL;
        mixed ^= mixed >>> 33;
        mixed *= 0xc4ceb9fe1a85ec53L;
        mixed ^= mixed >>> 33;
        return ((int) mixed) & (capacity - 1);
    }
}
