package com;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Local ESMC kernel copied from smcq_single_emcs_baseline.
 *
 * Candidate construction, circle construction, counting and skyline maintenance
 * are kept from the sister single-machine implementation. The distributed
 * entry point only restricts anchors to core points owned by the current Spark
 * partition; replicated points remain available as neighbours and pair endpoints.
 */
public class EMCSBaseline {
    private static final int SKYLINE_FLUSH_THRESHOLD = 10000;

    Point q = new Point(15, 15);
    double dc = 0;
    int densityK = 0;
    public ArrayList<Circle> circles = new ArrayList<Circle>();
    public ArrayList<Point> plist = new ArrayList<Point>();
    HashMap<Double, Circle> skymap = new HashMap<Double, Circle>();

    long candidateCount = 0;
    long singlePointCandidateCount = 0;
    long pairCandidateCount = 0;
    long zWindowChecks = 0;
    long pointDistanceChecks = 0;

    public EMCSBaseline(double dc, int densityK) {
        this.dc = dc;
        this.densityK = densityK;
    }

    public void setQueryPoint(double x, double y) {
        this.q.x = x;
        this.q.y = y;
    }

    public void init(String inputPath) throws IOException {
        init(inputPath, false);
    }

    public void init(String inputPath, boolean deduplicate) throws IOException {
        HashSet<String> seen = deduplicate ? new HashSet<String>() : null;
        try (BufferedReader br = new BufferedReader(new FileReader(inputPath))) {
            String line;
            long index = 0L;
            while ((line = br.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line);
                if (!tokenizer.hasMoreTokens()) {
                    continue;
                }
                double x = Double.parseDouble(tokenizer.nextToken());
                double y = Double.parseDouble(tokenizer.nextToken());
                if (deduplicate) {
                    String key = x + "," + y;
                    if (!seen.add(key)) {
                        continue;
                    }
                }

                Point point = new Point(x, y);
                point.id = index++;
                long[] pzval = {roundCoordinate(x, "x"), roundCoordinate(y, "y")};
                point.zval = Zorder.valueOf(2, pzval);
                long[] upper = {ceilCoordinate(x + 2 * dc, "upper x"), ceilCoordinate(y + 2 * dc, "upper y")};
                point.pupperzval = Zorder.valueOf(2, upper);
                long[] lower = {
                        x - 2 * dc > 0 ? floorCoordinate(x - 2 * dc, "lower x") : 0L,
                        y - 2 * dc > 0 ? floorCoordinate(y - 2 * dc, "lower y") : 0L
                };
                point.plowzval = Zorder.valueOf(2, lower);
                plist.add(point);
            }
        }

        Collections.sort(plist, new Comparator<Point>() {
            @Override
            public int compare(Point p1, Point p2) {
                return p1.zval.compareTo(p2.zval);
            }
        });
    }

    public void method() {
        methodRange(0, plist.size());
    }

    public void methodRange(int startAnchorInclusive, int endAnchorExclusive) {
        if (startAnchorInclusive < 0 || endAnchorExclusive < startAnchorInclusive
                || endAnchorExclusive > plist.size()) {
            throw new IllegalArgumentException("Invalid anchor range [" + startAnchorInclusive + ", "
                    + endAnchorExclusive + ") for " + plist.size() + " points");
        }

        methodInternal(startAnchorInclusive, endAnchorExclusive, -1, false);
    }

    public void methodForPartition(int partitionId) {
        methodInternal(0, plist.size(), partitionId, true);
    }

    private void methodInternal(
            int startAnchorInclusive,
            int endAnchorExclusive,
            int partitionId,
            boolean coreAnchorsOnly) {

        for (int i = startAnchorInclusive; i < endAnchorExclusive; i++) {
            Point p1 = plist.get(i);
            if (coreAnchorsOnly && (!p1.isCore || p1.ownerPartitionId != partitionId)) {
                continue;
            }
            double qp1 = q.distanceTo(p1);
            Circle anchorCircle = new Circle();

            int pposition1 = binarySearch(plist, p1.plowzval);
            int pposition2 = binarySearch(plist, p1.pupperzval);
            int start = Math.max(0, pposition1 - 1);
            int end = Math.min(plist.size(), pposition2 + 1);

            p1.pcirnum = 0;
            for (int n = start; n < end; n++) {
                pointDistanceChecks++;
                double cdp = round2(p1.distanceTo(plist.get(n)));
                if (cdp <= 2 * dc) {
                    p1.pcirnum++;
                }
            }

            anchorCircle.cirnum = p1.pcirnum;
            anchorCircle.discenq = Math.max(0, qp1 - dc);
            if (isDominated(anchorCircle)) {
                continue;
            }

            circles.add(buildSinglePointCircle(p1, qp1));
            candidateCount++;
            singlePointCandidateCount++;
            if (circles.size() >= SKYLINE_FLUSH_THRESHOLD) {
                flushCandidates();
            }

            for (int j = i + 1; j < end; j++) {
                Point p2 = plist.get(j);
                double d12 = p1.distanceTo(p2);
                if (d12 <= 0 || d12 > 2 * dc) {
                    continue;
                }

                Circle candidate = buildCandidateCircle(p1, p2, qp1);
                candidateCount++;
                pairCandidateCount++;
                if (candidate == null) {
                    continue;
                }
                circles.add(candidate);

                if (circles.size() >= SKYLINE_FLUSH_THRESHOLD) {
                    flushCandidates();
                }
            }
        }

        if (!circles.isEmpty()) {
            flushCandidates();
        }
    }

    private boolean isDominated(Circle candidate) {
        if (skymap == null || skymap.isEmpty()) {
            return false;
        }
        for (Circle skylineCircle : skymap.values()) {
            if (skylineCircle.cirnum > candidate.cirnum && skylineCircle.discenq < candidate.discenq) {
                return true;
            }
        }
        return false;
    }

    private Circle buildCandidateCircle(Point p1, Point p2, double qp1) {
        double qp2 = q.distanceTo(p2);
        Point projected = new Point();
        Circle cc = new Circle();

        if (qp1 > qp2) {
            projected = projectTowardQuery(p1, qp1);
            if (p2.distanceTo(projected) <= dc) {
                cc.centerX = projected.x;
                cc.centerY = projected.y;
            } else {
                Point center = circleCenter(p1.x, p1.y, p2.x, p2.y);
                if (center == null) {
                    return null;
                }
                cc.centerX = center.x;
                cc.centerY = center.y;
            }
        } else {
            projected = projectTowardQuery(p2, qp2);
            if (p1.distanceTo(projected) <= dc) {
                cc.centerX = projected.x;
                cc.centerY = projected.y;
            } else {
                Point center = circleCenter(p1.x, p1.y, p2.x, p2.y);
                if (center == null) {
                    return null;
                }
                cc.centerX = center.x;
                cc.centerY = center.y;
            }
        }

        cc.discenq = round2(Math.sqrt(
                (cc.centerX - q.x) * (cc.centerX - q.x) +
                        (cc.centerY - q.y) * (cc.centerY - q.y)
        ));

        long[] low = {
                cc.centerX - dc > 0 ? floorCoordinate(cc.centerX - dc, "candidate lower x") : 0L,
                cc.centerY - dc > 0 ? floorCoordinate(cc.centerY - dc, "candidate lower y") : 0L
        };
        cc.lowzval = Zorder.valueOf(2, low);
        long[] upper = {
                ceilCoordinate(cc.centerX + dc, "candidate upper x"),
                ceilCoordinate(cc.centerY + dc, "candidate upper y")
        };
        cc.upperzval = Zorder.valueOf(2, upper);
        return cc;
    }

    private Circle buildSinglePointCircle(Point point, double queryDistance) {
        Point projected = projectTowardQuery(point, queryDistance);
        Circle circle = new Circle();
        circle.centerX = projected.x;
        circle.centerY = projected.y;
        circle.discenq = round2(Math.sqrt(
                (circle.centerX - q.x) * (circle.centerX - q.x) +
                        (circle.centerY - q.y) * (circle.centerY - q.y)));
        long[] low = {
                circle.centerX - dc > 0 ? floorCoordinate(circle.centerX - dc, "single lower x") : 0L,
                circle.centerY - dc > 0 ? floorCoordinate(circle.centerY - dc, "single lower y") : 0L
        };
        circle.lowzval = Zorder.valueOf(2, low);
        long[] upper = {
                ceilCoordinate(circle.centerX + dc, "single upper x"),
                ceilCoordinate(circle.centerY + dc, "single upper y")
        };
        circle.upperzval = Zorder.valueOf(2, upper);
        return circle;
    }

    private Point projectTowardQuery(Point point, double queryDistance) {
        Point projected = new Point();
        if (queryDistance <= dc) {
            projected.x=q.x; projected.y=q.y; return projected;
        }
        if (point.x > q.x) {
            projected.x = q.x + ((queryDistance - dc) / queryDistance) * Math.abs(point.x - q.x);
        } else if (point.x == q.x) {
            projected.x = q.x;
        } else {
            projected.x = q.x - ((queryDistance - dc) / queryDistance) * Math.abs(point.x - q.x);
        }

        if (point.y > q.y) {
            projected.y = q.y + ((queryDistance - dc) / queryDistance) * Math.abs(point.y - q.y);
        } else if (point.y == q.y) {
            projected.y = q.y;
        } else {
            projected.y = q.y - ((queryDistance - dc) / queryDistance) * Math.abs(point.y - q.y);
        }
        return projected;
    }

    private void flushCandidates() {
        for (int d = 0; d < circles.size(); d++) {
            Circle candidate = circles.get(d);
            int position1 = binarySearch(plist, candidate.lowzval);
            int position2 = binarySearch(plist, candidate.upperzval);
            int start = Math.max(0, position1 - 1);
            int end = Math.min(plist.size(), position2 + 1);
            zWindowChecks += (end - start);
            for (int n = start; n < end; n++) {
                pointDistanceChecks++;
                double cdp = round2(Math.sqrt(
                        (candidate.centerX - plist.get(n).x) * (candidate.centerX - plist.get(n).x) +
                                (candidate.centerY - plist.get(n).y) * (candidate.centerY - plist.get(n).y)
                ));
                if (cdp <= dc) {
                    candidate.cirnum++;
                }
            }
        }

        ArrayList<Circle> merged = new ArrayList<Circle>(circles.size() + skymap.size());
        merged.addAll(circles);
        merged.addAll(skymap.values());
        Collections.sort(merged, new Comparator<Circle>() {
            @Override
            public int compare(Circle cc1, Circle cc2) {
                return Double.compare(cc1.discenq, cc2.discenq);
            }
        });

        HashMap<Double, Circle> nextSky = skylineCircle(merged);
        if (densityK > 0) {
            HashMap<Double, Circle> filtered = new HashMap<Double, Circle>();
            for (Map.Entry<Double, Circle> entry : nextSky.entrySet()) {
                if (entry.getValue().cirnum >= densityK) {
                    filtered.put(entry.getKey(), entry.getValue());
                }
            }
            skymap = filtered;
        } else {
            skymap = nextSky;
        }
        circles.clear();
    }

    public int binarySearch(ArrayList<Point> points, String lowz) {
        int low = 0;
        int high = points.size() - 1;
        while (low <= high) {
            int middle = (low + high) / 2;
            int cmp = points.get(middle).zval.compareTo(lowz);
            if (cmp > 0) {
                high = middle - 1;
            } else if (cmp < 0) {
                low = middle + 1;
            } else {
                return middle;
            }
        }
        return low;
    }

    public Point circleCenter(double x1, double y1, double x2, double y2) {
        Point p1 = new Point();
        Point p2 = new Point();
        Point p = new Point();
        double disp12 = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
        if (disp12 > 2 * dc) {
            return null;
        }
        if (Math.abs(disp12 - 2 * dc) < 1e-9) {
            p.x = (x1 + x2) / 2;
            p.y = (y1 + y2) / 2;
            return p;
        }

        if (x1 != x2) {
            double c1 = (x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1) / (2 * (x2 - x1));
            double c2 = (y2 - y1) / (x2 - x1);
            double A = c2 * c2 + 1;
            double B = 2 * x1 * c2 - 2 * c1 * c2 - 2 * y1;
            double C = x1 * x1 - 2 * x1 * c1 + c1 * c1 + y1 * y1 - dc * dc;
            double delta = B * B - 4 * A * C;
            if (delta < 0) {
                return null;
            }

            if (y1 == y2) {
                double middleX = (x1 + x2) / 2;
                double vertical = Math.sqrt(Math.max(0, dc * dc - ((x1 - x2) / 2) * ((x1 - x2) / 2)));
                p1.x = middleX;
                p1.y = y1 + vertical;
                p2.x = middleX;
                p2.y = y1 - vertical;
            } else {
                p1.y = (-B + Math.sqrt(delta)) / (2 * A);
                p1.x = c1 - c2 * p1.y;
                p2.y = (-B - Math.sqrt(delta)) / (2 * A);
                p2.x = c1 - c2 * p2.y;
            }
        } else {
            double middleY = (y1 + y2) / 2;
            double horizontal = Math.sqrt(Math.max(0, dc * dc - ((y1 - y2) / 2) * ((y1 - y2) / 2)));
            p1.y = middleY;
            p1.x = x1 + horizontal;
            p2.y = middleY;
            p2.x = x1 - horizontal;
        }

        return q.distanceTo(p1) < q.distanceTo(p2) ? p1 : p2;
    }

    public HashMap<Double, Circle> skylineCircle(ArrayList<Circle> candidateCircles) {
        HashMap<Double, Circle> map = new HashMap<Double, Circle>();
        int max = -1;
        for (Circle circle : candidateCircles) {
            if (map.containsKey(circle.discenq)) {
                if (isPreferredAtSameDistance(circle, map.get(circle.discenq))) {
                    map.put(circle.discenq, circle);
                    max = circle.getCirnum();
                }
            } else if (circle.getCirnum() > max) {
                map.put(circle.discenq, circle);
                max = circle.getCirnum();
            }
        }
        return map;
    }

    private boolean isPreferredAtSameDistance(Circle candidate, Circle current) {
        if (candidate.getCirnum() != current.getCirnum()) {
            return candidate.getCirnum() > current.getCirnum();
        }
        int centerXOrder = Double.compare(candidate.centerX, current.centerX);
        return centerXOrder < 0
                || (centerXOrder == 0 && Double.compare(candidate.centerY, current.centerY) < 0);
    }

    public void materializeFinalPoints() {
        if (skymap == null || skymap.isEmpty()) {
            return;
        }
        for (Circle circle : skymap.values()) {
            circle.p = new ArrayList<Point>();
            for (Point point : plist) {
                double cdp = round2(Math.sqrt(
                        (circle.centerX - point.x) * (circle.centerX - point.x) +
                                (circle.centerY - point.y) * (circle.centerY - point.y)
                ));
                if (cdp <= dc) {
                    circle.p.add(point);
                }
            }
        }
    }

    public void out(String outputPath, long queryTimeMs, long materializeTimeMs) throws IOException {
        ArrayList<Circle> ordered = new ArrayList<Circle>(skymap.values());
        Collections.sort(ordered, new Comparator<Circle>() {
            @Override
            public int compare(Circle a, Circle b) {
                return Double.compare(a.discenq, b.discenq);
            }
        });

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputPath))) {
            bw.write("query_time_s: " + formatSeconds(queryTimeMs) + "\r\n");
            bw.write("materialize_time_s: " + formatSeconds(materializeTimeMs) + "\r\n");
            bw.write("total_time_s: " + formatSeconds(queryTimeMs + materializeTimeMs) + "\r\n");
            bw.write("skyline_count: " + ordered.size() + "\r\n");
            bw.write("candidate_count: " + candidateCount + "\r\n");
            bw.write("single_point_candidates: " + singlePointCandidateCount + "\r\n");
            bw.write("pair_candidates: " + pairCandidateCount + "\r\n");
            bw.write("z_window_checks: " + zWindowChecks + "\r\n");
            bw.write("point_distance_checks: " + pointDistanceChecks + "\r\n");
            for (Circle circle : ordered) {
                bw.write(format2(circle.discenq) + " = " + circle.cirnum + " " + format2(circle.centerX) + " "
                        + format2(circle.centerY) + "\r\n");
                for (Point point : circle.p) {
                    bw.write("   " + format2(point.x) + "   " + format2(point.y) + "\r\n");
                }
            }
        }
    }

    public void appendEndToEndTime(String outputPath, long endToEndTimeMs) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputPath, true))) {
            bw.write("end_to_end_time_s: " + formatSeconds(endToEndTimeMs) + "\r\n");
        }
    }

    private double round2(double value) {
        return (double) Math.round(value * 100) / 100;
    }

    private long roundCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value + 0.5d), label);
    }

    private long ceilCoordinate(double value, String label) {
        return checkedCoordinate(Math.ceil(value), label);
    }

    private long floorCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value), label);
    }

    private long checkedCoordinate(double value, String label) {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            throw new IllegalArgumentException("Invalid " + label + " coordinate: " + value);
        }
        if (value < 0 || value > Long.MAX_VALUE) {
            throw new IllegalArgumentException("Coordinate is outside long range for " + label + ": " + value);
        }
        return (long) value;
    }

    public String formatSeconds(long millis) {
        return String.format(Locale.ROOT, "%.3f", millis / 1000.0);
    }

    private String format2(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
