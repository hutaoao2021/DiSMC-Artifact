package com;

import java.util.*;
import org.apache.spark.*;
import org.apache.spark.api.java.*;
import org.apache.spark.rdd.RDD;
import scala.Tuple2;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** One independently shuffled and cached complete neighbourhood per owner. */
public final class OwnerNeighborhoodRDD extends RDD<OwnerNeighborhoodRDD.Block> {
    public static final class Block {
        final int owner;
        final Point[] points;
        transient PreparedNeighborhood prepared;
        Block(int owner, Point[] points) { this.owner=owner; this.points=points; }
    }
    private final RDD<Tuple2<Integer,Point>> parent;
    private final Partition[] partitions;
    private static Seq<Dependency<?>> deps(RDD<Tuple2<Integer,Point>> parent) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(
                new OneToOneDependency<Tuple2<Integer,Point>>(parent))).asScala().toSeq();
    }
    public OwnerNeighborhoodRDD(JavaPairRDD<Integer,Point> input) {
        super(input.context(),deps(input.rdd()),ClassTag$.MODULE$.<Block>apply(Block.class));
        parent=input.rdd(); partitions=parent.partitions();
    }
    public Partition[] getPartitions(){return partitions;}
    public scala.collection.Iterator<Block> compute(Partition split,TaskContext context) {
        ArrayList<Point> points=new ArrayList<>();
        scala.collection.Iterator<Tuple2<Integer,Point>> it=parent.iterator(split,context);
        while(it.hasNext())points.add(it.next()._2());
        return JavaConverters.asScalaIteratorConverter(Collections.singletonList(
                new Block(split.index(),points.toArray(new Point[0]))).iterator()).asScala();
    }
    public JavaRDD<Block> asJava(){return JavaRDD.fromRDD(this,ClassTag$.MODULE$.<Block>apply(Block.class));}
}
