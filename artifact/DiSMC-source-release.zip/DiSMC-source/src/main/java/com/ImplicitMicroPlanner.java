package com;
import java.io.Serializable;import java.util.*;
/** Typed experimental adapter of the existing greedy peak/budget policy. */
public final class ImplicitMicroPlanner {
 public static final class Candidate implements Serializable {
  public final int owner;public final ImplicitResponsibility rule;private final long[]cores,inputs;private final double[]work;
  public Candidate(int owner,ImplicitResponsibility rule,long[]cores,long[]inputs,double[]work){
   if(owner<0||rule==null||cores==null||inputs==null||work==null||cores.length!=rule.pieces()||inputs.length!=cores.length||work.length!=cores.length)throw new IllegalArgumentException("candidate dimensions");
   for(int i=0;i<cores.length;i++)if(cores[i]<=0||inputs[i]<cores[i]||!Double.isFinite(work[i])||work[i]<0)throw new IllegalArgumentException("invalid task population/work");
   if(!rule.isHash()&&!Arrays.equals(cores,rule.coreCounts()))throw new IllegalArgumentException("rule/core cardinality mismatch");
   this.owner=owner;this.rule=rule;this.cores=cores.clone();this.inputs=inputs.clone();this.work=work.clone();
  }
  public long[]coreCounts(){return cores.clone();}public long[]inputCounts(){return inputs.clone();}public double[]work(){return work.clone();}
  public String signature(){return MicroPartitionLayout.digest("implicit-candidate-v1:"+owner+":"+rule.signature()+":"+Arrays.toString(cores)+":"+Arrays.toString(inputs));}
 }
 public static final class Plan implements Serializable {
  private final Candidate[]selected;private final long[]parent;private final double[]originalWork;private final long budget,extra;private final int slots;private final double peak,makespan;
  private Plan(Candidate[]selected,long[]parent,double[]work,long budget,int slots){this.selected=selected.clone();this.parent=parent.clone();originalWork=work.clone();this.budget=budget;this.slots=slots;long charge=0;for(int o=0;o<parent.length;o++)if(selected[o]!=null)charge=Math.addExact(charge,MicroPartitionPlanner.extra(selected[o].inputs,parent[o]));extra=charge;double[]tasks=work();peak=MicroPartitionPlanner.maximum(tasks);makespan=MicroPartitionPlanner.lpt(tasks,slots);}
  public int ownerCount(){return selected.length;}
  public long[]inputCounts(int owner){return selected[owner]==null?new long[]{parent[owner]}:selected[owner].inputCounts();}
  public int owner(int task){if(task<0)throw new IllegalArgumentException("negative task");for(int o=0;o<selected.length;o++){int k=selected[o]==null?1:selected[o].rule.pieces();if(task<k)return o;task-=k;}throw new IllegalArgumentException("task outside plan");}
  public int lane(int task){if(task<0)throw new IllegalArgumentException("negative task");for(Candidate c:selected){int k=c==null?1:c.rule.pieces();if(task<k)return task;task-=k;}throw new IllegalArgumentException("task outside plan");}
  public Candidate candidate(int owner){return selected[owner];}public long budgetRecords(){return budget;}public long extraRecords(){return extra;}
  public int taskCount(){int n=0;for(Candidate c:selected)n=Math.addExact(n,c==null?1:c.rule.pieces());return n;}
  public double[]work(){double[]tasks=new double[taskCount()];int i=0;for(int o=0;o<selected.length;o++){Candidate c=selected[o];if(c==null)tasks[i++]=originalWork[o];else for(double x:c.work)tasks[i++]=x;}return tasks;}
  public String signature(){StringBuilder s=new StringBuilder("implicit-plan-v1:").append(budget);for(int o=0;o<selected.length;o++)s.append('|').append(o).append(':').append(parent[o]).append(':').append(selected[o]==null?"unsplit":selected[o].signature());return MicroPartitionLayout.digest(s.toString());}
 }
 public static Plan select(long[]parent,double[]work,Candidate[]alternatives,double fraction,int slots){
  if(parent==null||work==null||alternatives==null||parent.length==0||parent.length!=work.length||slots<1||!Double.isFinite(fraction)||fraction<0||fraction>1)throw new IllegalArgumentException("planning dimensions");long sum=0;for(int o=0;o<parent.length;o++){if(parent[o]<0||!Double.isFinite(work[o])||work[o]<0)throw new IllegalArgumentException("invalid parent/work");sum=Math.addExact(sum,parent[o]);}
  for(Candidate c:alternatives){if(c==null||c.owner>=parent.length)throw new IllegalArgumentException("invalid candidate owner");long core=0;for(long n:c.cores)core=Math.addExact(core,n);if(core>parent[c.owner])throw new IllegalArgumentException("responsibility exceeds original parent");for(long n:c.inputs)if(n>parent[c.owner]||c.rule.isHash()&&n!=parent[c.owner])throw new IllegalArgumentException("candidate exceeds original parent/fullhash contract");}
  long budget=(long)Math.floor(sum*fraction);Plan current=new Plan(new Candidate[parent.length],parent,work,budget,slots);
  while(true){Plan best=null;double scoreBest=-1;int ownerBest=Integer.MAX_VALUE;String signatureBest=null;
   for(Candidate c:alternatives){Candidate prev=current.selected[c.owner];if(prev!=null&&c.rule.pieces()<=prev.rule.pieces())continue;Candidate[]selection=current.selected.clone();selection[c.owner]=c;Plan next=new Plan(selection,parent,work,budget,slots);if(next.extra>budget||!(next.peak<current.peak))continue;double score=(current.peak-next.peak)/Math.max(1,next.extra-current.extra);String signature=c.signature();
    if(score>scoreBest||score==scoreBest&&(best==null||next.makespan<best.makespan||next.makespan==best.makespan&&(next.extra<best.extra||next.extra==best.extra&&(c.owner<ownerBest||c.owner==ownerBest&&(next.taskCount()<best.taskCount()||next.taskCount()==best.taskCount()&&signature.compareTo(signatureBest)<0))))){best=next;scoreBest=score;ownerBest=c.owner;signatureBest=signature;}
   }if(best==null)return current;current=best;
  }
 }
 private ImplicitMicroPlanner(){}
}
