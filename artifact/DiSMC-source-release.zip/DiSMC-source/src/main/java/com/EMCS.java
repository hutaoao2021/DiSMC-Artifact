package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class EMCS {
    private static final int LOCAL_SKYLINE_BATCH_SIZE = 4096;

    Point q = new Point(100, 101);
    double dc = 0;
    double dc2 = 0;
    double twoDc = 0;
    double twoDc2 = 0;
    int density_k = 0;
    int part_id = 0;
    double cellSize = 1.0;

    public ArrayList<Circle> circles = new ArrayList<Circle>();
    public ArrayList<Point> plist = new ArrayList<Point>();
    HashMap<Double, Circle> skymap = new HashMap<Double, Circle>();
    private transient NavigableMap<Double, Circle> skylineByDistance = new TreeMap<Double, Circle>();

    private transient Map<Long, List<Point>> pointsByCell = new HashMap<Long, List<Point>>();
    private transient Map<Long, Double> queryDistanceByPointId = new HashMap<Long, Double>();
    private transient Map<Long, Integer> anchorCountByPointId = new HashMap<Long, Integer>();
    long candidateCount;
    long singlePointCandidateCount;
    long pairCandidateCount;

    public EMCS(double dc) {
        this.dc = dc;
        this.dc2 = dc * dc;
        this.twoDc = 2 * dc;
        this.twoDc2 = 4 * dc * dc;
    }

    public void setCellConfig(double cellSize) {
        this.cellSize = cellSize;
    }

    public void method(double dc) {
        rebuildIndexesAndCaches();
        for (int i = 0; i < plist.size(); i++) {
            Point p1 = plist.get(i);
            if (!p1.is_core || p1.ownerPartitionId != this.part_id) {
                continue;
            }

            Circle anchorCircle = buildAnchorCircle(p1);
            // Actual candidate centers are certified below.

            int p1AnchorUpperBound = anchorCircle.cirnum;
            Circle singlePointCandidate = buildSinglePointCircle(p1);
            candidateCount++;
            singlePointCandidateCount++;
            int singleRequiredCount = minimumRequiredCount(singlePointCandidate.discenq);
            if (p1AnchorUpperBound >= singleRequiredCount || !anchorContains(p1,singlePointCandidate.centerX,singlePointCandidate.centerY)) {
                int singlePointCount = countPointsNear(singlePointCandidate.centerX,
                        singlePointCandidate.centerY, dc2, dc, singleRequiredCount);
                if (singlePointCount >= singleRequiredCount && singlePointCount >= density_k) {
                    singlePointCandidate.cirnum = singlePointCount;
                    circles.add(singlePointCandidate);
                    if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) flushCandidateCircles();
                }
            }
            int minCellX = (int) Math.floor((p1.x - twoDc) / cellSize);
            int maxCellX = (int) Math.floor((p1.x + twoDc) / cellSize);
            int minCellY = (int) Math.floor((p1.y - twoDc) / cellSize);
            int maxCellY = (int) Math.floor((p1.y + twoDc) / cellSize);

            for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
                for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                    List<Point> bucket = pointsByCell.get(pack(cellX, cellY));
                    if (bucket == null) {
                        continue;
                    }

                    for (Point p2 : bucket) {
                        if (p1.id >= p2.id) {
                            continue;
                        }

                        double d12Squared = squaredDistance(p1.x, p1.y, p2.x, p2.y);
                        if (d12Squared <= 0 || d12Squared > twoDc2) {
                            continue;
                        }

                        Circle candidate = buildCandidateCircle(p1, p2, d12Squared);
                        candidateCount++;
                        pairCandidateCount++;
                        if (candidate == null) {
                            continue;
                        }

                        int requiredCount = minimumRequiredCount(candidate.discenq);
                        if (p1AnchorUpperBound < requiredCount && anchorContains(p1,candidate.centerX,candidate.centerY)) continue;
                        if (getAnchorCount(p2) < requiredCount && anchorContains(p2,candidate.centerX,candidate.centerY)) continue;

                        int candidateCount = countPointsNear(candidate.centerX, candidate.centerY, dc2, dc, requiredCount);
                        if (candidateCount < requiredCount || candidateCount < density_k) {
                            continue;
                        }

                        candidate.cirnum = candidateCount;
                        circles.add(candidate);
                        if (circles.size() >= LOCAL_SKYLINE_BATCH_SIZE) {
                            flushCandidateCircles();
                        }
                    }
                }
            }
        }

        flushCandidateCircles();
    }

    private void rebuildIndexesAndCaches() {
        pointsByCell = new HashMap<Long, List<Point>>();
        queryDistanceByPointId = new HashMap<Long, Double>();
        anchorCountByPointId = new HashMap<Long, Integer>();
        for (Point point : plist) {
            pointsByCell.computeIfAbsent(point.packedCellId, ignore -> new ArrayList<Point>()).add(point);
            queryDistanceByPointId.put(point.id, distance(point.x, point.y, q.x, q.y));
        }
    }

    private Circle buildAnchorCircle(Point p1) {
        Circle circle = new Circle();
        circle.discenq = Math.max(0.0, queryDistanceByPointId.get(p1.id) - dc);
        circle.cirnum = getAnchorCount(p1);
        return circle;
    }

    private Circle buildSinglePointCircle(Point point) {
        Point projected = new Point();
        projectTowardQuery(point, queryDistanceByPointId.get(point.id), projected);
        Circle circle = new Circle();
        circle.centerX = projected.x;
        circle.centerY = projected.y;
        circle.discenq = round2(distance(circle.centerX, circle.centerY, q.x, q.y));
        return circle;
    }

    private boolean anchorContains(Point p,double x,double y) {
        return NumericalCoverage.containsCandidate(p.x,p.y,x,y,dc,NumericalCoverage.anchorRadius(dc));
    }

    private int getAnchorCount(Point point) {
        Integer cached = anchorCountByPointId.get(point.id);
        if (cached != null) {
            return cached;
        }
        double safeRadius=NumericalCoverage.anchorRadius(dc);
        int count = countPointsNear(point.x, point.y, safeRadius*safeRadius, safeRadius, 0);
        anchorCountByPointId.put(point.id, count);
        return count;
    }

    private boolean isDominatedByCurrentSkyline(Circle candidate) {
        ensureSkylineIndex();
        if (skylineByDistance.isEmpty()) {
            return false;
        }
        Map.Entry<Double, Circle> lower = skylineByDistance.lowerEntry(candidate.discenq);
        return lower != null && lower.getValue().cirnum > candidate.cirnum;
    }

    private int minimumRequiredCount(double discenq) {
        int required = density_k;
        ensureSkylineIndex();
        if (skylineByDistance.isEmpty()) {
            return required;
        }
        Map.Entry<Double, Circle> lower = skylineByDistance.lowerEntry(discenq);
        if (lower != null) {
            required = Math.max(required, lower.getValue().cirnum + 1);
        }
        return required;
    }

    private Circle buildCandidateCircle(Point p1, Point p2, double d12Squared) {
        double qp1 = queryDistanceByPointId.get(p1.id);
        double qp2 = queryDistanceByPointId.get(p2.id);
        Point projected = new Point();
        Circle candidate = new Circle();

        if (qp1 > qp2) {
            projectTowardQuery(p1, qp1, projected);
            if (squaredDistance(p2.x, p2.y, projected.x, projected.y) <= dc2) {
                candidate.centerX = projected.x;
                candidate.centerY = projected.y;
            } else {
                Point center = circleCenter(p1.x, p1.y, p2.x, p2.y, d12Squared);
                if (center == null) {
                    return null;
                }
                candidate.centerX = center.x;
                candidate.centerY = center.y;
            }
        } else {
            projectTowardQuery(p2, qp2, projected);
            if (squaredDistance(p1.x, p1.y, projected.x, projected.y) <= dc2) {
                candidate.centerX = projected.x;
                candidate.centerY = projected.y;
            } else {
                Point center = circleCenter(p1.x, p1.y, p2.x, p2.y, d12Squared);
                if (center == null) {
                    return null;
                }
                candidate.centerX = center.x;
                candidate.centerY = center.y;
            }
        }

        candidate.discenq = round2(distance(candidate.centerX, candidate.centerY, q.x, q.y));
        return candidate;
    }

    private void projectTowardQuery(Point anchor, double queryDistance, Point projected) {
        if (queryDistance <= dc) {
            projected.x=q.x; projected.y=q.y; return;
        }
        if (anchor.x > q.x) {
            projected.x = q.x + ((queryDistance - dc) / queryDistance) * Math.abs(anchor.x - q.x);
        } else if (anchor.x == q.x) {
            projected.x = q.x;
        } else {
            projected.x = q.x - ((queryDistance - dc) / queryDistance) * Math.abs(anchor.x - q.x);
        }

        if (anchor.y > q.y) {
            projected.y = q.y + ((queryDistance - dc) / queryDistance) * Math.abs(anchor.y - q.y);
        } else if (anchor.y == q.y) {
            projected.y = q.y;
        } else {
            projected.y = q.y - ((queryDistance - dc) / queryDistance) * Math.abs(anchor.y - q.y);
        }
    }

    private int countPointsNear(double centerX, double centerY, double radiusSquared, double radius, int requiredCount) {
        double roundedRadius = Math.nextDown(radius + 0.005);
        double roundedRadiusSquared = roundedRadius * roundedRadius;
        int minCellX = (int) Math.floor((centerX - roundedRadius) / cellSize);
        int maxCellX = (int) Math.floor((centerX + roundedRadius) / cellSize);
        int minCellY = (int) Math.floor((centerY - roundedRadius) / cellSize);
        int maxCellY = (int) Math.floor((centerY + roundedRadius) / cellSize);

        if (requiredCount <= 0) {
            int count = 0;
            for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
                for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                    List<Point> bucket = pointsByCell.get(pack(cellX, cellY));
                    if (bucket == null) {
                        continue;
                    }
                    for (Point point : bucket) {
                        if (squaredDistance(centerX, centerY, point.x, point.y) <= roundedRadiusSquared) {
                            count++;
                        }
                    }
                }
            }
            return count;
        }

        int remainingPotential = 0;
        for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
            for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                List<Point> bucket = pointsByCell.get(pack(cellX, cellY));
                if (bucket != null) {
                    remainingPotential += bucket.size();
                }
            }
        }

        int count = 0;
        for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
            for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                List<Point> bucket = pointsByCell.get(pack(cellX, cellY));
                if (bucket == null) {
                    continue;
                }
                remainingPotential -= bucket.size();
                for (Point point : bucket) {
                    if (squaredDistance(centerX, centerY, point.x, point.y) <= roundedRadiusSquared) {
                        count++;
                    }
                }
                if (count + remainingPotential < requiredCount) {
                    return count;
                }
            }
        }
        return count;
    }

    private boolean isWithinRoundedRadius(double centerX, double centerY, double pointX, double pointY, double radius) {
        return round2(distance(centerX, centerY, pointX, pointY)) <= radius;
    }

    private void flushCandidateCircles() {
        if (circles.isEmpty() && (skymap == null || skymap.isEmpty())) {
            return;
        }
        ArrayList<Circle> merged = new ArrayList<Circle>(circles.size() + (skymap == null ? 0 : skymap.size()));
        merged.addAll(circles);
        if (skymap != null && !skymap.isEmpty()) {
            merged.addAll(skymap.values());
        }
        Collections.sort(merged, new Comparator<Circle>() {
            @Override
            public int compare(Circle left, Circle right) {
                return Double.compare(left.discenq, right.discenq);
            }
        });
        skymap = skylineCircle(merged);
        rebuildSkylineIndex();
        circles.clear();
    }

    private void ensureSkylineIndex() {
        if (skylineByDistance == null) {
            skylineByDistance = new TreeMap<Double, Circle>();
        }
        if (skylineByDistance.isEmpty() && skymap != null && !skymap.isEmpty()) {
            rebuildSkylineIndex();
        }
    }

    private void rebuildSkylineIndex() {
        skylineByDistance = new TreeMap<Double, Circle>();
        if (skymap == null || skymap.isEmpty()) {
            return;
        }
        for (Map.Entry<Double, Circle> entry : skymap.entrySet()) {
            skylineByDistance.put(entry.getKey(), entry.getValue());
        }
    }

    private long pack(int cellX, int cellY) {
        return (((long) cellX) << 32) ^ (cellY & 0xffffffffL);
    }

    private double squaredDistance(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2;
        double dy = y1 - y2;
        return dx * dx + dy * dy;
    }

    private double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(squaredDistance(x1, y1, x2, y2));
    }

    private double round2(double value) {
        return (double) Math.round(value * 100) / 100;
    }

    private Point circleCenter(double x1, double y1, double x2, double y2, double d12Squared) {
        Point p1 = new Point();
        Point p2 = new Point();
        Point p = new Point();
        if (d12Squared > twoDc2) {
            return null;
        }
        if (Math.abs(d12Squared - twoDc2) < 1e-9) {
            p.x = (x1 + x2) / 2;
            p.y = (y1 + y2) / 2;
            return p;
        }
        if (x1 != x2) {
            double c1 = (x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1) / (2 * (x2 - x1));
            double c2 = (y2 - y1) / (x2 - x1);
            double A = c2 * c2 + 1;
            double B = 2 * x1 * c2 - 2 * c1 * c2 - 2 * y1;
            double C = x1 * x1 - 2 * x1 * c1 + c1 * c1 + y1 * y1 - dc2;
            double delta = B * B - 4 * A * C;
            if (delta < 0) {
                return null;
            }
            if (y1 == y2) {
                double middleX = (x1 + x2) / 2;
                double vertical = Math.sqrt(Math.max(0, dc2 - ((x1 - x2) / 2) * ((x1 - x2) / 2)));
                p1.x = middleX;
                p1.y = y1 + vertical;
                p2.x = middleX;
                p2.y = y1 - vertical;
            } else {
                p1.y = (-B + Math.sqrt(delta)) / (2 * A);
                p1.x = c1 - c2 * p1.y;
                p2.y = (-B - Math.sqrt(delta)) / (2 * A);
                p2.x = c1 - c2 * p2.y;
            }
        } else {
            double middleY = (y1 + y2) / 2;
            double horizontal = Math.sqrt(Math.max(0, dc2 - ((y1 - y2) / 2) * ((y1 - y2) / 2)));
            p1.y = middleY;
            p1.x = x1 + horizontal;
            p2.y = middleY;
            p2.x = x1 - horizontal;
        }

        double dispc1 = distance(p1.x, p1.y, q.x, q.y);
        double dispc2 = distance(p2.x, p2.y, q.x, q.y);
        return dispc1 < dispc2 ? p1 : p2;
    }

    public HashMap<Double, Circle> skylineCircle(ArrayList<Circle> circles) {
        HashMap<Double, Circle> map = new HashMap<Double, Circle>();
        int max = -1;

        for (Circle circle : circles) {
            if (map.containsKey(circle.discenq)) {
                if (isPreferredAtSameDistance(circle, map.get(circle.discenq))) {
                    map.put(circle.discenq, circle);
                    max = circle.getCirnum();
                }
            } else if (circle.getCirnum() > max) {
                map.put(circle.discenq, circle);
                max = circle.getCirnum();
            }
        }
        return map;
    }

    private boolean isPreferredAtSameDistance(Circle candidate, Circle current) {
        if (candidate.getCirnum() != current.getCirnum()) {
            return candidate.getCirnum() > current.getCirnum();
        }
        int centerXOrder = Double.compare(candidate.centerX, current.centerX);
        return centerXOrder < 0
                || (centerXOrder == 0 && Double.compare(candidate.centerY, current.centerY) < 0);
    }
}
