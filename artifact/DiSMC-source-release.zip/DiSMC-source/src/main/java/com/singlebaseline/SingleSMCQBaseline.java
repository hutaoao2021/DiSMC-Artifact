package com.singlebaseline;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class SingleSMCQBaseline {
    public static void main(String[] args) throws Exception {
        long endToEndStartMs = System.currentTimeMillis();
        String inputPath = args.length >= 1 ? args[0] : "../spark_shared_env/dataset/CAS.txt";
        String outputPath = args.length >= 2 ? args[1] : "result-single.txt";
        double dc = args.length >= 3 ? Double.parseDouble(args[2]) : 2.0;
        int densityK = args.length >= 4 ? Integer.parseInt(args[3]) : 0;
        double queryX = args.length >= 5 ? Double.parseDouble(args[4]) : 15.0;
        double queryY = args.length >= 6 ? Double.parseDouble(args[5]) : 15.0;
        boolean deduplicate = args.length >= 7 ? Boolean.parseBoolean(args[6]) : true;

        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");

        EMCSBaseline baseline = new EMCSBaseline(dc, densityK);
        baseline.setQueryPoint(queryX, queryY);
        baseline.init(inputPath, deduplicate);

        long queryStart = System.currentTimeMillis();
        baseline.method();
        long queryEnd = System.currentTimeMillis();
        long queryTimeMs = queryEnd - queryStart;

        long materializeStart = System.currentTimeMillis();
        baseline.materializeFinalPoints();
        long materializeEnd = System.currentTimeMillis();
        long materializeTimeMs = materializeEnd - materializeStart;
        long totalTimeMs = queryTimeMs + materializeTimeMs;

        File outputFile = new File(outputPath);
        File parent = outputFile.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        baseline.out(outputPath, queryTimeMs, materializeTimeMs);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath, true))) {
            writer.write("method_profile: single_esmc\r\n");
            writer.write("method_composition: single_machine_esmc\r\n");
        }
        long endToEndTotalMs = System.currentTimeMillis() - endToEndStartMs;
        baseline.appendEndToEndTime(outputPath, endToEndTotalMs);
        System.out.println("method_profile=single_esmc");
        System.out.println("query_time_s=" + baseline.formatSeconds(queryTimeMs));
        System.out.println("materialize_time_s=" + baseline.formatSeconds(materializeTimeMs));
        System.out.println("total_time_s=" + baseline.formatSeconds(totalTimeMs));
        System.out.println("end_to_end_time_s=" + baseline.formatSeconds(endToEndTotalMs));
        System.out.println("skyline_count=" + baseline.skymap.size());
        System.out.println("deduplicate=" + deduplicate);
        System.out.println("output=" + outputFile.getAbsolutePath());
    }
}
