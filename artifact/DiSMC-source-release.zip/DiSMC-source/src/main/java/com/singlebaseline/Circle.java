package com.singlebaseline;

import java.util.ArrayList;

public class Circle {
    public double centerX;
    public double centerY;
    public double discenq;
    public int cirnum;
    public boolean isdominate;
    public String lowzval;
    public String upperzval;
    public ArrayList<Point> p = new ArrayList<Point>();

    public int getCirnum() {
        return cirnum;
    }
}
