package com.singlebaseline;

public class Point {
    public long id;
    public double x;
    public double y;
    public String zval;
    public String plowzval;
    public String pupperzval;
    public int pcirnum;

    public Point() {
    }

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double distanceTo(Point other) {
        double dx = x - other.x;
        double dy = y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
