package com.singlebaseline;

import java.util.ArrayList;
import java.math.BigInteger;
import java.util.List;

public class Zorder {
    private static final int LONG_COORD_BITS = 63;

    public static String createExtra(int num) {
        if (num < 1) {
            return "";
        }

        char[] extra = new char[num];
        for (int i = 0; i < num; i++) {
            extra[i] = '0';
        }
        return new String(extra);
    }

    public static int maxDecDigits(int dimension, int max) {
        BigInteger maxDec = BigInteger.ONE.shiftLeft(dimension * max).subtract(BigInteger.ONE);
        return maxDec.toString().length();
    }

    public static String valueOf(int dimension, int[] coord) {
        if (coord.length != dimension) {
            throw new IllegalArgumentException("dimension does not match coordinate length");
        }
        long[] longCoord = new long[coord.length];
        for (int i = 0; i < dimension; i++) {
            longCoord[i] = coord[i];
        }
        return valueOf(dimension, longCoord);
    }

    public static String valueOf(int dimension, long[] coord) {
        if (coord.length != dimension) {
            throw new IllegalArgumentException("dimension does not match coordinate length");
        }
        BigInteger[] bigCoord = new BigInteger[coord.length];
        for (int i = 0; i < dimension; i++) {
            if (coord[i] < 0) {
                throw new IllegalArgumentException("Z-order coordinates must be non-negative: " + coord[i]);
            }
            bigCoord[i] = BigInteger.valueOf(coord[i]);
        }
        return valueOf(dimension, bigCoord);
    }

    public static String valueOf(int dimension, BigInteger[] coord) {
        if (coord.length != dimension) {
            throw new IllegalArgumentException("dimension does not match coordinate length");
        }
        List<String> arrPtr = new ArrayList<String>(dimension);
        int fix = maxDecDigits(dimension, LONG_COORD_BITS);

        for (int i = 0; i < dimension; i++) {
            if (coord[i].signum() < 0) {
                throw new IllegalArgumentException("Z-order coordinates must be non-negative: " + coord[i]);
            }
            if (coord[i].bitLength() > LONG_COORD_BITS) {
                throw new IllegalArgumentException("coordinate exceeds " + LONG_COORD_BITS + " bits: " + coord[i]);
            }
            String binary = coord[i].toString(2);
            arrPtr.add(createExtra(LONG_COORD_BITS - binary.length()) + binary);
        }

        char[] value = new char[dimension * LONG_COORD_BITS];
        int index = 0;
        for (int i = 0; i < LONG_COORD_BITS; ++i) {
            for (String e : arrPtr) {
                value[index++] = e.charAt(i);
            }
        }

        String order = new String(value);
        BigInteger ret = new BigInteger(order, 2);
        order = ret.toString();
        if (order.length() < fix) {
            order = createExtra(fix - order.length()) + order;
        } else if (order.length() > fix) {
            throw new IllegalStateException("too big zorder, need to fix Zorder.java");
        }

        return order;
    }
}
