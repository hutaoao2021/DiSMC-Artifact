package com;

import java.io.Serializable;
import java.util.*;

/** Pair overlapping neighbourhoods under a CPU-load cap. No geometric pruning. */
public final class NeighborhoodBundles {
    public static final class Plan implements Serializable {
        public final int[] group, slot;
        public final int[][] members;
        public final long originalRecords, sharedRecords;
        public final double cpuCap;
        Plan(int[] group,int[] slot,int[][] members,long original,long shared,double cap) {
            this.group=group;this.slot=slot;this.members=members;
            originalRecords=original;sharedRecords=shared;cpuCap=cap;
        }
    }
    private static final class Edge {
        final int a,b; final long shared; final double score;
        Edge(int a,int b,long shared,double cost){this.a=a;this.b=b;this.shared=shared;score=shared/Math.max(cost,1e-12);}
    }
    public static Plan plan(double[] cpu,long[] assigned,long[][] overlap,int slots) {
        int n=cpu.length;
        if(n!=assigned.length||n!=overlap.length||slots<1)throw new IllegalArgumentException();
        double sum=0;long original=0;
        for(int i=0;i<n;i++) {
            if(!Double.isFinite(cpu[i])||cpu[i]<0||assigned[i]<0||overlap[i].length!=n)throw new IllegalArgumentException();
            sum+=cpu[i];original=Math.addExact(original,assigned[i]);
        }
        // At least two cache groups per execution slot; individually heavy owners stay separate.
        double cap=sum/Math.max(1,2*slots);
        ArrayList<Edge> edges=new ArrayList<Edge>();
        for(int a=0;a<n;a++)for(int b=a+1;b<n;b++)
            if(overlap[a][b]>0 && cpu[a]+cpu[b]<=cap)
                edges.add(new Edge(a,b,overlap[a][b],cpu[a]+cpu[b]));
        edges.sort((a,b)->{int c=Double.compare(b.score,a.score);if(c!=0)return c;c=Integer.compare(a.a,b.a);return c!=0?c:Integer.compare(a.b,b.b);});
        int[] mate=new int[n];Arrays.fill(mate,-1);int groups=n;long saved=0;
        for(Edge e:edges)if(groups>2*slots && mate[e.a]<0 && mate[e.b]<0) {
            mate[e.a]=e.b;mate[e.b]=e.a;groups--;saved+=e.shared;
        }
        int[] group=new int[n],slot=new int[n];Arrays.fill(group,-1);
        int[][] members=new int[groups][];int next=0;
        for(int p=0;p<n;p++)if(group[p]<0) {
            int q=mate[p];members[next]=q<0?new int[]{p}:new int[]{p,q};group[p]=next;
            if(q>=0){group[q]=next;slot[q]=1;}next++;
        }
        return new Plan(group,slot,members,original,original-saved,cap);
    }

    public static final class Route implements Serializable {
        public final int owner;
        public final int[] groups,masks;
        public Route(int owner,int[] targets,Plan plan) {
            this.owner=owner;
            int[] gs=new int[targets.length],ms=new int[targets.length];int n=0;
            for(int p:targets) {
                int g=plan.group[p],j=0;while(j<n&&gs[j]!=g)j++;
                if(j==n)gs[n++]=g;ms[j]|=1<<plan.slot[p];
            }
            groups=Arrays.copyOf(gs,n);masks=Arrays.copyOf(ms,n);
        }
    }
    /** Static adjacency lookup: discover a cell's destinations once, reuse for all its points. */
    public static final class Routes implements Serializable {
        private final long[] keys;
        private final Route[] values;
        private final int mask;
        public Routes(int size) {
            int capacity=4;while(capacity<(long)size*2)capacity<<=1;
            keys=new long[capacity];values=new Route[capacity];mask=capacity-1;
        }
        private int slot(long key){long h=key;h^=h>>>33;h*=0xff51afd7ed558ccdL;h^=h>>>33;return (int)h&mask;}
        public void put(long key,Route value){int s=slot(key);while(values[s]!=null&&keys[s]!=key)s=(s+1)&mask;keys[s]=key;values[s]=value;}
        public Route get(long key){int s=slot(key);while(values[s]!=null){if(keys[s]==key)return values[s];s=(s+1)&mask;}return null;}
    }
}
