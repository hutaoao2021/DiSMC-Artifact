package com;

import java.util.Arrays;

/** Coordinate refinement with separate routing, communication and workload guards. */
public final class ExecutionAwareCuts {
    public static final class Plan {
        public final int[] owners;
        public final long oldBoundaryPoints, boundaryPoints;
        public final double oldSpan, span;
        public final int moves;
        Plan(int[] owners, long oldBoundary, long boundary, double oldSpan, double span, int moves) {
            this.owners=owners; this.oldBoundaryPoints=oldBoundary; this.boundaryPoints=boundary;
            this.oldSpan=oldSpan; this.span=span; this.moves=moves;
        }
    }

    public static Plan plan(double[] work, long[] count, int[] min, int[] max, int partitions) {
        int n=work.length;
        if (partitions < 1 || count.length!=n || min.length!=n || max.length!=n) throw new IllegalArgumentException();
        int[] baseline=baseline(work,partitions);
        long oldBoundary=boundaryPoints(baseline,count,min,max);
        double oldSpan=span(baseline,count,min,max);
        if (n<partitions || partitions==1) return new Plan(baseline,oldBoundary,oldBoundary,oldSpan,oldSpan,0);
        double[] wp=new double[n+1], cp=new double[n+1];
        long[] crossing=new long[n+1];
        int[] startHead=new int[n+1], endHead=new int[n+1], nextStart=new int[n], nextEnd=new int[n];
        Arrays.fill(startHead,-1); Arrays.fill(endHead,-1);
        for (int i=0;i<n;i++) {
            if (!(work[i]>0) || !Double.isFinite(work[i]) || count[i]<1 || min[i]<0 || min[i]>i || max[i]<i || max[i]>=n)
                throw new IllegalArgumentException("invalid neighbourhood statistics");
            wp[i+1]=wp[i]+work[i]; cp[i+1]=cp[i]+count[i];
            if (min[i]<max[i]) {
                int begin=min[i]+1, end=max[i]+1;
                crossing[begin]+=count[i]; crossing[end]-=count[i];
                nextStart[i]=startHead[begin]; startHead[begin]=i;
                nextEnd[i]=endHead[end]; endHead[end]=i;
            }
        }
        for (int i=1;i<=n;i++) crossing[i]+=crossing[i-1];
        int[] cuts=new int[partitions+1]; cuts[partitions]=n;
        for (int i=1;i<n;i++) if (baseline[i]!=baseline[i-1]) cuts[baseline[i]]=i;
        double[] originalWork=new double[partitions], originalCore=new double[partitions];
        double maximumWork=0,maximumCore=0;
        for (int j=0;j<partitions;j++) {
            originalWork[j]=wp[cuts[j+1]]-wp[cuts[j]];
            originalCore[j]=cp[cuts[j+1]]-cp[cuts[j]];
            maximumWork=Math.max(maximumWork,originalWork[j]); maximumCore=Math.max(maximumCore,originalCore[j]);
        }
        int moves=0;
        for (int pass=0;pass<4;pass++) {
            boolean changed=false;
            for (int step=1;step<partitions;step++) {
                int j=(pass&1)==0?step:partitions-step;
                int left=cuts[j-1], current=cuts[j], right=cuts[j+1];
                double wl=Math.min(maximumWork,1.05*originalWork[j-1]);
                double wr=Math.min(maximumWork,1.05*originalWork[j]);
                double cl=Math.min(maximumCore,1.05*originalCore[j-1]);
                double cr=Math.min(maximumCore,1.05*originalCore[j]);
                int first=Math.max(left+1,Math.max(lowerBound(wp,wp[right]-wr),lowerBound(cp,cp[right]-cr)));
                int last=Math.min(right-1,Math.min(upperBound(wp,wp[left]+wl)-1,upperBound(cp,cp[left]+cl)-1));
                if (first>=last) continue;
                first=Math.min(first,current); last=Math.max(last,current);
                // Only endpoint events inside the feasible window affect relative
                // cost. Intervals already crossing 'first' add the same constant
                // until an endpoint is crossed, so their initial mass is unnecessary.
                long[] relativeRoute=new long[last-first+1];
                long delta=0;
                for (int t=first+1;t<=last;t++) {
                    for (int i=startHead[t];i>=0;i=nextStart[i])
                        if (min[i]>=left && max[i]<right) delta+=count[i];
                    for (int i=endHead[t];i>=0;i=nextEnd[i])
                        if (min[i]>=left && max[i]<right) delta-=count[i];
                    relativeRoute[t-first]=delta;
                }
                long originalRoute=relativeRoute[current-first], originalCommunication=crossing[current];
                int best=current;
                for (int t=first;t<=last;t++) {
                    long route=relativeRoute[t-first];
                    if (route>originalRoute || crossing[t]>originalCommunication) continue;
                    if (route<relativeRoute[best-first] || (route==relativeRoute[best-first] && crossing[t]<crossing[best])) best=t;
                }
                if (best!=current) { cuts[j]=best; moves++; changed=true; }
            }
            if (!changed) break;
        }
        int[] owners=new int[n];
        for (int j=0;j<partitions;j++) for (int i=cuts[j];i<cuts[j+1];i++) owners[i]=j;
        long boundary=boundaryPoints(owners,count,min,max);
        double cost=span(owners,count,min,max);
        if (boundary>oldBoundary || cost>oldSpan || (boundary==oldBoundary && cost==oldSpan))
            return new Plan(baseline,oldBoundary,oldBoundary,oldSpan,oldSpan,0);
        return new Plan(owners,oldBoundary,boundary,oldSpan,cost,moves);
    }

    static int[] baseline(double[] work,int partitions) {
        int n=work.length;
        int[] owners=new int[n];
        if (partitions==1 || n<partitions) return owners;
        double[] prefix=new double[n+1];
        for (int i=0;i<n;i++) prefix[i+1]=prefix[i]+work[i];
        int[] cuts=new int[partitions+1];cuts[partitions]=n;
        for (int part=1;part<partitions;part++) {
            double target=prefix[n]*part/partitions;
            int first=cuts[part-1]+1,last=n-(partitions-part);
            int cut=Math.max(first,Math.min(last,lowerBound(prefix,target)));
            if (cut>first && Math.abs(prefix[cut-1]-target)<=Math.abs(prefix[cut]-target)) cut--;
            cuts[part]=cut;
        }
        for (int part=0;part<partitions;part++)
            for (int i=cuts[part];i<cuts[part+1];i++) owners[i]=part;
        return owners;
    }
    static long boundaryPoints(int[] owner,long[] count,int[] min,int[] max) {
        long total=0;for (int i=0;i<owner.length;i++) if (owner[min[i]]!=owner[max[i]]) total+=count[i];return total;
    }
    static double span(int[] owner,long[] count,int[] min,int[] max) {
        double total=0;for (int i=0;i<owner.length;i++) total+=count[i]*(double)(owner[max[i]]-owner[min[i]]);return total;
    }
    private static int lowerBound(double[] a,double x) {
        int l=0,h=a.length;while(l<h){int m=(l+h)>>>1;if(a[m]<x)l=m+1;else h=m;}return l;
    }
    private static int upperBound(double[] a,double x) {
        int l=0,h=a.length;while(l<h){int m=(l+h)>>>1;if(a[m]<=x)l=m+1;else h=m;}return l;
    }
}
