package com;
import java.util.*;

/** Timing calibrates owner totals; spatial residuals distinguish lanes without changing geometry. */
public final class SpatialProbeCostModel {
    private static final int MIN_REGION_SAMPLES=4;
    private static final double PRIOR_SAMPLES=4;
    public static SampledAnchorCostProbe.Calibration calibrate(double[] proxy,long[] core,
            SampledAnchorCostProbe.Probe[] probes) {
        if(proxy.length!=core.length || probes.length==0)throw new IllegalArgumentException("invalid timing dimensions");
        double[] ratios=new double[probes.length];int count=0;
        for(SampledAnchorCostProbe.Probe p:probes){
            if(p.owner<0||p.owner>=proxy.length||proxy[p.owner]<=0||core[p.owner]<p.samples)
                throw new IllegalArgumentException("invalid timing owner");
            ratios[count++]=ownerEstimate(p,core[p.owner])/proxy[p.owner];
        }
        Arrays.sort(ratios);double scale=count%2==1?ratios[count/2]:(ratios[count/2-1]+ratios[count/2])/2;
        double[] work=proxy.clone();for(int o=0;o<work.length;o++)work[o]*=scale;
        for(SampledAnchorCostProbe.Probe p:probes)work[p.owner]=ownerEstimate(p,core[p.owner]);
        // Nanoseconds include all execution work; zero point checks are not a zero-cost task.
        return new SampledAnchorCostProbe.Calibration(work,1e-9,count,new int[0]);
    }
    public static MicroPartitionPopulation.Statistics reweight(MicroPartitionPopulation.Statistics source,
            SampledAnchorCostProbe.Probe[] probes,Map<Long,Double> cellWork) {
        Map<Integer,SampledAnchorCostProbe.Probe> observed=new HashMap<>();
        for(SampledAnchorCostProbe.Probe p:probes)observed.put(p.owner,p);
        MicroPartitionLayout.Candidate[] adjusted=new MicroPartitionLayout.Candidate[source.candidates.length];
        for(int index=0;index<adjusted.length;index++){
            MicroPartitionLayout.Candidate c=source.candidates[index];SampledAnchorCostProbe.Probe p=observed.get(c.owner);
            if(p==null||p.observations.length==0){adjusted[index]=c;continue;}
            int[] counts=new int[c.pieces];double[] nanos=new double[c.pieces],raw=new double[c.pieces];
            double totalNs=0,totalRaw=0,totalWork=0;
            Set<Long> ids=new HashSet<>();
            for(AnchorCostObservation a:p.observations){
                if(!ids.add(a.anchor.id))throw new IllegalArgumentException("duplicate probe anchor");
                int lane=c.laneOf(a.anchor);
                if(lane<0||lane>=c.pieces)throw new IllegalStateException("probe responsibility missing from candidate");
                double weight=cellWork.getOrDefault(a.anchor.packedCellId,Double.NaN);
                // Missing proxy metadata cannot support a spatial residual. Retain this alternative.
                if(!Double.isFinite(weight)||weight<=0){totalRaw=-1;break;}
                double recurring=Math.max(0,a.kernelNanos-a.indexBuildNanos);
                counts[lane]++;nanos[lane]+=recurring;raw[lane]+=weight;
                totalNs+=recurring;totalRaw+=weight;
            }
            if(totalNs<=0||totalRaw<=0){adjusted[index]=c;continue;}
            double global=totalNs/totalRaw;double[] work=new double[c.pieces];double sum=0;
            for(int l=0;l<c.pieces;l++){
                double correction=1;
                if(counts[l]>=MIN_REGION_SAMPLES&&raw[l]>0){
                    double residual=nanos[l]/raw[l]/global;
                    residual=Math.max(.25,Math.min(4,residual));
                    correction=(counts[l]*residual+PRIOR_SAMPLES)/(counts[l]+PRIOR_SAMPLES);
                }
                work[l]=c.work(l)*correction;sum+=work[l];totalWork+=c.work(l);
            }
            double fixed=fixedWork(p),recurringOwner=Math.max(0,totalWork-fixed);
            if(sum>0)for(int l=0;l<work.length;l++){
                work[l]*=recurringOwner/sum;
                // Each private task pays its own setup; exact routed populations scale this charge.
                work[l]+=fixed*(double)source.dependencyInputs[index][l]/Math.max(1L,source.originalAssigned[c.owner]);
            }
            adjusted[index]=c.withPhysicalWork(work);
        }
        MicroPartitionPopulation.Statistics result=new MicroPartitionPopulation.Statistics(source.originalAssigned,source.core,adjusted,source.dependencyInputs);
        result.sourceRecordsScanned=source.sourceRecordsScanned;result.collectMs=source.collectMs;
        result.populationMs=source.populationMs;result.originalPopulationMs=source.originalPopulationMs;
        result.dependencyPopulationScans=source.dependencyPopulationScans;result.populationFromCells=source.populationFromCells;
        result.populationDirect=source.populationDirect;result.populationCollectionFused=source.populationCollectionFused;
        result.fallbacks.addAll(source.fallbacks);return result;
    }
    private SpatialProbeCostModel() { }
    private static double fixedWork(SampledAnchorCostProbe.Probe p){return p.prepareNanos+p.setupNanos+(double)p.denseBoundaryBuildNanos;}
    private static double ownerEstimate(SampledAnchorCostProbe.Probe p,long core){
        double kernelFixed=p.setupNanos+(double)p.denseBoundaryBuildNanos;
        if(kernelFixed<0||kernelFixed>p.kernelNanos||p.prepareNanos<0)throw new IllegalArgumentException("invalid fixed probe cost");
        return (p.kernelNanos-kernelFixed)*(double)core/p.samples+fixedWork(p);
    }
}
