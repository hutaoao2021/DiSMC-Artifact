package com;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import org.apache.spark.TaskContext;
import org.apache.spark.util.CollectionAccumulator;

public final class TaskObservation implements Serializable {
    public final String runId, owners, pieces;
    public final int stageId, stageAttempt, partitionId, attempt, groupId, round;
    public final long taskAttemptId, parentAccessNanos, prepareNanos, kernelNanos, localWallNanos;
    public final long actualRecords, preparedRecords, buildCount, predictedProxyRecords;
    public final double predictedFixedSeconds, predictedVariableSeconds, predictedOverheadSeconds, predictedTotalSeconds;
    private final long[] counters;

    public TaskObservation(String runId, int stageId, int stageAttempt, int partitionId, long taskAttemptId,
            int attempt, BundleShardLayout.Task task, PhysicalBundleShardPlanner.TaskPrediction prediction,
            long parentAccessNanos, long prepareNanos, long kernelNanos, long localWallNanos,
            long actualRecords, long preparedRecords, long buildCount, long[] counters) {
        if (runId == null || runId.trim().isEmpty() || counters.length != 10
                || parentAccessNanos < 0 || prepareNanos < 0 || kernelNanos < 0 || localWallNanos < 0
                || actualRecords < 0 || preparedRecords < 0 || buildCount < 0
                || Math.addExact(Math.addExact(parentAccessNanos, prepareNanos), kernelNanos) > localWallNanos) {
            throw new IllegalArgumentException("invalid local task observation");
        }
        this.runId = runId;
        this.stageId = stageId;
        this.stageAttempt = stageAttempt;
        this.partitionId = partitionId;
        this.taskAttemptId = taskAttemptId;
        this.attempt = attempt;
        groupId = task.groupId;
        round = task.round;
        owners = Arrays.toString(task.owners);
        pieces = Arrays.toString(task.pieces);
        this.parentAccessNanos = parentAccessNanos;
        this.prepareNanos = prepareNanos;
        this.kernelNanos = kernelNanos;
        this.localWallNanos = localWallNanos;
        this.actualRecords = actualRecords;
        this.preparedRecords = preparedRecords;
        this.buildCount = buildCount;
        predictedProxyRecords = prediction.proxyRecords;
        predictedFixedSeconds = prediction.fixedSeconds;
        predictedVariableSeconds = prediction.variableSeconds;
        predictedOverheadSeconds = prediction.overheadSeconds;
        predictedTotalSeconds = prediction.totalSeconds;
        this.counters = counters.clone();
    }

    public static final class Collector implements Serializable {
        private final String runId;
        private final PhysicalBundleShardPlanner.TaskPrediction[] predictions;
        private final CollectionAccumulator<TaskObservation> observations;

        public Collector(String runId, PhysicalBundleShardPlanner.TaskPrediction[] predictions,
                CollectionAccumulator<TaskObservation> observations) {
            this.runId = runId;
            this.predictions = predictions.clone();
            this.observations = observations;
        }

        public void record(TaskContext context, BundleShardLayout.Task task, long access, long prepare,
                long kernel, long wall, long actualRecords, long preparedRecords, long builds, long[] counters) {
            observations.add(new TaskObservation(runId, context.stageId(), context.stageAttemptNumber(),
                    context.partitionId(), context.taskAttemptId(), context.attemptNumber(), task,
                    predictions[task.id], access, prepare, kernel, wall, actualRecords, preparedRecords, builds, counters));
        }
    }

    public static void write(Path prefix, List<TaskObservation> observations) throws IOException {
        Path target = prefix.resolveSibling(prefix.getFileName() + ".local_tasks.csv");
        List<TaskObservation> sorted = new ArrayList<TaskObservation>(observations);
        sorted.sort(Comparator.comparingInt((TaskObservation row) -> row.stageId)
                .thenComparingInt(row -> row.stageAttempt).thenComparingInt(row -> row.partitionId)
                .thenComparingLong(row -> row.taskAttemptId));
        try (BufferedWriter writer = Files.newBufferedWriter(target, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW)) {
            writer.write("run_id,stage_id,stage_attempt,partition_id,task_attempt_id,attempt,group_id,round,owners,pieces,predicted_fixed_s,predicted_variable_s,predicted_overhead_s,predicted_total_s,predicted_proxy_records,actual_records,prepared_records,build_count,parent_access_ns,prepare_ns,kernel_ns,local_wall_ns,candidate_count,single_point_candidates,pair_candidates,z_window_checks,distance_checks,projected_candidates,projected_count_hits,projected_bound_hits,mask_checks,mask_filtered,status,model_provenance\n");
            for (TaskObservation row : sorted) {
                List<Object> values = new ArrayList<Object>(Arrays.<Object>asList(row.runId, row.stageId, row.stageAttempt,
                        row.partitionId, row.taskAttemptId, row.attempt, row.groupId, row.round, row.owners, row.pieces,
                        row.predictedFixedSeconds, row.predictedVariableSeconds, row.predictedOverheadSeconds,
                        row.predictedTotalSeconds, row.predictedProxyRecords, row.actualRecords, row.preparedRecords,
                        row.buildCount, row.parentAccessNanos, row.prepareNanos, row.kernelNanos, row.localWallNanos));
                for (long counter : row.counters) values.add(counter);
                values.add("local_complete");
                values.add("historical_fixed_unverified_source");
                writer.write(csv(values));
            }
        }
    }

    static String csv(List<?> values) {
        StringBuilder result = new StringBuilder();
        for (Object value : values) {
            if (result.length() > 0) result.append(',');
            String text = value == null ? "" : value.toString();
            result.append('"').append(text.replace("\"", "\"\"")).append('"');
        }
        return result.append('\n').toString();
    }
}
