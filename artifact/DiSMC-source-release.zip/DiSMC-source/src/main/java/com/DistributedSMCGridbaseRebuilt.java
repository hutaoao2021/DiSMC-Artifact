package com;

import com.cellhalo.CellId;
import com.cellhalo.PartitionMetrics;
import org.apache.hadoop.shaded.net.minidev.json.JSONArray;
import org.apache.hadoop.shaded.net.minidev.json.JSONObject;
import org.apache.hadoop.shaded.net.minidev.json.JSONStyle;
import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardOpenOption;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class DistributedSMCGridbaseRebuilt implements Serializable {
    private static final String MODULES = "M1=1 M2=executor_route_v4 M3=1 M4=1";
    private static final String PARTITION_ROUTE_PATH = "direct_single_shuffle";
    private static final String TRANSPORT_PATH = "shared_masked_batches";
    private static final String LOCAL_KERNEL = "indexed_prepared_emcs";
    private static final String EXECUTION_PATH = "budgeted_guarded_shards_cost_order";
    private static final String GLOBAL_REDUCE_PATH = "baseline_driver_merge";
    private static final String MEMBER_MATERIALIZATION_PATH = "baseline_final_member_materialization";
    private static final class FinalCircleSpec implements Serializable {
        final int index;
        final double discenq;
        final double centerX;
        final double centerY;

        FinalCircleSpec(int index, double discenq, double centerX, double centerY) {
            this.index = index;
            this.discenq = discenq;
            this.centerX = centerX;
            this.centerY = centerY;
        }
    }

    private static final class CellCount implements Serializable {
        final long packed;
        final int x;
        final int y;
        final long count;
        final long zCode;
        private transient long hilbertCode;
        private transient boolean hilbertCodeComputed;

        CellCount(long packed, long count) {
            this.packed = packed;
            this.x = unpackCellX(packed);
            this.y = unpackCellY(packed);
            this.count = count;
            this.zCode = CellId.zCode(x, y);
        }

        long hilbertCode() {
            if (!hilbertCodeComputed) {
                hilbertCode = CellOrdering.hilbertKey(x, y);
                hilbertCodeComputed = true;
            }
            return hilbertCode;
        }
    }

    private static final class NeighborOffset implements Serializable {
        final int dx;
        final int dy;

        NeighborOffset(int dx, int dy) {
            this.dx = dx;
            this.dy = dy;
        }
    }

    private static final class CellPlanStats {
        final double[] work;
        final int[] minRank;
        final int[] maxRank;

        CellPlanStats(int size) {
            work = new double[size];
            minRank = new int[size];
            maxRank = new int[size];
        }
    }

    private static final class RouteChunk {
        final long[] assigned;
        final long[][] overlap;
        long interiorPoints;
        long boundaryPoints;
        int boundaryCells;

        RouteChunk(int owners) {
            assigned = new long[owners];
            overlap = new long[owners][owners];
        }
    }

    private static final class M2RoutingPlan {
        final long[] core;
        final long[] assigned;
        final long[][] overlap;
        final int[][] targetsByRank;
        final long interiorPoints;
        final long boundaryPoints;
        final int boundaryCells;

        M2RoutingPlan(long[] core, long[] assigned, long[][] overlap, int[][] targetsByRank,
                      long interiorPoints, long boundaryPoints, int boundaryCells) {
            this.core = core;
            this.assigned = assigned;
            this.overlap = overlap;
            this.targetsByRank = targetsByRank;
            this.interiorPoints = interiorPoints;
            this.boundaryPoints = boundaryPoints;
            this.boundaryCells = boundaryCells;
        }
    }

    static final class CellOwnerIndex implements Serializable {
        private final long[] keys;
        private final int[] values;
        private final int mask;

        CellOwnerIndex(int expectedSize) {
            int capacity = 4;
            long target = ((long) expectedSize * 4 + 2) / 3;
            while (capacity < target) capacity <<= 1;
            this.keys = new long[capacity];
            this.values = new int[capacity];
            this.mask = capacity - 1;
        }

        void put(long key, int value) {
            int slot = slot(key);
            while (values[slot] != 0 && keys[slot] != key) {
                slot = (slot + 1) & mask;
            }
            keys[slot] = key;
            values[slot] = value >= 0 ? value + 1 : value;
        }

        int getOrDefault(long key, int defaultValue) {
            int raw = getEncodedOrDefault(key, -1);
            if (raw == -1) return defaultValue;
            return raw < -1 ? -raw - 2 : raw;
        }

        // -1 means absent; -(owner+2) certifies all halo neighbours have this owner.
        int getEncodedOrDefault(long key, int defaultValue) {
            int slot = slot(key);
            while (values[slot] != 0) {
                if (keys[slot] == key) {
                    return values[slot] > 0 ? values[slot] - 1 : values[slot];
                }
                slot = (slot + 1) & mask;
            }
            return defaultValue;
        }

        private int slot(long key) {
            return hashCellCountKey(key) & mask;
        }
    }

    private static final class LongLongIndex implements Serializable {
        private final long[] keys;
        private final long[] values;
        private final boolean[] used;
        private final int mask;

        LongLongIndex(int expectedSize) {
            int capacity = tableCapacity(expectedSize);
            this.keys = new long[capacity];
            this.values = new long[capacity];
            this.used = new boolean[capacity];
            this.mask = capacity - 1;
        }

        void put(long key, long value) {
            int slot = slot(key);
            while (used[slot] && keys[slot] != key) {
                slot = (slot + 1) & mask;
            }
            keys[slot] = key;
            values[slot] = value;
            used[slot] = true;
        }

        long getOrDefault(long key, long defaultValue) {
            int slot = slot(key);
            while (used[slot]) {
                if (keys[slot] == key) {
                    return values[slot];
                }
                slot = (slot + 1) & mask;
            }
            return defaultValue;
        }

        private int slot(long key) {
            return hashCellCountKey(key) & mask;
        }
    }

    public transient HashMap<Double, Circle> skymap = new HashMap<Double, Circle>();
    List<Circle> sortedSkymapList;
    public int partition_number = 10;
    public int density_k = 0;
    public double queryX = 15.0;
    public double queryY = 15.0;
    public double cellSizeMultiplier = 1.0;
    public boolean emitPartitionJson = false;
    public boolean printLocalSkylines = false;

    long start_time = 0;
    long end_time = 0;
    long s1_read_process_data = 0;
    long s2_plan_cells = 0;
    long s3_clone_assign = 0;
    long s4_local_compute = 0;
    long s5_global_reduce = 0;
    long s6_materialize_final_points = 0;
    long end_to_end_time = 0;

    int finalSkylineCount = 0;
    JSONObject jsonOutput = new JSONObject();
    Map<String, Object> diagnostics = new LinkedHashMap<String, Object>();
    List<String> partitionCloneStatsOutput = new ArrayList<String>();
    private transient double[] plannedPartitionWork;
    private transient long[] actualPartitionCore,actualPartitionAssigned;
    private transient RangeOverlapEstimator.Result m2RangeStats;
    private MethodProfile profile = MethodProfile.FULL;
    private ExperimentConfig experiment;
    private transient org.apache.spark.util.CollectionAccumulator<TaskObservation> localObservations;
    private transient org.apache.spark.util.CollectionAccumulator<TransportObservation> transportObservations;
    private transient org.apache.spark.util.CollectionAccumulator<MicroPartitionObservation> microObservations;
    private transient Map<Long, Double> microCellWork;
    private transient CompactCellHashStatistics.Batch implicitCellStatistics;
    private transient double[] microOwnerCost;
    private boolean materializeFinalMembers = true;
    private boolean cacheMemberText = true;
    private boolean reuseMemberPoints = false;
    private boolean partitionedMemberOutput = false;

    public static void main(String[] args) {
        long endToEndStart = System.currentTimeMillis();
        String defaultInputPath = "../spark_shared_env/dataset/CAS.txt";
        String defaultOutputPath = "result.txt";
        DistributedSMCGridbaseRebuilt dsmc = new DistributedSMCGridbaseRebuilt();
        dsmc.profile = MethodProfile.parse(System.getProperty("spark.skyline.profile", "full"));
        if (dsmc.profile.isStandaloneBaseline()) {
            throw new IllegalArgumentException("profile " + dsmc.profile.id()
                    + " must use the unified launcher");
        }
        double dc = 2.0;

        String inputPath = defaultInputPath;
        String outputPath = defaultOutputPath;
        if (args.length >= 1) {
            inputPath = args[0];
        }
        if (args.length >= 2) {
            outputPath = args[1];
        }
        if (args.length >= 3) {
            dsmc.partition_number = Integer.parseInt(args[2]);
        }
        if (args.length >= 4) {
            dc = Double.parseDouble(args[3]);
        }
        if (args.length >= 5) {
            dsmc.density_k = Integer.parseInt(args[4]);
        }
        if (args.length >= 6) {
            dsmc.cellSizeMultiplier = Double.parseDouble(args[5]);
        }
        if (args.length > 6) {
            DistributedSMC.invocationArguments(dsmc.profile, args);
            dsmc.queryX = Double.parseDouble(args[6]);
            dsmc.queryY = Double.parseDouble(args[7]);
        }

        SparkConf conf = new SparkConf()
                .setAppName("DiSMC-" + dsmc.profile.id())
                .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .registerKryoClasses(new Class[]{Point.class, Circle.class, CellId.class,
                        FinalCircleSpec.class, NeighborOffset.class, CellOwnerIndex.class,
                        SharedNeighborhoodRDD.Packet.class, SharedNeighborhoodRDD.Block.class,
                        MaskedSharedBlock.class, NeighborhoodBundles.Route.class,
                        NeighborhoodBundles.Routes.class, CompactCellCounts.Batch.class, CompactCellHashStatistics.Batch.class,
                        CompactPacketBatches.Batch.class})
                .set("spark.default.parallelism", String.valueOf(dsmc.partition_number))
                .set("spark.sql.shuffle.partitions", String.valueOf(dsmc.partition_number))
                .set("spark.ui.showConsoleProgress", "false");

        if (!conf.contains("spark.skyline.m4.extraMapMs")) {
            conf.set("spark.skyline.m4.extraMapMs", "100.0");
        }

        if (!conf.contains("spark.master")) {
            conf.setMaster("local[*]");
        }

        dsmc.experiment = ExperimentConfig.from(conf, dsmc.profile);
        dsmc.experiment.requireSupportedExecution();
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");
        ExperimentSparkListener observer = ExperimentSparkListener.attach(sc, dsmc.experiment);
        long totalStart = System.currentTimeMillis();
        dsmc.start_time = totalStart;
        boolean queryCompleted = false;
        try {
            dsmc.executeDistributedSkylineMCQ(sc, dc, inputPath);
            long totalEnd = System.currentTimeMillis();
            dsmc.end_time = totalEnd;
            dsmc.out(outputPath, totalEnd - totalStart);
            dsmc.printRunSummary(outputPath, totalEnd - totalStart);
            if (dsmc.localObservations != null) {
                try {
                    TaskObservation.write(java.nio.file.Paths.get(dsmc.experiment.outputPrefix), dsmc.localObservations.value());
                } catch (IOException error) {
                    throw new IllegalStateException("cannot preserve local task observations", error);
                }
            }
            if (dsmc.microObservations != null && !dsmc.experiment.outputPrefix.isEmpty()) {
                try {
                    MicroPartitionObservation.write(Paths.get(dsmc.experiment.outputPrefix + ".micro_tasks.csv"), dsmc.microObservations.value());
                } catch (IOException error) { throw new IllegalStateException("cannot preserve micro task observations", error); }
            }
            queryCompleted = true;
        } finally {
            try {
                if (observer != null) {
                    if (dsmc.transportObservations != null) observer.setTransportRows(dsmc.transportObservations.value());
                    observer.finish(sc, queryCompleted);
                }
            } finally {
                sc.stop();
            }
        }
        long endToEndTotal = System.currentTimeMillis() - endToEndStart;
        dsmc.end_to_end_time = endToEndTotal;
        dsmc.appendEndToEndTime(outputPath, endToEndTotal);
        dsmc.out_json(dc, jsonOutputPath(outputPath, dsmc.experiment.enabled || dsmc.experiment.observe));
        System.out.println("end_to_end_time_s=" + dsmc.formatSeconds(endToEndTotal));
    }

    private void executeDistributedSkylineMCQ(JavaSparkContext sc, double dc, String inputPath) {
        ExecutionComposition composition = ExecutionComposition.forProfile(profile);
        diagnostics.put("method_profile", profile.id());
        diagnostics.put("method_composition", composition.toString());
        materializeFinalMembers = shouldMaterializeFinalMembers(sc.getConf());
        String memberMode=sc.getConf().get("spark.skyline.memberOutputMode","driver");
        if(!memberMode.equals("driver") && !memberMode.equals("partitioned"))
            throw new IllegalArgumentException("unknown member output mode: "+memberMode);
        partitionedMemberOutput=memberMode.equals("partitioned");
        if(partitionedMemberOutput && !materializeFinalMembers)
            throw new IllegalArgumentException("partitioned output requires complete member materialization");
        diagnostics.put("member_output_mode",memberMode);
        reuseMemberPoints = sc.getConf().getBoolean("spark.skyline.reuseMemberPoints",false);
        diagnostics.put("member_point_reuse_enabled",reuseMemberPoints);
        cacheMemberText = sc.getConf().getBoolean("spark.skyline.cacheMemberText",true);
        diagnostics.put("member_text_cache_enabled",cacheMemberText);
        diagnostics.put("member_materialization_enabled", materializeFinalMembers);
        diagnostics.put("result_fingerprint_scope",
                partitionedMemberOutput ? "circle_geometry_with_external_members" : (materializeFinalMembers ? "circle_geometry_and_members" : "circle_geometry_only"));
        double cellSize = Math.max(dc * 0.25, dc * cellSizeMultiplier);
        int haloCellRadius = Math.max(1, (int) Math.ceil((2 * dc) / cellSize));

        boolean implicitFamily = sc.getConf().getBoolean("spark.skyline.microImplicitFamily",false);
        if (implicitFamily && (!experiment.microPartition || !sc.getConf().getBoolean("spark.skyline.stableInputIds",false)))
            throw new IllegalArgumentException("implicit family requires microPartition and stableInputIds");
        boolean hashCellStatistics = implicitFamily || sc.getConf().getBoolean("spark.skyline.microCellHashStatistics",false);
        boolean fuseInputCensus = sc.getConf().getBoolean("spark.skyline.fuseInputCensus",false);
        diagnostics.put("input_census_fused",fuseInputCensus);
        diagnostics.put("input_census_timing_scope",fuseInputCensus ? "Read includes materializing cell census; compare E2E or Read+Plan" : "Read materializes count; Plan acquires census");
        long startRead = System.currentTimeMillis();
        JavaRDD<Point> points = readAndProcessData(sc, inputPath, cellSize)
                .persist(StorageLevel.MEMORY_AND_DISK());
        CellStatisticsAcquisition.Result materializedCensus = fuseInputCensus
                ? CellStatisticsAcquisition.collect(points,hashCellStatistics) : null;
        long originalCount = fuseInputCensus ? materializedCensus.sourceCount() : points.count();
        this.s1_read_process_data = System.currentTimeMillis() - startRead;

        long startPlan = System.currentTimeMillis();
        List<NeighborOffset> neighborOffsets = buildNeighborOffsets(haloCellRadius, cellSize, dc);
        CellStatisticsAcquisition.Result cellStatistics = fuseInputCensus ? materializedCensus
                : CellStatisticsAcquisition.collect(points,hashCellStatistics);
        List<CompactCellCounts.Batch> localCellCounts = cellStatistics.cellCounts;
        diagnostics.put("cell_hash_statistics_enabled",hashCellStatistics);
        diagnostics.put("cell_hash_statistics_merge_ms",cellStatistics.histogramMergeNanos / 1e6);
        if (hashCellStatistics) {
            implicitCellStatistics = cellStatistics.hashes.snapshot();
            diagnostics.put("cell_hash_statistics_cells",implicitCellStatistics.size());
        }
        long cellCountsCollected = System.nanoTime();
        CompactCellCounts mergedCellCounts = new CompactCellCounts();
        boolean legacyTieOrder = false;
        for (CompactCellCounts.Batch local : localCellCounts) {
            mergedCellCounts.add(local);
            legacyTieOrder |= local.negativeCoordinates;
        }
        // Positive cell coordinates have unique Morton codes. Preserve legacy HashMap
        // iteration when negative coordinates can produce equal clamped Morton codes.
        HashMap<Long, Long> legacyCounts = legacyTieOrder ? CompactCellCounts.legacyMerge(localCellCounts) : null;
        long cellCountsMerged = System.nanoTime();
        List<CellCount> orderedCells = new ArrayList<CellCount>(mergedCellCounts.size());
        if (legacyCounts != null) {
            for (Map.Entry<Long, Long> entry : legacyCounts.entrySet())
                orderedCells.add(new CellCount(entry.getKey(), entry.getValue()));
        } else {
            for (int i = 0; i < mergedCellCounts.size(); i++)
                orderedCells.add(new CellCount(mergedCellCounts.keyAt(i), mergedCellCounts.countAt(i)));
        }
        diagnostics.put("compact_cell_statistics", 1);
        diagnostics.put("legacy_cell_tie_order", legacyTieOrder ? 1 : 0);

        Collections.sort(orderedCells, new Comparator<CellCount>() {
            @Override
            public int compare(CellCount left, CellCount right) {
                int byOrder = profile.usesHilbertCellOrder()
                        ? Long.compareUnsigned(left.hilbertCode(), right.hilbertCode())
                        : Long.compareUnsigned(left.zCode, right.zCode);
                if (byOrder != 0) return byOrder;
                int byX = Integer.compare(left.x, right.x);
                return byX != 0 ? byX : Integer.compare(left.y, right.y);
            }
        });
        diagnostics.put("cell_ordering", profile.usesHilbertCellOrder() ? "hilbert" : "morton");

        long cellsSorted = System.nanoTime();
        CellOwnerIndex ownerByCell = assignCellsToPartitions(orderedCells, neighborOffsets);
        diagnostics.put("query_x", queryX);
        diagnostics.put("query_y", queryY);
        final ExperimentConfig experimentConfig = experiment == null
                ? ExperimentConfig.from(sc.getConf(), profile) : experiment;
        if (experimentConfig.enabled) {
            long[] cellKeys = new long[orderedCells.size()];
            int[] cellOwners = new int[orderedCells.size()];
            for (int index = 0; index < orderedCells.size(); index++) {
                cellKeys[index] = orderedCells.get(index).packed;
                cellOwners[index] = ownerByCell.getOrDefault(cellKeys[index], -1);
            }
            diagnostics.put("owner_layout_sha256", ExperimentLayouts.ownerSignature(cellKeys, cellOwners, "hilbert"));
            diagnostics.put("experiment_enabled", true);
            diagnostics.put("experiment_partition_strategy", experimentConfig.partitionStrategy);
            diagnostics.put("experiment_organization", experimentConfig.organization);
            diagnostics.put("experiment_transport_encoding", experimentConfig.transportEncoding);
            diagnostics.put("experiment_shard_strategy", experimentConfig.shardStrategy);
            diagnostics.put("owner_threads", experimentConfig.ownerThreads);
        }
        long ownersAssigned = System.nanoTime();
        boolean shareNeighborhood = profile.sharedNeighborhood;
        boolean m2V3Enabled = shareNeighborhood;
        final String m2RouteMode = sc.getConf().get("spark.skyline.m2.routeMode", "executor_dynamic");
        if (!m2RouteMode.equals("executor_dynamic") && !m2RouteMode.equals("driver_exact")) {
            throw new IllegalArgumentException("spark.skyline.m2.routeMode must be executor_dynamic or driver_exact");
        }
        diagnostics.put("m2_route_mode", m2RouteMode);
        if (experimentConfig.microPartition) {
            long[] coreCounts = new long[partition_number];
            for (CellCount cell : orderedCells) {
                int owner = ownerByCell.getOrDefault(cell.packed,-1);
                coreCounts[owner] = Math.addExact(coreCounts[owner],cell.count);
            }
            long[] assignedCounts=null;double populationMetadataMs=0;
            diagnostics.put("micro_population_prepass_cells",0);
            diagnostics.put("micro_population_prepass_ms",0.0);
            // Implicit candidate construction already derives exact original inputs.
            if(experimentConfig.microPopulationFromCells && !implicitFamily){
                long populationStart=System.nanoTime();
                long[] keys=new long[orderedCells.size()],counts=new long[orderedCells.size()];
                for(int cell=0;cell<orderedCells.size();cell++){
                    keys[cell]=orderedCells.get(cell).packed;counts[cell]=orderedCells.get(cell).count;
                }
                int[] dx=new int[neighborOffsets.size()],dy=new int[neighborOffsets.size()];
                for(int offset=0;offset<dx.length;offset++){dx[offset]=neighborOffsets.get(offset).dx;dy[offset]=neighborOffsets.get(offset).dy;}
                assignedCounts=MicroCellPopulation.assigned(keys,counts,ownerByCell,dx,dy,partition_number);
                populationMetadataMs=(System.nanoTime()-populationStart)/1e6;
                diagnostics.put("micro_population_prepass_cells",orderedCells.size());
                diagnostics.put("micro_population_prepass_ms",populationMetadataMs);
            }
            executeMicroPartition(sc, points, ownerByCell, neighborOffsets, dc, cellSize, originalCount, startPlan,coreCounts,assignedCounts,populationMetadataMs);
            return;
        }
        diagnostics.put("m2_v3_enabled", m2V3Enabled ? 1 : 0);
        NeighborhoodBundles.Plan bundlePlan = null;
        Broadcast<NeighborhoodBundles.Routes> routeBroadcast = null;
        if (shareNeighborhood) {
            if (partition_number > 4096) throw new IllegalArgumentException("shared planner supports at most 4096 owners");
            long bundleStart = System.nanoTime();
            M2RoutingPlan routingPlan = null;
            long[] core;
            long[] assigned;
            long[][] overlap;
            if (m2RouteMode.equals("executor_dynamic")) {
                if (m2RangeStats == null) throw new IllegalStateException("missing M2 range statistics");
                core = m2RangeStats.core;
                assigned = m2RangeStats.estimatedAssigned;
                overlap = new long[partition_number][partition_number];
                for (int owner = 0; owner + 1 < partition_number; owner++) {
                    overlap[owner][owner + 1] = m2RangeStats.adjacentOverlap[owner];
                }
                diagnostics.put("m2_v2_route_planning_threads", 0);
                diagnostics.put("m2_exact_driver_route_lookups", 0L);
            } else {
                int requestedRoutePlanningThreads = sc.getConf().getInt(
                        "spark.skyline.m2.v2.routePlanningThreads",
                        Math.min(8, Math.max(1, Runtime.getRuntime().availableProcessors())));
                long overlapMatrixBytes = 8L * partition_number * partition_number;
                int matrixBoundThreads = (int) Math.max(1L, Math.min(Integer.MAX_VALUE,
                        (256L * 1024L * 1024L) / Math.max(1L, overlapMatrixBytes)));
                int routePlanningThreads = Math.max(1,
                        Math.min(requestedRoutePlanningThreads, matrixBoundThreads));
                routingPlan = buildM2RoutingPlan(
                        orderedCells, ownerByCell, neighborOffsets, partition_number, routePlanningThreads);
                core = routingPlan.core;
                assigned = routingPlan.assigned;
                overlap = routingPlan.overlap;
                diagnostics.put("m2_v2_route_planning_threads", routePlanningThreads);
                diagnostics.put("interior_points", routingPlan.interiorPoints);
                diagnostics.put("boundary_points", routingPlan.boundaryPoints);
                diagnostics.put("skipped_neighbor_lookups",
                        routingPlan.interiorPoints * (neighborOffsets.size() - 1L));
                diagnostics.put("remaining_neighbor_lookups",
                        routingPlan.boundaryPoints * (neighborOffsets.size() - 1L));
                diagnostics.put("m2_exact_driver_route_lookups",
                        Math.multiplyExact((long) routingPlan.boundaryCells, neighborOffsets.size()));
            }
            long estimatedAssignedRecords = 0L;
            for (long value : assigned) estimatedAssignedRecords = Math.addExact(estimatedAssignedRecords, value);
            diagnostics.put("m2_estimated_assigned_records", estimatedAssignedRecords);
            int maxBundleOwners = sc.getConf().getInt("spark.skyline.m2.maxOwners",
                    sc.getConf().getInt("spark.skyline.maxBundleOwners", 2));
            int executionSlotsForM2 = Integer.parseInt(sc.getConf().get("spark.cores.max", "1"));
            M2AdaptivePlanner.Config m2Config = new M2AdaptivePlanner.Config(
                    maxBundleOwners,
                    sc.getConf().getLong("spark.skyline.m2.minOverlapRecords", 1L),
                    sc.getConf().getLong("spark.skyline.m2.maxGroupRecords", 1000000L),
                    sc.getConf().getDouble("spark.skyline.m2.pointBytes", 48.0),
                    sc.getConf().getDouble("spark.skyline.m2.independentRecordBytes", 96.0),
                    sc.getConf().getDouble("spark.skyline.m2.batchHeaderBytes", 4096.0),
                    sc.getConf().getDouble("spark.skyline.m2.sharedBlockOverheadRatio", 0.05),
                    sc.getConf().getDouble("spark.skyline.m2.indexSavedWeight", 1.0),
                    sc.getConf().getDouble("spark.skyline.m2.minBenefit", 0.0));
            M2AdaptivePlanner.Plan adaptivePlan = M2AdaptivePlanner.plan(
                    plannedPartitionWork, core, assigned, overlap, executionSlotsForM2, m2Config);
            boolean m2V2Enabled = sc.getConf().getBoolean("spark.skyline.m2.v2.enabled", true);
            double totalPlannedWork = 0.0;
            for (double work : plannedPartitionWork) totalPlannedWork += work;
            double maxBundleWorkFraction = sc.getConf().getDouble("spark.skyline.m2.v2.maxBundleWorkFraction", 0.50);
            double bundleCpuCap = totalPlannedWork / Math.max(1, executionSlotsForM2)
                    * maxBundleWorkFraction;
            long maxBundleRecordsV2 = sc.getConf().getLong("spark.skyline.m2.v2.maxBundleRecords", 1000000L);
            M2V2BundleGuard.Result guardedPlan = m2V2Enabled ? M2V2BundleGuard.apply(
                    adaptivePlan.group, adaptivePlan.slot, adaptivePlan.members, assigned,
                    plannedPartitionWork, overlap, bundleCpuCap, maxBundleRecordsV2) :
                    new M2V2BundleGuard.Result(adaptivePlan.group, adaptivePlan.slot, adaptivePlan.members,
                            adaptivePlan.originalRecords, adaptivePlan.sharedRecords, 0, 0);
            M2V3BenefitPlanner.Config m2V3Config = new M2V3BenefitPlanner.Config(
                    maxBundleRecordsV2,
                    bundleCpuCap,
                    sc.getConf().getDouble("spark.skyline.m2.v3.shuffleMsPerRecord", 0.0000021),
                    sc.getConf().getDouble("spark.skyline.m2.v3.indexMsPerRecord", 0.0000060),
                    sc.getConf().getDouble("spark.skyline.m2.v3.queryMsPerWork", 0.0),
                    sc.getConf().getDouble("spark.skyline.m2.v3.blockBuildMsPerRecord", 0.0000005),
                    sc.getConf().getDouble("spark.skyline.m2.v3.longTailMsPerWork", 0.0),
                    sc.getConf().getDouble("spark.skyline.m2.v3.minBenefitMs", 0.0));
            M2V3BenefitPlanner.Plan m2V3Plan = m2V3Enabled
                    ? M2V3BenefitPlanner.plan(plannedPartitionWork, core, assigned, overlap,
                            executionSlotsForM2, m2V3Config)
                    : null;
            bundlePlan = m2V3Enabled
                    ? new NeighborhoodBundles.Plan(m2V3Plan.group, m2V3Plan.slot,
                            m2V3Plan.members, m2V3Plan.originalRecords,
                            m2V3Plan.sharedRecords, bundleCpuCap)
                    : new NeighborhoodBundles.Plan(guardedPlan.group, guardedPlan.slot,
                            guardedPlan.members, guardedPlan.originalRecords,
                            guardedPlan.sharedRecords, bundleCpuCap);
            if (experimentConfig.enabled && experimentConfig.organization.equals("independent_owner")) {
                bundlePlan = ExperimentLayouts.independentOwners(assigned, bundleCpuCap);
            }
            if (experimentConfig.enabled) {
                diagnostics.put("bundle_layout_sha256", ExperimentLayouts.bundleSignature(bundlePlan.members));
            }
            diagnostics.put("bundle_max_owners", maxBundleOwners);
            diagnostics.put("m2_candidate_pairs", adaptivePlan.acceptedPairs + adaptivePlan.rejectedPairs);
            diagnostics.put("m2_accepted_pairs", adaptivePlan.acceptedPairs);
            diagnostics.put("m2_rejected_pairs", adaptivePlan.rejectedPairs);
            diagnostics.put("m2_rejected_low_overlap", adaptivePlan.rejectedLowOverlap);
            diagnostics.put("m2_rejected_memory_cap", adaptivePlan.rejectedMemoryCap);
            diagnostics.put("m2_rejected_negative_benefit", adaptivePlan.rejectedNegativeBenefit);
            diagnostics.put("m2_estimated_saved_records", adaptivePlan.estimatedSavedRecords);
            diagnostics.put("m2_estimated_saved_bytes", adaptivePlan.estimatedSavedBytes);
            diagnostics.put("m2_estimated_index_saved", adaptivePlan.estimatedIndexSaved);
            diagnostics.put("m2_estimated_bundle_cost", adaptivePlan.estimatedBundleCost);
            diagnostics.put("m2_max_group_records", adaptivePlan.maxGroupRecords);
            diagnostics.put("m2_max_group_owners", adaptivePlan.maxGroupOwners);
            diagnostics.put("m2_min_overlap_records", m2Config.minOverlapRecords);
            diagnostics.put("m2_max_group_record_cap", m2Config.maxGroupRecords);
            diagnostics.put("m2_point_bytes", m2Config.pointBytes);
            diagnostics.put("m2_independent_record_bytes", m2Config.independentRecordBytes);
            diagnostics.put("m2_batch_header_bytes", m2Config.batchHeaderBytes);
            diagnostics.put("m2_shared_block_overhead_ratio", m2Config.sharedBlockOverheadRatio);
            diagnostics.put("m2_index_saved_weight", m2Config.indexSavedWeight);
            diagnostics.put("m2_min_benefit", m2Config.minBenefit);
            diagnostics.put("m2_v2_enabled", m2V2Enabled ? 1 : 0);
            diagnostics.put("m2_v2_rejected_work", guardedPlan.rejectedWork);
            diagnostics.put("m2_v2_rejected_records", guardedPlan.rejectedRecords);
            diagnostics.put("m2_v2_max_bundle_work", bundleCpuCap);
            diagnostics.put("m2_v2_max_bundle_records", maxBundleRecordsV2);
            if (m2V3Plan != null) {
                diagnostics.put("m2_candidate_pairs", m2V3Plan.candidatePairs);
                diagnostics.put("m2_accepted_pairs", m2V3Plan.acceptedPairs);
                diagnostics.put("m2_rejected_pairs", m2V3Plan.candidatePairs - m2V3Plan.acceptedPairs);
                diagnostics.put("m2_rejected_memory_cap", m2V3Plan.rejectedRecords);
                diagnostics.put("m2_rejected_negative_benefit", m2V3Plan.rejectedNegativeBenefit);
                diagnostics.put("m2_v3_rejected_work", m2V3Plan.rejectedWork);
                diagnostics.put("m2_v3_predicted_benefit_ms", m2V3Plan.predictedBenefitMs);
                diagnostics.put("m2_v3_predicted_shuffle_saved_ms", m2V3Plan.predictedShuffleSavedMs);
                diagnostics.put("m2_v3_predicted_index_saved_ms", m2V3Plan.predictedIndexSavedMs);
                diagnostics.put("m2_v3_predicted_query_saved_ms", m2V3Plan.predictedQuerySavedMs);
                diagnostics.put("m2_v3_predicted_block_build_ms", m2V3Plan.predictedBlockBuildMs);
                diagnostics.put("m2_v3_predicted_long_tail_ms", m2V3Plan.predictedLongTailMs);
                diagnostics.put("m2_v3_shuffle_ms_per_record", m2V3Config.shuffleMsPerRecord);
                diagnostics.put("m2_v3_index_ms_per_record", m2V3Config.indexMsPerRecord);
                diagnostics.put("m2_v3_query_ms_per_work", m2V3Config.queryMsPerWork);
                diagnostics.put("m2_v3_block_build_ms_per_record", m2V3Config.blockBuildMsPerRecord);
                diagnostics.put("m2_v3_long_tail_ms_per_work", m2V3Config.longTailMsPerWork);
                diagnostics.put("m2_v3_min_benefit_ms", m2V3Config.minBenefitMs);
            }
            if (m2RouteMode.equals("driver_exact")) {
                NeighborhoodBundles.Routes routes = new NeighborhoodBundles.Routes(routingPlan.boundaryCells);
                for (int i = 0; i < orderedCells.size(); i++) {
                    int[] destinations = routingPlan.targetsByRank[i];
                    if (destinations == null) continue;
                    long packed = orderedCells.get(i).packed;
                    routes.put(packed, new NeighborhoodBundles.Route(
                            ownerByCell.getOrDefault(packed, -1), destinations, bundlePlan));
                }
                diagnostics.put("bundle_boundary_route_cells", routingPlan.boundaryCells);
                routeBroadcast = sc.broadcast(routes);
            } else {
                diagnostics.put("bundle_boundary_route_cells", 0);
            }
            diagnostics.put("bundle_groups", bundlePlan.members.length);
            diagnostics.put("bundle_owner_groups", java.util.Arrays.toString(bundlePlan.group));
            diagnostics.put("bundle_original_records", bundlePlan.originalRecords);
            diagnostics.put("bundle_shared_records", bundlePlan.sharedRecords);
            diagnostics.put("bundle_saved_records", bundlePlan.originalRecords - bundlePlan.sharedRecords);
            diagnostics.put("m2_estimated_saved_records",
                    bundlePlan.originalRecords - bundlePlan.sharedRecords);
            diagnostics.put("bundle_cpu_cap", bundlePlan.cpuCap);
            diagnostics.put("bundle_plan_ms", (System.nanoTime() - bundleStart) / 1000000.0);
        }
        diagnostics.put("shared_neighborhood", shareNeighborhood ? 1 : 0);

        Broadcast<CellOwnerIndex> ownerBroadcast = sc.broadcast(ownerByCell);
        Broadcast<List<NeighborOffset>> neighborOffsetsBroadcast = sc.broadcast(neighborOffsets);
        this.s2_plan_cells = System.currentTimeMillis() - startPlan;
        diagnostics.put("nonempty_cells", orderedCells.size());
        diagnostics.put("neighbor_offsets", neighborOffsets.size());
        diagnostics.put("s2_merge_ms", (cellCountsMerged - cellCountsCollected) / 1000000L);
        diagnostics.put("s2_sort_ms", (cellsSorted - cellCountsMerged) / 1000000L);
        diagnostics.put("s2_assign_ms", (ownersAssigned - cellsSorted) / 1000000L);

        long startClone = System.currentTimeMillis();
        JavaRDD<SharedNeighborhoodRDD.Block> sharedBlocks = null;
        JavaRDD<MaskedSharedBlock> maskedBlocks = null;
        org.apache.spark.util.LongAccumulator routingBatchRecords = sc.sc().longAccumulator("routing_batch_records");
        org.apache.spark.util.LongAccumulator executorNeighborLookups =
                sc.sc().longAccumulator("m2_executor_neighbor_lookups");
        JavaPairRDD<Integer, Point> partitionedPoints;
        if (shareNeighborhood) {
            final Broadcast<NeighborhoodBundles.Routes> routing = routeBroadcast;
            final int[] ownerGroups = bundlePlan.group, ownerSlots = bundlePlan.slot;
            final int groupCount = bundlePlan.members.length;
            final int[] offsetX = new int[neighborOffsets.size()];
            final int[] offsetY = new int[neighborOffsets.size()];
            for (int index = 0; index < neighborOffsets.size(); index++) {
                offsetX[index] = neighborOffsets.get(index).dx;
                offsetY[index] = neighborOffsets.get(index).dy;
            }
            JavaPairRDD<Integer, CompactPacketBatches.Batch> batches = points.mapPartitionsToPair(iterator -> {
                CellOwnerIndex owners = ownerBroadcast.value();
                if (m2RouteMode.equals("executor_dynamic")) {
                    return DynamicCompactPacketBatches.route(iterator, offsetX, offsetY,
                            ownerGroups, ownerSlots, groupCount,
                            packed -> owners.getEncodedOrDefault(packed, -1),
                            packed -> owners.getOrDefault(packed, -1),
                            routingBatchRecords, executorNeighborLookups,
                            experimentConfig.enabled ? experimentConfig.transportEncoding : "deduplicated_union");
                }
                return CompactPacketBatches.route(iterator, routing.value(), ownerGroups, ownerSlots,
                        groupCount, packed -> owners.getEncodedOrDefault(packed, -1), routingBatchRecords,
                        experimentConfig.enabled ? experimentConfig.transportEncoding : "deduplicated_union");
            });
            if (m2V3Enabled) {
                if (experimentConfig.observe) transportObservations = sc.sc().collectionAccumulator("transport_observations");
                maskedBlocks = MaskedSharedNeighborhoodRDD.cacheBatches(batches, bundlePlan, transportObservations);
                partitionedPoints = new MaskedSharedNeighborhoodRDD(maskedBlocks, bundlePlan).asPairs();
            } else {
                sharedBlocks = SharedNeighborhoodRDD.cacheBatches(batches, bundlePlan);
                partitionedPoints = new SharedNeighborhoodRDD(sharedBlocks, bundlePlan).asPairs();
            }
        } else {
        partitionedPoints = points.flatMapToPair(point -> {
            CellOwnerIndex owners = ownerBroadcast.value();
            int encodedOwner = owners.getEncodedOrDefault(point.packedCellId, -1);
            if (encodedOwner == -1) {
                return Collections.<Tuple2<Integer, Point>>emptyList().iterator();
            }
            boolean interior = encodedOwner < -1;
            int ownerPartitionId = interior ? -encodedOwner - 2 : encodedOwner;
            HashSet<Integer> targetPartitions = new HashSet<Integer>();
            targetPartitions.add(ownerPartitionId);

            ArrayList<Tuple2<Integer, Point>> result = new ArrayList<Tuple2<Integer, Point>>();
            Point coreCopy = new Point(point);
            coreCopy.ownerPartitionId = ownerPartitionId;
            coreCopy.is_core = true;
            coreCopy.is_clone = false;
            result.add(new Tuple2<Integer, Point>(ownerPartitionId, coreCopy));

            if (interior) return result.iterator();

            for (NeighborOffset offset : neighborOffsetsBroadcast.value()) {
                if (offset.dx == 0 && offset.dy == 0) {
                    continue;
                }
                int neighborOwner = owners.getOrDefault(pack(point.cellX + offset.dx, point.cellY + offset.dy), -1);
                if (neighborOwner < 0 || neighborOwner == ownerPartitionId || !targetPartitions.add(neighborOwner)) {
                    continue;
                }
                Point haloCopy = new Point(point);
                haloCopy.ownerPartitionId = ownerPartitionId;
                haloCopy.is_core = false;
                haloCopy.is_clone = true;
                result.add(new Tuple2<Integer, Point>(neighborOwner, haloCopy));
            }
            return result.iterator();
        }).partitionBy(new HashPartitioner(partition_number))
                .persist(StorageLevel.MEMORY_AND_DISK());
        }
        if (shareNeighborhood) {
            // One first materialization per cache group. Building through owner views can fetch
            // the same shuffle partition on multiple executors before the cache exists.
            final int[][] members = bundlePlan.members;
            List<PartitionMetrics> sharedMetrics;
            if (m2V3Enabled) {
                List<Tuple2<List<PartitionMetrics>, long[]>> groupMetrics = maskedBlocks
                        .mapPartitionsWithIndex((groupId, blocks) -> {
                            if (!blocks.hasNext()) throw new IllegalStateException("missing masked block");
                            MaskedSharedBlock block = blocks.next();
                            if (blocks.hasNext()) throw new IllegalStateException("multiple masked blocks");
                            ArrayList<PartitionMetrics> metrics = new ArrayList<PartitionMetrics>();
                            long logical = 0L;
                            for (int slot = 0; slot < block.ownerIds.length; slot++) {
                                long core = block.ownerCoreCounts[slot];
                                long assigned = block.ownerAssignedCounts[slot];
                                logical = Math.addExact(logical, assigned);
                                metrics.add(new PartitionMetrics(block.ownerIds[slot], core,
                                        assigned - core, block.ownerSourceCounts[slot]));
                            }
                            return Collections.singletonList(new Tuple2<List<PartitionMetrics>, long[]>(
                                    metrics, new long[]{block.unionPoints.length, logical})).iterator();
                        }, false).collect();
                sharedMetrics = new ArrayList<PartitionMetrics>();
                long physical = 0L, logical = 0L;
                for (Tuple2<List<PartitionMetrics>, long[]> group : groupMetrics) {
                    sharedMetrics.addAll(group._1());
                    physical = Math.addExact(physical, group._2()[0]);
                    logical = Math.addExact(logical, group._2()[1]);
                }
                diagnostics.put("masked_union_points", physical);
                diagnostics.put("masked_logical_records", logical);
                diagnostics.put("bundle_shared_records", physical);
                diagnostics.put("bundle_saved_records", logical - physical);
                diagnostics.put("m2_actual_saved_records", logical - physical);
                if (m2RouteMode.equals("driver_exact") && logical != bundlePlan.originalRecords)
                    throw new IllegalStateException("masked logical coverage mismatch");
            } else {
                sharedMetrics = sharedBlocks.mapPartitionsWithIndex((groupId, blocks) -> {
                    if (!blocks.hasNext()) throw new IllegalStateException("missing shared block");
                    SharedNeighborhoodRDD.Block block = blocks.next();
                    ArrayList<PartitionMetrics> metrics = new ArrayList<>();
                    for (int slot = 0; slot < block.bySlot.length; slot++) {
                        int owner = members[groupId][slot]; long core = 0;
                        HashSet<Integer> sources = new HashSet<>();
                        for (Point point : block.bySlot[slot]) {
                            if (point.ownerPartitionId == owner) core++;
                            sources.add(point.ownerPartitionId);
                        }
                        metrics.add(new PartitionMetrics(owner, core,
                                block.bySlot[slot].length - core, sources.size()));
                    }
                    return metrics.iterator();
                }, false).collect();
            }
            recordPartitionCloneStats(originalCount, sharedMetrics);
            diagnostics.put("routing_batch_records", routingBatchRecords.value());
            diagnostics.put("routing_batch_size", CompactPacketBatches.LIMIT);
            diagnostics.put("m2_executor_neighbor_lookups", executorNeighborLookups.value());
        } else capturePartitionCloneStats(originalCount, partitionedPoints);
        if (shareNeighborhood) {
            long actualAssignedRecords = ((Number) diagnostics.get("assigned_points")).longValue();
            long actualCoreRecords = 0L;
            for (long value : actualPartitionCore) {
                actualCoreRecords = Math.addExact(actualCoreRecords, value);
            }
            diagnostics.put("m2_actual_core_records", actualCoreRecords);
            diagnostics.put("m2_actual_assigned_records", actualAssignedRecords);
            if (m2RouteMode.equals("executor_dynamic")) {
                validateDynamicCoverage(originalCount,
                        ((Number) diagnostics.get("m2_estimated_assigned_records")).longValue(),
                        actualPartitionCore, actualAssignedRecords);
            } else if (actualAssignedRecords != bundlePlan.originalRecords) {
                throw new IllegalStateException("shared neighbourhood coverage mismatch");
            }
        }
        this.s3_clone_assign = System.currentTimeMillis() - startClone;

        if (sc.getConf().getBoolean("spark.skyline.validationFingerprints", false)) {
            ValidationFingerprints.Result validation = ValidationFingerprints.of(partitionedPoints);
            if (validation.anchorCount != originalCount)
                throw new IllegalStateException("anchor responsibility coverage mismatch: " + validation.anchorCount + " != " + originalCount);
            diagnostics.put("owner_neighborhood_fingerprint", validation.neighborhood);
            diagnostics.put("anchor_responsibility_fingerprint", validation.anchors);
            diagnostics.put("anchor_responsibility_count", validation.anchorCount);
        }

        long startLocal = System.currentTimeMillis();
        double budgetFraction = profile.refinement
                ? Double.parseDouble(sc.getConf().get("spark.skyline.shardReadBudget", "0.01"))
                : 0.0;
        int executionSlots = Integer.parseInt(sc.getConf().get("spark.cores.max", "1"));
        String costPolicy = sc.getConf().get("spark.skyline.costPolicy", "guarded");
        if (!costPolicy.equals("legacy") && !costPolicy.equals("calibrated") && !costPolicy.equals("guarded"))
            throw new IllegalArgumentException("costPolicy must be legacy, calibrated or guarded");
        // Keep the previous small/uniform-query behaviour; calibration is a skew remedy.
        BudgetedQueryShards.Plan baselinePlan = BudgetedQueryShards.plan(plannedPartitionWork,
                actualPartitionCore, actualPartitionAssigned, budgetFraction, 4);
        double[] baselineExecutionWork = new double[baselinePlan.tasks];
        int baselineTask = 0;
        for (int p = 0; p < partition_number; p++) for (int s = 0; s < baselinePlan.pieces[p]; s++)
            baselineExecutionWork[baselineTask++] = plannedPartitionWork[p] / baselinePlan.pieces[p];
        // Preserve P21's execution regime. A pre-split skew test alone can turn on
        // sorting for workloads where P21 deliberately kept the original order.
        boolean baselineReordered = CostOrderedMaterializer.order(baselineExecutionWork, executionSlots, "work") != null;
        boolean calibrated = !costPolicy.equals("legacy") && baselineReordered;
        diagnostics.put("execution_baseline_reordered", baselineReordered ? 1 : 0);
        diagnostics.put("execution_baseline_pieces", java.util.Arrays.toString(baselinePlan.pieces));
        double[] schedulingCost = calibrated ? CalibratedShardPlanner.costs(plannedPartitionWork,
                actualPartitionCore, actualPartitionAssigned) : plannedPartitionWork;
        BudgetedQueryShards.Plan shardPlan = calibrated && costPolicy.equals("guarded") ?
                GuardedCostShards.plan(plannedPartitionWork, actualPartitionCore, actualPartitionAssigned, budgetFraction, 4) :
                calibrated ? CalibratedShardPlanner.plan(plannedPartitionWork,
                actualPartitionCore, actualPartitionAssigned, budgetFraction, 4) :
                baselinePlan;
        double m4TargetFactor = Double.parseDouble(
                sc.getConf().get("spark.skyline.m4.targetFactor", "1.20"));
        if (!Double.isFinite(m4TargetFactor) || m4TargetFactor < 1.0) {
            throw new IllegalArgumentException(
                    "spark.skyline.m4.targetFactor must be finite and >= 1.0");
        }
        double m4ExtraTaskMs = Double.parseDouble(
                sc.getConf().get("spark.skyline.m4.extraTaskMs", "1.0"));
        if (!Double.isFinite(m4ExtraTaskMs) || m4ExtraTaskMs < 0.0) {
            throw new IllegalArgumentException(
                    "spark.skyline.m4.extraTaskMs must be finite and >= 0");
        }
        double m4ExtraMapMs = Double.parseDouble(
                sc.getConf().get("spark.skyline.m4.extraMapMs", "0.1"));
        if (!Double.isFinite(m4ExtraMapMs) || m4ExtraMapMs < 0.0) {
            throw new IllegalArgumentException(
                    "spark.skyline.m4.extraMapMs must be finite and >= 0");
        }
        PhysicalBundleShardPlanner.Plan physicalM4Plan = null;
        if (m2V3Enabled) {
            if (experimentConfig.enabled && !experimentConfig.shardStrategy.equals("cost_model")) {
                int[] pieces = new int[partition_number];
                java.util.Arrays.fill(pieces, 1);
                if (experimentConfig.shardStrategy.equals("uniform")) {
                    pieces = UniformBundleShardPlanner.plan(bundlePlan.members, actualPartitionCore,
                            actualPartitionAssigned, budgetFraction, experimentConfig.maxPieces, m4TargetFactor).pieces;
                }
                physicalM4Plan = PhysicalBundleShardPlanner.evaluate(bundlePlan.members, plannedPartitionWork,
                        actualPartitionCore, actualPartitionAssigned, pieces, budgetFraction, m4ExtraTaskMs, m4ExtraMapMs);
            } else if (experimentConfig.enabled) {
                physicalM4Plan = PhysicalBundleShardPlanner.plan(bundlePlan.members, plannedPartitionWork,
                        actualPartitionCore, actualPartitionAssigned, budgetFraction, experimentConfig.maxPieces,
                        m4TargetFactor, m4ExtraTaskMs, m4ExtraMapMs);
            } else {
                physicalM4Plan = planMaskedPhysicalShards(bundlePlan.members,
                    plannedPartitionWork, actualPartitionCore, actualPartitionAssigned,
                    budgetFraction, m4TargetFactor, m4ExtraTaskMs, m4ExtraMapMs);
            }
            shardPlan = physicalM4Plan.ownerPlan;
        }
        diagnostics.put("m4_target_factor", m4TargetFactor);
        diagnostics.put("m4_extra_task_ms", m4ExtraTaskMs);
        diagnostics.put("m4_extra_map_ms", m4ExtraMapMs);
        diagnostics.put("m4_physical_tasks", physicalM4Plan == null ? 0 : physicalM4Plan.physicalTasks);
        diagnostics.put("m4_split_bundles", physicalM4Plan == null ? 0 : physicalM4Plan.splitBundles);
        diagnostics.put("m4_extra_prepared_reads",
                physicalM4Plan == null ? 0L : physicalM4Plan.extraPreparedReads);
        diagnostics.put("m4_predicted_saving_s",
                physicalM4Plan == null ? 0.0 : physicalM4Plan.predictedSaving);
        diagnostics.put("m4_rejected_by_budget",
                physicalM4Plan == null ? 0L : physicalM4Plan.rejectedByBudget);
        diagnostics.put("m4_rejected_by_cost",
                physicalM4Plan == null ? 0L : physicalM4Plan.rejectedByCost);
        diagnostics.put("execution_cost_policy", calibrated ? costPolicy + "_cpu" : "legacy");
        diagnostics.put("execution_parent_costs", java.util.Arrays.toString(schedulingCost));
        String scheduleCost = sc.getConf().get("spark.skyline.scheduleCost", "work");
        if (!scheduleCost.equals("work") && !scheduleCost.equals("calibrated"))
            throw new IllegalArgumentException("scheduleCost must be work or calibrated");
        boolean calibratedSchedule = calibrated && scheduleCost.equals("calibrated");
        diagnostics.put("schedule_cost", scheduleCost);
        String priorityPolicy = sc.getConf().get("spark.skyline.shardPriority", "parent");
        if (!priorityPolicy.equals("parent") && !priorityPolicy.equals("child"))
            throw new IllegalArgumentException("shardPriority must be parent or child");
        diagnostics.put("shard_priority", priorityPolicy);
        diagnostics.put("shard_tasks", shardPlan.tasks);
        diagnostics.put("shard_split_partitions", shardPlan.splitPartitions);
        diagnostics.put("shard_extra_records", shardPlan.extraRecords);
        diagnostics.put("shard_record_budget", shardPlan.recordBudget);
        diagnostics.put("shard_pieces", java.util.Arrays.toString(shardPlan.pieces));
        diagnostics.put("shard_original_max_work", shardPlan.originalMaximum);
        diagnostics.put("shard_residual_max_work", shardPlan.residualMaximum);
        JavaRDD<HashMap<Double, Circle>> localClusters;
        double[] executionWork;
        if (shardPlan.splitPartitions == 0) {
            localClusters = performLocalClustering(partitionedPoints, dc, cellSize);
            executionWork = calibratedSchedule ? schedulingCost : plannedPartitionWork;
        } else {
            localClusters = new QueryShardRDD(partitionedPoints, shardPlan.pieces, dc, cellSize,
                    queryX, queryY, density_k).asJava();
            executionWork = new double[shardPlan.tasks];
            int task = 0;
            for (int p = 0; p < partition_number; p++) for (int s = 0; s < shardPlan.pieces[p]; s++)
                executionWork[task++] = calibratedSchedule ? (priorityPolicy.equals("parent") ? schedulingCost[p] :
                        CalibratedShardPlanner.fixed(actualPartitionAssigned[p]) +
                        CalibratedShardPlanner.variable(plannedPartitionWork[p], actualPartitionCore[p]) / shardPlan.pieces[p]) :
                        plannedPartitionWork[p] / shardPlan.pieces[p];
        }
        boolean indexedQueries = profile.reusableEngine;
        org.apache.spark.util.LongAccumulator indexBuilds = sc.sc().longAccumulator("index_builds");
        org.apache.spark.util.LongAccumulator indexReuses = sc.sc().longAccumulator("index_reuses");
        org.apache.spark.util.LongAccumulator indexNanos = sc.sc().longAccumulator("index_build_nanos");
        org.apache.spark.util.LongAccumulator candidateCount = sc.sc().longAccumulator("candidate_count");
        org.apache.spark.util.LongAccumulator singlePointCandidates = sc.sc().longAccumulator("single_point_candidates");
        org.apache.spark.util.LongAccumulator pairCandidates = sc.sc().longAccumulator("pair_candidates");
        org.apache.spark.util.LongAccumulator zWindowChecks = sc.sc().longAccumulator("z_window_checks");
        org.apache.spark.util.LongAccumulator pointDistanceChecks = sc.sc().longAccumulator("point_distance_checks");
        org.apache.spark.util.CollectionAccumulator<Long> taskTimesMs = sc.sc().collectionAccumulator("local_task_times_ms");
        org.apache.spark.util.CollectionAccumulator<Long> bundleTaskTimesMs = sc.sc().collectionAccumulator("bundle_task_times_ms");
        org.apache.spark.util.LongAccumulator projectedCandidates = sc.sc().longAccumulator("projected_candidates");
        org.apache.spark.util.LongAccumulator projectedHits = sc.sc().longAccumulator("projected_count_hits");
        org.apache.spark.util.LongAccumulator projectedBounds = sc.sc().longAccumulator("projected_bound_hits");
        org.apache.spark.util.LongAccumulator maskChecks = sc.sc().longAccumulator("m2_v3_mask_checks");
        org.apache.spark.util.LongAccumulator maskFiltered = sc.sc().longAccumulator("m2_v3_mask_filtered");
        org.apache.spark.util.LongAccumulator preparedReads = sc.sc().longAccumulator("m4_prepared_reads");
        boolean m2V2QueryEnabled = indexedQueries && shareNeighborhood;
        BundleQueryLayout queryLayout = null;
        BundleShardLayout physicalLayout = null;
        JavaRDD<MaskedPreparedNeighborhood> preparedBundles = null;
        boolean m4PhysicalExecution = false;
        EngineOptions engineOptions = new EngineOptions(experimentConfig.enabled
                ? experimentConfig.projectionCache : profile.newBounds, profile.preparedReuse,
                experimentConfig.geometricBounds);
        if (experimentConfig.enabled) {
            diagnostics.put("experiment_prepared_mode", experimentConfig.preparedMode);
            diagnostics.put("experiment_projection_cache", experimentConfig.projectionCache ? "on" : "off");
            diagnostics.put("experiment_geometric_bounds", experimentConfig.geometricBounds);
        }
        JavaRDD<OwnerNeighborhoodRDD.Block> ownerBlocks = null;
        if (indexedQueries && !shareNeighborhood) {
            diagnostics.put("local_engine_class", OwnerIndexedQueryRDD.class.getName());
            ownerBlocks = new OwnerNeighborhoodRDD(partitionedPoints).asJava()
                    .persist(StorageLevel.MEMORY_AND_DISK());
            localClusters = new OwnerIndexedQueryRDD(ownerBlocks, shardPlan.pieces,
                    dc, cellSize, queryX, queryY, density_k, indexBuilds, indexReuses,
                    indexNanos, candidateCount, singlePointCandidates, pairCandidates,
                    zWindowChecks, pointDistanceChecks,
                    taskTimesMs, projectedCandidates, projectedHits, projectedBounds).asJava();
        } else if (indexedQueries && (m2V3Enabled || m2V2QueryEnabled)) {
            diagnostics.put("local_engine_class", MaskedIndexedEMCS.class.getName());
            long[] ownerWork = new long[partition_number];
            for (int p = 0; p < partition_number; p++)
                ownerWork[p] = Math.max(0L, Math.round(calibratedSchedule ? schedulingCost[p] : plannedPartitionWork[p]));
            queryLayout = BundleQueryLayout.from(bundlePlan.members, bundlePlan.slot,
                    shardPlan.pieces, ownerWork);
            if (m2V3Enabled) {
                physicalLayout = BundleShardLayout.from(queryLayout);
                TaskObservation.Collector localObserver = null;
                if (experimentConfig.taskDetails) {
                    localObservations = sc.sc().collectionAccumulator("local_task_observations");
                    PhysicalBundleShardPlanner.TaskPrediction[] predictions = new PhysicalBundleShardPlanner.TaskPrediction[physicalLayout.taskCount()];
                    for (int taskId = 0; taskId < predictions.length; taskId++) {
                        predictions[taskId] = PhysicalBundleShardPlanner.predictTask(bundlePlan.members,
                                plannedPartitionWork, actualPartitionCore, actualPartitionAssigned,
                                physicalLayout.task(taskId), m4ExtraTaskMs, m4ExtraMapMs);
                    }
                    localObserver = new TaskObservation.Collector(experimentConfig.runId, predictions, localObservations);
                }
                if (experimentConfig.enabled) diagnostics.put("shard_layout_sha256", ExperimentLayouts.shardSignature(physicalLayout));
                if (physicalM4Plan == null
                        || physicalLayout.taskCount() != physicalM4Plan.physicalTasks) {
                    throw new IllegalStateException("M4 planner/physical layout mismatch");
                }
                diagnostics.put("m4_physical_tasks", physicalLayout.taskCount());
                diagnostics.put("m4_split_bundles", physicalLayout.splitBundleCount());
                if (!experimentConfig.enabled && physicalLayout.taskCount() == queryLayout.taskCount()) {
                    executionWork = new double[queryLayout.taskCount()];
                    for (int group = 0; group < queryLayout.taskCount(); group++) {
                        executionWork[group] = queryLayout.taskWork(group);
                    }
                    localClusters = new MaskedBundleQueryRDD(maskedBlocks, queryLayout,
                            dc, cellSize, queryX, queryY, density_k, indexBuilds, indexNanos,
                            candidateCount, singlePointCandidates, pairCandidates,
                            zWindowChecks, pointDistanceChecks, taskTimesMs,
                            bundleTaskTimesMs, projectedCandidates, projectedHits, projectedBounds,
                            maskChecks, maskFiltered, engineOptions).asJava();
                } else {
                    m4PhysicalExecution = true;
                    executionWork = physicalLayout.executionWork();
                    if (experimentConfig.enabled && experimentConfig.preparedMode.equals("private_owner_index")) {
                        localClusters = new MaskedRawShardQueryRDD(maskedBlocks, physicalLayout,
                                dc, cellSize, queryX, queryY, density_k, indexBuilds, indexNanos, preparedReads,
                                taskTimesMs, bundleTaskTimesMs, new MaskedLaneQuery.Metrics(candidateCount,
                                singlePointCandidates, pairCandidates, zWindowChecks, pointDistanceChecks,
                                projectedCandidates, projectedHits, projectedBounds, maskChecks, maskFiltered), engineOptions, localObserver).asJava();
                        diagnostics.put("m4_prewarmed_split_parents", 0);
                    } else {
                        preparedBundles = new MaskedPreparedBundleRDD(maskedBlocks,
                                dc, cellSize, queryX, queryY, indexBuilds, indexNanos)
                                .asJava().persist(StorageLevel.MEMORY_AND_DISK());
                        CostOrderedMaterializer.materializeSelected(
                                sc, preparedBundles, physicalLayout.splitParentGroups());
                        diagnostics.put("m4_prewarmed_split_parents",
                                physicalLayout.splitBundleCount());
                        localClusters = new MaskedShardQueryRDD(preparedBundles, physicalLayout,
                                dc, cellSize, queryX, queryY, density_k, preparedReads,
                                candidateCount, singlePointCandidates, pairCandidates,
                                zWindowChecks, pointDistanceChecks, taskTimesMs,
                                bundleTaskTimesMs, projectedCandidates, projectedHits, projectedBounds,
                                maskChecks, maskFiltered, engineOptions,
                                experimentConfig.enabled ? experimentConfig.ownerThreads : 2, localObserver).asJava();
                    }
                }
            } else {
                executionWork = new double[queryLayout.taskCount()];
                for (int group = 0; group < queryLayout.taskCount(); group++)
                    executionWork[group] = queryLayout.taskWork(group);
                localClusters = new BundleIndexedQueryRDD(sharedBlocks, queryLayout,
                        dc, cellSize, queryX, queryY, density_k, indexBuilds, indexReuses, indexNanos,
                        candidateCount, singlePointCandidates, pairCandidates,
                        zWindowChecks, pointDistanceChecks, taskTimesMs, bundleTaskTimesMs,
                        projectedCandidates, projectedHits, projectedBounds).asJava();
            }
            diagnostics.put("m2_v2_bundle_task_count", queryLayout.taskCount());
            diagnostics.put("m2_v2_owner_query_maps", queryLayout.totalOutputMaps());
            diagnostics.put("m2_v2_query_layout", queryLayout.describe());
        } else if (!indexedQueries && shareNeighborhood) {
            diagnostics.put("local_engine_class", BaselineLocalQuery.KERNEL);
            long[] ownerWork = new long[partition_number];
            for (int owner = 0; owner < partition_number; owner++) {
                ownerWork[owner] = Math.max(0L, Math.round(
                        calibratedSchedule ? schedulingCost[owner] : plannedPartitionWork[owner]));
            }
            queryLayout = BundleQueryLayout.from(bundlePlan.members, bundlePlan.slot,
                    shardPlan.pieces, ownerWork);
            physicalLayout = BundleShardLayout.from(queryLayout);
            if (physicalM4Plan == null
                    || physicalLayout.taskCount() != physicalM4Plan.physicalTasks) {
                throw new IllegalStateException("baseline engine M4 layout mismatch");
            }
            executionWork = physicalLayout.executionWork();
            m4PhysicalExecution = true;
            diagnostics.put("m4_physical_tasks", physicalLayout.taskCount());
            diagnostics.put("m4_split_bundles", physicalLayout.splitBundleCount());
            diagnostics.put("m2_v2_bundle_task_count", physicalLayout.taskCount());
            diagnostics.put("m2_v2_owner_query_maps", physicalLayout.totalOutputMaps());
            diagnostics.put("m2_v2_query_layout", queryLayout.describe());
            localClusters = new BaselineMaskedShardQueryRDD(maskedBlocks, physicalLayout,
                    dc, queryX, queryY, density_k, candidateCount,
                    singlePointCandidates, pairCandidates, zWindowChecks,
                    pointDistanceChecks, maskChecks, maskFiltered,
                    taskTimesMs, bundleTaskTimesMs).asJava();
        } else if (indexedQueries) {
            diagnostics.put("local_engine_class", IndexedEMCS.class.getName());
            localClusters = new IndexedQueryRDD(sharedBlocks, bundlePlan, shardPlan.pieces,
                    dc, cellSize, queryX, queryY, density_k, indexBuilds, indexReuses, indexNanos,
                    candidateCount, singlePointCandidates, pairCandidates,
                    zWindowChecks, pointDistanceChecks, taskTimesMs,
                    projectedCandidates, projectedHits, projectedBounds).asJava();
        }
        diagnostics.put("m4_physical_execution", m4PhysicalExecution ? 1 : 0);
        diagnostics.put("m2_v2_query_enabled", m2V2QueryEnabled ? 1 : 0);
        diagnostics.put("prepared_indexes", indexedQueries ? 1 : 0);
        String priorityFloor = sc.getConf().get("spark.skyline.priorityFloor", "median");
        if (!priorityFloor.equals("median") && !priorityFloor.equals("none"))
            throw new IllegalArgumentException("priorityFloor must be median or none");
        double floor = 0;
        if (ShardPriorityFloor.shouldApply(m2V2QueryEnabled, m4PhysicalExecution,
                baselineReordered, calibratedSchedule, priorityFloor,
                shardPlan.splitPartitions)) {
            floor = ShardPriorityFloor.apply(executionWork, plannedPartitionWork, shardPlan.pieces);
        }
        diagnostics.put("shard_priority_floor", floor);
        localClusters = localClusters.persist(StorageLevel.MEMORY_AND_DISK());
        String executionOrder = sc.getConf().get("spark.skyline.executionOrder", "work");
        diagnostics.put("execution_priorities", java.util.Arrays.toString(executionWork));
        long scheduleStart = System.nanoTime();
        // M4 already exposes physical rounds in the planner's execution order.
        // Re-running the generic cost sorter adds a driver-side scheduling pass
        // and can disturb the measured tail without improving task placement.
        int[] order = (m4PhysicalExecution || m2V3Enabled) ? null : CostOrderedMaterializer.order(
                executionWork, executionSlots, executionOrder,
                baselineReordered && shardPlan.splitPartitions > 0);
        diagnostics.put("execution_order", executionOrder);
        diagnostics.put("execution_reordered", order == null ? 0 : 1);
        diagnostics.put("execution_schedule_ms", (System.nanoTime()-scheduleStart)/1000000.0);
        if (order == null) localClusters.count();
        else {
            diagnostics.put("execution_partition_order", java.util.Arrays.toString(order));
            CostOrderedMaterializer.materialize(sc, localClusters, order);
        }
        this.s4_local_compute = System.currentTimeMillis() - startLocal;
        diagnostics.put("projected_bound_hits", projectedBounds.value());
        diagnostics.put("candidate_count", candidateCount.value());
        diagnostics.put("single_point_candidates", singlePointCandidates.value());
        diagnostics.put("pair_candidates", pairCandidates.value());
        diagnostics.put("z_window_checks", zWindowChecks.value());
        diagnostics.put("point_distance_checks", pointDistanceChecks.value());
        diagnostics.put("task_times_ms", taskTimesMs.value());
        diagnostics.put("m2_v2_bundle_task_times_ms", bundleTaskTimesMs.value());
        diagnostics.put("projected_candidates", projectedCandidates.value());
        diagnostics.put("projected_count_hits", projectedHits.value());
        diagnostics.put("index_builds", indexBuilds.value());
        diagnostics.put("index_reuses", indexReuses.value());
        diagnostics.put("index_build_task_ms", indexNanos.value() / 1000000.0);
        diagnostics.put("m4_prepared_reads", preparedReads.value());
        diagnostics.put("m2_v3_mask_checks", maskChecks.value());
        diagnostics.put("m2_v3_mask_filtered", maskFiltered.value());

        long startGlobal = System.currentTimeMillis();
        computeGlobalSkyline(localClusters);
        this.s5_global_reduce = System.currentTimeMillis() - startGlobal;
        if (preparedBundles != null) preparedBundles.unpersist();
        if (ownerBlocks != null) ownerBlocks.unpersist();

        long startMaterialize = System.currentTimeMillis();
        if (materializeFinalMembers) {
            materializeFinalCircleMembers(sc, points, dc, cellSize);
        } else {
            for (Circle circle : sortedSkymapList) {
                circle.p = null;
            }
        }
        this.s6_materialize_final_points = System.currentTimeMillis() - startMaterialize;

        if (emitPartitionJson) {
            json_partition_info(partitionedPoints);
        }

        points.unpersist();
        partitionedPoints.unpersist();
        if (sharedBlocks != null) sharedBlocks.unpersist();
        if (maskedBlocks != null) maskedBlocks.unpersist();
        if (routeBroadcast != null) routeBroadcast.destroy();
        localClusters.unpersist();
        ownerBroadcast.destroy();
        neighborOffsetsBroadcast.destroy();
    }

    /** Shared preprocessing only; the operator comparator supplies its own execution plan. */
    JavaRDD<Point> readOperatorSource(JavaSparkContext sc,String inputPath,double cellSize) {
        return readAndProcessData(sc,inputPath,cellSize);
    }

    private JavaRDD<Point> readAndProcessData(JavaSparkContext sc, String inputPath, double cellSize) {
        InputReadTaskLayout inputLayout=InputReadTaskLayout.prepare(sc,sc.textFile(inputPath,partition_number));
        diagnostics.put("input_read_coalesced",inputLayout.enabled);
        diagnostics.put("input_original_read_tasks",inputLayout.originalReadPartitions);
        diagnostics.put("input_read_tasks",inputLayout.readPartitions);
        diagnostics.put("input_dedup_partitions",inputLayout.dedupPartitions);
        JavaRDD<Tuple2<Double, Double>> rawCoords = inputLayout.lines
                .mapPartitions(iter -> {
                    List<Tuple2<Double, Double>> coords = new ArrayList<Tuple2<Double, Double>>();
                    HashSet<String> seen = new HashSet<String>();
                    while (iter.hasNext()) {
                        String line = iter.next().trim();
                        if (line.isEmpty()) {
                            continue;
                        }
                        String[] parts = line.split("\\s+");
                        double x = Double.parseDouble(parts[0]);
                        double y = Double.parseDouble(parts[1]);
                        String coordKey = x + "," + y;
                        if (!seen.contains(coordKey)) {
                            seen.add(coordKey);
                            coords.add(new Tuple2<>(x, y));
                        }
                    }
                    return coords.iterator();
                });

        JavaPairRDD<Tuple2<Double,Double>,Integer> coordinateKeys=rawCoords.mapToPair(coord -> new Tuple2<>(coord,1));
        JavaRDD<Tuple2<Double, Double>> uniqueCoords = (inputLayout.enabled
                ? coordinateKeys.reduceByKey((a,b)->a,inputLayout.dedupPartitions)
                : coordinateKeys.reduceByKey((a,b)->a)).map(Tuple2::_1);

        if (sc.getConf().getBoolean("spark.skyline.stableInputIds", false)) {
            uniqueCoords = StablePointIdentity.coordinates(uniqueCoords);
        }
        return uniqueCoords.zipWithUniqueId().map(tuple -> {
            Tuple2<Double, Double> coord = tuple._1();
            Point p = new Point(coord._1(), coord._2());
            p.id = tuple._2();
            p.setCell((int) Math.floor(p.x / cellSize), (int) Math.floor(p.y / cellSize));
            return p;
        });
    }

    private M2RoutingPlan buildM2RoutingPlan(
            List<CellCount> orderedCells,
            CellOwnerIndex ownerByCell,
            List<NeighborOffset> neighborOffsets,
            int ownerCount,
            int requestedThreads) {
        final int[][] targetsByRank = new int[orderedCells.size()][];
        int threads = Math.max(1, Math.min(requestedThreads, Math.max(1, orderedCells.size())));
        int chunkSize = Math.max(1, (orderedCells.size() + threads - 1) / threads);
        ExecutorService executor = Executors.newFixedThreadPool(threads);
        ArrayList<Future<RouteChunk>> futures = new ArrayList<Future<RouteChunk>>(threads);
        try {
            for (int start = 0; start < orderedCells.size(); start += chunkSize) {
                final int from = start;
                final int to = Math.min(orderedCells.size(), start + chunkSize);
                futures.add(executor.submit(new Callable<RouteChunk>() {
                    @Override
                    public RouteChunk call() {
                        RouteChunk chunk = new RouteChunk(ownerCount);
                        DestinationAccumulator destinations = new DestinationAccumulator(ownerCount);
                        for (int rank = from; rank < to; rank++) {
                            CellCount cell = orderedCells.get(rank);
                            int owner = ownerByCell.getOrDefault(cell.packed, -1);
                            int encodedOwner = ownerByCell.getEncodedOrDefault(cell.packed, -1);
                            if (encodedOwner < -1) {
                                chunk.assigned[owner] += cell.count;
                                chunk.interiorPoints += cell.count;
                                continue;
                            }
                            destinations.clear();
                            destinations.add(owner);
                            for (NeighborOffset offset : neighborOffsets) {
                                int target = ownerByCell.getOrDefault(
                                        pack(cell.x + offset.dx, cell.y + offset.dy), -1);
                                if (target >= 0) destinations.add(target);
                            }
                            destinations.sortInPlace();
                            int size = destinations.size();
                            for (int i = 0; i < size; i++) {
                                chunk.assigned[destinations.valueAt(i)] += cell.count;
                            }
                            if (size == 1) {
                                chunk.interiorPoints += cell.count;
                            } else {
                                chunk.boundaryPoints += cell.count;
                                chunk.boundaryCells++;
                                targetsByRank[rank] = destinations.copyValues();
                                for (int i = 0; i < size; i++) {
                                    for (int j = i + 1; j < size; j++) {
                                        chunk.overlap[destinations.valueAt(i)][destinations.valueAt(j)] += cell.count;
                                    }
                                }
                            }
                        }
                        return chunk;
                    }
                }));
            }

            long[] core = new long[ownerCount];
            long[] assigned = new long[ownerCount];
            long[][] overlap = new long[ownerCount][ownerCount];
            long interiorPoints = 0L, boundaryPoints = 0L;
            int boundaryCells = 0;
            for (Future<RouteChunk> future : futures) {
                RouteChunk chunk = future.get();
                interiorPoints += chunk.interiorPoints;
                boundaryPoints += chunk.boundaryPoints;
                boundaryCells += chunk.boundaryCells;
                for (int owner = 0; owner < ownerCount; owner++) {
                    assigned[owner] += chunk.assigned[owner];
                    for (int other = owner + 1; other < ownerCount; other++) {
                        overlap[owner][other] += chunk.overlap[owner][other];
                    }
                }
            }
            for (int rank = 0; rank < orderedCells.size(); rank++) {
                CellCount cell = orderedCells.get(rank);
                int owner = ownerByCell.getOrDefault(cell.packed, -1);
                core[owner] += cell.count;
                if (targetsByRank[rank] == null &&
                        ownerByCell.getEncodedOrDefault(cell.packed, -1) >= 0) {
                    ownerByCell.put(cell.packed, -owner - 2);
                }
            }
            return new M2RoutingPlan(core, assigned, overlap, targetsByRank,
                    interiorPoints, boundaryPoints, boundaryCells);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("M2 route planning interrupted", e);
        } catch (ExecutionException e) {
            throw new RuntimeException("M2 route planning failed", e.getCause());
        } finally {
            executor.shutdownNow();
        }
    }

    private void executeMicroPartition(JavaSparkContext sc, JavaRDD<Point> points, CellOwnerIndex ownerByCell,
            List<NeighborOffset> offsets, double radius, double cellSize, long originalCount, long startPlan, long[] coreCounts,
            long[] assignedCounts,double populationMetadataMs) {
        int[] offsetX = new int[offsets.size()], offsetY = new int[offsets.size()];
        for (int index = 0; index < offsets.size(); index++) { offsetX[index] = offsets.get(index).dx; offsetY[index] = offsets.get(index).dy; }
        String frozenStatePath=sc.getConf().get("spark.skyline.microFrozenStateLoad","");
        boolean frozenReplay=!frozenStatePath.isEmpty();
        boolean frozenExport=sc.getConf().getBoolean("spark.skyline.microFrozenStateExport",false);
        if((frozenReplay||frozenExport) && (!experiment.microPlannerPolicy.equals("sampled_peak")
                || !experiment.microPartitionMode.equals("dependency") || !experiment.microPartitionReplay.isEmpty()
                || sc.getConf().getBoolean("spark.skyline.microImplicitFamily",false)
                || sc.getConf().get("spark.skyline.inputSha256","").isEmpty()
                || !sc.getConf().getBoolean("spark.skyline.stableInputIds",false)))
            throw new IllegalArgumentException("Frozen control requires explicit sampled dependency, source identity and stable IDs");
        if(frozenReplay&&frozenExport)throw new IllegalArgumentException("Frozen export/load are exclusive");
        String selectorPolicy = sc.getConf().get("spark.skyline.microSelector", "joint_peak");
        if(sc.getConf().getInt("spark.skyline.microDiagnosticTargetAnchors",0)!=0)throw new IllegalArgumentException("Anchor-target automatic replication was retired; choose point splits under an explicit replication budget");
        if (!selectorPolicy.equals("joint_peak") && !selectorPolicy.equals("work_greedy"))
            throw new IllegalArgumentException("unknown micro selector override");
        if (selectorPolicy.equals("work_greedy") && ((!experiment.microPlannerPolicy.equals("sampled_peak") && !experiment.microPlannerPolicy.equals("peak"))
                || !experiment.microPartitionReplay.isEmpty() || sc.getConf().getBoolean("spark.skyline.microImplicitFamily",false)))
            throw new IllegalArgumentException("work greedy requires explicit native peak or sampled_peak without replay");
        diagnostics.put("micro_selection_algorithm", selectorPolicy);
        String finalSelectorPolicy=sc.getConf().get("spark.skyline.microFinalSelector",selectorPolicy);
        if (!finalSelectorPolicy.equals("joint_peak") && !finalSelectorPolicy.equals("work_greedy"))
            throw new IllegalArgumentException("unknown final micro selector override");
        if (!finalSelectorPolicy.equals(selectorPolicy) && (!experiment.microPlannerPolicy.equals("sampled_peak") || !experiment.microPartitionReplay.isEmpty()))
            throw new IllegalArgumentException("final-only override requires native sampled_peak");
        diagnostics.put("micro_final_selection_algorithm",finalSelectorPolicy);
        boolean nativeSampledRefreshDefault=experiment.microPlannerPolicy.equals("sampled_peak")
                    && experiment.microCostSignal.equals("sampled") && experiment.microPartitionReplay.isEmpty()
                    && !experiment.microPopulationInProbe && experiment.microFixedProbeSlots==0
                    && !sc.getConf().getBoolean("spark.skyline.microImplicitFamily",false);
            boolean refreshCandidates=!frozenReplay && sc.getConf().getBoolean("spark.skyline.microRefreshCandidates",nativeSampledRefreshDefault);
        int probeOwnerLimit=sc.getConf().getInt("spark.skyline.microProbeOwnerLimit",32);
        if(probeOwnerLimit<1 || probeOwnerLimit>256) throw new IllegalArgumentException("probe owner limit must be 1..256");
        if(refreshCandidates && (!experiment.microPlannerPolicy.equals("sampled_peak")
                || !experiment.microCostSignal.equals("sampled") || !experiment.microPartitionReplay.isEmpty()
                || experiment.microPopulationInProbe || experiment.microFixedProbeSlots>0
                || sc.getConf().getBoolean("spark.skyline.microImplicitFamily",false)))
            throw new IllegalArgumentException("candidate refresh requires native explicit Sampled without replay or fused probe population");
        diagnostics.put("micro_candidate_refresh_requested",refreshCandidates);
        diagnostics.put("micro_probe_owner_limit",probeOwnerLimit);
        boolean laneRefinementRequested=!frozenReplay && sc.getConf().getBoolean("spark.skyline.microLaneProbeRefinement",
                nativeSampledRefreshDefault&&refreshCandidates&&!experiment.microPartitionMode.equals("none")
                &&sc.getConf().getBoolean("spark.skyline.microSpatialCostCalibration",experiment.geometricBounds&&!experiment.microProbeTrace));
        if(laneRefinementRequested&&(!nativeSampledRefreshDefault||!refreshCandidates||experiment.microPartitionMode.equals("none")))
            throw new IllegalArgumentException("lane refinement requires native sampled candidate refresh without fixed probe or replay");
        diagnostics.put("micro_lane_probe_refinement_requested",laneRefinementRequested);
        diagnostics.put("micro_lane_probe_refinement",false);
        diagnostics.put("micro_lane_probe_added_anchors",0);
        diagnostics.put("micro_lane_probe_status",laneRefinementRequested?"requested_not_reached":"disabled");
        if (sc.getConf().getBoolean("spark.skyline.microImplicitFamily",false)) {
            executeImplicitMicroPartition(sc,points,ownerByCell,offsetX,offsetY,radius,cellSize,originalCount,startPlan,coreCounts);
            return;
        }
        Broadcast<CellOwnerIndex> owners = sc.broadcast(ownerByCell);
        JavaRDD<HashMap<Double,Circle>> local = null;
        Map<Integer,long[]> completedAnchors = new HashMap<>();
        List<HashMap<Double,Circle>> probeSkylines = new ArrayList<>();
        long[] probeCounters = new long[10];
        ProbeDominanceFrontier calibratedFrontier = null;
        List<String> probeSnapshotRows=new ArrayList<>();probeSnapshotRows.add("owner\tkind\thost\tpath");
        try {
            int slots = Integer.parseInt(sc.getConf().get("spark.cores.max", "1"));
            double budgetFraction = sc.getConf().getDouble("spark.skyline.shardReadBudget",0.01);
            boolean sampledPlanner = !frozenReplay && !experiment.microPlannerPolicy.equals("peak");
            int probeEligibilitySlots = FixedProbeControl.eligibilitySlots(experiment.microFixedProbeSlots,
                    slots, !experiment.microPartitionReplay.isEmpty());
            boolean sampledCompletion = sampledPlanner
                    && SampledAnchorCostProbe.skewEligible(microOwnerCost,probeEligibilitySlots);
            if (experiment.microFixedProbeSlots > 0)
                diagnostics.put("micro_probe_eligibility_slots", probeEligibilitySlots);
            // Probe eligibility controls calibration, not the existence of physical alternatives.
            // Completion can improve execution waves even when peak <= total / slots.
            // Sampled unsplit control needs the same candidate anchors for its real probes.
            // Only final selection uses "none"; preparation costs remain online and visible.
            String populationMode = sampledPlanner && experiment.microPartitionMode.equals("none")
                    ? "dependency" : experiment.microPartitionMode;
            boolean populationInProbe = experiment.microPopulationInProbe && sampledCompletion && assignedCounts == null;
            ProbePopulationPreparation populationPreparation = populationInProbe
                    ? ProbePopulationPreparation.prepare(sc,points,owners,offsetX,offsetY,microOwnerCost,microCellWork,radius,coreCounts)
                    : null;
            diagnostics.put("micro_population_in_probe_requested",experiment.microPopulationInProbe);
            diagnostics.put("micro_population_in_probe",populationInProbe);
            boolean refreshActive=refreshCandidates && sampledCompletion;
            String initialPopulationMode=refreshActive ? "none" : populationMode;
            diagnostics.put("micro_candidate_refresh_active",refreshActive);
            String frozenContext=diagnostics.get("owner_layout_sha256")+":"+sc.getConf().get("spark.skyline.inputSha256","")
                    +":"+Double.toHexString(radius)+":"+Double.toHexString(queryX)+":"+Double.toHexString(queryY)
                    +":"+density_k+":"+originalCount+":"+Double.toHexString(cellSize)+":stableInputIds=true";
            FrozenPlannerState frozen=null;
            try{
                if(frozenReplay){
                    String actualFrozenHash=FrozenPlannerState.sha256(Paths.get(frozenStatePath));
                    if(!actualFrozenHash.equals(sc.getConf().get("spark.skyline.microFrozenStateSha256","")))throw new IOException("Frozen artifact hash mismatch");
                    diagnostics.put("micro_frozen_state_sha256",actualFrozenHash);
                    frozen=FrozenPlannerState.read(Paths.get(frozenStatePath),frozenContext);
                }
            }catch(IOException e){throw new IllegalStateException("Cannot load frozen calibration",e);}
            if(frozen!=null){
                if(!Arrays.equals(coreCounts,frozen.population.core))throw new IllegalArgumentException("Frozen owner cores changed");
                completedAnchors.putAll(frozen.replayCompletedAnchors(experiment.microCompletionReuse));probeSkylines.addAll(frozen.probeSkylines);
                System.arraycopy(frozen.probeCounters,0,probeCounters,0,probeCounters.length);calibratedFrontier=frozen.replayProbeFrontier(experiment.microProbeFrontier);
            }
            MicroPartitionPopulation.Statistics population = frozen!=null ? frozen.population : populationInProbe ? null : assignedCounts == null
                    ? MicroPartitionPopulation.observe(sc,points,owners,offsetX,offsetY,microOwnerCost,microCellWork,radius,initialPopulationMode,coreCounts,experiment.microPopulationDirect)
                    : MicroPartitionPopulation.observe(sc,points,owners,offsetX,offsetY,microOwnerCost,microCellWork,radius,initialPopulationMode,coreCounts,assignedCounts,populationMetadataMs);
            String replayContext = diagnostics.get("owner_layout_sha256") + ":" + sc.getConf().get("spark.skyline.inputSha256","unrecorded")
                    + ":" + Double.toHexString(radius) + ":stableInputIds=" + sc.getConf().get("spark.skyline.stableInputIds","false");
            long planStart = System.nanoTime();
            MicroPartitionPlanner.Plan plan;
            try {
                if (sampledPlanner) {
                    double[] plannerWork = microOwnerCost;
                    double workSeconds = CalibratedShardPlanner.COUNT;
                    double probeSeconds = 0;
                    if (sampledCompletion) {
                        SampledAnchorCostProbe.Result sampled = refreshActive
                                ? SampledAnchorCostProbe.runForOwners(sc,points,owners,offsetX,offsetY,
                                    MicroPartitionPopulation.selectProbeOwners(microOwnerCost,population.core,probeOwnerLimit),
                                    population.core,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                                    experiment.microProbeEngineOptions(),24,experiment.microRefinedCounting,
                                    experiment.microProbeTrace,experiment.microProbeSelectedRouting)
                                : populationPreparation == null
                                ? SampledAnchorCostProbe.run(sc,points,owners,offsetX,offsetY,
                                    population,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                                    experiment.microProbeEngineOptions(),24,experiment.microRefinedCounting,experiment.microProbeTrace,experiment.microProbeSelectedRouting)
                                : SampledAnchorCostProbe.runWithPopulation(sc,points,owners,offsetX,offsetY,
                                    populationPreparation,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                                    experiment.microProbeEngineOptions(),24,experiment.microRefinedCounting,experiment.microProbeTrace,experiment.microProbeSelectedRouting);
                        int coverageLimit=sc.getConf().getInt("spark.skyline.microProbeCoverageAnchors",0);
                        if(coverageLimit<0||coverageLimit>24)throw new IllegalArgumentException("coverage probe count must be 0..24");
                        if(coverageLimit>0&&refreshActive){
                            if(experiment.microProbeTrace)throw new IllegalArgumentException("owner coverage requires ordinary exact probe kernel");
                            int[] uncovered=ProbeCoverageCalibration.uncovered(population.core,sampled.probes);
                            if(uncovered.length>0){
                                List<Circle> witnesses=new ArrayList<>();
                                if(experiment.microProbeFrontier)
                                    for(SampledAnchorCostProbe.Probe p:sampled.probes)witnesses.addAll(p.skyline.values());
                                ProbeDominanceFrontier coverageFrontier=ProbeDominanceFrontier.fromCircles(witnesses);
                                SampledAnchorCostProbe.Result extra=SampledAnchorCostProbe.runForOwners(sc,points,owners,offsetX,offsetY,
                                        uncovered,population.core,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                                        experiment.microProbeEngineOptions(),coverageLimit,experiment.microRefinedCounting,
                                        experiment.microProbeTrace,experiment.microProbeSelectedRouting,coverageFrontier);
                                diagnostics.put("micro_probe_coverage_witness_count",witnesses.size());
                                boolean timing=sampled.probes[0].observations.length>0;
                                sampled=ProbeCoverageCalibration.merge(microOwnerCost,population.core,sampled,extra,timing);
                            }
                            diagnostics.put("micro_probe_coverage_owner_count",uncovered.length);
                            diagnostics.put("micro_probe_coverage_anchors_per_owner",coverageLimit);
                        }
                        diagnostics.put("micro_probe_total_owner_count",sampled.probes.length);
                        diagnostics.put("micro_probe_actual_samples_per_owner",java.util.Arrays.stream(sampled.probes).map(p -> p.owner+":"+p.samples).collect(java.util.stream.Collectors.joining(",")));
                        if (populationPreparation != null) {
                            if (sampled.population == null) throw new IllegalStateException("probe populations not completed");
                            population = sampled.population;
                            long populationTaskNanos = 0;
                            for (SampledAnchorCostProbe.Probe probe : sampled.probes)
                                populationTaskNanos = Math.addExact(populationTaskNanos,probe.populationCounts.populationNanos);
                            diagnostics.put("micro_probe_population_task_wall_sum_s",populationTaskNanos/1e9);
                            diagnostics.put("micro_population_time_scope","preparation-only; exact lane counting and completion included in enclosing probe wall");
                        }

                        if (experiment.microFixedProbeSlots > 0) {
                            int[] actualOwners = new int[sampled.probes.length];
                            long[][] actualIds = new long[sampled.probes.length][];
                            for (int i=0;i<sampled.probes.length;i++) {
                                actualOwners[i]=sampled.probes[i].owner;
                                actualIds[i]=sampled.probes[i].anchorIds;
                            }
                            Files.write(Paths.get(experiment.outputPrefix+".micro_fixed_probe_ids.tsv"),
                                    FixedProbeControl.identityRows(actualOwners,actualIds),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                            diagnostics.put("micro_fixed_probe_ids_sha256",FixedProbeControl.identityHash(actualOwners,actualIds));
                        }
                        for (SampledAnchorCostProbe.Probe probe : sampled.probes) {
                            if(!probe.inputSnapshotPath.isEmpty())probeSnapshotRows.add(probe.owner+"\tdiscovery\t"+probe.inputSnapshotHost+"\t"+probe.inputSnapshotPath);
                            if (experiment.microCompletionReuse) completedAnchors.put(probe.owner,probe.anchorIds);
                            probeSkylines.add(probe.skyline);
                            for (int index = 0; index < probeCounters.length; index++) probeCounters[index] += probe.counters[index];
                        }
                        // Discovery results remain the only completion/output contribution of these IDs.
                        // Replay measures cost under one frozen frontier, also used by fresh probes and execution.
                        boolean alignFrontier=sc.getConf().getBoolean("spark.skyline.microCalibratePooledFrontier",
                                refreshActive&&experiment.microProbeFrontier&&experiment.microCostSignal.equals("sampled")
                                &&!experiment.microProbeTrace&&!experiment.microProbeAnchorBounds
                                &&sampled.probes.length>0&&sampled.probes[0].observations.length>0);
                        if(alignFrontier){
                            if(!experiment.microProbeFrontier||experiment.microProbeTrace||experiment.microProbeAnchorBounds
                                    ||sampled.probes.length==0||sampled.probes[0].observations.length==0)
                                throw new IllegalArgumentException("pooled calibration requires profiled exact probes and no pre-pruned anchor responsibility");
                            calibratedFrontier=ProbeDominanceFrontier.fromCircles(probeSkylines.stream()
                                    .flatMap(front -> front.values().stream()).collect(java.util.stream.Collectors.toList()));
                            SampledAnchorCostProbe.Result measured=SampledAnchorCostProbe.recalibrate(sc,points,owners,offsetX,offsetY,
                                    sampled.probes,population.core,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                                    experiment.microEngineOptions(),experiment.microRefinedCounting,experiment.microProbeSelectedRouting,calibratedFrontier);
                            Map<Integer,SampledAnchorCostProbe.Probe> before=new HashMap<>();
                            for(SampledAnchorCostProbe.Probe p:sampled.probes)before.put(p.owner,p);
                            List<String> rows=new ArrayList<>();
                            rows.add("owner,samples,discovery_kernel_ns,pooled_kernel_ns,discovery_owner_work,pooled_owner_work,discovery_point_checks,pooled_point_checks");
                            for(SampledAnchorCostProbe.Probe p:measured.probes){
                                if(!p.inputSnapshotPath.isEmpty())probeSnapshotRows.add(p.owner+"\tcalibration\t"+p.inputSnapshotHost+"\t"+p.inputSnapshotPath);
                                SampledAnchorCostProbe.Probe old=before.get(p.owner);
                                if(old==null||!Arrays.equals(old.anchorIds,p.anchorIds))throw new IllegalStateException("calibration replay changed identities");
                                for(int i=0;i<probeCounters.length;i++)probeCounters[i]=Math.addExact(probeCounters[i],p.counters[i]);
                                rows.add(p.owner+","+p.samples+","+old.kernelNanos+","+p.kernelNanos+","+sampled.calibration.work[p.owner]+","+measured.calibration.work[p.owner]+","+old.distanceChecks+","+p.distanceChecks);
                            }
                            if(!experiment.outputPrefix.isEmpty())Files.write(Paths.get(experiment.outputPrefix+".micro_frontier_calibration.csv"),rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                            diagnostics.put("micro_frontier_calibration_s",measured.wallSeconds);
                            diagnostics.put("micro_frontier_calibration_replayed_anchors",Arrays.stream(measured.probes).mapToInt(p -> p.samples).sum());
                            diagnostics.put("micro_frontier_calibration_index_builds",measured.probes.length);
                            diagnostics.put("micro_frontier_calibration_witness_distances",calibratedFrontier.witnessDistances());
                            diagnostics.put("micro_frontier_calibration_scope","same anchor IDs and complete owner input; frozen pooled frontier shared with refinement and formal execution; replay is cost measurement only");
                            sampled=new SampledAnchorCostProbe.Result(measured.calibration,measured.probes,
                                    sampled.wallSeconds+measured.wallSeconds,sampled.population);
                        }
                        diagnostics.put("micro_frontier_calibration",alignFrontier);
                        diagnostics.put("micro_probe_trace",experiment.microProbeTrace);
                        diagnostics.put("micro_probe_selected_routing",experiment.microProbeSelectedRouting);
                        if(experiment.microProbeTrace){
                            long postStart=System.nanoTime(),retainedBytes=0; int checkpoints=0;
                            List<Circle> certificates=new ArrayList<>();
                            for(SampledAnchorCostProbe.Probe probe:sampled.probes)certificates.addAll(probe.skyline.values());
                            ProbeDominanceFrontier traceFrontier=ProbeDominanceFrontier.fromCircles(certificates);
                            List<String> traceRows=new ArrayList<>();
                            traceRows.add("owner,samples,complete,accounted_retained_bytes,checkpoints,generation_checks,anchor_checks,projected_checks,other_checks");
                            List<Integer> traceFallbacks=new ArrayList<>();
                            for(SampledAnchorCostProbe.Probe probe:sampled.probes){
                                long[] parts=probe.trace.estimate(traceFrontier,density_k);
                                if(parts==null)traceFallbacks.add(probe.owner);
                                retainedBytes+=probe.trace.retainedBytes();checkpoints+=probe.trace.checkpointCount();
                                traceRows.add(probe.owner+","+probe.samples+","+(parts!=null)+","+probe.trace.retainedBytes()+","+probe.trace.checkpointCount()+","+probe.generationChecks+","+(parts==null?"NA,NA,NA":parts[0]+","+parts[1]+","+parts[2]));
                            }
                            if(!experiment.outputPrefix.isEmpty())Files.write(Paths.get(experiment.outputPrefix+".micro_probe_trace.csv"),traceRows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                            diagnostics.put("micro_probe_trace_retained_bytes",retainedBytes);
                            diagnostics.put("micro_probe_trace_checkpoints",checkpoints);
                            diagnostics.put("micro_probe_trace_fallback_owners",traceFallbacks.toString());
                            diagnostics.put("micro_probe_trace_postprocessing_s",(System.nanoTime()-postStart)/1e9);
                            diagnostics.put("micro_probe_trace_scope","observation only; selector unchanged; accounted storage not heap");
                        }
                        diagnostics.put("probe_index_builds",sampled.probes.length+(alignFrontier?sampled.probes.length:0));
                        diagnostics.put("micro_probe_refined_counting",experiment.microRefinedCounting);
                        diagnostics.put("micro_calibration_informative_probes",sampled.calibration.informativeProbes);
                        diagnostics.put("micro_calibration_proxy_fallback_owners",java.util.Arrays.toString(sampled.calibration.proxyFallbackOwners));
                        diagnostics.put("micro_completion_probe_counting_cell_sizes",java.util.Arrays.toString(java.util.Arrays.stream(sampled.probes)
                                .mapToDouble(probe -> probe.countCellSize).toArray()));
                        diagnostics.put("micro_completion_model_scope","full-owner estimate; does not subtract completed probe anchors");
                        diagnostics.put("micro_completion_reused_anchors",completedAnchors.values().stream().mapToInt(ids -> ids.length).sum());
                        diagnostics.put("micro_completion_reused_circles",probeSkylines.stream().mapToInt(Map::size).sum());
                        plannerWork = sampled.calibration.work;
                        workSeconds = sampled.calibration.secondsPerWork;
                        probeSeconds = sampled.wallSeconds;
                        if(refreshActive) {
                            population=sc.getConf().getBoolean("spark.skyline.microAdaptiveAcquisition",nativeSampledRefreshDefault)
                                    ? AdaptiveAnchorAcquisition.refresh(sc,points,owners,offsetX,offsetY,microOwnerCost,plannerWork,microCellWork,radius,populationMode,population)
                                    : MicroPartitionPopulation.refreshCandidates(sc,points,owners,offsetX,offsetY,microOwnerCost,plannerWork,microCellWork,radius,populationMode,population);
                            diagnostics.put("micro_refreshed_candidate_owners",java.util.Arrays.stream(population.candidates)
                                    .mapToInt(candidate -> candidate.owner).distinct().sorted().mapToObj(Integer::toString)
                                    .collect(java.util.stream.Collectors.joining(",")));
                        } else if (experiment.microCostSignal.equals("sampled"))
                            population = SampledAnchorCostProbe.reweight(population,microOwnerCost,plannerWork);
                        boolean spatialCosts=sampled.probes.length>0&&sampled.probes[0].observations.length>0;
                        MicroPartitionPopulation.Statistics laneProbeBase=population;
                        if(spatialCosts&&experiment.microCostSignal.equals("sampled"))
                            population=SpatialProbeCostModel.reweight(population,sampled.probes,microCellWork);
                        if(laneRefinementRequested){
                            if(!spatialCosts)throw new IllegalArgumentException("lane refinement requires profiled spatial timing");
                            boolean pairedParentReplay=sc.getConf().getBoolean("spark.skyline.microLaneParentReplay",true);
                            diagnostics.put("micro_lane_parent_replay_enabled",pairedParentReplay);
                            int anchorBudget=sc.getConf().getInt("spark.skyline.microLaneProbeMaxAnchors",256);
                            int ownerBudget=sc.getConf().getInt("spark.skyline.microLaneProbeMaxOwners",4);
                            int stratumMinimum=sc.getConf().getInt("spark.skyline.microLaneProbeMinimum",4);
                            int stratumMaximum=sc.getConf().getInt("spark.skyline.microLaneProbeMaximum",8);
                            if(anchorBudget<0||anchorBudget>4096||ownerBudget<1||ownerBudget>256)
                                throw new IllegalArgumentException("invalid lane refinement guard");
                            diagnostics.put("micro_lane_probe_max_anchors",anchorBudget);
                            diagnostics.put("micro_lane_probe_max_owners",ownerBudget);
                            diagnostics.put("micro_lane_probe_minimum",stratumMinimum);
                            diagnostics.put("micro_lane_probe_maximum",stratumMaximum);
                            Set<Integer> refinedOwners=new HashSet<>();int addedAnchors=0,rounds=0,refinementIndexBuilds=0;double refinementSeconds=0,parentReplaySeconds=0;int parentReplaySamples=0;
                            List<String> targetHistory=new ArrayList<>(),roundRows=new ArrayList<>(),workRows=new ArrayList<>(),parentRows=new ArrayList<>();
                            parentRows.add("round,owner,samples,parent_kernel_ns,parent_prepare_ns,old_parent_work,new_parent_work,private_peak_work,parent_replay_s");
                            roundRows.add("round,owner,pieces,added_anchors,remaining_anchors,remaining_owners,peak_before,peak_after,extra_records_after,probe_s");
                            workRows.add("owner,stratum,strata,anchor_id,x,y,population_weight,kernel_ns,index_build_ns,point_checks,candidates,bucket_classifications,round");
                            Map<Integer,Integer> sampleCounts=new HashMap<>();for(SampledAnchorCostProbe.Probe p:sampled.probes)sampleCounts.put(p.owner,p.samples);
                            while(addedAnchors<anchorBudget&&refinedOwners.size()<ownerBudget){
                                MicroPartitionPlanner.Plan provisional=selectorPolicy.equals("work_greedy")
                                        ? MicroPartitionPlanner.selectGreedy(plannerWork,population,budgetFraction,slots,experiment.microPartitionMode)
                                        : MicroPartitionPlanner.select(plannerWork,population,budgetFraction,slots,experiment.microPartitionMode);
                                SampledAnchorCostProbe.Probe[] eligibleProbes=Arrays.stream(sampled.probes)
                                        .filter(p -> !refinedOwners.contains(p.owner)).toArray(SampledAnchorCostProbe.Probe[]::new);
                                LaneProbeRefinement.Target[] targets=LaneProbeRefinement.targets(population,provisional,eligibleProbes,
                                        anchorBudget-addedAnchors,ownerBudget-refinedOwners.size(),stratumMinimum,stratumMaximum);
                                if(targets.length==0)break;
                                ProbeDominanceFrontier frontier=calibratedFrontier!=null?calibratedFrontier:experiment.microProbeFrontier
                                        ? ProbeDominanceFrontier.fromCircles(probeSkylines.stream().flatMap(front -> front.values().stream()).collect(java.util.stream.Collectors.toList()))
                                        : ProbeDominanceFrontier.EMPTY;
                                SampledAnchorCostProbe.Result extra=SampledAnchorCostProbe.runLaneTargets(sc,points,owners,offsetX,offsetY,
                                        targets,population.core,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                                        calibratedFrontier!=null?experiment.microEngineOptions():experiment.microProbeEngineOptions(),
                                        experiment.microRefinedCounting,experiment.microProbeSelectedRouting,frontier);
                                SampledAnchorCostProbe.Result parents=pairedParentReplay?SampledAnchorCostProbe.recalibrate(sc,points,owners,offsetX,offsetY,
                                        extra.probes,population.core,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                                        calibratedFrontier!=null?experiment.microEngineOptions():experiment.microProbeEngineOptions(),
                                        experiment.microRefinedCounting,experiment.microProbeSelectedRouting,frontier)
                                        :new SampledAnchorCostProbe.Result(null,new SampledAnchorCostProbe.Probe[0],0);
                                LaneProbeRefinement.Update update=LaneProbeRefinement.updateWithParentReplay(pairedParentReplay,laneProbeBase,population,plannerWork,targets,extra.probes,parents.probes);
                                for(SampledAnchorCostProbe.Probe parent:parents.probes){
                                    double privatePeak=0;for(MicroPartitionLayout.Candidate c:update.population.candidates)
                                        for(LaneProbeRefinement.Target t:targets)if(c.signature().equals(t.guide.signature()))
                                            for(int l=0;l<c.pieces;l++)privatePeak=Math.max(privatePeak,c.work(l));
                                    parentRows.add((rounds+1)+","+parent.owner+","+parent.samples+","+parent.kernelNanos+","+parent.prepareNanos+","+plannerWork[parent.owner]+","+update.ownerWork[parent.owner]+","+privatePeak+","+parents.wallSeconds);
                                    parentReplaySamples=Math.addExact(parentReplaySamples,parent.samples);
                                    refinementIndexBuilds=Math.addExact(refinementIndexBuilds,parent.indexBuilds);
                                    for(int i=0;i<probeCounters.length;i++)probeCounters[i]=Math.addExact(probeCounters[i],parent.counters[i]);
                                    if(!parent.inputSnapshotPath.isEmpty())probeSnapshotRows.add(parent.owner+"\tparent-replay-"+(rounds+1)+"\t"+parent.inputSnapshotHost+"\t"+parent.inputSnapshotPath);
                                }
                                population=update.population;plannerWork=update.ownerWork;probeSeconds+=extra.wallSeconds+parents.wallSeconds;
                                rounds++;refinementSeconds+=extra.wallSeconds+parents.wallSeconds;parentReplaySeconds+=parents.wallSeconds;
                                Map<Integer,LaneProbeRefinement.Target> byOwner=new HashMap<>();for(LaneProbeRefinement.Target t:targets)byOwner.put(t.guide.owner,t);
                                for(SampledAnchorCostProbe.Probe p:extra.probes){
                                    if(!p.inputSnapshotPath.isEmpty())probeSnapshotRows.add(p.owner+"\trefinement-"+rounds+"\t"+p.inputSnapshotHost+"\t"+p.inputSnapshotPath);
                                    if(!refinedOwners.add(p.owner))throw new IllegalStateException("owner refined twice");
                                    addedAnchors=Math.addExact(addedAnchors,p.samples);refinementIndexBuilds=Math.addExact(refinementIndexBuilds,p.indexBuilds);
                                    if(experiment.microCompletionReuse)completedAnchors.put(p.owner,LaneProbeRefinement.unionCompleted(completedAnchors.get(p.owner),p.anchorIds));
                                    probeSkylines.add(p.skyline);sampleCounts.merge(p.owner,p.samples,Integer::sum);
                                    for(int i=0;i<probeCounters.length;i++)probeCounters[i]=Math.addExact(probeCounters[i],p.counters[i]);
                                    LaneProbeRefinement.Target t=byOwner.get(p.owner);int[] counts=LaneProbeRefinement.counts(t.guide,p.observations);
                                    targetHistory.add(t.guide.owner+":"+t.guide.pieces+":"+p.samples);
                                    for(AnchorCostObservation obs:p.observations){int l=t.guide.laneOf(obs.anchor);workRows.add(p.owner+","+l+","+t.guide.pieces+","+obs.anchor.id+","+obs.anchor.x+","+obs.anchor.y+","+((double)t.guide.anchorCount(l)/counts[l])+","+obs.kernelNanos+","+obs.indexBuildNanos+","+obs.pointChecks+","+obs.candidates+","+obs.buckets+","+rounds);}
                                }
                                if(addedAnchors>anchorBudget||refinedOwners.size()>ownerBudget)throw new IllegalStateException("global refinement budget exceeded");
                                MicroPartitionPlanner.Plan after=selectorPolicy.equals("work_greedy")
                                        ? MicroPartitionPlanner.selectGreedy(plannerWork,population,budgetFraction,slots,experiment.microPartitionMode)
                                        : MicroPartitionPlanner.select(plannerWork,population,budgetFraction,slots,experiment.microPartitionMode);
                                for(LaneProbeRefinement.Target t:targets)roundRows.add(rounds+","+t.guide.owner+","+t.guide.pieces+","+t.sampleCount()+","+(anchorBudget-addedAnchors)+","+(ownerBudget-refinedOwners.size())+","+provisional.peak+","+after.peak+","+after.extraRecords+","+(extra.wallSeconds+parents.wallSeconds));
                            }
                            diagnostics.put("micro_lane_probe_refinement",rounds>0);
                            diagnostics.put("micro_lane_probe_status",rounds>0?"completed":"no_eligible_target_within_observation_budget");
                            diagnostics.put("micro_lane_probe_round_count",rounds);
                            diagnostics.put("micro_lane_probe_targets",String.join(",",targetHistory));
                            diagnostics.put("micro_lane_probe_owner_count",refinedOwners.size());
                            diagnostics.put("micro_lane_probe_added_anchors",addedAnchors);
                            diagnostics.put("micro_lane_probe_s",refinementSeconds);
                            diagnostics.put("micro_lane_parent_replay_s",parentReplaySeconds);
                            diagnostics.put("micro_lane_parent_replayed_samples",parentReplaySamples);
                            diagnostics.put("micro_lane_probe_work_scope","paired identical fresh IDs; private lanes and independent full-owner state; frozen external frontier; exact measured guide work; replay CPU counted, completion retained once");
                            diagnostics.put("micro_lane_probe_frontier_enabled",experiment.microProbeFrontier);
                            diagnostics.put("probe_index_builds",sampled.probes.length*(alignFrontier?2:1)+refinementIndexBuilds);
                            diagnostics.put("micro_completion_reused_anchors",completedAnchors.values().stream().mapToInt(ids -> ids.length).sum());
                            diagnostics.put("micro_completion_reused_circles",probeSkylines.stream().mapToInt(Map::size).sum());
                            diagnostics.put("micro_probe_actual_samples_per_owner",sampleCounts.entrySet().stream().sorted(Map.Entry.comparingByKey())
                                    .map(e -> e.getKey()+":"+e.getValue()).collect(java.util.stream.Collectors.joining(",")));
                            if(!experiment.outputPrefix.isEmpty()&&rounds>0){
                                Files.write(Paths.get(experiment.outputPrefix+".micro_lane_probe_work.csv"),workRows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                                Files.write(Paths.get(experiment.outputPrefix+".micro_lane_parent_replay.csv"),parentRows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                                Files.write(Paths.get(experiment.outputPrefix+".micro_lane_probe_rounds.csv"),roundRows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                            }
                        }
                        diagnostics.put("micro_spatial_cost_calibration",spatialCosts&&experiment.microCostSignal.equals("sampled"));
                        diagnostics.put("micro_cost_work_units",experiment.microCostSignal.equals("unit")?"anchor_count":experiment.microCostSignal.equals("static")?"cell_proxy_work":spatialCosts?"predicted_kernel_nanoseconds":"point_check_equivalent");
                        diagnostics.put("micro_spatial_cost_min_region_samples",4);
                        diagnostics.put("micro_spatial_cost_prior_samples",4);
                        if(spatialCosts&&!experiment.outputPrefix.isEmpty()){
                            List<String> rows=new ArrayList<>();rows.add("owner,anchor_id,x,y,cell_x,cell_y,kernel_ns,index_build_ns,point_checks,candidates,bucket_classifications");
                            for(SampledAnchorCostProbe.Probe p:sampled.probes)for(AnchorCostObservation a:p.observations)
                                rows.add(p.owner+","+a.anchor.id+","+a.anchor.x+","+a.anchor.y+","+a.anchor.cellX+","+a.anchor.cellY+","+a.kernelNanos+","+a.indexBuildNanos+","+a.pointChecks+","+a.candidates+","+a.buckets);
                            Files.write(Paths.get(experiment.outputPrefix+".micro_anchor_probe_work.csv"),rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                        }
                        diagnostics.put("micro_completion_probe_owners",java.util.Arrays.stream(sampled.probes)
                                .map(probe -> Integer.toString(probe.owner)).collect(java.util.stream.Collectors.joining(",")));
                        diagnostics.put("micro_completion_probe_checks",java.util.Arrays.stream(sampled.probes)
                                .map(probe -> Long.toString(probe.distanceChecks)).collect(java.util.stream.Collectors.joining(",")));
                        diagnostics.put("micro_completion_probe_status","sampled");
                        diagnostics.put("micro_completion_probe_anchor_limit",24);
                    } else {
                        diagnostics.put("micro_completion_probe_status","skipped_aggregate_dominated");
                        if (experiment.microFixedProbeSlots > 0) {
                            Files.write(Paths.get(experiment.outputPrefix+".micro_fixed_probe_ids.tsv"),
                                    FixedProbeControl.identityRows(new int[0],new long[0][]),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                            diagnostics.put("micro_fixed_probe_ids_sha256",FixedProbeControl.identityHash(new int[0],new long[0][]));
                        }
                    }
                    if (experiment.microCostSignal.equals("static")) plannerWork = microOwnerCost;
                    else if (experiment.microCostSignal.equals("unit")) {
                        plannerWork = Arrays.stream(population.core).mapToDouble(value -> value).toArray();
                        population = UnitCostSignal.apply(population,microOwnerCost);
                    }
                    diagnostics.put("micro_cost_signal",experiment.microCostSignal);
                    diagnostics.put("micro_cost_information_policy","same actual probes; signal affects plan and order");
                    double planningSeconds = Math.max(0,population.populationMs-population.originalPopulationMs)/1000 + probeSeconds;
                    CompletionMicroPlanner.Costs costs = new CompletionMicroPlanner.Costs(workSeconds,CalibratedShardPlanner.READ,
                            (sc.getConf().getDouble("spark.skyline.m4.extraTaskMs",1)+sc.getConf().getDouble("spark.skyline.m4.extraMapMs",100))/1000,
                            planningSeconds);
                    if (!experiment.microPartitionReplay.isEmpty()) {
                        plan = MicroPartitionPlanner.replay(Paths.get(experiment.microPartitionReplay),replayContext,
                                population,plannerWork,budgetFraction,slots,experiment.microPartitionMode,
                                sc.getConf().get("spark.skyline.microReplaySha256",""));
                        diagnostics.put("micro_completion_evaluated",0);
                        diagnostics.put("micro_completion_search_s",0);
                        diagnostics.put("micro_completion_reason","fixed_responsibility_replay_after_probe");
                    } else if (experiment.microPlannerPolicy.equals("sampled_peak")) {
                        long selectionStart = System.nanoTime();
                        plan = MicroPartitionPlanner.selectFinal(finalSelectorPolicy,plannerWork,population,budgetFraction,slots,experiment.microPartitionMode);
                        diagnostics.put("micro_sampled_peak_selection_s",(System.nanoTime()-selectionStart)/1e9);
                        diagnostics.put("micro_completion_evaluated",0);
                        diagnostics.put("micro_completion_search_s",0);
                        diagnostics.put("micro_completion_reason","sampled_peak_without_completion_gate");
                    } else {
                        CompletionMicroPlanner.Decision decision = CompletionMicroPlanner.select(plannerWork,population,budgetFraction,slots,experiment.microPartitionMode,costs);
                        plan = decision.plan;
                        diagnostics.put("micro_completion_baseline_s",decision.baselineSeconds);
                        diagnostics.put("micro_completion_candidate_s",decision.candidateSeconds);
                        diagnostics.put("micro_completion_selected_s",decision.executionSeconds);
                        diagnostics.put("micro_completion_search_s",decision.searchSeconds);
                        diagnostics.put("micro_completion_evaluated",decision.evaluatedPlans);
                        diagnostics.put("micro_completion_reason",decision.reason);
                    }
                    diagnostics.put("micro_completion_planning_s",planningSeconds);
                    diagnostics.put("micro_completion_probe_s",probeSeconds);
                    diagnostics.put("micro_completion_work_seconds",workSeconds);
                    diagnostics.put("micro_completion_model_provenance",sampledCompletion
                            ? "online deterministic anchor sample; exact Engine counters; historical READ; excludes full shuffle"
                            : "skew gate skipped probe; historical COUNT_READ; excludes full shuffle");
                    if (!experiment.outputPrefix.isEmpty() && experiment.microPlannerPolicy.equals("completion")) CompletionMicroPlanner.writeCandidates(
                            Paths.get(experiment.outputPrefix+".micro_completion_candidates.csv"),population,plannerWork,experiment.microPartitionMode);
                } else {
                    plan = frozen!=null ? MicroPartitionPlanner.selectFinal(finalSelectorPolicy,frozen.work,population,budgetFraction,slots,experiment.microPartitionMode)
                            : experiment.microPartitionReplay.isEmpty()
                            ? (selectorPolicy.equals("work_greedy")
                                ? MicroPartitionPlanner.selectGreedy(microOwnerCost,population,budgetFraction,slots,experiment.microPartitionMode)
                                : MicroPartitionPlanner.select(microOwnerCost,population,budgetFraction,slots,experiment.microPartitionMode))
                            : MicroPartitionPlanner.replay(Paths.get(experiment.microPartitionReplay),replayContext,population,microOwnerCost,budgetFraction,slots,
                                    experiment.microPartitionMode,sc.getConf().get("spark.skyline.microReplaySha256",""));
                    diagnostics.put("micro_cost_signal","static");
                    diagnostics.put("micro_cost_information_policy","raw proxy; fixed candidates; no online probes or calibration");
                    diagnostics.put("micro_completion_probe_status","disabled_static_control");
                    diagnostics.put("micro_completion_probe_s",0.0);
                    diagnostics.put("micro_completion_reused_anchors",0);
                    diagnostics.put("micro_completion_reused_circles",0);
                }
                if (!experiment.outputPrefix.isEmpty()) plan.write(Paths.get(experiment.outputPrefix + ".micro_plan.tsv"),replayContext);
                if (!experiment.outputPrefix.isEmpty()) plan.writeCosts(Paths.get(experiment.outputPrefix + ".micro_cost_predictions.csv"));
            } catch (IOException error) { throw new IllegalStateException("cannot preserve/replay micro responsibility",error); }
            if(frozenExport){
                ProbeDominanceFrontier shared=calibratedFrontier!=null?calibratedFrontier:experiment.microProbeFrontier
                    ? ProbeDominanceFrontier.fromCircles(probeSkylines.stream().flatMap(front -> front.values().stream()).collect(java.util.stream.Collectors.toList())):ProbeDominanceFrontier.EMPTY;
                try{
                    java.nio.file.Path snapshot=Paths.get(experiment.outputPrefix+".frozen_calibration.bin");
                    new FrozenPlannerState(population,plan.originalWork,shared,completedAnchors,probeSkylines,probeCounters).write(snapshot,frozenContext);
                    diagnostics.put("micro_frozen_state_sha256",FrozenPlannerState.sha256(snapshot));
                }catch(IOException e){throw new IllegalStateException("Cannot export frozen calibration",e);}
            }
            diagnostics.put("micro_frozen_state_replay",frozenReplay);
            diagnostics.put("micro_frozen_state_export",frozenExport);
            if(frozenReplay){
                diagnostics.put("micro_completion_probe_status","frozen_state_loaded_no_online_probes");
                diagnostics.put("micro_cost_signal","frozen_calibrated");
                diagnostics.put("micro_cost_information_policy","identical captured candidates/work/probes; R/W transfer switches apply only to formal execution");
                diagnostics.put("micro_completion_reused_anchors",completedAnchors.values().stream().mapToInt(ids -> ids.length).sum());
                diagnostics.put("micro_completion_reused_circles",probeSkylines.stream().mapToInt(Map::size).sum());
            }
            diagnostics.put("micro_plan_ms",(System.nanoTime()-planStart)/1e6);
            diagnostics.put("micro_population_ms",population.populationMs);
            diagnostics.put("micro_original_population_ms",population.originalPopulationMs);
            diagnostics.put("micro_collect_ms",population.collectMs);
            diagnostics.put("micro_population_source_records",population.sourceRecordsScanned);
            diagnostics.put("micro_population_collection_fused",population.populationCollectionFused);
            diagnostics.put("micro_population_direct",Boolean.toString(population.populationDirect));
            diagnostics.put("micro_population_from_cells",population.populationFromCells);
            diagnostics.put("micro_dependency_population_scans",population.dependencyPopulationScans);
            diagnostics.put("micro_dependency_envelope_candidates",java.util.Arrays.stream(population.candidates)
                    .filter(candidate -> candidate.dependencyInputsEnabled).count());
            diagnostics.put("micro_original_assigned",plan.originalAssigned);
            diagnostics.put("micro_budget_records",plan.budgetRecords);
            diagnostics.put("micro_extra_input_records",plan.extraRecords);
            diagnostics.put("micro_physical_tasks",plan.taskCount());
            diagnostics.put("micro_layout_sha256",plan.signature());
            diagnostics.put("micro_responsibility_sha256",plan.responsibilitySignature());
            diagnostics.put("micro_proxy_peak",plan.peak); diagnostics.put("micro_proxy_lpt",plan.makespan);
            diagnostics.put("micro_original_proxy_work",java.util.Arrays.toString(plan.originalWork));
            diagnostics.put("micro_task_proxy_work",java.util.Arrays.toString(plan.work()));
            diagnostics.put("micro_selected_owners",java.util.stream.IntStream.range(0,plan.selected.length)
                    .filter(owner -> plan.selected[owner] != null).mapToObj(owner -> Integer.toString(owner)).collect(java.util.stream.Collectors.joining(",")));
            diagnostics.put("micro_fallbacks",population.fallbacks.toString());            if(sc.getConf().getBoolean("spark.skyline.microAuditAllCandidates",false)){
                if(experiment.outputPrefix.isEmpty())throw new IllegalArgumentException("Candidate audit requires output prefix");
                try{List<String> rows=new ArrayList<>();rows.add("kind,owner,pieces,lane,anchors,input_records,work,extra_records,signature");
                    for(int o=0;o<plan.originalWork.length;o++)rows.add("original,"+o+",1,0,"+population.core[o]+","+population.originalAssigned[o]+","+plan.originalWork[o]+",0,unsplit");
                    for(int i=0;i<population.candidates.length;i++){MicroPartitionLayout.Candidate c=population.candidates[i];if(!c.responsibility.equals("spatial"))continue;
                        long charge=MicroPartitionPlanner.extra(population.dependencyInputs[i],population.originalAssigned[c.owner]);
                        for(int l=0;l<c.pieces;l++)rows.add("candidate,"+c.owner+","+c.pieces+","+l+","+c.anchorCount(l)+","+population.dependencyInputs[i][l]+","+c.work(l)+","+charge+","+c.signature());}
                    Files.write(Paths.get(experiment.outputPrefix+".all_candidates.csv"),rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                }catch(IOException e){throw new IllegalStateException("Cannot preserve complete candidate audit",e);}
            }


            if(sc.getConf().getBoolean("spark.skyline.microAuditAllCandidates",false)){
                try{List<String> rows=new ArrayList<>();rows.add("owner,lane,pieces,anchors,input_records");
                    for(int o=0;o<plan.selected.length;o++)if(plan.selected[o]!=null){MicroPartitionLayout.Candidate c=plan.selected[o];for(int l=0;l<c.pieces;l++)rows.add(o+","+l+","+c.pieces+","+c.anchorCount(l)+","+plan.taskInputs[o][l]);}
                    Files.write(Paths.get(experiment.outputPrefix+".selected_lanes.csv"),rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                }catch(IOException e){throw new IllegalStateException("Cannot preserve selected lane audit",e);}
            }

            if(!experiment.outputPrefix.isEmpty()){
                try{List<String> rows=new ArrayList<>();rows.add("owner,pieces,parent_work,candidate_peak,parent_input,extra_records,core_anchors,acquisition");
                    for(int i=0;i<population.candidates.length;i++){MicroPartitionLayout.Candidate c=population.candidates[i];double peak=0;for(int l=0;l<c.pieces;l++)peak=Math.max(peak,c.work(l));rows.add(c.owner+","+c.pieces+","+plan.originalWork[c.owner]+","+peak+","+population.originalAssigned[c.owner]+","+MicroPartitionPlanner.extra(population.dependencyInputs[i],population.originalAssigned[c.owner])+","+population.core[c.owner]+","+(c.isSampledPoint()?"bounded_sample":"full_points"));}
                    Files.write(Paths.get(experiment.outputPrefix+".micro_candidate_audit.csv"),rows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                    Files.write(Paths.get(experiment.outputPrefix+".micro_plan_summary.txt"),Arrays.asList("physical_tasks="+plan.taskCount(),"original_predicted_peak="+MicroPartitionPlanner.maximum(plan.originalWork),"selected_predicted_peak="+plan.peak,"extra_records="+plan.extraRecords,"budget_records="+plan.budgetRecords,"acquisition="+population.fallbacks),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                }catch(IOException e){throw new IllegalStateException("cannot preserve acquisition audit",e);}
                if(probeSnapshotRows.size()>1){
                    try{
                        Files.write(Paths.get(experiment.outputPrefix+".micro_probe_snapshots.tsv"),probeSnapshotRows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                        ProbeDominanceFrontier snapshotFrontier=calibratedFrontier!=null?calibratedFrontier:experiment.microProbeFrontier
                                ? ProbeDominanceFrontier.fromCircles(probeSkylines.stream().flatMap(front -> front.values().stream()).collect(java.util.stream.Collectors.toList()))
                                : ProbeDominanceFrontier.EMPTY;
                        try(java.io.ObjectOutputStream out=new java.io.ObjectOutputStream(Files.newOutputStream(Paths.get(experiment.outputPrefix+".planner_snapshot.bin"),StandardOpenOption.CREATE_NEW))){
                            out.writeObject(new Object[]{population.candidates,population.dependencyInputs,population.originalAssigned,population.core,
                                    plan,snapshotFrontier,completedAnchors,probeSkylines});
                        }
                    }catch(IOException e){throw new IllegalStateException("cannot preserve diagnostic planner inputs",e);}
                }
                if(sc.getConf().getBoolean("spark.skyline.microPlanAuditOnly",false))throw new IllegalStateException("PLAN_AUDIT_COMPLETE: execution intentionally not started");
            }

            diagnostics.put("micro_mode",experiment.microPartitionMode);
            diagnostics.put("micro_cost_model",experiment.microCostModel);
            diagnostics.put("micro_task_order",experiment.microTaskOrder);
            diagnostics.put("micro_planner_policy",experiment.microPlannerPolicy);
            diagnostics.put("micro_refined_counting",experiment.microRefinedCounting);
            diagnostics.put("micro_comparison_scope",frozenReplay?"fixed_calibrated_state_execution_not_online_e2e":experiment.microPartitionReplay.isEmpty() ? "budget_system" : "mechanism_control");
            diagnostics.put("micro_record_budget_satisfied",plan.extraRecords <= plan.budgetRecords);
            diagnostics.put("local_engine_class",MaskedIndexedEMCS.class.getName());
            diagnostics.put("method_composition","B+micro_" + experiment.microPartitionMode + "+private_masked_engine");
            diagnostics.put("shared_neighborhood",0); diagnostics.put("m2_v3_enabled",0);
            diagnostics.put("m4_physical_tasks",plan.taskCount()); diagnostics.put("shard_tasks",plan.taskCount());
            diagnostics.put("prepared_indexes",1); diagnostics.put("experiment_prepared_mode","private_lane_index");
            diagnostics.put("experiment_projection_cache",experiment.projectionCache ? "on" : "off");
            diagnostics.put("experiment_geometric_bounds",experiment.geometricBounds);
            diagnostics.put("routing_strategy","micro_pre_shuffle_compact_inputs");
            ProbeDominanceFrontier probeFrontier = calibratedFrontier!=null?calibratedFrontier:experiment.microProbeFrontier
                    ? ProbeDominanceFrontier.fromCircles(probeSkylines.stream().flatMap(front -> front.values().stream())
                            .collect(java.util.stream.Collectors.toList())) : ProbeDominanceFrontier.EMPTY;
            diagnostics.put("micro_probe_frontier",experiment.microProbeFrontier);
            diagnostics.put("micro_completion_reuse",experiment.microCompletionReuse);
            diagnostics.put("micro_counting_cell_multiplier",experiment.microCountingCellMultiplier);
            diagnostics.put("micro_probe_anchor_bounds",experiment.microProbeAnchorBounds);
            diagnostics.put("micro_probe_anchor_bound_grid",experiment.microProbeAnchorBoundGrid);
            diagnostics.put("micro_projected_dedup",experiment.microProjectedDedup);
            diagnostics.put("micro_count_window_cache",experiment.microCountWindowCache);
            diagnostics.put("micro_anchor_boundary",experiment.microAnchorBoundary);
            diagnostics.put("micro_deferred_circle_allocation",experiment.microDeferredCircleAllocation);
            diagnostics.put("micro_spatial_count_tree",experiment.microSpatialCountTree);
            diagnostics.put("micro_dense_boundary_counting",experiment.microDenseBoundaryCounting);
            diagnostics.put("micro_dense_boundary_scope","same exact visible bucket refinement in probe and formal execution; private lazy indexes; build time included in kernel");
            diagnostics.put("micro_spatial_count_tree_scope","formal task-private exact counts only; original probe/grid planner unchanged; tree construction included in kernel time");
            diagnostics.put("micro_pair_circle_allocation_scope","formal logical Circle constructor calls only; OFF derives attempts minus pre-factory skips; not measured heap bytes/JIT allocation");
            diagnostics.put("micro_anchor_boundary_scope","formal only; identical anchor operations; executor dontinline processAnchor required for JIT isolation evidence");
            diagnostics.put("micro_count_window_scope","formal immutable dependency metadata only; LRU input counting-bucket capacity; sums of per-task peaks are not simultaneous heap peaks");
            diagnostics.put("micro_projected_dedup_scope","formal task-local proven rejected projections only; accepted emission/flush unchanged");
            diagnostics.put("micro_probe_frontier_witness_distances",probeFrontier.witnessDistances());
            diagnostics.put("micro_probe_frontier_scope","valid probe coverage lower bounds; strict smaller distance; formal count pruning only");
            List<PartitionMetrics> metrics = new ArrayList<>();
            for (int owner = 0; owner < partition_number; owner++) metrics.add(new PartitionMetrics(owner,population.core[owner],
                    population.originalAssigned[owner]-population.core[owner],0));
            recordPartitionCloneStats(originalCount,metrics);
            this.s2_plan_cells = System.currentTimeMillis()-startPlan;
            long routingStart = System.currentTimeMillis();
            try (MicroPartitionExecution.Prepared prepared = MicroPartitionExecution.prepare(sc,points,owners,offsetX,offsetY,plan,experiment.microTaskOrder)) {
                diagnostics.put("micro_child_input_records",prepared.childInputRecords);
                diagnostics.put("micro_execution_source_records",originalCount);
                diagnostics.put("micro_parent_prepared_records",0);
                transportObservations = prepared.transport; microObservations = prepared.observations;
                this.s3_clone_assign = System.currentTimeMillis()-routingStart;
                org.apache.spark.util.LongAccumulator[] counts = new org.apache.spark.util.LongAccumulator[10];
                for (int index = 0; index < counts.length; index++) counts[index] = sc.sc().longAccumulator("micro_counter_"+index);
                long localStart = System.currentTimeMillis();
                local = MicroPartitionExecution.query(prepared,radius,cellSize,queryX,queryY,density_k,
                        experiment.microEngineOptions(),new MaskedLaneQuery.Metrics(counts),completedAnchors,experiment.microRefinedCounting,probeFrontier,experiment.microProbeAnchorBounds,experiment.microProbeAnchorBoundGrid.equals("coarse"),experiment.microAdaptiveCountIndex,experiment.microCountingCellMultiplier).persist(StorageLevel.MEMORY_AND_DISK());
                local.count(); this.s4_local_compute = System.currentTimeMillis()-localStart;
                String[] keys = {"candidate_count","single_point_candidates","pair_candidates","z_window_checks","point_distance_checks",
                        "projected_candidates","projected_count_hits","projected_bound_hits","m2_v3_mask_checks","m2_v3_mask_filtered"};
                for (int index = 0; index < keys.length; index++) {
                    diagnostics.put(keys[index],counts[index].value());
                    diagnostics.put("probe_"+keys[index],probeCounters[index]);
                    diagnostics.put("total_"+keys[index],counts[index].value()+probeCounters[index]);
                }
                List<Long> times = new ArrayList<>(); long prepareNanos = 0;
                for (MicroPartitionObservation row : microObservations.value()) { times.add(row.wallNanos/1000000); prepareNanos += row.prepareNanos; }
                diagnostics.put("micro_adaptive_count_index",experiment.microAdaptiveCountIndex);
                diagnostics.put("micro_count_index_dense_tasks",microObservations.value().stream().filter(row -> row.countingLookupMode.equals("dense")).count());
                diagnostics.put("micro_count_index_sparse_tasks",microObservations.value().stream().filter(row -> row.countingLookupMode.equals("sparse")).count());
                diagnostics.put("micro_count_index_hash_tasks",microObservations.value().stream().filter(row -> row.countingLookupMode.equals("hash")).count());
                diagnostics.put("micro_pair_circles_created",microObservations.value().stream().mapToLong(row -> row.pairCirclesCreated).sum());
                diagnostics.put("micro_candidate_batch_flushes",microObservations.value().stream().mapToLong(row -> row.candidateBatchFlushes).sum());
                diagnostics.put("micro_anchor_boundary_calls",microObservations.value().stream().mapToLong(row -> row.anchorBoundaryCalls).sum());
                diagnostics.put("micro_count_window_requests",microObservations.value().stream().mapToLong(row -> row.countWindowRequests).sum());
                diagnostics.put("micro_count_window_hits",microObservations.value().stream().mapToLong(row -> row.countWindowHits).sum());
                diagnostics.put("micro_count_window_bucket_lookups",microObservations.value().stream().mapToLong(row -> row.countWindowBucketLookups).sum());
                diagnostics.put("micro_count_window_entries_peak_sum",microObservations.value().stream().mapToLong(row -> row.countWindowEntriesPeak).sum());
                diagnostics.put("micro_count_window_references_peak_sum",microObservations.value().stream().mapToLong(row -> row.countWindowReferencesPeak).sum());
                diagnostics.put("micro_count_window_entries_peak_max",microObservations.value().stream().mapToLong(row -> row.countWindowEntriesPeak).max().orElse(0));
                diagnostics.put("micro_count_window_references_peak_max",microObservations.value().stream().mapToLong(row -> row.countWindowReferencesPeak).max().orElse(0));
                diagnostics.put("micro_count_window_evictions",microObservations.value().stream().mapToLong(row -> row.countWindowEvictions).sum());
                diagnostics.put("micro_projection_duplicates_skipped",microObservations.value().stream().mapToLong(row -> row.projectionDuplicatesSkipped).sum());
                diagnostics.put("micro_frontier_pruned_anchors",microObservations.value().stream().mapToLong(row -> row.frontierPrunedAnchors).sum());
                diagnostics.put("micro_frontier_bound_lookups",microObservations.value().stream().mapToLong(row -> row.frontierBoundLookups).sum());
                diagnostics.put("task_times_ms",times); diagnostics.put("index_builds",plan.taskCount()); diagnostics.put("index_reuses",0);
                diagnostics.put("index_build_task_ms",prepareNanos/1e6);
                diagnostics.put("total_index_builds",plan.taskCount()+(diagnostics.containsKey("probe_index_builds")?((Number)diagnostics.get("probe_index_builds")).intValue():probeSkylines.size()));
                long globalStart = System.currentTimeMillis(); computeGlobalSkyline(local,probeSkylines); this.s5_global_reduce = System.currentTimeMillis()-globalStart;
                long membersStart = System.currentTimeMillis();
                if (materializeFinalMembers) materializeFinalCircleMembers(sc,points,radius,cellSize);
                else for (Circle circle : sortedSkymapList) circle.p = null;
                this.s6_materialize_final_points = System.currentTimeMillis()-membersStart;
            }
        } finally {
            if (local != null) local.unpersist(false); points.unpersist(false); owners.destroy();
        }
    }

    private void executeImplicitMicroPartition(JavaSparkContext sc,JavaRDD<Point> points,CellOwnerIndex ownerByCell,
            int[] offsetX,int[] offsetY,double radius,double cellSize,long originalCount,long startPlan,long[] coreCounts) {
        if (implicitCellStatistics == null || !experiment.microPartitionReplay.isEmpty()
                || !(experiment.microPlannerPolicy.equals("peak") || experiment.microPlannerPolicy.equals("sampled_peak"))
                || !Arrays.asList("none","hash_full","dependency").contains(experiment.microPartitionMode))
            throw new IllegalArgumentException("implicit family supports peak/sampled_peak and none/hash_full/dependency; replay/completion policy unsupported");
        Broadcast<CellOwnerIndex> owners = sc.broadcast(ownerByCell);
        JavaRDD<HashMap<Double,Circle>> local = null;
        Map<Integer,long[]> completedAnchors = new HashMap<>();
        List<HashMap<Double,Circle>> probeSkylines = new ArrayList<>(); long[] probeCounters = new long[10];
        List<String> probeRows = new ArrayList<>();probeRows.add("owner\tanchor_ids\tcounters\tkernel_ns");
        try {
            long populationStart = System.nanoTime();
            ImplicitCandidatePopulation.Result population = ImplicitCandidatePopulation.observe(implicitCellStatistics,ownerByCell,
                    offsetX,offsetY,partition_number,radius,cellSize,microCellWork,experiment.microPartitionMode);
            if (!Arrays.equals(population.core,coreCounts)) throw new IllegalStateException("implicit/original core populations disagree");
            double populationMs = (System.nanoTime()-populationStart)/1e6;
            int slots = Integer.parseInt(sc.getConf().get("spark.cores.max","1"));
            double budgetFraction = sc.getConf().getDouble("spark.skyline.shardReadBudget",0.01);
            double[] plannerWork = microOwnerCost; double probeSeconds = 0;
            boolean sampled = experiment.microPlannerPolicy.equals("sampled_peak") && SampledAnchorCostProbe.skewEligible(microOwnerCost,slots);
            if (sampled) {
                int[] selected = MicroPartitionPopulation.selectOwners(microOwnerCost,coreCounts);
                SampledAnchorCostProbe.Result probes = SampledAnchorCostProbe.runForOwners(sc,points,owners,offsetX,offsetY,
                        selected,coreCounts,microOwnerCost,radius,cellSize,queryX,queryY,density_k,
                        experiment.microProbeEngineOptions(),24,experiment.microRefinedCounting,
                        experiment.microProbeTrace,experiment.microProbeSelectedRouting);
                plannerWork = probes.calibration.work; probeSeconds = probes.wallSeconds;
                for (SampledAnchorCostProbe.Probe probe : probes.probes) {
                    if (experiment.microCompletionReuse) completedAnchors.put(probe.owner,probe.anchorIds.clone());
                    probeSkylines.add(probe.skyline);
                    probeRows.add(probe.owner+"\t"+Arrays.toString(probe.anchorIds)+"\t"+Arrays.toString(probe.counters)+"\t"+probe.kernelNanos);
                    for (int i=0;i<10;i++) probeCounters[i]=Math.addExact(probeCounters[i],probe.counters[i]);
                }
                population = ImplicitCandidatePopulation.reweight(population,microOwnerCost,plannerWork);
                diagnostics.put("micro_completion_probe_owners",Arrays.stream(probes.probes).map(p -> Integer.toString(p.owner)).collect(java.util.stream.Collectors.joining(",")));
                diagnostics.put("micro_completion_probe_checks",Arrays.stream(probes.probes).map(p -> Long.toString(p.distanceChecks)).collect(java.util.stream.Collectors.joining(",")));
                diagnostics.put("micro_completion_probe_counting_cell_sizes",Arrays.toString(Arrays.stream(probes.probes).mapToDouble(p -> p.countCellSize).toArray()));
            }
            long planStart = System.nanoTime();
            ImplicitMicroPlanner.Candidate[] alternatives = experiment.microPartitionMode.equals("none")
                    ? new ImplicitMicroPlanner.Candidate[0] : Arrays.stream(population.candidates)
                        .filter(c -> !experiment.microPartitionMode.equals("hash_full") || c.rule.isHash())
                        .toArray(ImplicitMicroPlanner.Candidate[]::new);
            ImplicitMicroPlanner.Plan plan = ImplicitMicroPlanner.select(population.originalInputs,plannerWork,alternatives,budgetFraction,slots);
            if (!experiment.outputPrefix.isEmpty()) {
                String context=diagnostics.get("owner_layout_sha256")+":"+sc.getConf().get("spark.skyline.inputSha256","unrecorded")
                        +":"+Double.toHexString(radius)+":"+Double.toHexString(cellSize);
                List<String> planRows=new ArrayList<>();planRows.add("implicit-responsibility-v2\t"+context);
                for(int owner=0;owner<partition_number;owner++)planRows.add(owner+"\t"+(plan.candidate(owner)==null?"unsplit":plan.candidate(owner).signature()));
                try {
                    Files.write(Paths.get(experiment.outputPrefix+".micro_plan.tsv"),planRows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                    Files.write(Paths.get(experiment.outputPrefix+".micro_probe_ids.tsv"),probeRows,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                } catch(IOException error) {throw new IllegalStateException("cannot preserve implicit plan/probe identity",error);}
            }
            long originalAssigned=0;for(long n:population.originalInputs)originalAssigned=Math.addExact(originalAssigned,n);
            diagnostics.put("micro_implicit_family",true);
            diagnostics.put("micro_dependency_cell_population_checks",population.dependencyCellChecks);
            diagnostics.put("micro_comparison_scope","implicit_family_greedy_budget_system");
            diagnostics.put("micro_completion_probe_status",sampled?"sampled":"skipped");
            diagnostics.put("micro_completion_probe_anchor_limit",24);
            diagnostics.put("micro_completion_reused_anchors",completedAnchors.values().stream().mapToInt(ids -> ids.length).sum());
            diagnostics.put("micro_completion_probe_s",probeSeconds);
            diagnostics.put("micro_plan_ms",(System.nanoTime()-planStart)/1e6);
            diagnostics.put("micro_population_ms",populationMs); diagnostics.put("micro_original_population_ms",populationMs);
            diagnostics.put("micro_collect_ms",0); diagnostics.put("micro_population_source_records",0);
            diagnostics.put("micro_population_collection_fused",true); diagnostics.put("micro_population_direct","false");
            diagnostics.put("micro_population_from_cells",true); diagnostics.put("micro_dependency_population_scans",0);
            diagnostics.put("micro_dependency_envelope_candidates",Arrays.stream(alternatives).filter(c -> !c.rule.isHash()).count());
            diagnostics.put("micro_original_assigned",originalAssigned); diagnostics.put("micro_budget_records",plan.budgetRecords());
            diagnostics.put("micro_extra_input_records",plan.extraRecords());diagnostics.put("micro_physical_tasks",plan.taskCount());
            diagnostics.put("micro_layout_sha256",plan.signature());diagnostics.put("micro_responsibility_sha256",plan.signature());
            diagnostics.put("micro_proxy_peak",MicroPartitionPlanner.maximum(plan.work()));
            diagnostics.put("micro_proxy_lpt",MicroPartitionPlanner.lpt(plan.work(),slots));
            diagnostics.put("micro_original_proxy_work",Arrays.toString(plannerWork));diagnostics.put("micro_task_proxy_work",Arrays.toString(plan.work()));
            diagnostics.put("micro_selected_owners",java.util.stream.IntStream.range(0,partition_number).filter(o -> plan.candidate(o)!=null)
                    .mapToObj(Integer::toString).collect(java.util.stream.Collectors.joining(",")));
            diagnostics.put("micro_fallbacks","[]");diagnostics.put("micro_mode",experiment.microPartitionMode);
            diagnostics.put("micro_cost_model",experiment.microCostModel);diagnostics.put("micro_task_order",experiment.microTaskOrder);
            diagnostics.put("micro_planner_policy",experiment.microPlannerPolicy);diagnostics.put("micro_refined_counting",experiment.microRefinedCounting);
            diagnostics.put("micro_record_budget_satisfied",plan.extraRecords()<=plan.budgetRecords());
            diagnostics.put("local_engine_class",MaskedIndexedEMCS.class.getName());diagnostics.put("method_composition","B+implicit_cell_hash+private_masked_engine");
            diagnostics.put("shared_neighborhood",0);diagnostics.put("m2_v3_enabled",0);diagnostics.put("m4_physical_tasks",plan.taskCount());
            diagnostics.put("shard_tasks",plan.taskCount());diagnostics.put("prepared_indexes",1);
            diagnostics.put("experiment_prepared_mode","private_lane_index");diagnostics.put("experiment_projection_cache",experiment.projectionCache?"on":"off");
            diagnostics.put("experiment_geometric_bounds",experiment.geometricBounds);diagnostics.put("routing_strategy","implicit_pre_shuffle_compact_inputs");
            ProbeDominanceFrontier probeFrontier = experiment.microProbeFrontier
                    ? ProbeDominanceFrontier.fromCircles(probeSkylines.stream().flatMap(front -> front.values().stream()).collect(java.util.stream.Collectors.toList()))
                    : ProbeDominanceFrontier.EMPTY;
            diagnostics.put("micro_probe_frontier",experiment.microProbeFrontier);
            diagnostics.put("micro_completion_reuse",experiment.microCompletionReuse);
            diagnostics.put("micro_counting_cell_multiplier",experiment.microCountingCellMultiplier);
            diagnostics.put("micro_probe_frontier_witness_distances",probeFrontier.witnessDistances());
            List<PartitionMetrics> metrics = new ArrayList<>();
            for (int owner = 0; owner < partition_number; owner++) metrics.add(new PartitionMetrics(owner,population.core[owner],
                    population.originalInputs[owner]-population.core[owner],0));
            recordPartitionCloneStats(originalCount,metrics);
            this.s2_plan_cells = System.currentTimeMillis()-startPlan;
            long routingStart = System.currentTimeMillis();
            try (ImplicitMicroExecution.Prepared prepared = ImplicitMicroExecution.prepare(sc,points,owners,offsetX,offsetY,plan,population.core,experiment.microTaskOrder)) {
                diagnostics.put("micro_child_input_records",prepared.childInputRecords);
                diagnostics.put("micro_execution_source_records",originalCount);
                diagnostics.put("micro_parent_prepared_records",0);
                transportObservations = prepared.transport; microObservations = prepared.observations;
                this.s3_clone_assign = System.currentTimeMillis()-routingStart;
                org.apache.spark.util.LongAccumulator[] counts = new org.apache.spark.util.LongAccumulator[10];
                for (int index = 0; index < counts.length; index++) counts[index] = sc.sc().longAccumulator("micro_counter_"+index);
                long localStart = System.currentTimeMillis();
                local = ImplicitMicroExecution.query(prepared,radius,cellSize,queryX,queryY,density_k,
                        experiment.microEngineOptions(),new MaskedLaneQuery.Metrics(counts),completedAnchors,experiment.microRefinedCounting,probeFrontier,experiment.microProbeAnchorBounds,experiment.microProbeAnchorBoundGrid.equals("coarse"),experiment.microAdaptiveCountIndex,experiment.microCountingCellMultiplier).persist(StorageLevel.MEMORY_AND_DISK());
                local.count(); this.s4_local_compute = System.currentTimeMillis()-localStart;
                String[] keys = {"candidate_count","single_point_candidates","pair_candidates","z_window_checks","point_distance_checks",
                        "projected_candidates","projected_count_hits","projected_bound_hits","m2_v3_mask_checks","m2_v3_mask_filtered"};
                for (int index = 0; index < keys.length; index++) {
                    diagnostics.put(keys[index],counts[index].value());
                    diagnostics.put("probe_"+keys[index],probeCounters[index]);
                    diagnostics.put("total_"+keys[index],counts[index].value()+probeCounters[index]);
                }
                List<Long> times = new ArrayList<>(); long prepareNanos = 0;
                for (MicroPartitionObservation row : microObservations.value()) { times.add(row.wallNanos/1000000); prepareNanos += row.prepareNanos; }
                diagnostics.put("micro_adaptive_count_index",experiment.microAdaptiveCountIndex);
                diagnostics.put("micro_count_index_dense_tasks",microObservations.value().stream().filter(row -> row.countingLookupMode.equals("dense")).count());
                diagnostics.put("micro_count_index_sparse_tasks",microObservations.value().stream().filter(row -> row.countingLookupMode.equals("sparse")).count());
                diagnostics.put("micro_count_index_hash_tasks",microObservations.value().stream().filter(row -> row.countingLookupMode.equals("hash")).count());
                diagnostics.put("micro_pair_circles_created",microObservations.value().stream().mapToLong(row -> row.pairCirclesCreated).sum());
                diagnostics.put("micro_candidate_batch_flushes",microObservations.value().stream().mapToLong(row -> row.candidateBatchFlushes).sum());
                diagnostics.put("micro_anchor_boundary_calls",microObservations.value().stream().mapToLong(row -> row.anchorBoundaryCalls).sum());
                diagnostics.put("micro_count_window_requests",microObservations.value().stream().mapToLong(row -> row.countWindowRequests).sum());
                diagnostics.put("micro_count_window_hits",microObservations.value().stream().mapToLong(row -> row.countWindowHits).sum());
                diagnostics.put("micro_count_window_bucket_lookups",microObservations.value().stream().mapToLong(row -> row.countWindowBucketLookups).sum());
                diagnostics.put("micro_count_window_entries_peak_sum",microObservations.value().stream().mapToLong(row -> row.countWindowEntriesPeak).sum());
                diagnostics.put("micro_count_window_references_peak_sum",microObservations.value().stream().mapToLong(row -> row.countWindowReferencesPeak).sum());
                diagnostics.put("micro_count_window_entries_peak_max",microObservations.value().stream().mapToLong(row -> row.countWindowEntriesPeak).max().orElse(0));
                diagnostics.put("micro_count_window_references_peak_max",microObservations.value().stream().mapToLong(row -> row.countWindowReferencesPeak).max().orElse(0));
                diagnostics.put("micro_count_window_evictions",microObservations.value().stream().mapToLong(row -> row.countWindowEvictions).sum());
                diagnostics.put("micro_projection_duplicates_skipped",microObservations.value().stream().mapToLong(row -> row.projectionDuplicatesSkipped).sum());
                diagnostics.put("micro_frontier_pruned_anchors",microObservations.value().stream().mapToLong(row -> row.frontierPrunedAnchors).sum());
                diagnostics.put("micro_frontier_bound_lookups",microObservations.value().stream().mapToLong(row -> row.frontierBoundLookups).sum());
                diagnostics.put("task_times_ms",times); diagnostics.put("index_builds",plan.taskCount()); diagnostics.put("index_reuses",0);
                diagnostics.put("index_build_task_ms",prepareNanos/1e6);
                diagnostics.put("total_index_builds",plan.taskCount()+probeSkylines.size());
                long globalStart = System.currentTimeMillis(); computeGlobalSkyline(local,probeSkylines); this.s5_global_reduce = System.currentTimeMillis()-globalStart;
                long membersStart = System.currentTimeMillis();
                if (materializeFinalMembers) materializeFinalCircleMembers(sc,points,radius,cellSize);
                else for (Circle circle : sortedSkymapList) circle.p = null;
                this.s6_materialize_final_points = System.currentTimeMillis()-membersStart;
            }
        } finally {
            if (local != null) local.unpersist(false); points.unpersist(false); owners.destroy();
        }
    }

    private CellOwnerIndex assignCellsToPartitions(
            List<CellCount> orderedCells,
            List<NeighborOffset> neighborOffsets) {
        boolean dependencyPartition = experiment == null ? profile.dependencyPartition : experiment.dependencyPartition;
        boolean interiorRouting = experiment == null ? profile.dependencyPartition : experiment.interiorRouting;
        CellOwnerIndex ownerByCell = new CellOwnerIndex(orderedCells.size());
        if (orderedCells.isEmpty()) {
            long rangeStart = System.nanoTime();
            m2RangeStats = RangeOverlapEstimator.estimate(
                    new long[0], new int[0], new int[0], new int[0], partition_number);
            diagnostics.put("m2_range_plan_ms", (System.nanoTime() - rangeStart) / 1000000.0);
            plannedPartitionWork = new double[partition_number];
            microOwnerCost = new double[partition_number];
            microCellWork = new HashMap<>();
            return ownerByCell;
        }

        CellPlanStats stats = estimateCellPlanStats(orderedCells, neighborOffsets);
        double[] workloadByCell = stats.work;
        if (experiment != null && experiment.microPartition) {
            microCellWork = new HashMap<>();
            for (int index = 0; index < orderedCells.size(); index++)
                microCellWork.put(orderedCells.get(index).packed,
                        experiment.microCellCost(workloadByCell[index], orderedCells.get(index).count) / orderedCells.get(index).count);
        }
        long[] counts = new long[orderedCells.size()];
        for (int i = 0; i < counts.length; i++) counts[i] = orderedCells.get(i).count;
        int[] ownerByRank;
        if (experiment != null && experiment.enabled) {
            long planStart = System.nanoTime();
            ExecutionAwareCuts.Plan plan = LogicalPartitionPlanner.plan(experiment.partitionStrategy,
                    workloadByCell, counts, stats.minRank, stats.maxRank, partition_number);
            ownerByRank = plan.owners;
            diagnostics.put("joint_refine_ms", experiment.partitionStrategy.equals("dependency")
                    ? (System.nanoTime() - planStart) / 1000000L : 0L);
            diagnostics.put("joint_boundary_before", plan.oldBoundaryPoints);
            diagnostics.put("joint_boundary_after", plan.boundaryPoints);
            diagnostics.put("joint_span_before", plan.oldSpan);
            diagnostics.put("joint_span_after", plan.span);
            diagnostics.put("joint_moves", plan.moves);
            diagnostics.put("partitioning_strategy", LogicalPartitionPlanner.label(experiment.partitionStrategy));
        } else if (dependencyPartition) {
            long refineStart = System.nanoTime();
            ExecutionAwareCuts.Plan plan = ExecutionAwareCuts.plan(
                    workloadByCell, counts, stats.minRank, stats.maxRank, partition_number);
            ownerByRank = plan.owners;
            diagnostics.put("joint_refine_ms", (System.nanoTime() - refineStart) / 1000000L);
            diagnostics.put("joint_boundary_before", plan.oldBoundaryPoints);
            diagnostics.put("joint_boundary_after", plan.boundaryPoints);
            diagnostics.put("joint_span_before", plan.oldSpan);
            diagnostics.put("joint_span_after", plan.span);
            diagnostics.put("joint_moves", plan.moves);
            diagnostics.put("partitioning_strategy", profile.usesHilbertCellOrder()
                    ? "dependency_aware_hilbert_grid"
                    : "dependency_aware_grid");
        } else {
            double[] pointWeights = new double[counts.length];
            for (int i = 0; i < counts.length; i++) pointWeights[i] = counts[i];
            ownerByRank = ExecutionAwareCuts.baseline(pointWeights, partition_number);
            diagnostics.put("joint_refine_ms", 0L);
            diagnostics.put("joint_boundary_before", 0L);
            diagnostics.put("joint_boundary_after", 0L);
            diagnostics.put("joint_span_before", 0.0);
            diagnostics.put("joint_span_after", 0.0);
            diagnostics.put("joint_moves", 0);
            diagnostics.put("partitioning_strategy", "point_count_grid");
        }
        long rangeStart = System.nanoTime();
        m2RangeStats = RangeOverlapEstimator.estimate(
                counts, ownerByRank, stats.minRank, stats.maxRank, partition_number);
        diagnostics.put("m2_range_plan_ms", (System.nanoTime() - rangeStart) / 1000000.0);
        diagnostics.put("m2_range_crossed_cuts", m2RangeStats.crossedCuts);
        long interiorPoints = 0L;
        long totalPoints = 0L;
        for (int i = 0; i < orderedCells.size(); i++) {
            CellCount cell = orderedCells.get(i);
            int owner = ownerByRank[i];
            boolean interior = interiorRouting
                    && ownerByRank[stats.minRank[i]] == ownerByRank[stats.maxRank[i]];
            ownerByCell.put(cell.packed, interior ? -owner - 2 : owner);
            totalPoints += cell.count;
            if (interior) interiorPoints += cell.count;
        }
        diagnostics.put("interior_points", interiorPoints);
        diagnostics.put("boundary_points", totalPoints - interiorPoints);
        diagnostics.put("skipped_neighbor_lookups", interiorPoints * (neighborOffsets.size() - 1L));
        diagnostics.put("remaining_neighbor_lookups", (totalPoints - interiorPoints) * (neighborOffsets.size() - 1L));
        ArrayList<Double> partitionWorkloads = new ArrayList<Double>(partition_number);
        double[] partWork = new double[partition_number];
        for (int i = 0; i < ownerByRank.length; i++) partWork[ownerByRank[i]] += stats.work[i];
        for (double value : partWork) partitionWorkloads.add(value);
        plannedPartitionWork = partWork;
        if (experiment != null && experiment.microPartition) {
            microOwnerCost = new double[partition_number];
            for (int index = 0; index < ownerByRank.length; index++)
                microOwnerCost[ownerByRank[index]] += experiment.microCellCost(stats.work[index], counts[index]);
        }
        diagnostics.put("partition_workloads", partitionWorkloads.toString());
        return ownerByCell;
    }

    private CellPlanStats estimateCellPlanStats(
            List<CellCount> orderedCells,
            List<NeighborOffset> neighborOffsets) {
        LongLongIndex rankByCell = new LongLongIndex(orderedCells.size());
        long[] counts = new long[orderedCells.size()];
        for (int i = 0; i < orderedCells.size(); i++) {
            rankByCell.put(orderedCells.get(i).packed, i);
            counts[i] = orderedCells.get(i).count;
        }

        CellPlanStats stats = new CellPlanStats(orderedCells.size());
        for (int i = 0; i < orderedCells.size(); i++) {
            CellCount cell = orderedCells.get(i);
            long neighborhoodCount = 0L;
            int minRank = i, maxRank = i;
            for (NeighborOffset offset : neighborOffsets) {
                int rank = (int) rankByCell.getOrDefault(pack(cell.x + offset.dx, cell.y + offset.dy), -1L);
                if (rank >= 0) {
                    neighborhoodCount += counts[rank];
                    minRank = Math.min(minRank, rank);
                    maxRank = Math.max(maxRank, rank);
                }
            }
            stats.work[i] = Math.max(1.0, (double) cell.count * Math.max(1L, neighborhoodCount));
            stats.minRank[i] = minRank;
            stats.maxRank[i] = maxRank;
        }
        return stats;
    }

    private List<NeighborOffset> buildNeighborOffsets(
            int haloCellRadius,
            double cellSize,
            double dc) {
        ArrayList<NeighborOffset> offsets = new ArrayList<NeighborOffset>();
        // A candidate center can be r from its anchor; counting admits r+.005.
        // Partner generation alone therefore gives an insufficient halo envelope.
        double dependencyRadius = 2 * dc + 0.005;
        double dependencyRadiusSquared = dependencyRadius * dependencyRadius;
        int dependencyCellRadius = Math.max(haloCellRadius,(int)Math.ceil(dependencyRadius/cellSize));
        for (int dx = -dependencyCellRadius; dx <= dependencyCellRadius; dx++) {
            for (int dy = -dependencyCellRadius; dy <= dependencyCellRadius; dy++) {
                if (minCellDistanceSquared(0, 0, dx, dy, cellSize) <= dependencyRadiusSquared) {
                    offsets.add(new NeighborOffset(dx, dy));
                }
            }
        }
        return offsets;
    }

    private double minCellDistanceSquared(int ax, int ay, int bx, int by, double cellSize) {
        double aMinX = ax * cellSize;
        double aMaxX = aMinX + cellSize;
        double aMinY = ay * cellSize;
        double aMaxY = aMinY + cellSize;

        double bMinX = bx * cellSize;
        double bMaxX = bMinX + cellSize;
        double bMinY = by * cellSize;
        double bMaxY = bMinY + cellSize;

        double dx = 0.0;
        if (aMaxX < bMinX) {
            dx = bMinX - aMaxX;
        } else if (bMaxX < aMinX) {
            dx = aMinX - bMaxX;
        }

        double dy = 0.0;
        if (aMaxY < bMinY) {
            dy = bMinY - aMaxY;
        } else if (bMaxY < aMinY) {
            dy = aMinY - bMaxY;
        }

        return dx * dx + dy * dy;
    }

    private JavaRDD<HashMap<Double, Circle>> performLocalClustering(
            JavaPairRDD<Integer, Point> partitionedPoints, double dc, double cellSize) {
        return partitionedPoints.mapPartitionsWithIndex((partitionId, iterator) -> {
            EMCS emcs = new EMCS(dc);
            emcs.q.x = queryX;
            emcs.q.y = queryY;
            emcs.density_k = this.density_k;
            emcs.part_id = partitionId;
            emcs.setCellConfig(cellSize);
            while (iterator.hasNext()) {
                emcs.plist.add(iterator.next()._2());
            }
            emcs.method(dc);
            if (printLocalSkylines) {
                System.out.println("partition " + partitionId + " local skyline size=" + emcs.skymap.size());
            }
            return Collections.singletonList(emcs.skymap).iterator();
        }, true);
    }

    public void computeGlobalSkyline(JavaRDD<HashMap<Double, Circle>> localClusters) {
        computeGlobalSkyline(localClusters,Collections.emptyList());
    }

    public void computeGlobalSkyline(JavaRDD<HashMap<Double, Circle>> localClusters,
            List<HashMap<Double,Circle>> completed) {
        ArrayList<Circle> combined = new ArrayList<Circle>();
        for (HashMap<Double,Circle> front : completed) combined.addAll(front.values());
        for (HashMap<Double, Circle> local : localClusters.collect()) {
            if (local != null) combined.addAll(local.values());
        }
        Collections.sort(combined, new Comparator<Circle>() {
            @Override
            public int compare(Circle a, Circle b) {
                return Double.compare(a.discenq, b.discenq);
            }
        });
        skymap = skylineCircle(combined);
        finalSkylineCount = skymap.size();
        sortedSkymapList = new ArrayList<Circle>(skymap.values());
        Collections.sort(sortedSkymapList, new Comparator<Circle>() {
            @Override
            public int compare(Circle a, Circle b) {
                return Double.compare(a.discenq, b.discenq);
            }
        });
    }

    private void materializeFinalCircleMembers(JavaSparkContext sc, JavaRDD<Point> originalPoints, double dc, double cellSize) {
        if (sortedSkymapList == null || sortedSkymapList.isEmpty()) {
            return;
        }

        List<FinalCircleSpec> specs = new ArrayList<FinalCircleSpec>(sortedSkymapList.size());
        Map<Long, List<FinalCircleSpec>> circlesByCell = new HashMap<Long, List<FinalCircleSpec>>();
        double memberEnvelopeRadius = Math.nextUp(dc + 0.005);
        diagnostics.put("member_envelope_radius",memberEnvelopeRadius);
        for (int index = 0; index < sortedSkymapList.size(); index++) {
            Circle circle = sortedSkymapList.get(index);
            circle.p = new ArrayList<Point>();
            FinalCircleSpec spec = new FinalCircleSpec(index, circle.discenq, circle.centerX, circle.centerY);
            specs.add(spec);
            int minCellX = (int) Math.floor(Math.nextDown(circle.centerX - memberEnvelopeRadius) / cellSize);
            int maxCellX = (int) Math.floor(Math.nextUp(circle.centerX + memberEnvelopeRadius) / cellSize);
            int minCellY = (int) Math.floor(Math.nextDown(circle.centerY - memberEnvelopeRadius) / cellSize);
            int maxCellY = (int) Math.floor(Math.nextUp(circle.centerY + memberEnvelopeRadius) / cellSize);
            for (int cellX = minCellX; cellX <= maxCellX; cellX++) {
                for (int cellY = minCellY; cellY <= maxCellY; cellY++) {
                    circlesByCell.computeIfAbsent(pack(cellX, cellY), ignore -> new ArrayList<FinalCircleSpec>())
                            .add(spec);
                }
            }
        }

        if(partitionedMemberOutput) {
            Map<Long,List<double[]>> lookup=new HashMap<>();
            for(Map.Entry<Long,List<FinalCircleSpec>> entry:circlesByCell.entrySet()) {
                List<double[]> rows=new ArrayList<>();
                for(FinalCircleSpec spec:entry.getValue())rows.add(new double[]{spec.index,spec.centerX,spec.centerY});
                lookup.put(entry.getKey(),rows);
            }
            String prefix=experiment.outputPrefix;
            if(prefix.isEmpty())throw new IllegalArgumentException("partitioned members need outputPrefix");
            String root=sc.getConf().get("spark.skyline.memberOutputPath",prefix+".members");
            PartitionedMemberWriter.Result exported=PartitionedMemberWriter.write(sc,originalPoints,lookup,dc,
                    sortedSkymapList,root,prefix+".members.manifest.tsv");
            diagnostics.put("external_member_manifest",exported.manifest);
            diagnostics.put("external_member_records_total",exported.records);
            diagnostics.put("external_member_part_count",exported.parts);
            diagnostics.put("member_materialization_path","executor_streaming_part_files");
            return;
        }
        Broadcast<Map<Long, List<FinalCircleSpec>>> circleCellBroadcast = sc.broadcast(circlesByCell);
        final boolean shareMemberPoint = reuseMemberPoints;

        Map<Integer, List<Point>> circleMembers = originalPoints.mapPartitionsToPair(iterator -> {
            HashMap<Integer, List<Point>> local = new HashMap<Integer, List<Point>>();
            Map<Long, List<FinalCircleSpec>> cellIndex = circleCellBroadcast.value();
            while (iterator.hasNext()) {
                Point point = iterator.next();
                List<FinalCircleSpec> candidates = cellIndex.get(point.packedCellId);
                if (candidates == null) {
                    continue;
                }
                Point memberCopy = null;
                for (FinalCircleSpec spec : candidates) {
                    if (NumericalCoverage.covers(spec.centerX,spec.centerY,point.x,point.y,dc)) {
                        // Per-source-record coordinate copy only. Circle lists stay independent;
                        // these output points are not mutated after collection.
                        if (shareMemberPoint && memberCopy == null) memberCopy = new Point(point.x, point.y);
                        local.computeIfAbsent(spec.index, ignore -> new ArrayList<Point>())
                                .add(shareMemberPoint ? memberCopy : new Point(point.x, point.y));
                    }
                }
            }
            ArrayList<Tuple2<Integer, List<Point>>> output = new ArrayList<Tuple2<Integer, List<Point>>>(local.size());
            for (Map.Entry<Integer, List<Point>> entry : local.entrySet()) {
                output.add(new Tuple2<Integer, List<Point>>(entry.getKey(), entry.getValue()));
            }
            return output.iterator();
        }).reduceByKey((left, right) -> {
            left.addAll(right);
            return left;
        }).collectAsMap();

        for (int index = 0; index < sortedSkymapList.size(); index++) {
            List<Point> members = circleMembers.get(index);
            sortedSkymapList.get(index).p = members == null ? new ArrayList<Point>() : new ArrayList<Point>(members);
        }
        circleCellBroadcast.destroy();
    }

    static boolean shouldMaterializeFinalMembers(SparkConf conf) {
        return conf.getBoolean("spark.skyline.materializeMembers", true);
    }

    private static HashMap<Double, Circle> skylineCircle(ArrayList<Circle> circles) {
        HashMap<Double, Circle> map = new HashMap<Double, Circle>();
        int max = -1;
        for (Circle circle : circles) {
            if (map.containsKey(circle.discenq)) {
                Circle current = map.get(circle.discenq);
                // Match the local Engine's representative rule so probe-first
                // merging and physical task order cannot decide an objective tie.
                if (circle.cirnum > current.cirnum
                        || circle.cirnum == current.cirnum
                        && (Double.compare(circle.centerX, current.centerX) < 0
                        || Double.compare(circle.centerX, current.centerX) == 0
                        && Double.compare(circle.centerY, current.centerY) < 0)) {
                    map.put(circle.discenq, circle);
                    max = circle.cirnum;
                }
            } else if (circle.cirnum > max) {
                map.put(circle.discenq, circle);
                max = circle.cirnum;
            }
        }
        return map;
    }

    private static long pack(int cellX, int cellY) {
        return (((long) cellX) << 32) ^ (cellY & 0xffffffffL);
    }

    static void validateDynamicCoverage(long originalPointCount, long estimatedAssignedRecords,
            long[] actualCore, long actualAssignedRecords) {
        if (originalPointCount < 0 || estimatedAssignedRecords < 0
                || actualAssignedRecords < 0 || actualCore == null) {
            throw new IllegalArgumentException("negative or missing dynamic coverage");
        }
        long core = 0L;
        for (long value : actualCore) {
            if (value < 0) throw new IllegalArgumentException("negative core count");
            core = Math.addExact(core, value);
        }
        if (core != originalPointCount) {
            throw new IllegalStateException(
                    "core coverage mismatch: " + core + " != " + originalPointCount);
        }
        if (actualAssignedRecords < core) {
            throw new IllegalStateException("actual assigned records below core coverage");
        }
        // estimatedAssignedRecords is a conservative planning value. It is deliberately
        // not compared with actualAssignedRecords, which comes from exact Executor routing.
    }

    static PhysicalBundleShardPlanner.Plan planMaskedPhysicalShards(
            int[][] members, double[] work, long[] core, long[] assigned,
            double budgetFraction, double targetFactor,
            double extraTaskMs, double extraMapMs) {
        return PhysicalBundleShardPlanner.plan(members, work, core, assigned,
                budgetFraction, 4, targetFactor, extraTaskMs, extraMapMs);
    }

    private static int tableCapacity(int expectedSize) {
        int capacity = 1;
        int target = Math.max(4, expectedSize * 4);
        while (capacity < target) {
            capacity <<= 1;
        }
        return capacity;
    }

    private static int hashLong(long key) {
        int hash = (int) (key ^ (key >>> 32));
        hash ^= hash >>> 16;
        hash *= 0x7feb352d;
        hash ^= hash >>> 15;
        hash *= 0x846ca68b;
        hash ^= hash >>> 16;
        return hash;
    }

    private static int hashCellCountKey(long key) {
        // Mix both 32-bit coordinates before truncating. Folding first reduces
        // packed (x,y) to x^y: every diagonal (x,x) then has the same hash.
        // MurmurHash3's 64-bit finalizer preserves entropy from both halves.
        key ^= key >>> 33;
        key *= 0xff51afd7ed558ccdL;
        key ^= key >>> 33;
        key *= 0xc4ceb9fe1a85ec53L;
        key ^= key >>> 33;
        return (int) key;
    }

    private static int unpackCellX(long packed) {
        return (int) (packed >> 32);
    }

    private static int unpackCellY(long packed) {
        return (int) packed;
    }

    public void out(String outputPath, long time) {
        long outputStartNanos = System.nanoTime();
        try {
            File outputFile = new File(outputPath);
            ensureParentDirectory(outputFile);
            if (outputFile.exists()) {
                Files.deleteIfExists(Paths.get(outputPath));
            }

            MemberTextFormatter memberText = new MemberTextFormatter(cacheMemberText);
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
                bw.write("member_text_cache_enabled: " + cacheMemberText + "\r\n");
                bw.write("modules: " + MODULES + "\r\n");
                bw.write("partition_route_path: " + PARTITION_ROUTE_PATH + "\r\n");
                bw.write("transport_path: " + TRANSPORT_PATH + "\r\n");
                bw.write("local_kernel: " + LOCAL_KERNEL + "\r\n");
                bw.write("execution_path: " + EXECUTION_PATH + "\r\n");
                bw.write("global_reduce_path: " + GLOBAL_REDUCE_PATH + "\r\n");
                bw.write("member_materialization_path: "
                        + (partitionedMemberOutput ? "executor_streaming_part_files" : (materializeFinalMembers ? MEMBER_MATERIALIZATION_PATH : "disabled"))
                        + "\r\n");
                bw.write("member_materialization_enabled: " + materializeFinalMembers + "\r\n");
                bw.write("result_fingerprint_scope: "
                        + diagnostics.get("result_fingerprint_scope") + "\r\n");
                RunMetrics.write(bw, time, comparableQueryTime(), s1_read_process_data,
                        s2_plan_cells, s3_clone_assign, s4_local_compute, s5_global_reduce,
                        s6_materialize_final_points, diagnostics, actualPartitionCore,
                        actualPartitionAssigned, partition_number, ResultFingerprint.of(skymap));
                for (Map.Entry<String,Object> entry : diagnostics.entrySet())
                    if (entry.getKey().startsWith("micro_")) bw.write(entry.getKey() + ": " + entry.getValue() + "\r\n");
                bw.write("core_compute_time_s: " + formatSeconds(coreComputeTime()) + "\r\n");
                bw.write("setup_time_s: " + formatSeconds(setupTime()) + "\r\n");
                bw.write("s1_read_process_data_s: " + formatSeconds(s1_read_process_data) + "\r\n");
                bw.write("s2_plan_cells_s: " + formatSeconds(s2_plan_cells) + "\r\n");
                bw.write("s3_clone_assign_s: " + formatSeconds(s3_clone_assign) + "\r\n");
                bw.write("s4_local_compute_s: " + formatSeconds(s4_local_compute) + "\r\n");
                bw.write("s5_global_reduce_s: " + formatSeconds(s5_global_reduce) + "\r\n");
                bw.write("s6_materialize_final_points_s: " + formatSeconds(s6_materialize_final_points) + "\r\n");
                bw.write("skyline_count: " + skymap.size() + "\r\n");
                for (Circle circle : sortedSkymapList) {
                    bw.write(format2(circle.discenq) + " = " + circle.cirnum + " " + format2(circle.centerX) + " "
                            + format2(circle.centerY) + "\r\n");
                    if (circle.p != null) {
                        for (Point point : circle.p) {
                            bw.write("   " + memberText.format(point.x) + "   " + memberText.format(point.y) + "\r\n");
                        }
                    }
                }
            }
            MemberTextFormatter.appendOutputTiming(outputPath,System.nanoTime()-outputStartNanos);
        } catch (IOException e) {
            System.err.println("write result failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void appendEndToEndTime(String outputPath, long endToEndTimeMs) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputPath, true))) {
            bw.write("end_to_end_time_s: " + formatSeconds(endToEndTimeMs) + "\r\n");
        } catch (IOException e) {
            System.err.println("append end-to-end time failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void ensureParentDirectory(File outputFile) throws IOException {
        File parent = outputFile.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists()) {
            Files.createDirectories(parent.toPath());
        }
    }

    private void capturePartitionCloneStats(long originalPointCount, JavaPairRDD<Integer, Point> partitionedPoints) {
        List<PartitionMetrics> perPartition = new ArrayList<PartitionMetrics>(partitionedPoints.mapPartitionsWithIndex((partitionId, iterator) -> {
            long assignedPoints = 0L;
            long haloPoints = 0L;
            HashSet<Integer> sourcePartitions = new HashSet<Integer>();
            while (iterator.hasNext()) {
                Point point = iterator.next()._2();
                assignedPoints++;
                sourcePartitions.add(point.ownerPartitionId);
                if (point.is_clone) {
                    haloPoints++;
                }
            }
            long corePoints = assignedPoints - haloPoints;
            return Collections.singletonList(
                    new PartitionMetrics(partitionId, corePoints, haloPoints, sourcePartitions.size())
            ).iterator();
        }, true).collect());

        recordPartitionCloneStats(originalPointCount, perPartition);
    }

    private void recordPartitionCloneStats(long originalPointCount, List<PartitionMetrics> source) {
        List<PartitionMetrics> perPartition = new ArrayList<>(source);
        Collections.sort(perPartition, new Comparator<PartitionMetrics>() {
            @Override
            public int compare(PartitionMetrics left, PartitionMetrics right) {
                return Integer.compare(left.partitionId, right.partitionId);
            }
        });

        long totalAssignedPoints = 0L;
        long totalClonePoints = 0L;
        actualPartitionCore = new long[partition_number];
        actualPartitionAssigned = new long[partition_number];
        partitionCloneStatsOutput = new ArrayList<String>();
        for (PartitionMetrics metric : perPartition) {
            actualPartitionCore[metric.partitionId] = metric.corePoints;
            actualPartitionAssigned[metric.partitionId] = metric.corePoints + metric.haloPoints;
            totalAssignedPoints += metric.corePoints + metric.haloPoints;
            totalClonePoints += metric.haloPoints;
            double multiplier = metric.corePoints == 0L ? 0.0 : (double) (metric.corePoints + metric.haloPoints) / metric.corePoints;
            partitionCloneStatsOutput.add(String.format(
                    Locale.ROOT,
                    "partition %d: core=%d halo=%d multiplier=%.2f sourcePartitions=%d",
                    metric.partitionId,
                    metric.corePoints,
                    metric.haloPoints,
                    multiplier,
                    metric.uniqueSourcePartitions
            ));
        }

        diagnostics.put("original_points", originalPointCount);
        diagnostics.put("assigned_points", totalAssignedPoints);
        diagnostics.put("clone_points", totalClonePoints);
        diagnostics.put("clone_ratio", originalPointCount == 0L ? 0.0 : (double) totalClonePoints / originalPointCount);
    }

    private void printRunSummary(String outputPath, long totalTimeMs) {
        System.out.println("method_profile=" + profile.id());
        System.out.println("method_composition=" + diagnostics.get("method_composition"));
        System.out.println("partitioning_strategy=" + diagnostics.get("partitioning_strategy"));
        System.out.println("cell_ordering=" + diagnostics.get("cell_ordering"));
        System.out.println("local_engine_class=" + diagnostics.get("local_engine_class"));
        for (String line : partitionCloneStatsOutput) {
            System.out.println(line);
        }
        for (String key : new String[]{"routing_batch_records", "routing_batch_size", "compact_cell_statistics", "legacy_cell_tie_order", "projected_bound_hits", "projected_candidates", "projected_count_hits", "bundle_max_owners", "bundle_owner_groups", "prepared_indexes", "index_builds", "index_reuses", "index_build_task_ms", "shared_neighborhood", "bundle_groups", "bundle_original_records", "m2_v3_enabled", "masked_union_points", "masked_logical_records", "m2_v3_mask_checks", "m2_v3_mask_filtered", "m2_route_mode", "m2_range_plan_ms", "m2_range_crossed_cuts", "m2_exact_driver_route_lookups", "m2_executor_neighbor_lookups", "m2_estimated_assigned_records", "m2_actual_core_records", "m2_actual_assigned_records", "m2_actual_saved_records",
                "bundle_shared_records", "bundle_saved_records", "bundle_cpu_cap", "bundle_plan_ms", "bundle_boundary_route_cells", "m2_candidate_pairs", "m2_accepted_pairs", "m2_rejected_pairs", "m2_rejected_low_overlap", "m2_rejected_memory_cap", "m2_rejected_negative_benefit", "m2_estimated_saved_records", "m2_estimated_saved_bytes", "m2_estimated_index_saved", "m2_estimated_bundle_cost", "m2_max_group_records", "m2_max_group_owners", "m2_v2_enabled", "m2_v2_query_enabled", "m2_v2_bundle_task_count", "m2_v2_owner_query_maps", "m2_v2_rejected_work", "m2_v2_rejected_records", "m2_v2_max_bundle_work", "m2_v2_max_bundle_records"})
            if (diagnostics.containsKey(key)) System.out.println(key + "=" + diagnostics.get(key));
        System.out.println("original_points=" + diagnostics.get("original_points"));
        System.out.println("assigned_points=" + diagnostics.get("assigned_points"));
        System.out.println("clone_points=" + diagnostics.get("clone_points"));
        System.out.println("clone_ratio=" + diagnostics.get("clone_ratio"));
        System.out.println("total_time_s=" + formatSeconds(totalTimeMs));
        System.out.println("comparable_query_time_s=" + formatSeconds(comparableQueryTime()));
        System.out.println("core_compute_time_s=" + formatSeconds(coreComputeTime()));
        System.out.println("setup_time_s=" + formatSeconds(setupTime()));
        System.out.println("s1_read_process_data_s=" + formatSeconds(s1_read_process_data));
        System.out.println("s2_plan_cells_s=" + formatSeconds(s2_plan_cells));
        System.out.println("s3_clone_assign_s=" + formatSeconds(s3_clone_assign));
        System.out.println("s4_local_compute_s=" + formatSeconds(s4_local_compute));
        System.out.println("s5_global_reduce_s=" + formatSeconds(s5_global_reduce));
        System.out.println("s6_materialize_final_points_s=" + formatSeconds(s6_materialize_final_points));
        System.out.println("member_materialization_enabled=" + materializeFinalMembers);
        System.out.println("result_fingerprint_scope=" + diagnostics.get("result_fingerprint_scope"));
        System.out.println("s2_s3_s4_s5_time_s=" + formatSeconds(s2_plan_cells + s3_clone_assign + s4_local_compute + s5_global_reduce));
        System.out.println("nonempty_cells=" + diagnostics.get("nonempty_cells"));
        System.out.println("neighbor_offsets=" + diagnostics.get("neighbor_offsets"));
        System.out.println("s2_merge_ms=" + diagnostics.get("s2_merge_ms"));
        System.out.println("s2_sort_ms=" + diagnostics.get("s2_sort_ms"));
        System.out.println("s2_assign_ms=" + diagnostics.get("s2_assign_ms"));
        System.out.println("interior_points=" + diagnostics.get("interior_points"));
        System.out.println("boundary_points=" + diagnostics.get("boundary_points"));
        System.out.println("skipped_neighbor_lookups=" + diagnostics.get("skipped_neighbor_lookups"));
        System.out.println("remaining_neighbor_lookups=" + diagnostics.get("remaining_neighbor_lookups"));
        System.out.println("joint_refine_ms=" + diagnostics.get("joint_refine_ms"));
        System.out.println("joint_boundary_before=" + diagnostics.get("joint_boundary_before"));
        System.out.println("joint_boundary_after=" + diagnostics.get("joint_boundary_after"));
        System.out.println("joint_span_before=" + diagnostics.get("joint_span_before"));
        System.out.println("joint_span_after=" + diagnostics.get("joint_span_after"));
        System.out.println("joint_moves=" + diagnostics.get("joint_moves"));
        System.out.println("final_skyline_count=" + finalSkylineCount);
        System.out.println("output=" + new File(outputPath).getAbsolutePath());
    }

    public void json_partition_info(JavaPairRDD<Integer, Point> partitionedPoints) {
        JavaRDD<JSONObject> jsonRDD = partitionedPoints.map(tuple -> {
            JSONObject obj = new JSONObject();
            obj.put("partitionID", tuple._1());
            obj.put("ownerPartitionID", tuple._2().ownerPartitionId);
            obj.put("x", tuple._2().x);
            obj.put("y", tuple._2().y);
            obj.put("isCore", tuple._2().is_core);
            obj.put("isClone", tuple._2().is_clone);
            obj.put("cellX", tuple._2().cellX);
            obj.put("cellY", tuple._2().cellY);
            return obj;
        });
        jsonOutput.put("partition_info", jsonRDD.collect());
    }

    public void out_json(double dc) {
        out_json(dc, jsonOutputPath(null, false));
    }

    static String jsonOutputPath(String outputPath, boolean experimental) {
        return experimental ? outputPath + ".json" : "./plt/output.json";
    }

    private void out_json(double dc, String outPath) {
        try {
            File outputFile = new File(outPath);
            ensureParentDirectory(outputFile);
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
                bw.write('{');
                writeParamsJson(bw, dc);
                bw.write(',');
                writeDiagnosticsJson(bw);
                bw.write(',');
                writeTimeJson(bw);
                bw.write(',');
                writeCirclesJson(bw);
                bw.write('}');
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeParamsJson(BufferedWriter bw, double dc) throws IOException {
        bw.write("\"params_info\":{");
        bw.write("\"is_distri\":\"true\",");
        bw.write("\"dc\":");
        bw.write(formatNumber(dc));
        bw.write(',');
        bw.write("\"partitionNum\":");
        bw.write(Integer.toString(partition_number));
        bw.write(',');
        bw.write("\"cellSizeMultiplier\":");
        bw.write(formatNumber(cellSizeMultiplier));
        bw.write(',');
        bw.write("\"q\":{");
        bw.write("\"x\":");
        bw.write(formatNumber(queryX));
        bw.write(',');
        bw.write("\"y\":");
        bw.write(formatNumber(queryY));
        bw.write("}}");
    }

    private void writeDiagnosticsJson(BufferedWriter bw) throws IOException {
        bw.write("\"diagnostics\":{");
        boolean first = true;
        for (Map.Entry<String, Object> entry : diagnostics.entrySet()) {
            if (!first) {
                bw.write(',');
            }
            first = false;
            writeJsonString(bw, entry.getKey());
            bw.write(':');
            writeJsonValue(bw, entry.getValue());
        }
        if (!first) {
            bw.write(',');
        }
        writeJsonString(bw, "per_partition");
        bw.write(':');
        bw.write('[');
        for (int i = 0; i < partitionCloneStatsOutput.size(); i++) {
            if (i > 0) {
                bw.write(',');
            }
            writeJsonString(bw, partitionCloneStatsOutput.get(i));
        }
        bw.write(']');
        bw.write('}');
    }

    private void writeTimeJson(BufferedWriter bw) throws IOException {
        bw.write("\"time_info\":{");
        bw.write("\"total_time\":\"");
        bw.write(formatSeconds(end_time - start_time));
        bw.write("s\",");
        bw.write("\"end_to_end_time\":\"");
        bw.write(formatSeconds(end_to_end_time));
        bw.write("s\",");
        bw.write("\"s1_read_process_data\":\"");
        bw.write(formatSeconds(s1_read_process_data));
        bw.write("s\",");
        bw.write("\"s2_plan_cells\":\"");
        bw.write(formatSeconds(s2_plan_cells));
        bw.write("s\",");
        bw.write("\"s3_clone_assign\":\"");
        bw.write(formatSeconds(s3_clone_assign));
        bw.write("s\",");
        bw.write("\"s4_local_compute\":\"");
        bw.write(formatSeconds(s4_local_compute));
        bw.write("s\",");
        bw.write("\"s5_global_reduce\":\"");
        bw.write(formatSeconds(s5_global_reduce));
        bw.write("s\",");
        bw.write("\"s6_materialize_final_points\":\"");
        bw.write(formatSeconds(s6_materialize_final_points));
        bw.write("s\",");
        bw.write("\"comparable_query_time\":\"");
        bw.write(formatSeconds(comparableQueryTime()));
        bw.write("s\",");
        bw.write("\"core_compute_time\":\"");
        bw.write(formatSeconds(coreComputeTime()));
        bw.write("s\",");
        bw.write("\"setup_time\":\"");
        bw.write(formatSeconds(setupTime()));
        bw.write("s\"}");
    }

    private void writeCirclesJson(BufferedWriter bw) throws IOException {
        bw.write("\"Circles_info\":[");
        for (int i = 0; i < sortedSkymapList.size(); i++) {
            if (i > 0) {
                bw.write(',');
            }
            Circle circle = sortedSkymapList.get(i);
            bw.write('{');
            bw.write("\"pointsNum\":");
            bw.write(Integer.toString(circle.cirnum));
            bw.write(',');
            bw.write("\"discenq\":");
            bw.write(formatNumber(circle.discenq));
            bw.write(',');
            bw.write("\"cenX\":");
            bw.write(formatNumber(circle.centerX));
            bw.write(',');
            bw.write("\"cenY\":");
            bw.write(formatNumber(circle.centerY));
            bw.write(',');
            if(partitionedMemberOutput)bw.write("\"points_external\":true,");
            bw.write("\"points\":[");
            if (circle.p != null) {
                for (int j = 0; j < circle.p.size(); j++) {
                    if (j > 0) {
                        bw.write(',');
                    }
                    Point point = circle.p.get(j);
                    bw.write('{');
                    bw.write("\"x\":");
                    bw.write(formatNumber(point.x));
                    bw.write(',');
                    bw.write("\"y\":");
                    bw.write(formatNumber(point.y));
                    bw.write('}');
                }
            }
            bw.write(']');
            bw.write('}');
        }
        bw.write(']');
    }

    private void writeJsonValue(BufferedWriter bw, Object value) throws IOException {
        if (value == null) {
            bw.write("null");
        } else if (value instanceof Number || value instanceof Boolean) {
            bw.write(String.valueOf(value));
        } else {
            writeJsonString(bw, String.valueOf(value));
        }
    }

    private void writeJsonString(BufferedWriter bw, String value) throws IOException {
        bw.write('"');
        bw.write(escapeJson(value));
        bw.write('"');
    }

    private String escapeJson(String value) {
        StringBuilder escaped = new StringBuilder(value.length() + 16);
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '\\':
                    escaped.append("\\\\");
                    break;
                case '"':
                    escaped.append("\\\"");
                    break;
                case '\b':
                    escaped.append("\\b");
                    break;
                case '\f':
                    escaped.append("\\f");
                    break;
                case '\n':
                    escaped.append("\\n");
                    break;
                case '\r':
                    escaped.append("\\r");
                    break;
                case '\t':
                    escaped.append("\\t");
                    break;
                default:
                    if (c < 0x20) {
                        escaped.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
                    } else {
                        escaped.append(c);
                    }
                    break;
            }
        }
        return escaped.toString();
    }

    private String formatNumber(double value) {
        if (Math.rint(value) == value) {
            return String.format(Locale.ROOT, "%.0f", value);
        }
        return Double.toString(value);
    }

    private String formatSeconds(long millis) {
        return String.format(Locale.ROOT, "%.3f", millis / 1000.0);
    }

    private long comparableQueryTime() {
        return s3_clone_assign + s4_local_compute + s5_global_reduce + s6_materialize_final_points;
    }

    private long coreComputeTime() {
        return s4_local_compute + s5_global_reduce;
    }

    private long setupTime() {
        return s1_read_process_data + s2_plan_cells;
    }

    private String format2(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
