package com;

import java.util.Arrays;

/** A split must not demote a previously heavy parent behind nearly all ordinary work. */
public final class ShardPriorityFloor {
    public static boolean shouldApply(boolean m2V2QueryEnabled,
            boolean m4PhysicalExecution, boolean baselineReordered,
            boolean calibratedSchedule, String policy, int splitPartitions) {
        return !m2V2QueryEnabled && !m4PhysicalExecution && baselineReordered
                && !calibratedSchedule && "median".equals(policy) && splitPartitions > 0;
    }

    public static double apply(double[] priorities,double[] parentWork,int[] pieces) {
        if(parentWork.length!=pieces.length)throw new IllegalArgumentException("parent length mismatch");
        double[] nonempty=Arrays.stream(parentWork).filter(w->w>0).sorted().toArray();
        double median=nonempty.length==0?0:nonempty[nonempty.length/2];
        int child=0;
        for(int p=0;p<pieces.length;p++)for(int s=0;s<pieces[p];s++) {
            if(pieces[p]>1)priorities[child]=Math.max(priorities[child],median);
            child++;
        }
        if(child!=priorities.length)throw new IllegalArgumentException("child length mismatch");
        return median;
    }
}
