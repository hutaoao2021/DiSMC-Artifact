package com;

import java.io.Serializable;
import java.util.ArrayList;

public class Circle implements Serializable {
    private static final long serialVersionUID = 1L;

    public int id;
    public int k;
    public double dis;
    public double centerX;
    public double centerY;
    public double radius;
    public ArrayList<Point> p = new ArrayList<Point>();
    public double discenq;
    public int cirnum;
    public boolean isdominate;
    public String lowzval;
    public String upperzval;

    public Circle() {
    }

    public Circle(int id, double centerX, double centerY) {
        this.id = id;
        this.centerX = centerX;
        this.centerY = centerY;
    }

    public Circle(double centerX, double centerY) {
        this.centerX = centerX;
        this.centerY = centerY;
    }

    public void setcenterX(double centerX) {
        this.centerX = centerX;
    }

    public double getcenterX() {
        return centerX;
    }

    public void setcenterY(double centerY) {
        this.centerY = centerY;
    }

    public double getcenterY() {
        return centerY;
    }

    public double getDiscenq() {
        return discenq;
    }

    public int getCirnum() {
        return cirnum;
    }

    public ArrayList<Point> getP() {
        return p;
    }

    public void setCirnum(int cirnum) {
        this.cirnum = cirnum;
    }

    public boolean isdominate() {
        return isdominate;
    }

    public void isdominate(boolean dominate) {
        isdominate = dominate;
    }
}
