package com;

import java.util.Arrays;

/** Reusable primitive owner-set for the shared-routing planner. */
public final class DestinationAccumulator {
    private final int[] marks;
    private final int[] values;
    private int stamp = 1;
    private int size;

    public DestinationAccumulator(int ownerCount) {
        if (ownerCount < 1) throw new IllegalArgumentException("ownerCount must be positive");
        marks = new int[ownerCount];
        values = new int[ownerCount];
    }

    public void clear() {
        size = 0;
        if (++stamp == Integer.MAX_VALUE) {
            Arrays.fill(marks, 0);
            stamp = 1;
        }
    }

    public void add(int owner) {
        if (owner < 0 || owner >= marks.length) {
            throw new IllegalArgumentException("owner out of range: " + owner);
        }
        if (marks[owner] != stamp) {
            marks[owner] = stamp;
            values[size++] = owner;
        }
    }

    public int size() { return size; }

    public void sortInPlace() { Arrays.sort(values, 0, size); }

    public int valueAt(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("index=" + index);
        return values[index];
    }

    public int[] copyValues() { return Arrays.copyOf(values, size); }

    /** Compatibility helper for small callers and tests. */
    public int[] sortedValues() {
        sortInPlace();
        return copyValues();
    }
}
