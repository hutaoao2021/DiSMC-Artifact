package com;

import java.math.BigInteger;

public final class HilbertOrder {
    private static final int COORDINATE_BITS = 63;
    private static final int SERIALIZED_WIDTH = BigInteger.ONE.shiftLeft(2 * COORDINATE_BITS)
            .subtract(BigInteger.ONE).toString().length();

    private HilbertOrder() {
    }

    public static BigInteger index(long x, long y, int bits) {
        if (x < 0L || y < 0L) {
            throw new IllegalArgumentException("Hilbert coordinates must be non-negative");
        }
        if (bits < 1 || bits > COORDINATE_BITS) {
            throw new IllegalArgumentException("Hilbert bits must be between 1 and 63");
        }
        BigInteger coordinateX = BigInteger.valueOf(x);
        BigInteger coordinateY = BigInteger.valueOf(y);
        if (coordinateX.bitLength() > bits || coordinateY.bitLength() > bits) {
            throw new IllegalArgumentException("Hilbert coordinate exceeds " + bits + " bits");
        }

        BigInteger distance = BigInteger.ZERO;
        for (BigInteger scale = BigInteger.ONE.shiftLeft(bits - 1);
                scale.signum() > 0; scale = scale.shiftRight(1)) {
            boolean right = coordinateX.and(scale).signum() != 0;
            boolean upper = coordinateY.and(scale).signum() != 0;
            int quadrant = ((right ? 3 : 0) ^ (upper ? 1 : 0));
            distance = distance.add(scale.multiply(scale).multiply(BigInteger.valueOf(quadrant)));
            if (!upper) {
                if (right) {
                    BigInteger reflection = scale.subtract(BigInteger.ONE);
                    coordinateX = reflection.subtract(coordinateX);
                    coordinateY = reflection.subtract(coordinateY);
                }
                BigInteger swap = coordinateX;
                coordinateX = coordinateY;
                coordinateY = swap;
            }
        }
        return distance;
    }

    public static long index31(int x, int y) {
        if (x < 0 || y < 0) {
            throw new IllegalArgumentException("Hilbert coordinates must be non-negative");
        }

        long coordinateX = x;
        long coordinateY = y;
        long distance = 0L;
        for (long scale = 1L << 30; scale > 0L; scale >>= 1) {
            boolean right = (coordinateX & scale) != 0L;
            boolean upper = (coordinateY & scale) != 0L;
            int quadrant = ((right ? 3 : 0) ^ (upper ? 1 : 0));
            distance += scale * scale * quadrant;
            if (!upper) {
                if (right) {
                    long reflection = scale - 1L;
                    coordinateX = reflection - coordinateX;
                    coordinateY = reflection - coordinateY;
                }
                long swap = coordinateX;
                coordinateX = coordinateY;
                coordinateY = swap;
            }
        }
        return distance;
    }

    public static String valueOf(long x, long y) {
        String value = index(x, y, COORDINATE_BITS).toString();
        return Zorder.createExtra(SERIALIZED_WIDTH - value.length()) + value;
    }
}
