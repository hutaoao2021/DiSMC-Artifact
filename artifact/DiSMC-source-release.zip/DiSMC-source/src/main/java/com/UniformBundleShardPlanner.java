package com;

import java.util.Arrays;

public final class UniformBundleShardPlanner {
    public static final class Plan {
        public final int[] pieces;
        public final long extraRecords, recordBudget, targetAnchors;
        public final int physicalTasks;

        private Plan(int[] pieces, long extraRecords, long recordBudget, long targetAnchors, int physicalTasks) {
            this.pieces = pieces.clone();
            this.extraRecords = extraRecords;
            this.recordBudget = recordBudget;
            this.targetAnchors = targetAnchors;
            this.physicalTasks = physicalTasks;
        }
    }

    private UniformBundleShardPlanner() {
    }

    public static Plan plan(int[][] members, long[] core, long[] assigned,
            double fraction, int maxPieces, double targetFactor) {
        if (members == null || members.length == 0 || core == null || assigned == null
                || core.length == 0 || core.length != assigned.length || !Double.isFinite(fraction)
                || fraction < 0 || fraction > 1 || maxPieces < 1 || maxPieces > 4
                || !Double.isFinite(targetFactor) || targetFactor < 1) {
            throw new IllegalArgumentException("invalid uniform shard inputs");
        }
        int[] ownerGroup = new int[core.length];
        Arrays.fill(ownerGroup, -1);
        long totalCore = 0;
        long totalAssigned = 0;
        for (int owner = 0; owner < core.length; owner++) {
            if (core[owner] < 0 || assigned[owner] < core[owner]) throw new IllegalArgumentException("invalid owner counts");
            totalCore = Math.addExact(totalCore, core[owner]);
            totalAssigned = Math.addExact(totalAssigned, assigned[owner]);
        }
        long[] groupAssigned = new long[members.length];
        for (int group = 0; group < members.length; group++) {
            if (members[group] == null || members[group].length == 0) throw new IllegalArgumentException("empty bundle");
            for (int owner : members[group]) {
                if (owner < 0 || owner >= core.length || ownerGroup[owner] != -1) throw new IllegalArgumentException("invalid membership");
                ownerGroup[owner] = group;
                groupAssigned[group] = Math.addExact(groupAssigned[group], assigned[owner]);
            }
        }
        for (int group : ownerGroup) if (group < 0) throw new IllegalArgumentException("missing owner");
        double target = Math.ceil(targetFactor * totalCore / members.length);
        if (!Double.isFinite(target) || target >= Long.MAX_VALUE) throw new IllegalArgumentException("target overflow");
        long targetAnchors = Math.max(1, (long) target);
        long budget = budget(fraction, totalAssigned);
        long extraRecords = 0;
        int[] pieces = new int[core.length];
        Arrays.fill(pieces, 1);
        for (;;) {
            int bestOwner = -1;
            int bestGroup = Integer.MAX_VALUE;
            long bestAdded = 0;
            double bestReduction = 0;
            for (int group = 0; group < members.length; group++) {
                double current = anchorMaximum(members[group], core, pieces);
                if (current <= targetAnchors) continue;
                int rounds = rounds(members[group], pieces);
                for (int owner : members[group]) {
                    int next = pieces[owner] + 1;
                    if (next > maxPieces || core[owner] < 2L * next) continue;
                    long added = next > rounds ? groupAssigned[group] : 0;
                    if (added > budget - extraRecords) continue;
                    pieces[owner]++;
                    double reduction = current - anchorMaximum(members[group], core, pieces);
                    pieces[owner]--;
                    if (reduction > bestReduction || (reduction > 0 && reduction == bestReduction
                            && (group < bestGroup || (group == bestGroup && owner < bestOwner)))) {
                        bestOwner = owner;
                        bestGroup = group;
                        bestAdded = added;
                        bestReduction = reduction;
                    }
                }
            }
            if (bestOwner < 0) break;
            pieces[bestOwner]++;
            extraRecords = Math.addExact(extraRecords, bestAdded);
        }
        int tasks = 0;
        for (int[] group : members) tasks = Math.addExact(tasks, rounds(group, pieces));
        return new Plan(pieces, extraRecords, budget, targetAnchors, tasks);
    }

    static long budget(double fraction, long records) {
        return java.math.BigDecimal.valueOf(fraction).multiply(java.math.BigDecimal.valueOf(records))
                .setScale(0, java.math.RoundingMode.FLOOR).longValueExact();
    }

    private static int rounds(int[] members, int[] pieces) {
        int rounds = 1;
        for (int owner : members) rounds = Math.max(rounds, pieces[owner]);
        return rounds;
    }

    private static double anchorMaximum(int[] members, long[] core, int[] pieces) {
        double maximum = 0;
        for (int round = 0; round < rounds(members, pieces); round++) {
            double anchors = 0;
            for (int owner : members) if (round < pieces[owner]) anchors += (double) core[owner] / pieces[owner];
            maximum = Math.max(maximum, anchors);
        }
        return maximum;
    }
}
