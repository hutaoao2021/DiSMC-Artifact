package com;

import java.util.Arrays;

/** Plans owner pieces against the physical bundle rounds Spark will execute. */
public final class PhysicalBundleShardPlanner {
    public static final class Plan {
        public final BudgetedQueryShards.Plan ownerPlan;
        public final int physicalTasks;
        public final int splitBundles;
        public final long extraPreparedReads;
        public final double predictedOriginalMaximum;
        public final double predictedResidualMaximum;
        public final double predictedSaving;
        public final long rejectedByBudget;
        public final long rejectedByCost;

        private Plan(BudgetedQueryShards.Plan ownerPlan, int physicalTasks,
                int splitBundles, long extraPreparedReads,
                double predictedOriginalMaximum, double predictedResidualMaximum,
                long rejectedByBudget, long rejectedByCost) {
            this.ownerPlan = ownerPlan;
            this.physicalTasks = physicalTasks;
            this.splitBundles = splitBundles;
            this.extraPreparedReads = extraPreparedReads;
            this.predictedOriginalMaximum = predictedOriginalMaximum;
            this.predictedResidualMaximum = predictedResidualMaximum;
            this.predictedSaving = predictedOriginalMaximum - predictedResidualMaximum;
            this.rejectedByBudget = rejectedByBudget;
            this.rejectedByCost = rejectedByCost;
        }
    }

    private PhysicalBundleShardPlanner() { }

    public static final class TaskPrediction implements java.io.Serializable {
        public final double fixedSeconds, variableSeconds, overheadSeconds, totalSeconds;
        public final long proxyRecords;

        private TaskPrediction(double fixed, double variable, double overhead, long proxyRecords) {
            fixedSeconds = fixed;
            variableSeconds = variable;
            overheadSeconds = overhead;
            totalSeconds = fixed + variable + overhead;
            this.proxyRecords = proxyRecords;
            if (!Double.isFinite(totalSeconds)) throw new IllegalArgumentException("prediction overflow");
        }
    }

    public static TaskPrediction predictTask(int[][] members, double[] work, long[] core, long[] assigned,
            BundleShardLayout.Task task, double extraTaskMs, double extraMapMs) {
        validateInputs(members, work, core, assigned, 0, 4, 1, extraTaskMs, extraMapMs);
        if (task == null || task.groupId < 0 || task.groupId >= members.length) throw new IllegalArgumentException("invalid task group");
        long records = 0;
        java.util.HashSet<Integer> group = new java.util.HashSet<Integer>();
        for (int owner : members[task.groupId]) {
            if (owner < 0 || owner >= assigned.length || !group.add(owner)) throw new IllegalArgumentException("invalid membership");
            records = Math.addExact(records, assigned[owner]);
        }
        double variable = 0;
        java.util.HashSet<Integer> lanes = new java.util.HashSet<Integer>();
        for (int lane = 0; lane < task.owners.length; lane++) {
            int owner = task.owners[lane];
            if (!group.contains(owner) || !lanes.add(owner) || task.pieces[lane] < 1
                    || task.pieces[lane] > 4 || task.round < 0 || task.round >= task.pieces[lane]) {
                throw new IllegalArgumentException("invalid active lane");
            }
            variable += CalibratedShardPlanner.variable(work[owner], core[owner]) / task.pieces[lane];
        }
        return new TaskPrediction(CalibratedShardPlanner.fixed(records), variable,
                (extraTaskMs + extraMapMs * task.owners.length) / 1000, records);
    }

    public static Plan plan(int[][] members, double[] work, long[] core,
            long[] assigned, double fraction, int maxPieces, double targetFactor,
            double extraTaskMs, double extraMapMs) {
        validateInputs(members, work, core, assigned, fraction, maxPieces,
                targetFactor, extraTaskMs, extraMapMs);
        int ownerCount = work.length;
        int[] ownerGroup = new int[ownerCount];
        Arrays.fill(ownerGroup, -1);
        long[] groupAssigned = new long[members.length];
        long totalAssigned = 0L;
        for (int owner = 0; owner < ownerCount; owner++) {
            totalAssigned = Math.addExact(totalAssigned, assigned[owner]);
        }
        for (int group = 0; group < members.length; group++) {
            int[] groupMembers = members[group];
            if (groupMembers == null || groupMembers.length == 0) {
                throw new IllegalArgumentException("empty bundle group");
            }
            long records = 0L;
            for (int owner : groupMembers) {
                if (owner < 0 || owner >= ownerCount || ownerGroup[owner] >= 0) {
                    throw new IllegalArgumentException("invalid or duplicate bundle owner");
                }
                ownerGroup[owner] = group;
                records = Math.addExact(records, assigned[owner]);
            }
            groupAssigned[group] = records;
        }
        for (int group : ownerGroup) {
            if (group < 0) throw new IllegalArgumentException("owner missing from bundles");
        }

        double[] variable = new double[ownerCount];
        for (int owner = 0; owner < ownerCount; owner++) {
            variable[owner] = CalibratedShardPlanner.variable(work[owner], core[owner]);
            if (!Double.isFinite(variable[owner])) {
                throw new IllegalArgumentException("owner cost overflow");
            }
        }
        double extraTaskSeconds = extraTaskMs / 1000.0;
        double extraMapSeconds = extraMapMs / 1000.0;
        int[] pieces = new int[ownerCount];
        Arrays.fill(pieces, 1);
        double sumOriginal = 0.0;
        double originalMaximum = 0.0;
        for (int group = 0; group < members.length; group++) {
            double cost = groupMaximum(members[group], pieces, groupAssigned[group],
                    variable, extraTaskSeconds, extraMapSeconds);
            sumOriginal += cost;
            originalMaximum = Math.max(originalMaximum, cost);
        }
        if (!Double.isFinite(sumOriginal)) {
            throw new IllegalArgumentException("group cost overflow");
        }
        double target = targetFactor * sumOriginal / members.length;
        if (!Double.isFinite(target)) throw new IllegalArgumentException("target cost overflow");
        long budget = (long) Math.floor(fraction * totalAssigned);
        long extraRecords = 0L;
        long rejectedByBudget = 0L;
        long rejectedByCost = 0L;

        for (;;) {
            int bestOwner = -1;
            long bestAddedRecords = 0L;
            double bestScore = Double.NEGATIVE_INFINITY;
            double bestNetSaving = Double.NEGATIVE_INFINITY;
            for (int owner = 0; owner < ownerCount; owner++) {
                int newPieces = pieces[owner] + 1;
                if (newPieces > maxPieces || core[owner] < 2L * newPieces) continue;
                int group = ownerGroup[owner];
                double current = groupMaximum(members[group], pieces,
                        groupAssigned[group], variable, extraTaskSeconds, extraMapSeconds);
                if (!(current > target)) continue;
                int currentRounds = groupRounds(members[group], pieces);
                boolean addsRound = newPieces > currentRounds;
                long addedRecords = addsRound ? groupAssigned[group] : 0L;
                if (addedRecords > budget - extraRecords) {
                    rejectedByBudget++;
                    continue;
                }
                pieces[owner] = newPieces;
                double candidate = groupMaximum(members[group], pieces,
                        groupAssigned[group], variable, extraTaskSeconds, extraMapSeconds);
                pieces[owner]--;
                double grossTailSaving = current - candidate;
                double incrementalCost = extraMapSeconds;
                if (addsRound) {
                    incrementalCost += CalibratedShardPlanner.fixed(groupAssigned[group])
                            + extraTaskSeconds;
                }
                double netSaving = grossTailSaving - incrementalCost;
                if (!(netSaving > 0.0) || !Double.isFinite(netSaving)) {
                    rejectedByCost++;
                    continue;
                }
                double score = netSaving / Math.max(1.0, (double) addedRecords);
                int scoreOrder = Double.compare(score, bestScore);
                int savingOrder = Double.compare(netSaving, bestNetSaving);
                if (bestOwner < 0 || scoreOrder > 0
                        || (scoreOrder == 0 && savingOrder > 0)
                        || (scoreOrder == 0 && savingOrder == 0 && owner < bestOwner)) {
                    bestOwner = owner;
                    bestAddedRecords = addedRecords;
                    bestScore = score;
                    bestNetSaving = netSaving;
                }
            }
            if (bestOwner < 0) break;
            pieces[bestOwner]++;
            extraRecords = Math.addExact(extraRecords, bestAddedRecords);
        }

        int ownerTasks = 0;
        int splitOwners = 0;
        int physicalTasks = 0;
        int splitBundles = 0;
        double residualMaximum = 0.0;
        for (int ownerPieces : pieces) {
            ownerTasks = Math.addExact(ownerTasks, ownerPieces);
            if (ownerPieces > 1) splitOwners++;
        }
        for (int group = 0; group < members.length; group++) {
            int rounds = groupRounds(members[group], pieces);
            physicalTasks = Math.addExact(physicalTasks, rounds);
            if (rounds > 1) splitBundles++;
            residualMaximum = Math.max(residualMaximum,
                    groupMaximum(members[group], pieces, groupAssigned[group],
                            variable, extraTaskSeconds, extraMapSeconds));
        }
        long extraPreparedReads = (long) physicalTasks - members.length;
        BudgetedQueryShards.Plan ownerPlan = new BudgetedQueryShards.Plan(
                pieces.clone(), extraRecords, budget, originalMaximum,
                residualMaximum, ownerTasks, splitOwners);
        return new Plan(ownerPlan, physicalTasks, splitBundles, extraPreparedReads,
                originalMaximum, residualMaximum, rejectedByBudget, rejectedByCost);
    }

    public static Plan evaluate(int[][] members, double[] work, long[] core,
            long[] assigned, int[] pieces, double fraction, double extraTaskMs, double extraMapMs) {
        validateInputs(members, work, core, assigned, fraction, 4, 1.0, extraTaskMs, extraMapMs);
        if (pieces == null || pieces.length != work.length) throw new IllegalArgumentException("invalid pieces");
        boolean[] seen = new boolean[work.length];
        double[] variable = new double[work.length];
        int[] unsplit = new int[work.length];
        Arrays.fill(unsplit, 1);
        long totalAssigned = 0;
        int ownerTasks = 0;
        int splitOwners = 0;
        for (int owner = 0; owner < work.length; owner++) {
            if (pieces[owner] < 1 || pieces[owner] > 4
                    || (pieces[owner] > 1 && core[owner] < 2L * pieces[owner])) {
                throw new IllegalArgumentException("invalid responsibility pieces");
            }
            variable[owner] = CalibratedShardPlanner.variable(work[owner], core[owner]);
            if (!Double.isFinite(variable[owner])) throw new IllegalArgumentException("owner cost overflow");
            totalAssigned = Math.addExact(totalAssigned, assigned[owner]);
            ownerTasks = Math.addExact(ownerTasks, pieces[owner]);
            if (pieces[owner] > 1) splitOwners++;
        }
        long extraRecords = 0;
        int physicalTasks = 0;
        int splitBundles = 0;
        double originalMaximum = 0;
        double residualMaximum = 0;
        for (int[] group : members) {
            if (group == null || group.length == 0) throw new IllegalArgumentException("empty bundle");
            long records = 0;
            for (int owner : group) {
                if (owner < 0 || owner >= work.length || seen[owner]) throw new IllegalArgumentException("invalid membership");
                seen[owner] = true;
                records = Math.addExact(records, assigned[owner]);
            }
            int rounds = groupRounds(group, pieces);
            physicalTasks = Math.addExact(physicalTasks, rounds);
            if (rounds > 1) splitBundles++;
            extraRecords = Math.addExact(extraRecords, Math.multiplyExact(records, (long) rounds - 1));
            originalMaximum = Math.max(originalMaximum, groupMaximum(group, unsplit, records, variable, extraTaskMs / 1000, extraMapMs / 1000));
            residualMaximum = Math.max(residualMaximum, groupMaximum(group, pieces, records, variable, extraTaskMs / 1000, extraMapMs / 1000));
        }
        for (boolean included : seen) if (!included) throw new IllegalArgumentException("missing owner");
        long budget = UniformBundleShardPlanner.budget(fraction, totalAssigned);
        if (extraRecords > budget) throw new IllegalArgumentException("read budget exceeded");
        BudgetedQueryShards.Plan ownerPlan = new BudgetedQueryShards.Plan(pieces.clone(), extraRecords,
                budget, originalMaximum, residualMaximum, ownerTasks, splitOwners);
        return new Plan(ownerPlan, physicalTasks, splitBundles, (long) physicalTasks - members.length,
                originalMaximum, residualMaximum, 0, 0);
    }

    private static int groupRounds(int[] members, int[] pieces) {
        int rounds = 1;
        for (int owner : members) rounds = Math.max(rounds, pieces[owner]);
        return rounds;
    }

    private static double groupMaximum(int[] members, int[] pieces,
            long assigned, double[] variable, double extraTaskSeconds,
            double extraMapSeconds) {
        int rounds = groupRounds(members, pieces);
        double maximum = 0.0;
        double fixed = CalibratedShardPlanner.fixed(assigned) + extraTaskSeconds;
        for (int round = 0; round < rounds; round++) {
            double cost = fixed;
            for (int owner : members) {
                if (round < pieces[owner]) {
                    cost += variable[owner] / pieces[owner] + extraMapSeconds;
                }
            }
            if (!Double.isFinite(cost)) throw new IllegalArgumentException("round cost overflow");
            maximum = Math.max(maximum, cost);
        }
        return maximum;
    }

    private static void validateInputs(int[][] members, double[] work, long[] core,
            long[] assigned, double fraction, int maxPieces, double targetFactor,
            double extraTaskMs, double extraMapMs) {
        if (members == null || members.length == 0 || work == null || core == null
                || assigned == null || work.length == 0 || work.length != core.length
                || work.length != assigned.length || !(fraction >= 0.0 && fraction <= 1.0)
                || maxPieces < 1 || !Double.isFinite(targetFactor) || targetFactor < 1.0
                || !Double.isFinite(extraTaskMs) || extraTaskMs < 0.0
                || !Double.isFinite(extraMapMs) || extraMapMs < 0.0) {
            throw new IllegalArgumentException("invalid physical shard planner inputs");
        }
        for (int owner = 0; owner < work.length; owner++) {
            if (!Double.isFinite(work[owner]) || work[owner] < 0.0
                    || core[owner] < 0L || assigned[owner] < core[owner]) {
                throw new IllegalArgumentException("invalid owner statistics");
            }
        }
    }
}
