package com;

import com.cellhalo.CellId;

public final class CellOrdering {
    private CellOrdering() {
    }

    static int compare(MethodProfile profile,
            int leftX, int leftY, int rightX, int rightY) {
        int byOrder;
        if (profile.usesHilbertCellOrder()) {
            byOrder = Long.compareUnsigned(
                    hilbertKey(leftX, leftY), hilbertKey(rightX, rightY));
        } else {
            byOrder = Long.compareUnsigned(
                    CellId.zCode(leftX, leftY), CellId.zCode(rightX, rightY));
        }
        if (byOrder != 0) return byOrder;
        int byX = Integer.compare(leftX, rightX);
        return byX != 0 ? byX : Integer.compare(leftY, rightY);
    }

    static long hilbertKey(int cellX, int cellY) {
        return HilbertOrder.index31(Math.max(0, cellX), Math.max(0, cellY));
    }
}
