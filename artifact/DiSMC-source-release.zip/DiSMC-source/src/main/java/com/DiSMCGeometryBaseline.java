package com;

/** Reference local computation with exactly the DiSMC pair-center arithmetic.
 * Only distributed geometric baselines instantiate this class; the single baseline is unchanged.
 */
public final class DiSMCGeometryBaseline extends EMCSBaseline {
    private final double dc2, twoDc2;
    public DiSMCGeometryBaseline(double radius, int density) {
        super(radius, density);
        dc2 = radius * radius;
        twoDc2 = 4 * radius * radius;
    }
    @Override public Point circleCenter(double x1, double y1, double x2, double y2) {
        double dx = x2-x1, dy = y2-y1;
        return circleCenter(x1,y1,x2,y2,dx*dx+dy*dy);
    }
    private static double geometryDistance(double x1,double y1,double x2,double y2) {
        double dx=x1-x2,dy=y1-y2;
        return Math.sqrt(dx*dx+dy*dy);
    }
    private Point circleCenter(double x1, double y1, double x2, double y2, double d12Squared) {
        if (!MicroPartitionLayout.safeCoordinate(x1) || !MicroPartitionLayout.safeCoordinate(y1)
                || !MicroPartitionLayout.safeCoordinate(x2) || !MicroPartitionLayout.safeCoordinate(y2) || dc < 0.01 || dc > 100000)
            return legacyCircleCenter(x1,y1,x2,y2,d12Squared);
        if (d12Squared <= 0 || d12Squared > twoDc2) return null;
        double dx = x2-x1, dy = y2-y1;
        double middleX = x1+dx/2, middleY = y1+dy/2;
        Point result = new Point();
        if (Math.abs(d12Squared-twoDc2) < 1e-9) {
            result.x = middleX; result.y = middleY; return result;
        }
        // Work in the pair's local frame; global squared coordinates lose precision.
        // Subnormal squared distances can lose a large fraction of the pair norm.
        // Keep ordinary-input arithmetic unchanged; hypot scales tiny components safely.
        double pairNorm = d12Squared < Double.MIN_NORMAL ? Math.hypot(dx,dy) : Math.sqrt(d12Squared);
        double scale = Math.sqrt(Math.max(0,dc2-d12Squared/4))/pairNorm;
        double offsetX = -dy*scale, offsetY = dx*scale;
        // Preserve the reference upper-Y (or right-X for vertical pairs) tie order.
        if (offsetY < 0 || offsetY == 0 && offsetX < 0) {
            offsetX = -offsetX; offsetY = -offsetY;
        }
        double firstX = middleX+offsetX, firstY = middleY+offsetY;
        double secondX = middleX-offsetX, secondY = middleY-offsetY;
        boolean first = geometryDistance(firstX,firstY,q.x,q.y) < geometryDistance(secondX,secondY,q.x,q.y);
        result.x = first ? firstX : secondX;
        result.y = first ? firstY : secondY;
        return result;
    }

    private Point legacyCircleCenter(double x1, double y1, double x2, double y2, double d12Squared) {
        Point p1 = new Point(), p2 = new Point(), result = new Point();
        if (d12Squared > twoDc2) return null;
        if (Math.abs(d12Squared - twoDc2) < 1e-9) {
            result.x = (x1 + x2) / 2;
            result.y = (y1 + y2) / 2;
            return result;
        }
        if (x1 != x2) {
            double c1 = (x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1) / (2 * (x2 - x1));
            double c2 = (y2 - y1) / (x2 - x1);
            double a = c2 * c2 + 1;
            double b = 2 * x1 * c2 - 2 * c1 * c2 - 2 * y1;
            double c = x1 * x1 - 2 * x1 * c1 + c1 * c1 + y1 * y1 - dc2;
            double delta = b * b - 4 * a * c;
            if (delta < 0) return null;
            if (y1 == y2) {
                double middleX = (x1 + x2) / 2;
                double vertical = Math.sqrt(Math.max(0, dc2 - ((x1 - x2) / 2) * ((x1 - x2) / 2)));
                p1.x = middleX; p1.y = y1 + vertical;
                p2.x = middleX; p2.y = y1 - vertical;
            } else {
                p1.y = (-b + Math.sqrt(delta)) / (2 * a);
                p1.x = c1 - c2 * p1.y;
                p2.y = (-b - Math.sqrt(delta)) / (2 * a);
                p2.x = c1 - c2 * p2.y;
            }
        } else {
            double middleY = (y1 + y2) / 2;
            double horizontal = Math.sqrt(Math.max(0, dc2 - ((y1 - y2) / 2) * ((y1 - y2) / 2)));
            p1.y = middleY; p1.x = x1 + horizontal;
            p2.y = middleY; p2.x = x1 - horizontal;
        }
        double first = geometryDistance(p1.x, p1.y, q.x, q.y);
        double second = geometryDistance(p2.x, p2.y, q.x, q.y);
        return first < second ? p1 : p2;
    }

}
