package com;
import java.io.Serializable;import java.util.*;
/** Experimental mergeable four-bin per-cell histogram, without point coordinates. */
public final class CompactCellHashStatistics {
 public static final class Batch implements Serializable {
  private final long[]keys,bins;private final boolean negativeCoordinates;
  private Batch(long[]keys,long[]bins,boolean negative){this.keys=keys;this.bins=bins;negativeCoordinates=negative;}
  public int size(){return keys.length;}
  public long keyAt(int index){return keys[index];}
  public long[] binsAt(int index){return Arrays.copyOfRange(bins,index*4,index*4+4);}
  public CompactCellCounts.Batch cellCounts(){long[]counts=new long[keys.length];for(int i=0;i<counts.length;i++)for(int b=0;b<4;b++)counts[i]=Math.addExact(counts[i],bins[4*i+b]);return new CompactCellCounts.Batch(keys.clone(),counts,negativeCoordinates);}
 }
 private long[]keys=new long[16],bins=new long[64];private int[]slots=new int[32];private int size;private boolean negative;
 private static int hash(long key){key^=key>>>33;key*=0xff51afd7ed558ccdL;key^=key>>>33;key*=0xc4ceb9fe1a85ec53L;key^=key>>>33;return (int)key;}
 private int locate(long key){int slot=hash(key)&(slots.length-1);while(slots[slot]!=0&&keys[slots[slot]-1]!=key)slot=(slot+1)&(slots.length-1);return slot;}
 private int index(long key){int slot=locate(key);if(slots[slot]!=0)return slots[slot]-1;
  if(size>=slots.length/2){if(slots.length>=1<<30)throw new IllegalStateException("too many cells");slots=new int[slots.length*2];for(int i=0;i<size;i++)slots[locate(keys[i])]=i+1;slot=locate(key);}
  if(size==keys.length){keys=Arrays.copyOf(keys,keys.length*2);bins=Arrays.copyOf(bins,Math.multiplyExact(keys.length,4));}
  keys[size]=key;slots[slot]=size+1;negative|=(int)(key>>32)<0||(int)key<0;return size++;
 }
 public void add(long cell,long id){int i=index(cell),b=BudgetedQueryShards.shard(id,4);bins[i*4+b]=Math.addExact(bins[i*4+b],1);}
 public long[] bins(long cell){int slot=locate(cell);if(slots[slot]==0)throw new IllegalArgumentException("missing cell");int i=slots[slot]-1;return Arrays.copyOfRange(bins,4*i,4*i+4);}
 public Batch snapshot(){return new Batch(Arrays.copyOf(keys,size),Arrays.copyOf(bins,size*4),negative);}
 public void merge(Batch batch){if(batch==null)throw new IllegalArgumentException("missing batch");for(int j=0;j<batch.keys.length;j++){int i=index(batch.keys[j]);for(int b=0;b<4;b++){long delta=batch.bins[4*j+b];if(delta<0)throw new IllegalArgumentException("negative count");bins[4*i+b]=Math.addExact(bins[4*i+b],delta);}}}
}
