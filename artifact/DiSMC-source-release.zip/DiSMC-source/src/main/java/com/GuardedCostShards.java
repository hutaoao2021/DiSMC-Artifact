package com;

/** Preserve the original plan, then spend only its unused read budget on predicted benefit. */
public final class GuardedCostShards {
    public static BudgetedQueryShards.Plan plan(double[] work,long[] core,long[] assigned,double fraction,int maxPieces) {
        BudgetedQueryShards.Plan baseline=BudgetedQueryShards.plan(work,core,assigned,fraction,maxPieces);
        int[] pieces=baseline.pieces.clone();long extra=baseline.extraRecords;
        double[] cost=CalibratedShardPlanner.costs(work,core,assigned);
        double sum=0,original=0;
        for(double c:cost){if(!Double.isFinite(c))throw new IllegalArgumentException("cost overflow");sum+=c;original=Math.max(original,c);}
        double target=work.length==0?0:1.5*sum/work.length;
        for(;;) {
            int best=-1;double bestGainPerRecord=0;
            for(int i=0;i<pieces.length;i++) {
                if(pieces[i]>=maxPieces || core[i]<2L*(pieces[i]+1) || assigned[i]>baseline.recordBudget-extra)continue;
                double fixed=CalibratedShardPlanner.fixed(assigned[i]);
                double variable=CalibratedShardPlanner.variable(work[i],core[i]);
                if(fixed+variable/pieces[i]<=target)continue;
                double gain=variable/(pieces[i]*(pieces[i]+1.0))-fixed;
                double gainPerRecord=gain/Math.max(1L,assigned[i]);
                if(gainPerRecord>bestGainPerRecord){bestGainPerRecord=gainPerRecord;best=i;}
            }
            if(best<0)break;
            pieces[best]++;extra+=assigned[best];
        }
        int tasks=0,split=0;double residual=0;
        for(int i=0;i<pieces.length;i++) {
            tasks+=pieces[i];if(pieces[i]>1)split++;
            residual=Math.max(residual,CalibratedShardPlanner.fixed(assigned[i])+
                    CalibratedShardPlanner.variable(work[i],core[i])/pieces[i]);
        }
        return new BudgetedQueryShards.Plan(pieces,extra,baseline.recordBudget,original,residual,tasks,split);
    }
}
