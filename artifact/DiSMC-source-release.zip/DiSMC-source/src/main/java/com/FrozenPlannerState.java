package com;
import java.io.*;
import java.nio.file.*;
import java.util.*;
/** Trusted local experiment state. Not an online planner or untrusted-file interface. */
public final class FrozenPlannerState implements Serializable {
 private static final long serialVersionUID=1L;
 private static final String FORMAT="dismc-frozen-calibration-v1";
 public final MicroPartitionPopulation.Statistics population;
 public final double[] work;
 public final ProbeDominanceFrontier frontier;
 public final Map<Integer,long[]> completedAnchors;
 public final List<HashMap<Double,Circle>> probeSkylines;
 public final long[] probeCounters;
 public FrozenPlannerState(MicroPartitionPopulation.Statistics population,double[] work,
   ProbeDominanceFrontier frontier,Map<Integer,long[]> completed,List<HashMap<Double,Circle>> skylines,long[] counters) {
  if(population==null||work==null||frontier==null||completed==null||skylines==null||counters==null)throw new IllegalArgumentException("Missing frozen state");
  this.population=population;this.work=work.clone();this.frontier=frontier;
  this.completedAnchors=new HashMap<>();for(Map.Entry<Integer,long[]> e:completed.entrySet())this.completedAnchors.put(e.getKey(),e.getValue().clone());
  this.probeSkylines=new ArrayList<>();for(HashMap<Double,Circle> s:skylines)this.probeSkylines.add(new HashMap<>(s));
  this.probeCounters=counters.clone();validate();
 }
 private void validate(){
  if(population==null||work==null||frontier==null||completedAnchors==null||probeSkylines==null||probeCounters==null)throw new IllegalArgumentException("Missing frozen fields");
  new MicroPartitionPopulation.Statistics(population.originalAssigned,population.core,population.candidates,population.dependencyInputs);
  for(MicroPartitionLayout.Candidate c:population.candidates){
   if(c==null||c.owner<0||c.owner>=work.length||c.pieces<1)throw new IllegalArgumentException("Invalid frozen candidate");
   for(int lane=0;lane<c.pieces;lane++)if(!Double.isFinite(c.work(lane))||c.work(lane)<0)throw new IllegalArgumentException("Invalid candidate work");
  }
  for(HashMap<Double,Circle> sky:probeSkylines){
   if(sky==null)throw new IllegalArgumentException("Missing retained skyline");
   for(Circle c:sky.values())if(c==null||!Double.isFinite(c.discenq)||c.discenq<0||c.cirnum<0)throw new IllegalArgumentException("Invalid retained circle");
  }
  if(work.length!=population.originalAssigned.length||probeCounters.length!=10)throw new IllegalArgumentException("Frozen dimensions mismatch");
  for(double x:work)if(!Double.isFinite(x)||x<0)throw new IllegalArgumentException("Invalid frozen work");
  for(Map.Entry<Integer,long[]> e:completedAnchors.entrySet()){
   if(e.getKey()==null||e.getKey()<0||e.getKey()>=work.length||e.getValue()==null)throw new IllegalArgumentException("Invalid completed owner");
   Set<Long> seen=new HashSet<>();for(long id:e.getValue())if(!seen.add(id))throw new IllegalArgumentException("Duplicate completed identity");
  }
 }
 /** Use the captured completed IDs only when completion reuse R is enabled. */
 public Map<Integer,long[]> replayCompletedAnchors(boolean reuse) {
  if(!reuse) return Collections.emptyMap();
  Map<Integer,long[]> selected=new HashMap<>();
  for(Map.Entry<Integer,long[]> entry:completedAnchors.entrySet())selected.put(entry.getKey(),entry.getValue().clone());
  return selected;
 }
 /** Transfer captured frontier witnesses to formal execution only when W is enabled. */
 public ProbeDominanceFrontier replayProbeFrontier(boolean transfer) {
  return transfer ? frontier : ProbeDominanceFrontier.EMPTY;
 }
 public void write(Path path,String context)throws IOException{
  if(context==null||context.isEmpty())throw new IllegalArgumentException("Missing frozen context");
  validate();
  try(ObjectOutputStream out=new ObjectOutputStream(Files.newOutputStream(path,StandardOpenOption.CREATE_NEW))){out.writeUTF(FORMAT);out.writeUTF(context);out.writeObject(this);}
 }
 public static String sha256(Path path)throws IOException{
  try{
   java.security.MessageDigest digest=java.security.MessageDigest.getInstance("SHA-256");
   try(InputStream in=Files.newInputStream(path)){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)digest.update(buffer,0,n);}
   StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format("%02x",b&255));return hex.toString();
  }catch(java.security.NoSuchAlgorithmException e){throw new IOException(e);}
 }
 public static FrozenPlannerState read(Path path,String expected)throws IOException{
  if(expected==null||expected.isEmpty())throw new IllegalArgumentException("Missing frozen context");
  try(ObjectInputStream in=new ObjectInputStream(Files.newInputStream(path))){
   if(!FORMAT.equals(in.readUTF())||!expected.equals(in.readUTF()))throw new IOException("Frozen source/query/layout context mismatch");
   Object value=in.readObject();if(!(value instanceof FrozenPlannerState))throw new IOException("Wrong frozen state type");
   FrozenPlannerState state=(FrozenPlannerState)value;state.validate();return state;
  }catch(ClassNotFoundException|RuntimeException e){throw new IOException("Invalid frozen state",e);}
 }
}
