package com;

import java.io.Serializable;
import java.util.Arrays;

/** Immutable owner-to-bundle query layout used by the bundle-level RDD. */
public final class BundleQueryLayout implements Serializable {
    public static final class Task implements Serializable {
        public final int groupId;
        public final int[] owners;
        public final int[] slots;
        public final int[] pieces;
        public final long[] ownerWork;
        public final long work;

        private Task(int groupId, int[] owners, int[] slots, int[] pieces,
                long[] ownerWork, long work) {
            this.groupId = groupId;
            this.owners = owners;
            this.slots = slots;
            this.pieces = pieces;
            this.ownerWork = ownerWork;
            this.work = work;
        }

        public long outputMaps() {
            long total = 0L;
            for (int value : pieces) total = Math.addExact(total, value);
            return total;
        }
    }

    private final Task[] tasks;
    private final int[] groupByOwner;
    private final long totalOutputMaps;

    private BundleQueryLayout(Task[] tasks, int[] groupByOwner, long totalOutputMaps) {
        this.tasks = tasks;
        this.groupByOwner = groupByOwner;
        this.totalOutputMaps = totalOutputMaps;
    }

    public static BundleQueryLayout from(int[][] members, int[] pieces, long[] ownerWork) {
        int[] ownerSlots = new int[pieces == null ? 0 : pieces.length];
        if (members != null) for (int[] group : members) {
            if (group == null) continue;
            for (int slot = 0; slot < group.length; slot++) {
                if (group[slot] >= 0 && group[slot] < ownerSlots.length) ownerSlots[group[slot]] = slot;
            }
        }
        return from(members, ownerSlots, pieces, ownerWork);
    }

    public static BundleQueryLayout from(int[][] members, int[] ownerSlots,
            int[] pieces, long[] ownerWork) {
        if (members == null || ownerSlots == null || pieces == null || ownerWork == null
                || pieces.length != ownerWork.length || ownerSlots.length != pieces.length) {
            throw new IllegalArgumentException("invalid bundle layout inputs");
        }
        int ownerCount = pieces.length;
        int[] groupByOwner = new int[ownerCount];
        Arrays.fill(groupByOwner, -1);
        Task[] tasks = new Task[members.length];
        long outputMaps = 0L;
        for (int groupId = 0; groupId < members.length; groupId++) {
            int[] groupOwners = members[groupId];
            if (groupOwners == null || groupOwners.length == 0) {
                throw new IllegalArgumentException("empty bundle");
            }
            int[] ownersCopy = groupOwners.clone();
            int[] slotsCopy = new int[ownersCopy.length];
            int[] piecesCopy = new int[ownersCopy.length];
            long[] ownerWorkCopy = new long[ownersCopy.length];
            long work = 0L;
            for (int i = 0; i < ownersCopy.length; i++) {
                int owner = ownersCopy[i];
                if (owner < 0 || owner >= ownerCount || groupByOwner[owner] >= 0) {
                    throw new IllegalArgumentException("owner appears in multiple bundles");
                }
                if (pieces[owner] < 1 || ownerWork[owner] < 0L) {
                    throw new IllegalArgumentException("invalid owner query layout");
                }
                if (ownerSlots[owner] != i || ownerSlots[owner] < 0 || ownerSlots[owner] >= groupOwners.length) {
                    throw new IllegalArgumentException("owner slot does not match bundle position");
                }
                groupByOwner[owner] = groupId;
                slotsCopy[i] = ownerSlots[owner];
                piecesCopy[i] = pieces[owner];
                ownerWorkCopy[i] = ownerWork[owner];
                work = Math.addExact(work, ownerWork[owner]);
            }
            Task task = new Task(groupId, ownersCopy, slotsCopy, piecesCopy,
                    ownerWorkCopy, work);
            tasks[groupId] = task;
            outputMaps = Math.addExact(outputMaps, task.outputMaps());
        }
        for (int owner = 0; owner < groupByOwner.length; owner++) {
            if (groupByOwner[owner] < 0) throw new IllegalArgumentException("owner missing from bundles");
        }
        return new BundleQueryLayout(tasks, groupByOwner, outputMaps);
    }

    public int groupCount() { return tasks.length; }
    public int taskCount() { return tasks.length; }
    public Task task(int groupId) { return tasks[groupId]; }
    public int groupForOwner(int owner) { return groupByOwner[owner]; }
    public long taskWork(int groupId) { return tasks[groupId].work; }
    public long totalOutputMaps() { return totalOutputMaps; }

    public String describe() {
        StringBuilder result = new StringBuilder();
        for (Task task : tasks) {
            result.append(task.groupId).append(':')
                    .append(Arrays.toString(task.owners)).append(':')
                    .append(Arrays.toString(task.slots)).append(':')
                    .append(Arrays.toString(task.pieces)).append(':')
                    .append(task.work).append(';');
        }
        return result.toString();
    }
}
