package com;
import java.util.*;

/** Exact local refinement of an already visible boundary bucket; never stores a query result. */
public final class DenseBoundaryCounter {
    // Short boundary leaves reduce literal point checks; keep the bounded tree depth.
    private static final int LEAF_SIZE=8,MAX_DEPTH=8;
    private final Node root;
    public long lastPointChecks,lastNodeVisits;
    private static final class Node {
        double minX=Double.POSITIVE_INFINITY,minY=minX,maxX=Double.NEGATIVE_INFINITY,maxY=maxX;
        int population;Node left,right;MaskedPreparedNeighborhood.IndexedPoint[] points;
        Node(MaskedPreparedNeighborhood.IndexedPoint[] source,int depth){
            population=source.length;
            for(Point p:source){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}
            if(source.length<=LEAF_SIZE||depth>=MAX_DEPTH){points=source;return;}
            boolean byX=maxX-minX>=maxY-minY;double middle=byX?minX+(maxX-minX)/2:minY+(maxY-minY)/2;
            int low=0;for(Point p:source)if((byX?p.x:p.y)<=middle)low++;
            if(low==0||low==source.length){points=source;return;}
            MaskedPreparedNeighborhood.IndexedPoint[] a=new MaskedPreparedNeighborhood.IndexedPoint[low],b=new MaskedPreparedNeighborhood.IndexedPoint[source.length-low];
            int i=0,j=0;for(MaskedPreparedNeighborhood.IndexedPoint p:source)if((byX?p.x:p.y)<=middle)a[i++]=p;else b[j++]=p;
            left=new Node(a,depth+1);right=new Node(b,depth+1);
        }
    }
    public DenseBoundaryCounter(MaskedPreparedNeighborhood.IndexedPoint[] points){root=new Node(points.clone(),0);}
    public int count(double x,double y,double radiusSquared){lastPointChecks=0;lastNodeVisits=0;return count(root,x,y,radiusSquared);}
    private int count(Node n,double x,double y,double rr){
        lastNodeVisits++;
        double nearX=x<n.minX?n.minX-x:x>n.maxX?x-n.maxX:0;
        double nearY=y<n.minY?n.minY-y:y>n.maxY?y-n.maxY:0;
        if(nearX*nearX+nearY*nearY>rr)return 0;
        double farX=Math.max(Math.abs(x-n.minX),Math.abs(x-n.maxX)),farY=Math.max(Math.abs(y-n.minY),Math.abs(y-n.maxY));
        if(farX*farX+farY*farY<=rr)return n.population;
        if(n.points==null)return count(n.left,x,y,rr)+count(n.right,x,y,rr);
        int total=0;for(Point p:n.points){lastPointChecks++;double dx=x-p.x,dy=y-p.y;if(dx*dx+dy*dy<=rr)total++;}return total;
    }
}
