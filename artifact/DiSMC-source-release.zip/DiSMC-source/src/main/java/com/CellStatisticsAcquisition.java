package com;
import java.util.*;
import org.apache.spark.api.java.JavaRDD;
/** Uses one existing cell-statistics action; hash metadata is opt-in. */
public final class CellStatisticsAcquisition {
 public static final class Result {
  public final List<CompactCellCounts.Batch> cellCounts;
  public final CompactCellHashStatistics hashes;
  public final long histogramMergeNanos;
  /** Exact source population from the same partition census; no additional Spark action. */
  public long sourceCount(){long total=0;for(CompactCellCounts.Batch batch:cellCounts)for(long count:batch.counts)total=Math.addExact(total,count);return total;}
  Result(List<CompactCellCounts.Batch> cells,CompactCellHashStatistics hashes,long mergeNanos){cellCounts=cells;this.hashes=hashes;histogramMergeNanos=mergeNanos;}
 }
 public static Result collect(JavaRDD<Point> points,boolean hashMetadata){
  if(!hashMetadata){List<CompactCellCounts.Batch> cells=points.mapPartitions(iterator->{CompactCellCounts local=new CompactCellCounts();while(iterator.hasNext())local.add(iterator.next().packedCellId,1L);return Collections.singletonList(local.snapshot()).iterator();}).collect();return new Result(cells,null,0);}
  List<CompactCellHashStatistics.Batch> batches=points.mapPartitions(iterator->{CompactCellHashStatistics local=new CompactCellHashStatistics();while(iterator.hasNext()){Point p=iterator.next();local.add(p.packedCellId,p.id);}return Collections.singletonList(local.snapshot()).iterator();}).collect();
  long start=System.nanoTime();CompactCellHashStatistics merged=new CompactCellHashStatistics();List<CompactCellCounts.Batch> cells=new ArrayList<>(batches.size());for(CompactCellHashStatistics.Batch batch:batches){merged.merge(batch);cells.add(batch.cellCounts());}return new Result(cells,merged,System.nanoTime()-start);
 }
 private CellStatisticsAcquisition(){}
}
