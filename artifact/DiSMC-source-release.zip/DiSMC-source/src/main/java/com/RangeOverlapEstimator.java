package com;

/** Conservative owner-interval statistics derived without cell-neighbor lookups. */
public final class RangeOverlapEstimator {
    public static final class Result {
        public final long[] core;
        public final long[] estimatedAssigned;
        public final long[] adjacentOverlap;
        public final long crossedCuts;

        Result(long[] core, long[] estimatedAssigned, long[] adjacentOverlap,
                long crossedCuts) {
            this.core = core;
            this.estimatedAssigned = estimatedAssigned;
            this.adjacentOverlap = adjacentOverlap;
            this.crossedCuts = crossedCuts;
        }
    }

    private RangeOverlapEstimator() { }

    public static Result estimate(long[] cellCounts, int[] ownerByRank,
            int[] minRank, int[] maxRank, int ownerCount) {
        if (cellCounts == null || ownerByRank == null || minRank == null
                || maxRank == null || ownerCount < 1
                || ownerByRank.length != cellCounts.length
                || minRank.length != cellCounts.length
                || maxRank.length != cellCounts.length) {
            throw new IllegalArgumentException("invalid range-estimator inputs");
        }

        int cells = cellCounts.length;
        for (int rank = 0; rank < cells; rank++) {
            int owner = ownerByRank[rank];
            if (cellCounts[rank] < 0 || owner < 0 || owner >= ownerCount
                    || (rank > 0 && owner < ownerByRank[rank - 1])
                    || minRank[rank] < 0 || minRank[rank] > rank
                    || maxRank[rank] < rank || maxRank[rank] >= cells) {
                throw new IllegalArgumentException("invalid range statistics at rank " + rank);
            }
        }

        long[] core = new long[ownerCount];
        long[] assignedDiff = new long[ownerCount + 1];
        long[] overlapDiff = new long[ownerCount];
        long crossedCuts = 0L;
        for (int rank = 0; rank < cells; rank++) {
            long count = cellCounts[rank];
            int owner = ownerByRank[rank];
            int lowOwner = ownerByRank[minRank[rank]];
            int highOwner = ownerByRank[maxRank[rank]];
            core[owner] = Math.addExact(core[owner], count);
            addRange(assignedDiff, lowOwner, highOwner, count);
            if (lowOwner < highOwner) {
                addRange(overlapDiff, lowOwner, highOwner - 1, count);
                crossedCuts = Math.addExact(crossedCuts, highOwner - lowOwner);
            }
        }

        long[] assigned = prefixExact(assignedDiff, ownerCount);
        long[] overlap = prefixExact(overlapDiff, Math.max(0, ownerCount - 1));
        return new Result(core, assigned, overlap, crossedCuts);
    }

    private static void addRange(long[] difference, int low, int high, long value) {
        difference[low] = Math.addExact(difference[low], value);
        difference[high + 1] = Math.subtractExact(difference[high + 1], value);
    }

    private static long[] prefixExact(long[] difference, int length) {
        long[] result = new long[length];
        long running = 0L;
        for (int index = 0; index < length; index++) {
            running = Math.addExact(running, difference[index]);
            result[index] = running;
        }
        return result;
    }
}
