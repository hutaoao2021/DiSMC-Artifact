package com;

import java.io.Serializable;

public final class EngineOptions implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final EngineOptions FULL = new EngineOptions(true, true);

    public final boolean newBounds;
    public final boolean preparedReuse;
    public final boolean geometricBounds;
    public final boolean projectedDedup;
    public final boolean countWindowCache;
    public final boolean anchorBoundary;
    public final boolean deferredCircleAllocation;
    public final boolean spatialCountTree;
    public final boolean denseBoundaryCounting;

    public EngineOptions(boolean newBounds, boolean preparedReuse) {
        this(newBounds, preparedReuse, false);
    }

    public EngineOptions(boolean newBounds, boolean preparedReuse, boolean geometricBounds) {
        this(newBounds,preparedReuse,geometricBounds,false);
    }

    public EngineOptions(boolean newBounds, boolean preparedReuse, boolean geometricBounds, boolean projectedDedup) {
        this(newBounds,preparedReuse,geometricBounds,projectedDedup,false);
    }

    public EngineOptions(boolean newBounds, boolean preparedReuse, boolean geometricBounds,
            boolean projectedDedup, boolean countWindowCache) {
        this(newBounds,preparedReuse,geometricBounds,projectedDedup,countWindowCache,false);
    }

    public EngineOptions(boolean newBounds,boolean preparedReuse,boolean geometricBounds,
            boolean projectedDedup,boolean countWindowCache,boolean anchorBoundary) {
        this(newBounds,preparedReuse,geometricBounds,projectedDedup,countWindowCache,anchorBoundary,false);
    }

    public EngineOptions(boolean newBounds,boolean preparedReuse,boolean geometricBounds,
            boolean projectedDedup,boolean countWindowCache,boolean anchorBoundary,boolean deferredCircleAllocation) {
        this(newBounds,preparedReuse,geometricBounds,projectedDedup,countWindowCache,anchorBoundary,deferredCircleAllocation,false);
    }

    public EngineOptions(boolean newBounds, boolean preparedReuse, boolean geometricBounds,
            boolean projectedDedup, boolean countWindowCache, boolean anchorBoundary,
            boolean deferredCircleAllocation, boolean spatialCountTree) {
        this(newBounds,preparedReuse,geometricBounds,projectedDedup,countWindowCache,anchorBoundary,deferredCircleAllocation,spatialCountTree,false);
    }
    public EngineOptions(boolean newBounds, boolean preparedReuse, boolean geometricBounds,
            boolean projectedDedup, boolean countWindowCache, boolean anchorBoundary,
            boolean deferredCircleAllocation, boolean spatialCountTree, boolean denseBoundaryCounting) {
        if(denseBoundaryCounting&&!geometricBounds)throw new IllegalArgumentException("dense boundary refinement requires geometric counting");
        this.denseBoundaryCounting=denseBoundaryCounting;
        if (spatialCountTree && (geometricBounds || countWindowCache))
            throw new IllegalArgumentException("spatial tree is an alternative counting backend");
        this.spatialCountTree=spatialCountTree;
        this.deferredCircleAllocation=deferredCircleAllocation;
        this.anchorBoundary=anchorBoundary;
        if(countWindowCache && geometricBounds)throw new IllegalArgumentException("count-window reuse requires ordinary counting");
        this.countWindowCache=countWindowCache;
        this.projectedDedup=projectedDedup;
        this.newBounds = newBounds;
        this.preparedReuse = preparedReuse;
        this.geometricBounds = geometricBounds;
    }
}
