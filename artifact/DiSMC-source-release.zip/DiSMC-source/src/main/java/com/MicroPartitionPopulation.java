package com;

import java.io.Serializable;
import java.util.*;
import org.apache.spark.api.java.*;
import org.apache.spark.broadcast.Broadcast;
import scala.Tuple2;

public final class MicroPartitionPopulation {
    public static final class Statistics implements Serializable {
        public final long[] originalAssigned, core;
        public final MicroPartitionLayout.Candidate[] candidates;
        public final long[][] dependencyInputs;
        public final List<String> fallbacks = new ArrayList<>();
        public long sourceRecordsScanned;
        public int dependencyPopulationScans;
        public boolean populationFromCells, populationCollectionFused, populationDirect;
        public double collectMs, populationMs, originalPopulationMs;
        public Statistics(long[] assigned, long[] core, MicroPartitionLayout.Candidate[] candidates, long[][] inputs) {
            this.originalAssigned = assigned.clone(); this.core = core.clone(); this.candidates = candidates.clone();
            this.dependencyInputs = new long[inputs.length][];
            if (assigned.length != core.length || candidates.length != inputs.length) throw new IllegalArgumentException("population dimensions");
            for (int index = 0; index < inputs.length; index++) {
                if (inputs[index].length != candidates[index].pieces) throw new IllegalArgumentException("lane population dimensions");
                this.dependencyInputs[index] = inputs[index].clone();
                for (long count : inputs[index]) if (count < 0) throw new IllegalArgumentException("negative population");
            }
            for (int owner = 0; owner < assigned.length; owner++)
                if (core[owner] < 0 || assigned[owner] < core[owner]) throw new IllegalArgumentException("invalid owner population");
        }
    }

    static Iterator<Tuple2<Integer, CompactPacketBatches.Batch>> route(Iterator<Point> input,
            DistributedSMCGridbaseRebuilt.CellOwnerIndex owners, int[] offsetX, int[] offsetY, int count) {
        int[] groups = new int[count], slots = new int[count];
        for (int owner = 0; owner < count; owner++) groups[owner] = owner;
        return DynamicCompactPacketBatches.route(input, offsetX, offsetY, groups, slots, count,
                cell -> owners.getEncodedOrDefault(cell, -1), cell -> owners.getOrDefault(cell, -1), null, null);
    }

    /** Probe coverage is independent of the later full-anchor collection cap. */
    public static int[] selectProbeOwners(double[] work,long[] core,int limit) {
        if (work.length!=core.length || limit<1) throw new IllegalArgumentException("invalid probe coverage");
        List<Integer> order=new ArrayList<>();
        for(int owner=0;owner<work.length;owner++) {
            if(!Double.isFinite(work[owner]) || work[owner]<0 || core[owner]<0)
                throw new IllegalArgumentException("invalid probe population or work");
            if(core[owner]>0 && work[owner]>0) order.add(owner);
        }
        order.sort(Comparator.<Integer>comparingDouble(owner -> -work[owner]).thenComparingInt(owner -> owner));
        return order.stream().limit(limit).mapToInt(Integer::intValue).toArray();
    }

    /** Reuse the exact census and create geometry only after online cost calibration. */
    public static Statistics refreshCandidates(JavaSparkContext context,JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners,int[] offsetX,int[] offsetY,
            double[] originalWork,double[] calibratedWork,Map<Long,Double> cellWorkPerPoint,
            double radius,String mode,Statistics census) {
        Statistics geometry=observe(context,points,owners,offsetX,offsetY,calibratedWork,cellWorkPerPoint,radius,mode,
                census.core,census.originalAssigned,census.originalPopulationMs);
        Statistics refreshed=SampledAnchorCostProbe.reweight(geometry,originalWork,calibratedWork);
        refreshed.populationFromCells=census.populationFromCells;
        refreshed.sourceRecordsScanned=Math.addExact(refreshed.sourceRecordsScanned,census.sourceRecordsScanned);
        return refreshed;
    }

    public static int[] selectOwners(double[] work, long[] core) {
        if (work.length != core.length) throw new IllegalArgumentException("owner dimensions");
        List<Integer> order = new ArrayList<>();
        for (int owner = 0; owner < work.length; owner++) order.add(owner);
        order.sort(Comparator.<Integer>comparingDouble(owner -> -work[owner]).thenComparingInt(owner -> owner));
        List<Integer> selected = new ArrayList<>(); long used = 0;
        for (int owner : order) {
            if (selected.size() == 8) break;
            if (core[owner] == 0 || core[owner] > 50000 - used) continue;
            selected.add(owner); used = Math.addExact(used, core[owner]);
        }
        return selected.stream().mapToInt(Integer::intValue).toArray();
    }

    public static Statistics observe(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            double[] work, Map<Long, Double> cellWorkPerPoint, double radius, String mode) {
        long start = System.nanoTime(); final int count = work.length;
        List<long[]> partial = points.mapPartitions(input -> {
            long[] counts = new long[count * 2];
            Iterator<Tuple2<Integer, CompactPacketBatches.Batch>> routed = route(input, owners.value(), offsetX, offsetY, count);
            while (routed.hasNext()) {
                Tuple2<Integer, CompactPacketBatches.Batch> packet = routed.next(); int owner = packet._1();
                counts[owner] = Math.addExact(counts[owner], packet._2().size());
                for (int index = 0; index < packet._2().size(); index++)
                    if (packet._2().owners[index] == owner) counts[count + owner] = Math.addExact(counts[count + owner], 1);
            }
            return Collections.singletonList(counts).iterator();
        }).collect();
        long[] assigned = new long[count], core = new long[count];
        for (long[] row : partial) for (int owner = 0; owner < count; owner++) {
            assigned[owner] = Math.addExact(assigned[owner], row[owner]); core[owner] = Math.addExact(core[owner], row[count + owner]);
        }
        long sourceCount = 0; for (long value : core) sourceCount = Math.addExact(sourceCount, value);
        double originalPopulationMs = (System.nanoTime() - start) / 1e6;
        if (mode.equals("none")) {
            Statistics stats = new Statistics(assigned, core, new MicroPartitionLayout.Candidate[0], new long[0][]);
            stats.sourceRecordsScanned = sourceCount; stats.originalPopulationMs = originalPopulationMs;
            stats.populationMs = (System.nanoTime() - start) / 1e6; return stats;
        }
        int[] selected = selectOwners(work, core);
        final boolean[] selectedOwners = new boolean[count]; for (int owner : selected) selectedOwners[owner] = true;
        Broadcast<Map<Long, Double>> weights = context.broadcast(new HashMap<>(cellWorkPerPoint));
        List<Tuple2<Integer, MicroPartitionLayout.Anchor>> collected;
        long collectStart = System.nanoTime();
        try {
            collected = points.mapPartitions(input -> {
                List<Tuple2<Integer, MicroPartitionLayout.Anchor>> anchors = new ArrayList<>();
                while (input.hasNext()) {
                    Point point = input.next(); int owner = owners.value().getOrDefault(point.packedCellId, -1);
                    if (owner >= 0 && selectedOwners[owner]) anchors.add(new Tuple2<>(owner,
                            new MicroPartitionLayout.Anchor(point.id, point.x, point.y, weights.value().getOrDefault(point.packedCellId, 0.0))));
                    if (anchors.size() > 50000) throw new IllegalStateException("bounded anchor collection exceeded");
                }
                return anchors.iterator();
            }).collect();
        } finally { weights.destroy(); }
        if (collected.size() > 50000) throw new IllegalStateException("global anchor collection exceeded");
        return finish(context,points,owners,offsetX,offsetY,radius,mode,start,assigned,core,selected,selectedOwners,collected,
                originalPopulationMs,(System.nanoTime()-collectStart)/1e6,3);
    }

    private static final class Partial implements Serializable {
        final long[] assigned, core;
        final List<Tuple2<Integer,MicroPartitionLayout.Anchor>> anchors = new ArrayList<>();
        Partial(int count) { assigned = new long[count]; core = new long[count]; }
    }

    /** Cell counts select owners before routing, allowing population and anchor collection in one pass. */
    public static Statistics observe(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            double[] work, Map<Long,Double> cellWorkPerPoint, double radius, String mode, long[] knownCore) {
        return observe(context,points,owners,offsetX,offsetY,work,cellWorkPerPoint,radius,mode,knownCore,false);
    }

    public static Statistics observe(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            double[] work, Map<Long,Double> cellWorkPerPoint, double radius, String mode, long[] knownCore, boolean direct) {
        if (knownCore.length != work.length) throw new IllegalArgumentException("core metadata dimensions");
        for (long value : knownCore) if (value < 0) throw new IllegalArgumentException("negative core metadata");
        if (mode.equals("none")) return observe(context,points,owners,offsetX,offsetY,work,cellWorkPerPoint,radius,mode);
        long start = System.nanoTime(); final int count = work.length;
        int[] selected = selectOwners(work,knownCore);
        final boolean[] selectedOwners = new boolean[count]; for (int owner : selected) selectedOwners[owner] = true;
        Broadcast<Map<Long,Double>> weights = context.broadcast(new HashMap<>(cellWorkPerPoint));
        List<Partial> partials;
        try {
            partials = points.mapPartitions(input -> {
                Partial partial = new Partial(count);
                if(direct){
                    DistributedSMCGridbaseRebuilt.CellOwnerIndex localOwners=owners.value();
                    Map<Long,Double> localWeights=weights.value();
                    DestinationAccumulator targets=new DestinationAccumulator(count);
                    while(input.hasNext()){
                        Point point=input.next();
                        int coreOwner=MicroCellPopulation.recipients(localOwners,point.packedCellId,point.cellX,point.cellY,offsetX,offsetY,targets,count);
                        partial.core[coreOwner]=Math.addExact(partial.core[coreOwner],1);
                        for(int t=0;t<targets.size();t++){
                            int owner=targets.valueAt(t);partial.assigned[owner]=Math.addExact(partial.assigned[owner],1);
                        }
                        if(selectedOwners[coreOwner]){
                            partial.anchors.add(new Tuple2<>(coreOwner,new MicroPartitionLayout.Anchor(point.id,point.x,point.y,localWeights.getOrDefault(point.packedCellId,0.0))));
                            if(partial.anchors.size()>50000)throw new IllegalStateException("bounded anchor collection exceeded");
                        }
                    }
                }else{
                Iterator<Tuple2<Integer,CompactPacketBatches.Batch>> routed = route(input,owners.value(),offsetX,offsetY,count);
                while (routed.hasNext()) {
                    Tuple2<Integer,CompactPacketBatches.Batch> packet = routed.next(); int owner = packet._1();
                    partial.assigned[owner] = Math.addExact(partial.assigned[owner],packet._2().size());
                    for (int row = 0; row < packet._2().size(); row++) if (packet._2().owners[row] == owner) {
                        partial.core[owner] = Math.addExact(partial.core[owner],1);
                        if (selectedOwners[owner]) {
                            Point point = packet._2().pointAt(row);
                            partial.anchors.add(new Tuple2<>(owner,new MicroPartitionLayout.Anchor(point.id,point.x,point.y,
                                    weights.value().getOrDefault(point.packedCellId,0.0))));
                            if (partial.anchors.size() > 50000) throw new IllegalStateException("bounded anchor collection exceeded");
                        }
                    }
                }
                }
                return Collections.singletonList(partial).iterator();
            }).collect();
        } finally { weights.destroy(); }
        long[] assigned = new long[count], core = new long[count];
        List<Tuple2<Integer,MicroPartitionLayout.Anchor>> collected = new ArrayList<>();
        for (Partial partial : partials) {
            for (int owner = 0; owner < count; owner++) {
                assigned[owner] = Math.addExact(assigned[owner],partial.assigned[owner]);
                core[owner] = Math.addExact(core[owner],partial.core[owner]);
            }
            collected.addAll(partial.anchors);
            if (collected.size() > 50000) throw new IllegalStateException("global anchor collection exceeded");
        }
        if (!Arrays.equals(core,knownCore)) throw new IllegalStateException("cell/routed core metadata mismatch");
        return finish(context,points,owners,offsetX,offsetY,radius,mode,start,assigned,core,selected,selectedOwners,collected,
                (System.nanoTime()-start)/1e6,0,2,direct);
    }

    private static Statistics finish(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            double radius, String mode, long start, long[] assigned, long[] core, int[] selected, boolean[] selectedOwners,
            List<Tuple2<Integer,MicroPartitionLayout.Anchor>> collected, double originalPopulationMs, double collectMs, int passes) {
        return finish(context,points,owners,offsetX,offsetY,radius,mode,start,assigned,core,selected,selectedOwners,collected,originalPopulationMs,collectMs,passes,false);
    }

    private static Statistics finish(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            double radius, String mode, long start, long[] assigned, long[] core, int[] selected, boolean[] selectedOwners,
            List<Tuple2<Integer,MicroPartitionLayout.Anchor>> collected, double originalPopulationMs, double collectMs, int passes, boolean direct) {
        final int count = core.length;
        long sourceCount = 0; for (long value : core) sourceCount = Math.addExact(sourceCount,value);
        Map<Integer, List<MicroPartitionLayout.Anchor>> byOwner = new HashMap<>();
        for (Tuple2<Integer, MicroPartitionLayout.Anchor> anchor : collected)
            byOwner.computeIfAbsent(anchor._1(), ignored -> new ArrayList<>()).add(anchor._2());
        List<MicroPartitionLayout.Candidate> candidates = new ArrayList<>();
        for (int owner : selected) {
            MicroPartitionLayout.Anchor[] anchors = byOwner.getOrDefault(owner, Collections.emptyList()).toArray(new MicroPartitionLayout.Anchor[0]);
            if (anchors.length != core[owner]) throw new IllegalStateException("core collection mismatch");
            for (String responsibility : new String[]{"spatial", "hash"}) for (int pieces : new int[]{2,4})
                if (anchors.length >= pieces) candidates.add(new MicroPartitionLayout.Candidate(owner, responsibility, pieces, anchors, radius,-1,mode.equals("dependency")));
            if (anchors.length >= 2) for (int axis = 0; axis < 2; axis++) {
                MicroPartitionLayout.Candidate alternative = new MicroPartitionLayout.Candidate(owner,"spatial",2,anchors,radius,axis,mode.equals("dependency"));
                boolean duplicate = false;
                for (MicroPartitionLayout.Candidate existing : candidates)
                    if (existing.owner == owner && existing.signature().equals(alternative.signature())) { duplicate = true; break; }
                if (!duplicate) candidates.add(alternative);
            }
        }
        final MicroPartitionLayout.Candidate[] descriptors = candidates.toArray(new MicroPartitionLayout.Candidate[0]);

        long[][] inputs = new long[descriptors.length][];
        for (int index = 0; index < inputs.length; index++) inputs[index] = new long[descriptors[index].pieces];
        if (mode.equals("dependency")) {
            final int[][] candidateByOwner = new int[count][];
            for (int owner = 0; owner < count; owner++) {
                List<Integer> indices = new ArrayList<>();
                for (int index = 0; index < descriptors.length; index++) if (descriptors[index].owner == owner) indices.add(index);
                candidateByOwner[owner] = indices.stream().mapToInt(Integer::intValue).toArray();
            }
            Broadcast<MicroPartitionLayout.Candidate[]> description = context.broadcast(descriptors);
            List<long[][]> populations;
            try {
                populations = points.mapPartitions(input -> {
                    MicroPartitionLayout.Candidate[] local = description.value(); long[][] counts = new long[local.length][];
                    for (int index = 0; index < local.length; index++) counts[index] = new long[local[index].pieces];
                    if(direct){
                        DistributedSMCGridbaseRebuilt.CellOwnerIndex localOwners=owners.value();
                        DestinationAccumulator targets=new DestinationAccumulator(count);
                        while(input.hasNext()){
                            Point point=input.next();
                            MicroCellPopulation.recipients(localOwners,point.packedCellId,point.cellX,point.cellY,offsetX,offsetY,targets,count);
                            for(int t=0;t<targets.size();t++)for(int index:candidateByOwner[targets.valueAt(t)])
                                for(int lane=0;lane<local[index].pieces;lane++)if(MicroPartitionLayout.matches(local[index],lane,point,true))
                                    counts[index][lane]=Math.addExact(counts[index][lane],1);
                        }
                    }else{
                    Iterator<Tuple2<Integer, CompactPacketBatches.Batch>> routed = route(input, owners.value(), offsetX, offsetY, count);
                    while (routed.hasNext()) {
                        Tuple2<Integer, CompactPacketBatches.Batch> packet = routed.next();
                        for (int row = 0; row < packet._2().size(); row++) {
                            Point point = packet._2().pointAt(row);
                            for (int index : candidateByOwner[packet._1()]) for (int lane = 0; lane < local[index].pieces; lane++)
                                if (MicroPartitionLayout.matches(local[index], lane, point, true)) counts[index][lane] = Math.addExact(counts[index][lane], 1);
                        }
                    }
                    }
                    return Collections.singletonList(counts).iterator();
                }).collect();
            } finally { description.destroy(); }
            for (long[][] population : populations) for (int index = 0; index < inputs.length; index++)
                for (int lane = 0; lane < inputs[index].length; lane++) inputs[index][lane] = Math.addExact(inputs[index][lane], population[index][lane]);
        } else {
            for (int index = 0; index < inputs.length; index++) Arrays.fill(inputs[index],assigned[descriptors[index].owner]);
        }
        Statistics stats = new Statistics(assigned, core, descriptors, inputs);
        stats.dependencyPopulationScans = mode.equals("dependency") ? 1 : 0;
        stats.populationCollectionFused = passes == 2;
        stats.populationDirect = direct;
        stats.originalPopulationMs = originalPopulationMs;
        for (int owner = 0; owner < count; owner++) if (!selectedOwners[owner] && core[owner] > 0)
            stats.fallbacks.add(owner + ":not_selected_or_collection_cap");
        stats.sourceRecordsScanned = Math.multiplyExact(sourceCount, mode.equals("dependency") ? passes : passes-1); stats.collectMs = collectMs;
        stats.populationMs = (System.nanoTime() - start) / 1e6; return stats;
    }
    /** Original populations are exact cell metadata; only selected anchors need collection. */
    public static Statistics observe(JavaSparkContext context, JavaRDD<Point> points,
            Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners, int[] offsetX, int[] offsetY,
            double[] work, Map<Long,Double> cellWorkPerPoint, double radius, String mode,
            long[] knownCore, long[] knownAssigned, double metadataMs) {
        if(knownCore.length!=work.length||knownAssigned.length!=work.length
                ||!Double.isFinite(metadataMs)||metadataMs<0)
            throw new IllegalArgumentException("invalid known population metadata");
        long start=System.nanoTime();
        Statistics seed=new Statistics(knownAssigned,knownCore,new MicroPartitionLayout.Candidate[0],new long[0][]);
        seed.populationFromCells=true;seed.originalPopulationMs=metadataMs;
        if(mode.equals("none")){
            seed.populationMs=metadataMs+(System.nanoTime()-start)/1e6;
            return seed;
        }
        int[] selected=selectOwners(work,knownCore);
        final boolean[] selectedOwners=new boolean[work.length];
        for(int owner:selected)selectedOwners[owner]=true;
        Broadcast<Map<Long,Double>> weights=context.broadcast(new HashMap<>(cellWorkPerPoint));
        List<Tuple2<Integer,MicroPartitionLayout.Anchor>> collected;
        long collectStart=System.nanoTime();
        try{
            collected=points.mapPartitions(input -> {
                List<Tuple2<Integer,MicroPartitionLayout.Anchor>> anchors=new ArrayList<>();
                while(input.hasNext()){
                    Point point=input.next();int owner=owners.value().getOrDefault(point.packedCellId,-1);
                    if(owner<0||owner>=selectedOwners.length)throw new IllegalStateException("missing core owner");
                    if(selectedOwners[owner]){
                        anchors.add(new Tuple2<>(owner,new MicroPartitionLayout.Anchor(point.id,point.x,point.y,
                                weights.value().getOrDefault(point.packedCellId,1.0))));
                        if(anchors.size()>50000)throw new IllegalStateException("bounded anchor collection exceeded");
                    }
                }
                return anchors.iterator();
            }).collect();
        }finally{weights.destroy();}
        if(collected.size()>50000)throw new IllegalStateException("global anchor collection exceeded");
        Statistics result=finish(context,points,owners,offsetX,offsetY,radius,mode,start,
                knownAssigned,knownCore,selected,selectedOwners,collected,metadataMs,
                (System.nanoTime()-collectStart)/1e6,2);
        result.populationFromCells=true;result.populationCollectionFused=false;
        result.populationMs+=metadataMs;
        return result;
    }
    private MicroPartitionPopulation() { }
}
