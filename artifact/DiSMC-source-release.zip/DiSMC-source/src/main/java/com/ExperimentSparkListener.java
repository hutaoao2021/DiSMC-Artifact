package com;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.apache.hadoop.shaded.net.minidev.json.JSONObject;
import org.apache.spark.SparkConf;
import org.apache.spark.Success$;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.executor.TaskMetrics;
import org.apache.spark.scheduler.JobSucceeded$;
import org.apache.spark.scheduler.SparkListener;
import org.apache.spark.scheduler.SparkListenerJobEnd;
import org.apache.spark.scheduler.SparkListenerTaskEnd;
import org.apache.spark.scheduler.SparkListenerTaskStart;
import org.apache.spark.scheduler.SparkListenerStageCompleted;
import org.apache.spark.scheduler.TaskInfo;
import scala.Tuple2;

public final class ExperimentSparkListener extends SparkListener {
    public static final class TaskRow {
        public final int stageId, stageAttempt, partitionId, attempt;
        public final long taskAttemptId, durationMillis, finishTimeMillis;
        public final String executorId, reason;
        public final boolean success;
        public final Long executorRunMillis, executorCpuNanos, gcMillis, shuffleRemoteBytes, shuffleLocalBytes;
        public final Long shuffleReadTotalBytes, shuffleWriteBytes, memorySpillBytes, diskSpillBytes;
        public final Long resultBytes, resultSerializationMillis, executorDeserializeMillis;

        public TaskRow(SparkListenerTaskEnd event) {
            TaskInfo info = event.taskInfo();
            stageId = event.stageId();
            stageAttempt = event.stageAttemptId();
            partitionId = info.index();
            attempt = info.attemptNumber();
            taskAttemptId = info.taskId();
            durationMillis = info.duration();
            finishTimeMillis = info.finishTime();
            executorId = info.executorId();
            success = event.reason() == Success$.MODULE$ && info.successful();
            reason = event.reason() == null ? "unavailable" : event.reason().getClass().getSimpleName();
            TaskMetrics metrics = event.taskMetrics();
            executorRunMillis = metrics == null ? null : metrics.executorRunTime();
            executorCpuNanos = metrics == null ? null : metrics.executorCpuTime();
            gcMillis = metrics == null ? null : metrics.jvmGCTime();
            shuffleRemoteBytes = metrics == null ? null : metrics.shuffleReadMetrics().remoteBytesRead();
            shuffleLocalBytes = metrics == null ? null : metrics.shuffleReadMetrics().localBytesRead();
            shuffleReadTotalBytes = metrics == null ? null : metrics.shuffleReadMetrics().totalBytesRead();
            shuffleWriteBytes = metrics == null ? null : metrics.shuffleWriteMetrics().bytesWritten();
            memorySpillBytes = metrics == null ? null : metrics.memoryBytesSpilled();
            diskSpillBytes = metrics == null ? null : metrics.diskBytesSpilled();
            resultBytes = metrics == null ? null : metrics.resultSize();
            resultSerializationMillis = metrics == null ? null : metrics.resultSerializationTime();
            executorDeserializeMillis = metrics == null ? null : metrics.executorDeserializeTime();
        }
    }

    private final SparkConf conf;
    private final List<TaskRow> tasks = new ArrayList<TaskRow>();
    private final Set<Integer> endedJobs = new HashSet<Integer>();
    private final Set<Long> startedTasks = new HashSet<Long>(), endedTasks = new HashSet<Long>();
    private int[] expectedJobs = new int[0];
    private boolean eventsComplete, queryComplete = true;
    private int failedJobs;
    private String sparkVersion = "unavailable";
    private boolean standalone;
    private List<TransportObservation> transportRows = Collections.emptyList();
    private final Map<String, List<Integer>> stageParents = new TreeMap<String, List<Integer>>();
    private final Map<String, Boolean> stageSuccess = new TreeMap<String, Boolean>();

    public void setTransportRows(List<TransportObservation> rows) {
        transportRows = new ArrayList<TransportObservation>(rows);
    }

    public synchronized void onStageCompleted(SparkListenerStageCompleted event) {
        List<Integer> parents = new ArrayList<Integer>();
        scala.collection.Iterator<Object> input = event.stageInfo().parentIds().iterator();
        while (input.hasNext()) parents.add(((Number) input.next()).intValue());
        stageParents.put(event.stageInfo().stageId() + ":" + event.stageInfo().attemptNumber(), parents);
        stageSuccess.put(event.stageInfo().stageId() + ":" + event.stageInfo().attemptNumber(), event.stageInfo().failureReason().isEmpty());
        notifyAll();
    }

    public ExperimentSparkListener(SparkConf conf) {
        this.conf = conf.clone();
    }

    public static ExperimentSparkListener attach(JavaSparkContext context, ExperimentConfig config) {
        if (!config.observe) return null;
        ExperimentSparkListener listener = new ExperimentSparkListener(context.getConf());
        context.sc().addSparkListener(listener);
        context.setJobGroup(config.runId, "DiSMC experiment " + config.runId);
        return listener;
    }

    public static void writeStandalone(SparkConf conf, boolean queryComplete) throws IOException {
        ExperimentSparkListener listener = new ExperimentSparkListener(conf);
        listener.standalone = true;
        listener.queryComplete = queryComplete;
        listener.eventsComplete = true;
        listener.sparkVersion = "not_applicable";
        listener.write(Paths.get(conf.get("spark.skyline.experiment.outputPrefix")));
    }

    public synchronized void onTaskStart(SparkListenerTaskStart event) {
        startedTasks.add(event.taskInfo().taskId());
    }

    public synchronized void onTaskEnd(SparkListenerTaskEnd event) {
        tasks.add(new TaskRow(event));
        endedTasks.add(event.taskInfo().taskId());
        notifyAll();
    }

    public synchronized void onJobEnd(SparkListenerJobEnd event) {
        endedJobs.add(event.jobId());
        if (event.jobResult() != JobSucceeded$.MODULE$) failedJobs++;
        notifyAll();
    }

    public synchronized List<TaskRow> rows() {
        return Collections.unmodifiableList(new ArrayList<TaskRow>(tasks));
    }

    public synchronized boolean awaitJobs(int[] expected, long timeoutMillis) {
        if (timeoutMillis < 0) throw new IllegalArgumentException("negative listener timeout");
        expectedJobs = expected.clone();
        long start = System.nanoTime();
        for (;;) {
            boolean complete = true;
            for (int job : expected) complete &= endedJobs.contains(job);
            complete &= endedTasks.containsAll(startedTasks);
            if (complete) {
                eventsComplete = true;
                return true;
            }
            long remaining = timeoutMillis - (System.nanoTime() - start) / 1000000;
            if (remaining <= 0) {
                eventsComplete = false;
                return false;
            }
            try {
                wait(remaining);
            } catch (InterruptedException error) {
                Thread.currentThread().interrupt();
                eventsComplete = false;
                return false;
            }
        }
    }

    public void finish(JavaSparkContext context, boolean queryCompleted) {
        queryComplete = queryCompleted;
        sparkVersion = context.version();
        awaitJobs(context.statusTracker().getJobIdsForGroup(conf.get("spark.skyline.experiment.runId", "")), 60000);
        try {
            write(Paths.get(conf.get("spark.skyline.experiment.outputPrefix")));
        } catch (IOException error) {
            if (queryCompleted) throw new IllegalStateException("cannot preserve experiment observation", error);
            System.err.println("Failed-query observation write failed: " + error);
        }
    }

    public void write(Path prefix) throws IOException {
        Path csv = prefix.resolveSibling(prefix.getFileName() + ".spark_tasks.csv");
        Path metadataPath = prefix.resolveSibling(prefix.getFileName() + ".observation.json");
        if (Files.exists(csv) || Files.exists(metadataPath)) throw new java.nio.file.FileAlreadyExistsException(prefix.toString());
        if (prefix.toAbsolutePath().getParent() != null) Files.createDirectories(prefix.toAbsolutePath().getParent());
        List<TaskRow> sorted = new ArrayList<TaskRow>(rows());
        Map<String, Boolean> stageOutcomes;
        synchronized (this) {
            stageOutcomes = new TreeMap<String, Boolean>(stageSuccess);
        }
        sorted.sort(Comparator.comparingInt((TaskRow row) -> row.stageId).thenComparingInt(row -> row.stageAttempt)
                .thenComparingInt(row -> row.partitionId).thenComparingLong(row -> row.taskAttemptId));
        try (BufferedWriter writer = Files.newBufferedWriter(csv, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW)) {
            writer.write("run_id,stage_id,stage_attempt,partition_id,task_attempt_id,attempt,executor_id,success,stage_success,reason,duration_ms,finish_time_ms,executor_run_ms,executor_cpu_ns,gc_ms,shuffle_remote_bytes,shuffle_local_bytes,shuffle_read_total_bytes,shuffle_write_bytes,memory_spill_bytes,disk_spill_bytes,result_bytes,result_serialization_ms,executor_deserialize_ms\n");
            for (TaskRow row : sorted) {
                writer.write(TaskObservation.csv(Arrays.asList(conf.get("spark.skyline.experiment.runId", ""), row.stageId,
                        row.stageAttempt, row.partitionId, row.taskAttemptId, row.attempt, row.executorId, row.success,
                        stageOutcomes.get(row.stageId + ":" + row.stageAttempt), row.reason, row.durationMillis, row.finishTimeMillis, row.executorRunMillis, row.executorCpuNanos,
                        row.gcMillis, row.shuffleRemoteBytes, row.shuffleLocalBytes, row.shuffleReadTotalBytes,
                        row.shuffleWriteBytes, row.memorySpillBytes, row.diskSpillBytes,
                        row.resultBytes, row.resultSerializationMillis, row.executorDeserializeMillis)));
            }
        }
        boolean metricsComplete = true;
        boolean stageMetadataComplete = true;
        Map<String, TaskRow> chosen = new LinkedHashMap<String, TaskRow>();
        for (TaskRow row : sorted) {
            metricsComplete &= row.shuffleReadTotalBytes != null;
            stageMetadataComplete &= stageOutcomes.containsKey(row.stageId + ":" + row.stageAttempt);
            if (row.success && Boolean.TRUE.equals(stageOutcomes.get(row.stageId + ":" + row.stageAttempt))) {
                String key = row.stageId + ":" + row.stageAttempt + ":" + row.partitionId;
                TaskRow previous = chosen.get(key);
                if (previous == null || row.finishTimeMillis < previous.finishTimeMillis
                        || (row.finishTimeMillis == previous.finishTimeMillis && row.taskAttemptId < previous.taskAttemptId)) chosen.put(key, row);
            }
        }
        Map<String, Object> metadata = new TreeMap<String, Object>();
        metadata.put("schema_version", 1);
        metadata.put("run_id", conf.get("spark.skyline.experiment.runId", ""));
        metadata.put("configuration_hash", conf.get("spark.skyline.configurationHash", "unverified"));
        metadata.put("query_complete", queryComplete);
        metadata.put("events_complete", eventsComplete);
        metadata.put("metrics_complete", metricsComplete);
        metadata.put("observation_complete", queryComplete && eventsComplete && metricsComplete && stageMetadataComplete && failedJobs == 0 && (standalone || expectedJobs.length > 0));
        metadata.put("stage_metadata_complete", stageMetadataComplete);
        metadata.put("stage_attempts", stageOutcomes);
        metadata.put("observation_kind", standalone ? "standalone_runtime" : "spark_tasks");
        metadata.put("local_tasks_expected", conf.getBoolean("spark.skyline.experiment.taskDetails", false));
        metadata.put("task_attempt_count", sorted.size());
        metadata.put("successful_partition_attempt_count", chosen.size());
        metadata.put("failed_job_count", failedJobs);
        metadata.put("expected_job_ids", expectedJobs);
        metadata.put("all_attempt_totals", totals(sorted));
        metadata.put("successful_attempt_totals", totals(new ArrayList<TaskRow>(chosen.values())));
        metadata.put("spark_version", sparkVersion);
        metadata.put("java_version", System.getProperty("java.version"));
        metadata.put("model_provenance", "historical_fixed_unverified_source");
        metadata.put("model_read_seconds_per_record", CalibratedShardPlanner.READ);
        metadata.put("model_pair_seconds_per_work", CalibratedShardPlanner.PAIR);
        metadata.put("model_count_seconds_per_work_squared_per_core", CalibratedShardPlanner.COUNT);
        metadata.put("local_timing_scope", "parent access excluding attributed index construction; actual prepare; lane kernel; enclosing local wall");
        Map<String, String> configuration = new TreeMap<String, String>();
        for (Tuple2<String, String> entry : conf.getAll()) {
            if (entry._1().startsWith("spark.skyline.") || entry._1().startsWith("spark.executor.")
                    || Arrays.asList("spark.master", "spark.cores.max", "spark.driver.memory", "spark.serializer",
                    "spark.shuffle.compress", "spark.io.compression.codec", "spark.resultGetter.threads", "spark.task.maxDirectResultSize",
                    "spark.locality.wait", "spark.locality.wait.process", "spark.locality.wait.node", "spark.locality.wait.rack",
                    "spark.scheduler.mode", "spark.scheduler.minRegisteredResourcesRatio",
                    "spark.scheduler.maxRegisteredResourcesWaitingTime", "spark.dynamicAllocation.enabled").contains(entry._1())) configuration.put(entry._1(), entry._2());
        }
        metadata.put("configuration", configuration);
        List<Map<String, Object>> transport = new ArrayList<Map<String, Object>>();
        transportRows.sort(Comparator.comparingInt((TransportObservation row) -> row.groupId)
                .thenComparingLong(row -> row.taskAttemptId));
        for (TransportObservation row : transportRows) transport.add(row.metadata());
        metadata.put("transport", transport);
        metadata.put("transport_decode_scope", "batch expansion, ID/mask merge and block finalization; excludes input wait/deserialization and separately timed signature validation");
        synchronized (this) {
            metadata.put("stage_parents", new TreeMap<String, List<Integer>>(stageParents));
        }
        try (BufferedWriter writer = Files.newBufferedWriter(metadataPath, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW)) {
            writer.write(new JSONObject(metadata).toJSONString());
            writer.newLine();
        }
    }

    private static Map<String, Object> totals(List<TaskRow> rows) {
        long remote = 0, local = 0, read = 0, write = 0;
        boolean available = true;
        for (TaskRow row : rows) {
            if (row.shuffleReadTotalBytes == null) {
                available = false;
            } else {
                remote = Math.addExact(remote, row.shuffleRemoteBytes);
                local = Math.addExact(local, row.shuffleLocalBytes);
                read = Math.addExact(read, row.shuffleReadTotalBytes);
                write = Math.addExact(write, row.shuffleWriteBytes);
            }
        }
        Map<String, Object> totals = new TreeMap<String, Object>();
        totals.put("shuffle_remote_read_bytes", available ? remote : null);
        totals.put("shuffle_local_read_bytes", available ? local : null);
        totals.put("shuffle_read_total_bytes", available ? read : null);
        totals.put("shuffle_write_bytes", available ? write : null);
        return totals;
    }
}
