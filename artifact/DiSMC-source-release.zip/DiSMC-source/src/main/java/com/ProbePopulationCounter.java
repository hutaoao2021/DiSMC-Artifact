package com;

/** Exact dependency populations from the complete parent already present in a probe task. */
public final class ProbePopulationCounter {
    public static long[][] count(MaskedSharedBlock block, int slot, int owner, long expectedParentCount,
            MicroPartitionLayout.Candidate[] candidates) {
        if (block == null || candidates == null || slot < 0 || slot >= block.ownerIds.length
                || block.ownerIds[slot] != owner || expectedParentCount < 0)
            throw new IllegalArgumentException("invalid probe parent population context");
        long[][] counts = new long[candidates.length][];
        int relevant = 0;
        for (int index = 0; index < candidates.length; index++) {
            MicroPartitionLayout.Candidate candidate = candidates[index];
            if (candidate == null) throw new IllegalArgumentException("null candidate");
            counts[index] = new long[candidate.pieces];
            if (candidate.owner == owner) {
                if (!candidate.dependencyInputsEnabled)
                    throw new IllegalArgumentException("dependency envelopes required");
                relevant++;
            }
        }
        if (relevant == 0) throw new IllegalArgumentException("probe owner has no candidates");
        int[] indices = new int[relevant];
        for (int index = 0, used = 0; index < candidates.length; index++)
            if (candidates[index].owner == owner) indices[used++] = index;
        long visible = 0;
        for (int ordinal = 0; ordinal < block.unionPoints.length; ordinal++) {
            if (((block.visibilityMasks[ordinal] & 255) & (1 << slot)) == 0) continue;
            visible = Math.addExact(visible, 1);
            Point point = block.unionPoints[ordinal];
            for (int index : indices) {
                MicroPartitionLayout.Candidate candidate = candidates[index];
                for (int lane = 0; lane < candidate.pieces; lane++)
                    if (MicroPartitionLayout.matches(candidate, lane, point, true))
                        counts[index][lane] = Math.addExact(counts[index][lane], 1);
            }
        }
        if (visible != expectedParentCount)
            throw new IllegalStateException("incomplete probe parent input: " + visible + " != " + expectedParentCount);
        return counts;
    }

    private ProbePopulationCounter() { }
}
