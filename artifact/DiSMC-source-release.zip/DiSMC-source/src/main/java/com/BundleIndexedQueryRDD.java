package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.apache.spark.Dependency;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.CollectionAccumulator;
import org.apache.spark.util.LongAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/**
 * One Spark query partition per owner bundle. A bundle task builds one prepared
 * indexed object, then executes all member owner shards without merging maps.
 */
public final class BundleIndexedQueryRDD extends RDD<HashMap<Double,Circle>> {
    private static final class BundlePartition implements Partition {
        final int id;
        final int groupId;
        final Partition parent;
        BundlePartition(int id, int groupId, Partition parent) {
            this.id=id;this.groupId=groupId;this.parent=parent;
        }
        public int index(){return id;}
        public boolean org$apache$spark$Partition$$super$equals(Object other){return super.equals(other);}
        public boolean equals(Object other){return other instanceof BundlePartition && ((BundlePartition)other).id==id;}
        public int hashCode(){return id;}
    }

    private static final class BundleDependency extends NarrowDependency<SharedNeighborhoodRDD.Block> {
        private final int[] parentIds;
        BundleDependency(RDD<SharedNeighborhoodRDD.Block> parent, BundleQueryLayout layout) {
            super(parent);parentIds=new int[layout.taskCount()];
            for(int i=0;i<parentIds.length;i++) parentIds[i]=i;
        }
        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(
                    Collections.<Object>singletonList(parentIds[child])).asScala().toSeq();
        }
    }

    private static Seq<Dependency<?>> dependency(RDD<SharedNeighborhoodRDD.Block> parent,
            BundleQueryLayout layout) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(
                new BundleDependency(parent,layout))).asScala().toSeq();
    }

    private final RDD<SharedNeighborhoodRDD.Block> parent;
    private final BundleQueryLayout layout;
    private final double dc,cellSize,qx,qy;
    private final int density;
    private final LongAccumulator builds,reuses,buildNanos,candidates,singlePointCandidates,pairCandidates,zChecks,distanceChecks;
    private final CollectionAccumulator<Long> taskTimesMs,bundleTaskTimesMs;
    private final LongAccumulator projectedCandidates,projectedCountHits,projectedBoundHits;
    private final BundlePartition[] partitions;

    public BundleIndexedQueryRDD(JavaRDD<SharedNeighborhoodRDD.Block> blocks,
            BundleQueryLayout layout, double dc, double cellSize, double qx, double qy, int density,
            LongAccumulator builds, LongAccumulator reuses, LongAccumulator nanos,
            LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks, LongAccumulator distanceChecks,
            CollectionAccumulator<Long> taskTimesMs, CollectionAccumulator<Long> bundleTaskTimesMs,
            LongAccumulator projectedCandidates, LongAccumulator projectedCountHits,
            LongAccumulator projectedBoundHits) {
        super(blocks.context(),dependency(blocks.rdd(),layout),
                ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));
        if (blocks.getNumPartitions()!=layout.taskCount())
            throw new IllegalArgumentException("bundle block/task count mismatch");
        parent=blocks.rdd();this.layout=layout;this.dc=dc;this.cellSize=cellSize;
        this.qx=qx;this.qy=qy;this.density=density;this.builds=builds;this.reuses=reuses;
        this.buildNanos=nanos;this.candidates=candidates;this.singlePointCandidates=singlePointCandidates;this.pairCandidates=pairCandidates;this.zChecks=zChecks;
        this.distanceChecks=distanceChecks;this.taskTimesMs=taskTimesMs;
        this.bundleTaskTimesMs=bundleTaskTimesMs;this.projectedCandidates=projectedCandidates;
        this.projectedCountHits=projectedCountHits;this.projectedBoundHits=projectedBoundHits;
        Partition[] parents=parent.partitions();partitions=new BundlePartition[layout.taskCount()];
        for(int i=0;i<partitions.length;i++) partitions[i]=new BundlePartition(i,i,parents[i]);
    }

    public Partition[] getPartitions(){return partitions;}

    public scala.collection.Iterator<HashMap<Double,Circle>> compute(Partition split,TaskContext context) {
        long taskStart=System.nanoTime();
        BundlePartition bundle=(BundlePartition)split;
        scala.collection.Iterator<SharedNeighborhoodRDD.Block> it=parent.iterator(bundle.parent,context);
        if(!it.hasNext())throw new IllegalStateException("missing bundle block");
        SharedNeighborhoodRDD.Block block=it.next();
        if(it.hasNext())throw new IllegalStateException("multiple bundle blocks");

        PreparedNeighborhood prepared;
        synchronized(block) {
            if(block.prepared==null) {
                long start=System.nanoTime();
                block.prepared=new PreparedNeighborhood(block.bySlot,dc,cellSize,qx,qy);
                builds.add(1);buildNanos.add(System.nanoTime()-start);
            } else reuses.add(1);
            prepared=block.prepared;
        }

        ArrayList<HashMap<Double,Circle>> results=new ArrayList<HashMap<Double,Circle>>();
        List<List<BundleQueryExecution.Job>> batches=BundleQueryExecution.ownerBatches(layout.task(bundle.groupId));
        if (batches.size() <= 1) {
            for (BundleQueryExecution.Job job : batches.get(0)) results.add(executeJob(prepared, job));
        } else {
            ExecutorService pool=Executors.newFixedThreadPool(Math.min(2,batches.size()));
            try {
                ArrayList<Future<List<HashMap<Double,Circle>>>> futures=new ArrayList<Future<List<HashMap<Double,Circle>>>>();
                for (final List<BundleQueryExecution.Job> batch : batches) {
                    futures.add(pool.submit(new Callable<List<HashMap<Double,Circle>>>() {
                        public List<HashMap<Double,Circle>> call() {
                            ArrayList<HashMap<Double,Circle>> ownerResults=new ArrayList<HashMap<Double,Circle>>();
                            for (BundleQueryExecution.Job job : batch) ownerResults.add(executeJob(prepared,job));
                            return ownerResults;
                        }
                    }));
                }
                for (Future<List<HashMap<Double,Circle>>> future : futures) results.addAll(future.get());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("bundle query interrupted",e);
            } catch (ExecutionException e) {
                throw new RuntimeException("bundle query failed",e.getCause());
            } finally {
                pool.shutdownNow();
            }
        }
        long elapsed=(System.nanoTime()-taskStart)/1000000L;
        taskTimesMs.add(elapsed);bundleTaskTimesMs.add(elapsed);
        return JavaConverters.asScalaIteratorConverter(results.iterator()).asScala();
    }

    private HashMap<Double,Circle> executeJob(PreparedNeighborhood prepared,
            BundleQueryExecution.Job job) {
        IndexedEMCS emcs=new IndexedEMCS(dc);
        emcs.q.x=qx;emcs.q.y=qy;emcs.density_k=density;emcs.part_id=job.owner;emcs.setCellConfig(cellSize);
        emcs.usePrepared(prepared.views[job.slot],job.piece,job.pieces);emcs.method(dc);
        candidates.add(emcs.candidateCount);singlePointCandidates.add(emcs.singlePointCandidateCount);pairCandidates.add(emcs.pairCandidateCount);zChecks.add(emcs.zWindowChecks);
        distanceChecks.add(emcs.pointDistanceChecks);projectedCandidates.add(emcs.projectedCandidates);
        projectedCountHits.add(emcs.projectedCountHits);projectedBoundHits.add(emcs.projectedBoundHits);
        return emcs.skymap;
    }

    public JavaRDD<HashMap<Double,Circle>> asJava(){
        return JavaRDD.fromRDD(this,ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));
    }
}
