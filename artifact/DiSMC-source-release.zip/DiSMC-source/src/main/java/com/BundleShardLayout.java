package com;

import java.io.Serializable;

/** Physical Spark task rounds expanded from a logical bundle query layout. */
public final class BundleShardLayout implements Serializable {
    public static final class Task implements Serializable {
        public final int id;
        public final int groupId;
        public final int round;
        public final int[] owners;
        public final int[] slots;
        public final int[] pieces;
        public final long work;

        private Task(int id, int groupId, int round, int[] owners,
                int[] slots, int[] pieces, long work) {
            this.id = id;
            this.groupId = groupId;
            this.round = round;
            this.owners = owners.clone();
            this.slots = slots.clone();
            this.pieces = pieces.clone();
            this.work = work;
        }
    }

    private final int groupCount;
    private final Task[] tasks;
    private final int[] parentGroups;
    private final double[] executionWork;
    private final int splitBundleCount;
    private final int[] splitParentGroups;
    private final long totalOutputMaps;

    private BundleShardLayout(int groupCount, Task[] tasks, int[] parentGroups,
            double[] executionWork, int splitBundleCount, int[] splitParentGroups,
            long totalOutputMaps) {
        this.groupCount = groupCount;
        this.tasks = tasks;
        this.parentGroups = parentGroups;
        this.executionWork = executionWork;
        this.splitBundleCount = splitBundleCount;
        this.splitParentGroups = splitParentGroups;
        this.totalOutputMaps = totalOutputMaps;
    }

    public static BundleShardLayout from(BundleQueryLayout logical) {
        if (logical == null || logical.groupCount() == 0) {
            throw new IllegalArgumentException("logical bundle layout is empty");
        }
        int physicalCount = 0;
        int splitBundles = 0;
        for (int group = 0; group < logical.groupCount(); group++) {
            BundleQueryLayout.Task task = logical.task(group);
            if (task == null || task.owners.length == 0
                    || task.owners.length != task.slots.length
                    || task.owners.length != task.pieces.length
                    || task.owners.length != task.ownerWork.length) {
                throw new IllegalArgumentException("invalid logical bundle task");
            }
            int rounds = 1;
            for (int pieces : task.pieces) {
                if (pieces < 1) throw new IllegalArgumentException("invalid piece count");
                rounds = Math.max(rounds, pieces);
            }
            physicalCount = Math.addExact(physicalCount, rounds);
            if (rounds > 1) splitBundles++;
        }

        Task[] tasks = new Task[physicalCount];
        int[] parentGroups = new int[physicalCount];
        double[] work = new double[physicalCount];
        int[] splitParentGroups = new int[splitBundles];
        int splitAt = 0;
        int taskId = 0;
        long outputMaps = 0L;
        for (int group = 0; group < logical.groupCount(); group++) {
            BundleQueryLayout.Task logicalTask = logical.task(group);
            int rounds = 1;
            for (int pieces : logicalTask.pieces) rounds = Math.max(rounds, pieces);
            if (rounds > 1) splitParentGroups[splitAt++] = group;
            for (int round = 0; round < rounds; round++) {
                int jobs = 0;
                for (int pieces : logicalTask.pieces) if (round < pieces) jobs++;
                int[] owners = new int[jobs];
                int[] slots = new int[jobs];
                int[] pieces = new int[jobs];
                long childWork = 0L;
                int at = 0;
                for (int i = 0; i < logicalTask.owners.length; i++) {
                    if (round >= logicalTask.pieces[i]) continue;
                    owners[at] = logicalTask.owners[i];
                    slots[at] = logicalTask.slots[i];
                    pieces[at] = logicalTask.pieces[i];
                    long share = logicalTask.ownerWork[i] / logicalTask.pieces[i];
                    if (logicalTask.ownerWork[i] % logicalTask.pieces[i] != 0L) {
                        share = Math.addExact(share, 1L);
                    }
                    childWork = Math.addExact(childWork, share);
                    at++;
                }
                tasks[taskId] = new Task(taskId, group, round,
                        owners, slots, pieces, childWork);
                parentGroups[taskId] = group;
                work[taskId] = childWork;
                outputMaps = Math.addExact(outputMaps, jobs);
                taskId++;
            }
        }
        if (outputMaps != logical.totalOutputMaps()) {
            throw new IllegalStateException("physical layout lost owner shard jobs");
        }
        return new BundleShardLayout(logical.groupCount(), tasks, parentGroups,
                work, splitBundles, splitParentGroups, outputMaps);
    }

    public int groupCount() { return groupCount; }
    public int taskCount() { return tasks.length; }
    public Task task(int id) { return tasks[id]; }
    public int parentGroup(int id) { return parentGroups[id]; }
    public double[] executionWork() { return executionWork.clone(); }
    public int splitBundleCount() { return splitBundleCount; }
    public int[] splitParentGroups() { return splitParentGroups.clone(); }
    public long totalOutputMaps() { return totalOutputMaps; }
}
