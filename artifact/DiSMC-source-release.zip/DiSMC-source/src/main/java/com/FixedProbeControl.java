package com;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Experimental controls for replayed physical plans, never an online sampling tuner. */
public final class FixedProbeControl {
    private FixedProbeControl() {}
    public static int eligibilitySlots(int frozen, int actual, boolean replay) {
        if (frozen < 0 || actual < 1 || (frozen > 0 && !replay))
            throw new IllegalArgumentException("fixed probe slots require a replayed plan");
        return frozen == 0 ? actual : frozen;
    }
    public static List<String> identityRows(int[] owners, long[][] ids) {
        if (owners.length != ids.length) throw new IllegalArgumentException("invalid probe identities");
        TreeMap<Integer,long[]> ordered = new TreeMap<>();
        for (int i=0;i<owners.length;i++) {
            long[] copy=ids[i].clone(); Arrays.sort(copy);
            if (owners[i]<0 || ordered.put(owners[i],copy)!=null)
                throw new IllegalArgumentException("duplicate or invalid probe owner");
            for (int j=1;j<copy.length;j++) if (copy[j]==copy[j-1])
                throw new IllegalArgumentException("duplicate probe anchor");
        }
        List<String> rows=new ArrayList<>(); rows.add("owner\tanchor_ids");
        for (Map.Entry<Integer,long[]> entry:ordered.entrySet())
            rows.add(entry.getKey()+"\t"+Arrays.toString(entry.getValue()));
        return rows;
    }
    public static String identityHash(int[] owners,long[][] ids) {
        try {
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            for (String row:identityRows(owners,ids)) digest.update((row+"\n").getBytes(StandardCharsets.UTF_8));
            StringBuilder result=new StringBuilder();
            for (byte b:digest.digest()) result.append(String.format(java.util.Locale.ROOT,"%02x",b & 255));
            return result.toString();
        } catch (java.security.NoSuchAlgorithmException e) {throw new IllegalStateException(e);}
    }
}
