package com;

import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Controlled comparison baseline: whole grid cells are the partitioning unit,
 * and a cell is replicated to every owner whose core cells can be within 2dc.
 * This intentionally omits all optimized boundary-routing and workload logic.
 */
public class DistributedSMCGridBoundBaseline {
    private static final class CellCount implements Serializable {
        private static final long serialVersionUID = 1L;
        final long packed;
        final int x;
        final int y;
        final long count;
        final long zCode;

        CellCount(long packed, long count) {
            this.packed = packed;
            this.x = unpackCellX(packed);
            this.y = unpackCellY(packed);
            this.count = count;
            this.zCode = mortonCode(Math.max(0, x), Math.max(0, y));
        }
    }

    private static final class NeighborOffset implements Serializable {
        private static final long serialVersionUID = 1L;
        final int dx;
        final int dy;

        NeighborOffset(int dx, int dy) {
            this.dx = dx;
            this.dy = dy;
        }
    }

    private static final class PartitionStats implements Serializable {
        private static final long serialVersionUID = 1L;
        final int partitionId;
        final long coreCount;
        final long cloneCount;

        PartitionStats(int partitionId, long coreCount, long cloneCount) {
            this.partitionId = partitionId;
            this.coreCount = coreCount;
            this.cloneCount = cloneCount;
        }
    }

    private static final class LocalResult implements Serializable {
        private static final long serialVersionUID = 1L;
        final int partitionId;
        final ArrayList<Circle> skyline;
        final long candidateCount;
        final long singlePointCandidateCount;
        final long pairCandidateCount;
        final long zWindowChecks;
        final long pointDistanceChecks;
        final long computeTimeMs;

        LocalResult(
                int partitionId,
                ArrayList<Circle> skyline,
                long candidateCount,
                long singlePointCandidateCount,
                long pairCandidateCount,
                long zWindowChecks,
                long pointDistanceChecks,
                long computeTimeMs) {
            this.partitionId = partitionId;
            this.skyline = skyline;
            this.candidateCount = candidateCount;
            this.singlePointCandidateCount = singlePointCandidateCount;
            this.pairCandidateCount = pairCandidateCount;
            this.zWindowChecks = zWindowChecks;
            this.pointDistanceChecks = pointDistanceChecks;
            this.computeTimeMs = computeTimeMs;
        }
    }

    private static final class FinalCircleSpec implements Serializable {
        private static final long serialVersionUID = 1L;
        final int index;
        final double centerX;
        final double centerY;

        FinalCircleSpec(int index, double centerX, double centerY) {
            this.index = index;
            this.centerX = centerX;
            this.centerY = centerY;
        }
    }

    public static void main(String[] args) throws Exception {
        long endToEndStartMs = System.currentTimeMillis();
        if (args.length < 2) {
            printUsageAndExit();
        }

        String inputPath = args[0];
        String outputPath = localPath(args[1]);
        int partitionCount = args.length >= 3 ? Integer.parseInt(args[2]) : 10;
        double dc = args.length >= 4 ? Double.parseDouble(args[3]) : 2.0;
        int densityK = args.length >= 5 ? Integer.parseInt(args[4]) : 0;
        double cellSizeMultiplier = args.length >= 6 ? Double.parseDouble(args[5]) : 1.0;
        double queryX = args.length >= 7 ? Double.parseDouble(args[6]) : 15.0;
        double queryY = args.length >= 8 ? Double.parseDouble(args[7]) : 15.0;
        boolean deduplicate = args.length >= 9 ? Boolean.parseBoolean(args[8]) : true;

        validateArguments(partitionCount, dc, densityK, cellSizeMultiplier);
        final double cellSize = dc * cellSizeMultiplier;
        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");

        SparkConf conf = new SparkConf()
                .setAppName("SkylineMCQGridBoundBaseline")
                .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .registerKryoClasses(new Class[]{
                        Point.class, Circle.class, CellCount.class, NeighborOffset.class,
                        PartitionStats.class, LocalResult.class, FinalCircleSpec.class
                })
                .set("spark.default.parallelism", String.valueOf(partitionCount))
                .set("spark.ui.showConsoleProgress", "false");
        if (!conf.contains("spark.master")) {
            conf.setMaster("local[*]");
        }

        ExperimentConfig experiment = ExperimentConfig.from(conf, MethodProfile.GRID_D0);
        experiment.requireSupportedExecution();
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");
        ExperimentSparkListener observer = ExperimentSparkListener.attach(sc, experiment);
        boolean queryCompleted = false;
        Broadcast<Map<Long, Integer>> ownerBroadcast = null;
        Broadcast<List<NeighborOffset>> neighborOffsetsBroadcast = null;
        JavaRDD<Point> points = null;
        JavaPairRDD<Integer, Point> coreByOwner = null;
        JavaPairRDD<Integer, Point> assignedPoints = null;

        long s1ReadPrepareMs;
        long s2PartitionPlanMs;
        long s3ReplicateShuffleMs;
        long s4LocalComputeMs;
        long s5GlobalReduceMs;
        long s6MaterializeMs;
        long originalPointCount;
        long assignedPointCount;
        long clonePointCount;
        long nonemptyCellCount;
        int neighborOffsetCount;
        long maxCore = 0L;
        long minCore = Long.MAX_VALUE;
        long maxAssigned = 0L;
        long minAssigned = Long.MAX_VALUE;
        long localCandidateCount = 0L;
        long localSinglePointCandidateCount = 0L;
        long localPairCandidateCount = 0L;
        long localZWindowChecks = 0L;
        long localPointDistanceChecks = 0L;
        long localTaskComputeSumMs = 0L;
        long localTaskComputeMaxMs = 0L;
        EMCSBaseline finalResult;

        try {
            long s1Start = System.currentTimeMillis();
            points = readAndPreparePoints(sc, inputPath, dc, cellSize, partitionCount, deduplicate)
                    .persist(StorageLevel.MEMORY_AND_DISK());
            originalPointCount = points.count();
            if (originalPointCount == 0L) {
                throw new IllegalArgumentException("Input contains no points");
            }
            s1ReadPrepareMs = System.currentTimeMillis() - s1Start;

            long s2Start = System.currentTimeMillis();
            List<Tuple2<Long, Long>> rawCellCounts = points
                    .mapToPair(point -> new Tuple2<Long, Long>(point.packedCellId, 1L))
                    .reduceByKey((left, right) -> left + right, partitionCount)
                    .collect();
            ArrayList<CellCount> orderedCells = new ArrayList<CellCount>(rawCellCounts.size());
            for (Tuple2<Long, Long> entry : rawCellCounts) {
                orderedCells.add(new CellCount(entry._1(), entry._2()));
            }
            Collections.sort(orderedCells, new Comparator<CellCount>() {
                @Override
                public int compare(CellCount left, CellCount right) {
                    int byMorton = Long.compareUnsigned(left.zCode, right.zCode);
                    if (byMorton != 0) return byMorton;
                    int byX = Integer.compare(left.x, right.x);
                    return byX != 0 ? byX : Integer.compare(left.y, right.y);
                }
            });
            Map<Long, Integer> ownerByCell = assignCellsToPartitions(orderedCells, partitionCount);
            List<NeighborOffset> neighborOffsets = buildNeighborOffsets(cellSize, dc);
            nonemptyCellCount = orderedCells.size();
            neighborOffsetCount = neighborOffsets.size();
            ownerBroadcast = sc.broadcast(ownerByCell);
            neighborOffsetsBroadcast = sc.broadcast(neighborOffsets);

            final Broadcast<Map<Long, Integer>> taskOwners = ownerBroadcast;
            coreByOwner = points.mapToPair(point -> {
                Integer owner = taskOwners.value().get(point.packedCellId);
                if (owner == null) {
                    throw new IllegalStateException("Missing owner for cell " + point.packedCellId);
                }
                return new Tuple2<Integer, Point>(owner, point.assignmentCopy(owner, true));
            }).partitionBy(new HashPartitioner(partitionCount)).persist(StorageLevel.MEMORY_AND_DISK());
            coreByOwner.count();
            s2PartitionPlanMs = System.currentTimeMillis() - s2Start;

            long s3Start = System.currentTimeMillis();
            final Broadcast<List<NeighborOffset>> taskOffsets = neighborOffsetsBroadcast;
            assignedPoints = coreByOwner.flatMapToPair(tuple -> {
                int sourceOwner = tuple._1();
                Point point = tuple._2();
                ArrayList<Tuple2<Integer, Point>> output = new ArrayList<Tuple2<Integer, Point>>();
                output.add(new Tuple2<Integer, Point>(sourceOwner, point.assignmentCopy(sourceOwner, true)));
                HashSet<Integer> destinations = new HashSet<Integer>();
                destinations.add(sourceOwner);
                Map<Long, Integer> owners = taskOwners.value();
                for (NeighborOffset offset : taskOffsets.value()) {
                    Integer target = owners.get(Point.pack(point.cellX + offset.dx, point.cellY + offset.dy));
                    if (target != null && destinations.add(target)) {
                        output.add(new Tuple2<Integer, Point>(target, point.assignmentCopy(sourceOwner, false)));
                    }
                }
                return output.iterator();
            }).partitionBy(new HashPartitioner(partitionCount)).persist(StorageLevel.MEMORY_AND_DISK());

            List<PartitionStats> partitionStats = assignedPoints.mapPartitionsWithIndex((partitionId, iterator) -> {
                long core = 0L;
                long clone = 0L;
                while (iterator.hasNext()) {
                    Point point = iterator.next()._2();
                    if (point.isCore) {
                        core++;
                    } else {
                        clone++;
                    }
                }
                return Collections.singletonList(new PartitionStats(partitionId, core, clone)).iterator();
            }, true).collect();

            assignedPointCount = 0L;
            clonePointCount = 0L;
            for (PartitionStats stats : partitionStats) {
                long assigned = stats.coreCount + stats.cloneCount;
                assignedPointCount += assigned;
                clonePointCount += stats.cloneCount;
                maxCore = Math.max(maxCore, stats.coreCount);
                minCore = Math.min(minCore, stats.coreCount);
                maxAssigned = Math.max(maxAssigned, assigned);
                minAssigned = Math.min(minAssigned, assigned);
            }
            if (minCore == Long.MAX_VALUE) minCore = 0L;
            if (minAssigned == Long.MAX_VALUE) minAssigned = 0L;
            s3ReplicateShuffleMs = System.currentTimeMillis() - s3Start;

            long s4Start = System.currentTimeMillis();
            final double localDc = dc;
            final int localDensityK = densityK;
            final double localQueryX = queryX;
            final double localQueryY = queryY;
            JavaRDD<LocalResult> localResultsRdd = assignedPoints.mapPartitionsWithIndex((partitionId, iterator) -> {
                ArrayList<Point> localPoints = new ArrayList<Point>();
                while (iterator.hasNext()) {
                    localPoints.add(iterator.next()._2());
                }
                sortPoints(localPoints);
                EMCSBaseline local = new DiSMCGeometryBaseline(localDc, localDensityK);
                local.setQueryPoint(localQueryX, localQueryY);
                local.plist = localPoints;
                long taskStart = System.currentTimeMillis();
                local.methodForPartition(partitionId);
                long taskTime = System.currentTimeMillis() - taskStart;
                ArrayList<Circle> skyline = new ArrayList<Circle>(local.skymap.values());
                sortCircles(skyline);
                return Collections.singletonList(new LocalResult(
                        partitionId,
                        skyline,
                        local.candidateCount,
                        local.singlePointCandidateCount,
                        local.pairCandidateCount,
                        local.zWindowChecks,
                        local.pointDistanceChecks,
                        taskTime
                )).iterator();
            }, true);

            List<LocalResult> localResults = new ArrayList<LocalResult>(localResultsRdd.collect());
            s4LocalComputeMs = System.currentTimeMillis() - s4Start;

            long s5Start = System.currentTimeMillis();
            Collections.sort(localResults, Comparator.comparingInt(result -> result.partitionId));
            ArrayList<Circle> skylineUnion = new ArrayList<Circle>();
            for (LocalResult result : localResults) {
                skylineUnion.addAll(result.skyline);
                localCandidateCount += result.candidateCount;
                localSinglePointCandidateCount += result.singlePointCandidateCount;
                localPairCandidateCount += result.pairCandidateCount;
                localZWindowChecks += result.zWindowChecks;
                localPointDistanceChecks += result.pointDistanceChecks;
                localTaskComputeSumMs += result.computeTimeMs;
                localTaskComputeMaxMs = Math.max(localTaskComputeMaxMs, result.computeTimeMs);
            }
            sortCircles(skylineUnion);
            finalResult = new DiSMCGeometryBaseline(dc, densityK);
            finalResult.setQueryPoint(queryX, queryY);
            finalResult.skymap = finalResult.skylineCircle(skylineUnion);
            s5GlobalReduceMs = System.currentTimeMillis() - s5Start;

            long s6Start = System.currentTimeMillis();
            materializeFinalMembers(sc, points, finalResult, dc, cellSize);
            s6MaterializeMs = System.currentTimeMillis() - s6Start;

            int countMismatches = countMismatches(finalResult);
            if (countMismatches != 0) {
                throw new IllegalStateException("Final circle/member count mismatches: " + countMismatches);
            }

            long algorithmTotalMs = s1ReadPrepareMs + s2PartitionPlanMs + s3ReplicateShuffleMs
                    + s4LocalComputeMs + s5GlobalReduceMs + s6MaterializeMs;
            long comparableQueryMs = s2PartitionPlanMs + s3ReplicateShuffleMs + s4LocalComputeMs + s5GlobalReduceMs;
            writeOutput(
                    outputPath,
                    finalResult,
                    algorithmTotalMs,
                    comparableQueryMs,
                    s1ReadPrepareMs,
                    s2PartitionPlanMs,
                    s3ReplicateShuffleMs,
                    s4LocalComputeMs,
                    s5GlobalReduceMs,
                    s6MaterializeMs,
                    partitionCount,
                    dc,
                    densityK,
                    cellSizeMultiplier,
                    queryX,
                    queryY,
                    deduplicate,
                    originalPointCount,
                    assignedPointCount,
                    clonePointCount,
                    minCore,
                    maxCore,
                    minAssigned,
                    maxAssigned,
                    localCandidateCount,
                    localSinglePointCandidateCount,
                    localPairCandidateCount,
                    localZWindowChecks,
                    localPointDistanceChecks,
                    localTaskComputeSumMs,
                    localTaskComputeMaxMs,
                    nonemptyCellCount,
                    neighborOffsetCount,
                    countMismatches,
                    conf.getBoolean("spark.skyline.cacheMemberText",true)
            );

            printSummary(
                    outputPath,
                    finalResult.skymap.size(),
                    originalPointCount,
                    assignedPointCount,
                    clonePointCount,
                    comparableQueryMs,
                    algorithmTotalMs
            );
            queryCompleted = true;
        } finally {
            // Stopping the context releases all persisted RDDs and broadcasts.
            // Explicit asynchronous cleanup here races Spark's local shutdown pool.
            try {
                if (observer != null) observer.finish(sc, queryCompleted);
            } finally {
                sc.stop();
            }
        }

        long endToEndMs = System.currentTimeMillis() - endToEndStartMs;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath, true))) {
            writer.write("end_to_end_time_s: " + formatSeconds(endToEndMs) + "\r\n");
        }
        System.out.println("end_to_end_time_s=" + formatSeconds(endToEndMs));
    }

    private static JavaRDD<Point> readAndPreparePoints(
            JavaSparkContext sc,
            String inputPath,
            double dc,
            double cellSize,
            int partitionCount,
            boolean deduplicate) {
        JavaRDD<Tuple2<Double, Double>> coordinates = sc.textFile(inputPath, partitionCount).mapPartitions(iterator -> {
            ArrayList<Tuple2<Double, Double>> parsed = new ArrayList<Tuple2<Double, Double>>();
            HashSet<String> localSeen = deduplicate ? new HashSet<String>() : null;
            while (iterator.hasNext()) {
                String line = iterator.next().trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split("\\s+");
                if (parts.length < 2) {
                    throw new IllegalArgumentException("Invalid point line: " + line);
                }
                double x = Double.parseDouble(parts[0]);
                double y = Double.parseDouble(parts[1]);
                if (deduplicate && !localSeen.add(x + "," + y)) continue;
                parsed.add(new Tuple2<Double, Double>(x, y));
            }
            return parsed.iterator();
        });

        if (deduplicate) {
            coordinates = coordinates.mapToPair(coord -> new Tuple2<Tuple2<Double, Double>, Integer>(coord, 1))
                    .reduceByKey((left, right) -> left, partitionCount)
                    .keys();
        }

        if (sc.getConf().getBoolean("spark.skyline.stableInputIds", false)) {
            coordinates = StablePointIdentity.coordinates(coordinates);
        }
        final double dependencyRadius = 2.0 * dc;
        return coordinates.zipWithUniqueId().map(tuple -> {
            Tuple2<Double, Double> coordinate = tuple._1();
            Point point = new Point(coordinate._1(), coordinate._2());
            point.id = tuple._2();
            point.zval = zValue(roundCoordinate(point.x, "x"), roundCoordinate(point.y, "y"));
            point.plowzval = zValue(
                    point.x - dependencyRadius > 0.0 ? floorCoordinate(point.x - dependencyRadius, "lower x") : 0L,
                    point.y - dependencyRadius > 0.0 ? floorCoordinate(point.y - dependencyRadius, "lower y") : 0L
            );
            point.pupperzval = zValue(
                    ceilCoordinate(point.x + dependencyRadius, "upper x"),
                    ceilCoordinate(point.y + dependencyRadius, "upper y")
            );
            int cellX = checkedCellCoordinate(Math.floor(point.x / cellSize), "cell x");
            int cellY = checkedCellCoordinate(Math.floor(point.y / cellSize), "cell y");
            point.setCell(cellX, cellY);
            return point;
        });
    }

    private static Map<Long, Integer> assignCellsToPartitions(
            List<CellCount> orderedCells,
            int partitionCount) {
        HashMap<Long, Integer> owners = new HashMap<Long, Integer>();
        if (orderedCells.isEmpty()) return owners;

        long totalPoints = 0L;
        for (CellCount cell : orderedCells) totalPoints += cell.count;
        double target = Math.max(1.0, totalPoints / (double) partitionCount);
        double load = 0.0;
        int owner = 0;
        for (int index = 0; index < orderedCells.size(); index++) {
            CellCount cell = orderedCells.get(index);
            owners.put(cell.packed, owner);
            load += cell.count;
            int cellsLeft = orderedCells.size() - index - 1;
            int partitionsLeft = partitionCount - owner - 1;
            if (owner < partitionCount - 1 && cellsLeft >= partitionsLeft
                    && (load >= target || cellsLeft == partitionsLeft)) {
                owner++;
                load = 0.0;
            }
        }
        return owners;
    }

    private static List<NeighborOffset> buildNeighborOffsets(double cellSize, double dc) {
        ArrayList<NeighborOffset> offsets = new ArrayList<NeighborOffset>();
        // The sister kernel rounds neighbourhood-count distances to two decimals.
        // dc + 0.005 is therefore a conservative geometric boundary, not a pruning optimization.
        double safeDistance = 2.0 * dc + 0.005;
        double safeDistanceSquared = safeDistance * safeDistance;
        int radius = (int) Math.ceil(safeDistance / cellSize) + 1;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                if (minCellDistanceSquared(dx, dy, cellSize) <= safeDistanceSquared) {
                    offsets.add(new NeighborOffset(dx, dy));
                }
            }
        }
        return offsets;
    }

    private static double minCellDistanceSquared(int dx, int dy, double cellSize) {
        double gapX = Math.max(0.0, (Math.abs((double) dx) - 1.0) * cellSize);
        double gapY = Math.max(0.0, (Math.abs((double) dy) - 1.0) * cellSize);
        return gapX * gapX + gapY * gapY;
    }

    private static void materializeFinalMembers(
            JavaSparkContext sc,
            JavaRDD<Point> originalPoints,
            EMCSBaseline result,
            double dc,
            double cellSize) {
        ArrayList<Circle> circles = new ArrayList<Circle>(result.skymap.values());
        sortCircles(circles);
        if (circles.isEmpty()) return;

        HashMap<Long, List<FinalCircleSpec>> byCell = new HashMap<Long, List<FinalCircleSpec>>();
        for (int index = 0; index < circles.size(); index++) {
            Circle circle = circles.get(index);
            circle.p = new ArrayList<Point>();
            FinalCircleSpec spec = new FinalCircleSpec(index, circle.centerX, circle.centerY);
            // round2(distance) <= dc can admit points just outside the raw radius.
            // Index the conservative envelope; the unchanged predicate filters its edge.
            double memberRadius = Math.nextUp(dc + 0.005);
            int minX = checkedCellCoordinate(Math.floor((circle.centerX - memberRadius) / cellSize), "circle cell min x");
            int maxX = checkedCellCoordinate(Math.floor((circle.centerX + memberRadius) / cellSize), "circle cell max x");
            int minY = checkedCellCoordinate(Math.floor((circle.centerY - memberRadius) / cellSize), "circle cell min y");
            int maxY = checkedCellCoordinate(Math.floor((circle.centerY + memberRadius) / cellSize), "circle cell max y");
            for (int cellX = minX; cellX <= maxX; cellX++) {
                for (int cellY = minY; cellY <= maxY; cellY++) {
                    byCell.computeIfAbsent(Point.pack(cellX, cellY), ignored -> new ArrayList<FinalCircleSpec>())
                            .add(spec);
                }
            }
        }

        Broadcast<Map<Long, List<FinalCircleSpec>>> circleIndex = sc.broadcast(byCell);
        Map<Integer, List<Point>> members = originalPoints.mapPartitionsToPair(iterator -> {
            HashMap<Integer, List<Point>> local = new HashMap<Integer, List<Point>>();
            Map<Long, List<FinalCircleSpec>> index = circleIndex.value();
            while (iterator.hasNext()) {
                Point point = iterator.next();
                List<FinalCircleSpec> candidates = index.get(point.packedCellId);
                if (candidates == null) continue;
                for (FinalCircleSpec spec : candidates) {
                    if (round2(distance(spec.centerX, spec.centerY, point.x, point.y)) <= dc) {
                        local.computeIfAbsent(spec.index, ignored -> new ArrayList<Point>())
                                .add(new Point(point.x, point.y));
                    }
                }
            }
            ArrayList<Tuple2<Integer, List<Point>>> output = new ArrayList<Tuple2<Integer, List<Point>>>();
            for (Map.Entry<Integer, List<Point>> entry : local.entrySet()) {
                output.add(new Tuple2<Integer, List<Point>>(entry.getKey(), entry.getValue()));
            }
            return output.iterator();
        }).reduceByKey((left, right) -> {
            left.addAll(right);
            return left;
        }).collectAsMap();

        for (int index = 0; index < circles.size(); index++) {
            List<Point> points = members.get(index);
            circles.get(index).p = points == null ? new ArrayList<Point>() : new ArrayList<Point>(points);
        }
        result.skymap = new HashMap<Double, Circle>();
        for (Circle circle : circles) result.skymap.put(circle.discenq, circle);
    }

    private static void writeOutput(
            String outputPath,
            EMCSBaseline result,
            long totalMs,
            long comparableQueryMs,
            long s1,
            long s2,
            long s3,
            long s4,
            long s5,
            long s6,
            int partitions,
            double dc,
            int densityK,
            double cellSizeMultiplier,
            double queryX,
            double queryY,
            boolean deduplicate,
            long originalPoints,
            long assignedPoints,
            long clonePoints,
            long minCore,
            long maxCore,
            long minAssigned,
            long maxAssigned,
            long candidateCount,
            long singlePointCandidateCount,
            long pairCandidateCount,
            long zWindowChecks,
            long pointDistanceChecks,
            long taskComputeSum,
            long taskComputeMax,
            long nonemptyCells,
            int neighborOffsets,
            int countMismatches, boolean cacheMemberText) throws IOException {
        long outputStartNanos=System.nanoTime();
        File outputFile = new File(outputPath);
        File parent = outputFile.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("Cannot create output directory: " + parent);
        }
        ArrayList<Circle> circles = new ArrayList<Circle>(result.skymap.values());
        sortCircles(circles);
        MemberTextFormatter memberText=new MemberTextFormatter(cacheMemberText);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            writer.write("member_text_cache_enabled: " + cacheMemberText + "\r\n");
            writer.write("method_profile: grid_d0\r\n");
            writer.write("method_composition: grid_point_count+exact_halo+baseline+single_task\r\n");
            writer.write("routing_strategy: exact_geometric_cell_halo\r\n");
            writer.write("strategy: GRID_GEOMETRIC_2DC_BOUND\r\n");
            writer.write("dependency_radius: 2dc\r\n");
            writer.write("time_s: " + formatSeconds(totalMs) + "\r\n");
            writer.write("comparable_query_time_s: " + formatSeconds(comparableQueryMs) + "\r\n");
            writer.write("s1_read_prepare_s: " + formatSeconds(s1) + "\r\n");
            writer.write("s2_partition_plan_s: " + formatSeconds(s2) + "\r\n");
            writer.write("s3_replicate_shuffle_s: " + formatSeconds(s3) + "\r\n");
            writer.write("s4_local_compute_s: " + formatSeconds(s4) + "\r\n");
            writer.write("s5_global_reduce_s: " + formatSeconds(s5) + "\r\n");
            writer.write("s6_materialize_s: " + formatSeconds(s6) + "\r\n");
            writer.write("partition_count: " + partitions + "\r\n");
            writer.write("dc: " + dc + "\r\n");
            writer.write("density_k: " + densityK + "\r\n");
            writer.write("cell_size_multiplier: " + cellSizeMultiplier + "\r\n");
            writer.write("query_x: " + queryX + "\r\n");
            writer.write("query_y: " + queryY + "\r\n");
            writer.write("deduplicate: " + deduplicate + "\r\n");
            writer.write("original_points: " + originalPoints + "\r\n");
            writer.write("assigned_points: " + assignedPoints + "\r\n");
            writer.write("clone_points: " + clonePoints + "\r\n");
            writer.write("clone_ratio: " + formatRatio(clonePoints, originalPoints) + "\r\n");
            writer.write("replication_multiplier: " + formatRatio(assignedPoints, originalPoints) + "\r\n");
            writer.write("routing_cell_lookups: " + originalPoints * (long) neighborOffsets + "\r\n");
            writer.write("min_core_points: " + minCore + "\r\n");
            writer.write("max_core_points: " + maxCore + "\r\n");
            writer.write("min_assigned_points: " + minAssigned + "\r\n");
            writer.write("max_assigned_points: " + maxAssigned + "\r\n");
            writer.write("candidate_count: " + candidateCount + "\r\n");
            writer.write("single_point_candidates: " + singlePointCandidateCount + "\r\n");
            writer.write("pair_candidates: " + pairCandidateCount + "\r\n");
            writer.write("z_window_checks: " + zWindowChecks + "\r\n");
            writer.write("point_distance_checks: " + pointDistanceChecks + "\r\n");
            writer.write("local_task_compute_sum_s: " + formatSeconds(taskComputeSum) + "\r\n");
            writer.write("local_task_compute_max_s: " + formatSeconds(taskComputeMax) + "\r\n");
            writer.write("nonempty_cells: " + nonemptyCells + "\r\n");
            writer.write("neighbor_cell_offsets: " + neighborOffsets + "\r\n");
            writer.write("count_mismatches: " + countMismatches + "\r\n");
            writer.write("skyline_count: " + circles.size() + "\r\n");
            for (Circle circle : circles) {
                writer.write(format2(circle.discenq) + " = " + circle.cirnum + " "
                        + format2(circle.centerX) + " " + format2(circle.centerY) + "\r\n");
                if (circle.p != null) {
                    for (Point point : circle.p) {
                        writer.write("   " + memberText.format(point.x) + "   " + memberText.format(point.y) + "\r\n");
                    }
                }
            }
        }
        MemberTextFormatter.appendOutputTiming(outputPath,System.nanoTime()-outputStartNanos);
    }

    private static int countMismatches(EMCSBaseline result) {
        int mismatches = 0;
        for (Circle circle : result.skymap.values()) {
            int size = circle.p == null ? 0 : circle.p.size();
            if (circle.cirnum != size) mismatches++;
        }
        return mismatches;
    }

    private static void printSummary(
            String outputPath,
            int skylineCount,
            long originalPoints,
            long assignedPoints,
            long clonePoints,
            long comparableQueryMs,
            long totalMs) {
        System.out.println("method_profile=grid_d0");
        System.out.println("strategy=GRID_GEOMETRIC_2DC_BOUND");
        System.out.println("dependency_radius=2dc");
        System.out.println("original_points=" + originalPoints);
        System.out.println("assigned_points=" + assignedPoints);
        System.out.println("clone_points=" + clonePoints);
        System.out.println("clone_ratio=" + formatRatio(clonePoints, originalPoints));
        System.out.println("replication_multiplier=" + formatRatio(assignedPoints, originalPoints));
        System.out.println("comparable_query_time_s=" + formatSeconds(comparableQueryMs));
        System.out.println("total_time_s=" + formatSeconds(totalMs));
        System.out.println("skyline_count=" + skylineCount);
        System.out.println("output=" + new File(outputPath).getAbsolutePath());
    }

    private static void sortPoints(ArrayList<Point> points) {
        Collections.sort(points, new Comparator<Point>() {
            @Override
            public int compare(Point left, Point right) {
                int byZ = left.zval.compareTo(right.zval);
                return byZ != 0 ? byZ : Long.compare(left.id, right.id);
            }
        });
    }

    private static void sortCircles(List<Circle> circles) {
        Collections.sort(circles, new Comparator<Circle>() {
            @Override
            public int compare(Circle left, Circle right) {
                return Double.compare(left.discenq, right.discenq);
            }
        });
    }

    private static long mortonCode(int x, int y) {
        return (spreadBits(x) << 1) | spreadBits(y);
    }

    private static long spreadBits(int value) {
        long bits = value & 0xffffffffL;
        bits = (bits | (bits << 16)) & 0x0000ffff0000ffffL;
        bits = (bits | (bits << 8)) & 0x00ff00ff00ff00ffL;
        bits = (bits | (bits << 4)) & 0x0f0f0f0f0f0f0f0fL;
        bits = (bits | (bits << 2)) & 0x3333333333333333L;
        bits = (bits | (bits << 1)) & 0x5555555555555555L;
        return bits;
    }

    private static int unpackCellX(long packed) {
        return (int) (packed >> 32);
    }

    private static int unpackCellY(long packed) {
        return (int) packed;
    }

    private static String zValue(long x, long y) {
        return Zorder.valueOf(2, new long[]{x, y});
    }

    private static long roundCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value + 0.5d), label);
    }

    private static long ceilCoordinate(double value, String label) {
        return checkedCoordinate(Math.ceil(value), label);
    }

    private static long floorCoordinate(double value, String label) {
        return checkedCoordinate(Math.floor(value), label);
    }

    private static long checkedCoordinate(double value, String label) {
        if (Double.isNaN(value) || Double.isInfinite(value) || value < 0.0 || value > Long.MAX_VALUE) {
            throw new IllegalArgumentException("Invalid " + label + " coordinate: " + value);
        }
        return (long) value;
    }

    private static int checkedCellCoordinate(double value, String label) {
        if (Double.isNaN(value) || Double.isInfinite(value) || value < Integer.MIN_VALUE || value > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("Invalid " + label + ": " + value);
        }
        return (int) value;
    }

    private static double distance(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2;
        double dy = y1 - y2;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private static double round2(double value) {
        return (double) Math.round(value * 100.0) / 100.0;
    }

    private static String formatSeconds(long millis) {
        return String.format(Locale.ROOT, "%.3f", millis / 1000.0);
    }

    private static String formatRatio(long numerator, long denominator) {
        return String.format(Locale.ROOT, "%.6f", denominator == 0L ? 0.0 : (double) numerator / denominator);
    }

    private static String format2(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    private static String localPath(String argument) throws URISyntaxException {
        URI uri = new URI(argument);
        if (uri.getScheme() == null) return argument;
        if (!"file".equalsIgnoreCase(uri.getScheme())) {
            throw new IllegalArgumentException("Output must be a local path or file:// URI: " + argument);
        }
        return new File(uri).getPath();
    }

    private static void validateArguments(int partitions, double dc, int densityK, double cellSizeMultiplier) {
        if (partitions <= 0) throw new IllegalArgumentException("partitions must be positive");
        if (!(dc > 0.0) || Double.isNaN(dc) || Double.isInfinite(dc)) {
            throw new IllegalArgumentException("dc must be finite and positive");
        }
        if (densityK < 0) throw new IllegalArgumentException("densityK cannot be negative");
        if (!(cellSizeMultiplier > 0.0) || Double.isNaN(cellSizeMultiplier)
                || Double.isInfinite(cellSizeMultiplier)) {
            throw new IllegalArgumentException("cellSizeMultiplier must be finite and positive");
        }
    }

    private static void printUsageAndExit() {
        System.err.println("Usage: DistributedSMCGridBoundBaseline input output partitions dc densityK "
                + "cellSizeMultiplier [queryX queryY deduplicate]");
        System.exit(2);
    }
}
