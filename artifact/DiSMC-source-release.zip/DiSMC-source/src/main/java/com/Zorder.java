package com;



import java.util.*;
import java.math.*;

public class Zorder {
	private static final int LONG_COORD_BITS = 63;
	// 创建指定长度的0字符串
	public static String createExtra(int num) {
		if( num < 1 ) return "";

		char[] extra = new char[num];
		for (int i = 0; i < num; i++) 
			extra[i] = '0';
		return (new String(extra)); 	
	}

	// 计算最大可能的zorder值的长度
	// dimension: 维度 的数量
	// max: 最大值
	public static int maxDecDigits( int dimension, int max) {
		BigInteger maxDec = new BigInteger( "1" );
		maxDec = maxDec.shiftLeft( dimension * max );
		maxDec.subtract( BigInteger.ONE );
		return maxDec.toString().length();
	}

	// 计算最大可能的zorder值字符串
	// dimension: 维度 的数量
	public static String maxDecString( int dimension ) {
		int max = 32;
		BigInteger maxDec = new BigInteger( "1" );
		maxDec = maxDec.shiftLeft( dimension * max );
		maxDec.subtract( BigInteger.ONE );
		return maxDec.toString();
	}
	
	// Convert an multi-dimensional coordinate into a zorder
	// coordinates have already been scaled and shifted
	public static String valueOf(int dimension, int[] coord) {
		int max = 32;
		Vector<String> arrPtr = new Vector<String>(dimension);
		// 最大可能的zorder值的长度
		int fix = maxDecDigits(dimension, max);

		// 将每个维度坐标转换为二进制字符串
		for (int i = 0; i < dimension; i++) {
			String p = Integer.toBinaryString((int)coord[i]);
			arrPtr.add(p);
		}

		// 将每个维度二进制字符串补齐到最大长度
		for( int i = 0; i < arrPtr.size(); ++i ) {
			String extra = createExtra( max - arrPtr.elementAt(i).length() ); 
			arrPtr.set(i, extra + arrPtr.elementAt(i) );
		}
		
		char[] value = new char[dimension * max];
		int index = 0;

		// 计算zorder值
		for (int i = 0; i < max; ++i ) {
			for (String e: arrPtr) {
				char ch = e.charAt(i);
				value[index++] = ch;
			}	
		}		

		// 将二进制表示的order转换为大整数
		String order = new String(value);
		BigInteger ret = new BigInteger( order, 2 );

		// 返回固定长度的十进制字符串表示
		order = ret.toString();	
		if (order.length() < fix) {
			String extra = createExtra(fix - order.length());
			order = extra + order;
		} else if (order.length() > fix) {
			System.out.println("too big zorder, need to fix Zorder.java");
			System.exit(-1);
		}
		//System.out.println("order length: " + order.length());
		return order;
	}

	public static String valueOf(int dimension, long[] coord) {
		if (coord.length != dimension) {
			throw new IllegalArgumentException("dimension does not match coordinate length");
		}
		BigInteger[] values = new BigInteger[dimension];
		for (int i = 0; i < dimension; i++) {
			if (coord[i] < 0) {
				throw new IllegalArgumentException("Z-order coordinates must be non-negative: " + coord[i]);
			}
			values[i] = BigInteger.valueOf(coord[i]);
		}
		int digits = maxDecDigits(dimension, LONG_COORD_BITS);
		StringBuilder interleaved = new StringBuilder(dimension * LONG_COORD_BITS);
		for (int bit = LONG_COORD_BITS - 1; bit >= 0; bit--) {
			for (BigInteger value : values) interleaved.append(value.testBit(bit) ? '1' : '0');
		}
		String order = new BigInteger(interleaved.toString(), 2).toString();
		return createExtra(digits - order.length()) + order;
	}



	public static String getMinOverlap(List<Point> localPoints, double dc) {
		// 实现Z值范围计算逻辑
		//return String.format("%032d", Integer.parseInt(baseZ) - 1000);
		BigInteger  minZ = BigInteger.valueOf(Integer.MAX_VALUE);
		for (Point p : localPoints) {
			// 计算右上角坐标
			double lowerX = p.x - dc;
			double lowerY = p.y - dc;
			if(lowerX<=0)
				lowerX=0;
			if(lowerY<=0)
				lowerY=0;
			// 转换为Z-order坐标（四舍五入取整）
			int[] coord = {
					(int) Math.round(lowerX),
					(int) Math.round(lowerY)
			};


			// 计算Z值并转换为整数
			String zValue = valueOf(2, coord);

			//BigInteger currentZ = BigInteger.valueOf(Long.parseLong(zValue));
			BigInteger currentZ = new BigInteger(zValue); // 替换 Long.parseLong
			//System.out.println("Z-order value2: " + currentZ);
			// 更新最小值
			if (currentZ.compareTo( minZ)<0) {
				minZ = currentZ;
			}
		}
		// 返回20位填充的字符串格式
		return String.format("%020d", minZ);
		//return valueOf(2,)
	}

	public static String getMaxOverlap(List<Point> localPoints, double dc) {
		BigInteger maxZ = BigInteger.valueOf(Integer.MIN_VALUE);

		for (Point p : localPoints) {
			// 计算右上角坐标
			double upperX = p.x + dc;
			double upperY = p.y + dc;

			// 转换为Z-order坐标（四舍五入取整）
			int[] coord = {
					(int) Math.round(upperX),
					(int) Math.round(upperY)
			};

			// 计算Z值并转换为整数
			String zValue = valueOf(2, coord);
			//BigInteger currentZ = BigInteger.valueOf(Long.parseLong (zValue));
			BigInteger currentZ = new BigInteger(zValue); // 替换 Long.parseLong
			//System.out.println("lowerX: " + (int) Math.round(upperX) + ", lowerY: " + (int) Math.round(upperY)+'\n');

			// 更新最大值
			if (currentZ.compareTo(maxZ)>0) {
				maxZ = currentZ;
			}
		}

		// 返回20位填充的字符串格式
		return String.format("%020d", maxZ);
		//return maxZ.toString();
	}



	// 测试
	public static void main(String[] args) {
		// 测试 createExtra 方法
		System.out.println("Testing createExtra:");
		System.out.println("createExtra(3) = " + createExtra(3));
		System.out.println("createExtra(5) = " + createExtra(5));
		System.out.println("createExtra(0) = " + createExtra(0));
		System.out.println("createExtra(-1) = " + createExtra(-1));
		System.out.println();

		// 测试 maxDecDigits 方法
		System.out.println("Testing maxDecDigits:");
		System.out.println("maxDecDigits(2, 32) = " + maxDecDigits(2, 32));
		System.out.println("maxDecDigits(3, 32) = " + maxDecDigits(3, 32));
		System.out.println();

		// 测试 valueOf 方法 - 2维空间
		System.out.println("Testing valueOf - 2D space:");
		int[] coord2D = {3, 4};
		String result2D = valueOf(2, coord2D);
		System.out.println("Input coordinates: (3, 4)");
		System.out.println("Z-order value: " + result2D);
		System.out.println("Length: " + result2D.length());
		System.out.println();

		// 测试 valueOf 方法 - 3维空间
		System.out.println("Testing valueOf - 3D space:");
		int[] coord3D = {1, 2, 3};
		String result3D = valueOf(3, coord3D);
		System.out.println("Input coordinates: (1, 2, 3)");
		System.out.println("Z-order value: " + result3D);
		System.out.println("Length: " + result3D.length());
		System.out.println();

		// 测试边界值
		System.out.println("Testing boundary values:");
		int[] coordZero = {0, 0};
		String resultZero = valueOf(2, coordZero);
		System.out.println("Input coordinates: (0, 0)");
		System.out.println("Z-order value: " + resultZero);
		System.out.println("Length: " + resultZero.length());
	}
}
