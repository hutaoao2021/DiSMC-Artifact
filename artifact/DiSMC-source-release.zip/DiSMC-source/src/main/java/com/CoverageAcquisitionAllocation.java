package com;
import java.util.*;
/** Reserve bounded cut samples before upgrading selected owners to full coordinates. */
public final class CoverageAcquisitionAllocation {
 public final boolean[] full,sampled;
 public final int[] selected;
 public final int quota;
 public final long reservedCoordinates;
 private CoverageAcquisitionAllocation(boolean[] f,boolean[] s,int[] ids,int q,long reserved){full=f;sampled=s;selected=ids;quota=q;reservedCoordinates=reserved;}
 public static CoverageAcquisitionAllocation allocate(long[] core,double[] work,int[] legacy,long cap,int limit,int partitions){
  if(core.length!=work.length||cap<0||limit<1||partitions<1)throw new IllegalArgumentException("Invalid coverage allocation dimensions");
  List<Integer> order=new ArrayList<>();
  for(int o=0;o<core.length;o++){
   if(core[o]<0||!Double.isFinite(work[o])||work[o]<0)throw new IllegalArgumentException("Invalid owner population or cost");
   if(core[o]>=2)order.add(o);
  }
  order.sort(Comparator.<Integer>comparingDouble(o->-work[o]).thenComparingInt(o->o));
  if(order.size()>limit)order=new ArrayList<>(order.subList(0,limit));
  boolean[] full=new boolean[core.length],sampled=new boolean[core.length];
  if(order.isEmpty())return new CoverageAcquisitionAllocation(full,sampled,new int[0],0,0);
  long denominator=Math.multiplyExact((long)order.size(),partitions);
  long desired=Math.max(4,(2048L+partitions-1)/partitions);
  int quota=(int)Math.min(desired,cap/denominator);
  if(quota<4)throw new IllegalArgumentException("Coverage budget cannot reserve four cut coordinates per partition and owner; increase acquisition cap or explicitly reduce owner limit");
  long perOwner=Math.multiplyExact((long)quota,partitions),reserved=0;
  for(int o:order){full[o]=core[o]<=perOwner;sampled[o]=!full[o];reserved=Math.addExact(reserved,Math.min(core[o],perOwner));}
  Set<Integer> eligible=new HashSet<>(order),seen=new HashSet<>();List<Integer> upgrades=new ArrayList<>();
  for(int o:legacy){if(o<0||o>=core.length)throw new IllegalArgumentException("Invalid legacy owner");if(eligible.contains(o)&&seen.add(o))upgrades.add(o);}
  for(int o:order)if(seen.add(o))upgrades.add(o);
  for(int o:upgrades)if(!full[o]){
   long extra=core[o]-perOwner;
   if(extra<=cap-reserved){full[o]=true;sampled[o]=false;reserved=Math.addExact(reserved,extra);}
  }
  return new CoverageAcquisitionAllocation(full,sampled,order.stream().mapToInt(o->o).toArray(),quota,reserved);
 }
}
