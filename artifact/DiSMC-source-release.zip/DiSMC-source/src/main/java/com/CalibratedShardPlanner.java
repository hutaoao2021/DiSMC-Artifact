package com;

import java.util.Arrays;

/** Historical CPU calibration. The read budget is in records, not physical network bytes. */
public final class CalibratedShardPlanner {
    public static final double READ = 0.14920512226344448 / 10000.0;
    public static final double PAIR = 0.17421444495619087 / 1000000.0;
    public static final double COUNT = 1.0459162572858485 / 1000000000.0;
    public static double fixed(long assigned) { return READ * assigned; }
    public static double variable(double work, long core) {
        return PAIR * work + COUNT * work * work / Math.max(1L, core);
    }
    public static double[] costs(double[] work, long[] core, long[] assigned) {
        if (work.length != core.length || work.length != assigned.length)
            throw new IllegalArgumentException("statistics length mismatch");
        double[] cost = new double[work.length];
        for (int i=0; i<work.length; i++) cost[i] = fixed(assigned[i]) + variable(work[i],core[i]);
        return cost;
    }
    public static BudgetedQueryShards.Plan plan(double[] work, long[] core, long[] assigned,
                                                double fraction, int maxPieces) {
        // Reuse validation including overflow checking; zero budget cannot change the input plan.
        BudgetedQueryShards.plan(work,core,assigned,0,maxPieces);
        if (!(fraction>=0 && fraction<=1)) throw new IllegalArgumentException("invalid read budget");
        double[] cost=costs(work,core,assigned);
        double sum=0,max=0;long records=0;
        for(int i=0;i<cost.length;i++) {
            if(!Double.isFinite(cost[i]))throw new IllegalArgumentException("cost overflow");
            sum+=cost[i];max=Math.max(max,cost[i]);records=Math.addExact(records,assigned[i]);
        }
        long budget=(long)Math.floor(fraction*records),extra=0;
        int[] pieces=new int[work.length];Arrays.fill(pieces,1);
        double target=work.length==0?0:1.5*sum/work.length;
        for(;;) {
            int best=-1;double largest=target;
            for(int i=0;i<pieces.length;i++) {
                if(pieces[i]>=maxPieces || core[i]<2L*(pieces[i]+1) || assigned[i]>budget-extra)continue;
                double current=fixed(assigned[i])+variable(work[i],core[i])/pieces[i];
                double saved=variable(work[i],core[i])/(pieces[i]*(pieces[i]+1.0));
                // Conservative CPU gain guard: extra per-child preparation is not assumed free.
                if(saved<=fixed(assigned[i]))continue;
                if(current>largest){largest=current;best=i;}
            }
            if(best<0)break;
            pieces[best]++;extra+=assigned[best];
        }
        int tasks=0,split=0;double residual=0;
        for(int i=0;i<pieces.length;i++) {
            tasks+=pieces[i];if(pieces[i]>1)split++;
            residual=Math.max(residual,fixed(assigned[i])+variable(work[i],core[i])/pieces[i]);
        }
        return new BudgetedQueryShards.Plan(pieces,extra,budget,max,residual,tasks,split);
    }
}
