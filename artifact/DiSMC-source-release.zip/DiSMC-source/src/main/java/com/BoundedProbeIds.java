package com;
import java.io.Serializable;import java.util.*;
/** Exact bounded selection for unique source IDs; inputs/merged shards must be disjoint. */
public final class BoundedProbeIds implements Serializable {
 private enum Order implements Comparator<Long>{INSTANCE;public int compare(Long a,Long b){int c=Long.compare(mix(a),mix(b));return c!=0?c:Long.compare(a,b);}}
 private final int limit;private final PriorityQueue<Long>heap;
 public BoundedProbeIds(int limit){if(limit<1)throw new IllegalArgumentException("positive sample limit required");this.limit=limit;heap=new PriorityQueue<>(limit,Collections.reverseOrder(Order.INSTANCE));}
 public void add(long id){if(heap.size()<limit)heap.add(id);else if(Order.INSTANCE.compare(id,heap.peek())<0){heap.remove();heap.add(id);}}
 public void merge(long[]selected){if(selected==null)throw new IllegalArgumentException("missing samples");for(long id:selected)add(id);}
 public int size(){return heap.size();}
 public long[]ids(){long[]ids=new long[heap.size()];int i=0;for(long id:heap)ids[i++]=id;Arrays.sort(ids);return ids;}
 private static long mix(long value){value^=value>>>33;value*=0xff51afd7ed558ccdL;value^=value>>>33;value*=0xc4ceb9fe1a85ec53L;return value^(value>>>33);}
}
