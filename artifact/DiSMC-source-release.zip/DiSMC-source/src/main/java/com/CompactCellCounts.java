package com;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Exact positive cell counts, with insertion order retained for the legacy tie fallback. */
public final class CompactCellCounts {
    public static final class Batch implements Serializable {
        public final long[] keys, counts;
        public final boolean negativeCoordinates;
        Batch(long[] keys, long[] counts, boolean negativeCoordinates) {
            this.keys=keys; this.counts=counts; this.negativeCoordinates=negativeCoordinates;
        }
    }
    private long[] keys=new long[16], counts=new long[16];
    private int[] slots=new int[32];
    private int size;
    private boolean negativeCoordinates;

    public int size() { return size; }
    public long keyAt(int index) { return keys[index]; }
    public long countAt(int index) { return counts[index]; }
    private static int hash(long key) {
        key ^= key >>> 33; key *= 0xff51afd7ed558ccdL;
        key ^= key >>> 33; key *= 0xc4ceb9fe1a85ec53L;
        key ^= key >>> 33; return (int)key;
    }
    public void add(long key, long delta) {
        if(delta<=0) throw new IllegalArgumentException("counts must be positive");
        int mask=slots.length-1, slot=hash(key)&mask;
        while(slots[slot]!=0) {
            int index=slots[slot]-1;
            if(keys[index]==key) { counts[index]=Math.addExact(counts[index],delta); return; }
            slot=(slot+1)&mask;
        }
        if(size>=slots.length/2) {
            if(slots.length>=1<<30) throw new IllegalStateException("too many cells");
            slots=new int[slots.length*2]; mask=slots.length-1;
            for(int i=0;i<size;i++) {
                int s=hash(keys[i])&mask;
                while(slots[s]!=0) s=(s+1)&mask;
                slots[s]=i+1;
            }
            slot=hash(key)&mask;
            while(slots[slot]!=0) slot=(slot+1)&mask;
        }
        if(size==keys.length) {
            keys=Arrays.copyOf(keys,keys.length*2);
            counts=Arrays.copyOf(counts,counts.length*2);
        }
        keys[size]=key; counts[size]=delta; slots[slot]=++size;
        negativeCoordinates |= (int)(key>>32)<0 || (int)key<0;
    }
    public long get(long key) {
        int mask=slots.length-1, slot=hash(key)&mask;
        while(slots[slot]!=0) {
            int index=slots[slot]-1;
            if(keys[index]==key) return counts[index];
            slot=(slot+1)&mask;
        }
        throw new IllegalArgumentException("missing cell");
    }
    public Batch snapshot() {
        return new Batch(Arrays.copyOf(keys,size),Arrays.copyOf(counts,size),negativeCoordinates);
    }
    public void add(Batch batch) {
        for(int i=0;i<batch.keys.length;i++) add(batch.keys[i],batch.counts[i]);
    }

    /**
     * Negative coordinates can share a clamped Morton key. Recreate the old HashMaps
     * from first-insertion order so stable sorting retains the original tie order.
     * Repeated value updates do not change a HashMap's iteration order.
     */
    public static HashMap<Long,Long> legacyMerge(List<Batch> batches) {
        HashMap<Long,Long> merged=new HashMap<Long,Long>();
        for(Batch batch:batches) {
            HashMap<Long,Long> local=new HashMap<Long,Long>();
            for(int i=0;i<batch.keys.length;i++) local.put(batch.keys[i],batch.counts[i]);
            for(Map.Entry<Long,Long> entry:local.entrySet()) {
                Long previous=merged.get(entry.getKey());
                merged.put(entry.getKey(),previous==null?entry.getValue():Math.addExact(previous,entry.getValue()));
            }
        }
        return merged;
    }
}
