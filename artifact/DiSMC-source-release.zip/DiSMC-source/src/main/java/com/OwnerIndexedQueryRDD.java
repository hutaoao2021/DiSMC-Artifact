package com;

import java.util.*;
import org.apache.spark.*;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.LongAccumulator;
import org.apache.spark.util.CollectionAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Indexed query execution over independent owner blocks; no cross-owner sharing. */
public final class OwnerIndexedQueryRDD extends RDD<HashMap<Double,Circle>> {
    private static final class QueryPartition implements Partition {
        final int id,owner,piece,pieces; final Partition parent;
        QueryPartition(int id,int owner,int piece,int pieces,Partition parent){this.id=id;this.owner=owner;this.piece=piece;this.pieces=pieces;this.parent=parent;}
        public int index(){return id;}
        public boolean org$apache$spark$Partition$$super$equals(Object o){return super.equals(o);}
    }
    private static final class QueryDependency extends NarrowDependency<OwnerNeighborhoodRDD.Block> {
        final int[] parents;
        QueryDependency(RDD<OwnerNeighborhoodRDD.Block> parent,int[] pieces){super(parent);int n=0;for(int p:pieces)n+=p;parents=new int[n];int j=0;for(int owner=0;owner<pieces.length;owner++)for(int s=0;s<pieces[owner];s++)parents[j++]=owner;}
        public Seq<Object> getParents(int child){return JavaConverters.asScalaBufferConverter(Collections.<Object>singletonList(parents[child])).asScala().toSeq();}
    }
    private static Seq<Dependency<?>> deps(RDD<OwnerNeighborhoodRDD.Block> parent,int[] pieces){return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(new QueryDependency(parent,pieces))).asScala().toSeq();}
    private final RDD<OwnerNeighborhoodRDD.Block> parent; private final Partition[] queries;
    private final double dc,cellSize,qx,qy; private final int density;
    private final LongAccumulator builds,reuses,nanos,candidates,singlePointCandidates,pairCandidates,zChecks,distanceChecks,projectedCandidates,projectedHits,projectedBounds;
    private final CollectionAccumulator<Long> taskTimesMs;
    public OwnerIndexedQueryRDD(JavaRDD<OwnerNeighborhoodRDD.Block> blocks,int[] pieces,double dc,double cellSize,double qx,double qy,int density,
            LongAccumulator builds,LongAccumulator reuses,LongAccumulator nanos,
            LongAccumulator candidates,LongAccumulator singlePointCandidates,LongAccumulator pairCandidates,LongAccumulator zChecks,LongAccumulator distanceChecks,CollectionAccumulator<Long> taskTimesMs,
            LongAccumulator projectedCandidates,LongAccumulator projectedHits,LongAccumulator projectedBounds){
        super(blocks.context(),deps(blocks.rdd(),pieces),ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));
        parent=blocks.rdd();this.dc=dc;this.cellSize=cellSize;this.qx=qx;this.qy=qy;this.density=density;this.builds=builds;this.reuses=reuses;this.nanos=nanos;this.candidates=candidates;this.singlePointCandidates=singlePointCandidates;this.pairCandidates=pairCandidates;this.zChecks=zChecks;this.distanceChecks=distanceChecks;this.taskTimesMs=taskTimesMs;this.projectedCandidates=projectedCandidates;this.projectedHits=projectedHits;this.projectedBounds=projectedBounds;
        int count=0;for(int p:pieces)count+=p;queries=new Partition[count];int next=0;Partition[] originals=parent.partitions();
        for(int owner=0;owner<pieces.length;owner++)for(int piece=0;piece<pieces[owner];piece++)queries[next]=new QueryPartition(next++,owner,piece,pieces[owner],originals[owner]);
    }
    public Partition[] getPartitions(){return queries;}
    public scala.collection.Iterator<HashMap<Double,Circle>> compute(Partition split,TaskContext context){
        long taskStart=System.nanoTime();
        QueryPartition q=(QueryPartition)split;scala.collection.Iterator<OwnerNeighborhoodRDD.Block> it=parent.iterator(q.parent,context);
        if(!it.hasNext())throw new IllegalStateException("missing owner block");OwnerNeighborhoodRDD.Block block=it.next();PreparedNeighborhood prepared;
        synchronized(block){if(block.prepared==null){long start=System.nanoTime();block.prepared=new PreparedNeighborhood(new Point[][]{block.points},dc,cellSize,qx,qy);builds.add(1);nanos.add(System.nanoTime()-start);}else reuses.add(1);prepared=block.prepared;}
        IndexedEMCS emcs=new IndexedEMCS(dc);emcs.q.x=qx;emcs.q.y=qy;emcs.density_k=density;emcs.part_id=q.owner;emcs.setCellConfig(cellSize);emcs.usePrepared(prepared.views[0],q.piece,q.pieces);emcs.method(dc);
        candidates.add(emcs.candidateCount);singlePointCandidates.add(emcs.singlePointCandidateCount);pairCandidates.add(emcs.pairCandidateCount);zChecks.add(emcs.zWindowChecks);distanceChecks.add(emcs.pointDistanceChecks);taskTimesMs.add((System.nanoTime()-taskStart)/1000000L);
        projectedCandidates.add(emcs.projectedCandidates);projectedHits.add(emcs.projectedCountHits);projectedBounds.add(emcs.projectedBoundHits);
        return JavaConverters.asScalaIteratorConverter(Collections.singletonList(emcs.skymap).iterator()).asScala();
    }
    public JavaRDD<HashMap<Double,Circle>> asJava(){return JavaRDD.fromRDD(this,ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));}
}
