package com;

import java.util.*;
import org.apache.spark.*;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.LongAccumulator;
import org.apache.spark.util.CollectionAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Query responsibility stays independent of cached geometry and its immutable indexes. */
public final class IndexedQueryRDD extends RDD<HashMap<Double,Circle>> {
    private static final class QueryPartition implements Partition {
        final int id,owner,slot,piece,pieces;final Partition parent;
        QueryPartition(int id,int owner,int slot,int piece,int pieces,Partition parent){this.id=id;this.owner=owner;this.slot=slot;this.piece=piece;this.pieces=pieces;this.parent=parent;}
        public int index(){return id;}
        public boolean org$apache$spark$Partition$$super$equals(Object o){return super.equals(o);}
    }
    private static final class QueryDependency extends NarrowDependency<SharedNeighborhoodRDD.Block> {
        final int[] parents;
        QueryDependency(RDD<SharedNeighborhoodRDD.Block> parent,int[] groups,int[] pieces) {
            super(parent);int n=0;for(int s:pieces)n+=s;parents=new int[n];int next=0;
            for(int p=0;p<pieces.length;p++)for(int s=0;s<pieces[p];s++)parents[next++]=groups[p];
        }
        public Seq<Object> getParents(int child){return JavaConverters.asScalaBufferConverter(Collections.<Object>singletonList(parents[child])).asScala().toSeq();}
    }
    private static Seq<Dependency<?>> deps(RDD<SharedNeighborhoodRDD.Block> parent,int[] groups,int[] pieces) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(new QueryDependency(parent,groups,pieces))).asScala().toSeq();
    }
    private final RDD<SharedNeighborhoodRDD.Block> parent;
    private final Partition[] queries;
    private final double dc,cellSize,qx,qy;private final int density;
    private final LongAccumulator builds,reuses,buildNanos,candidates,singlePointCandidates,pairCandidates,zChecks,distanceChecks,projectedCandidates,projectedCountHits,projectedBoundHits;
    private final CollectionAccumulator<Long> taskTimesMs;
    public IndexedQueryRDD(JavaRDD<SharedNeighborhoodRDD.Block> blocks,NeighborhoodBundles.Plan plan,int[] pieces,
            double dc,double cellSize,double qx,double qy,int density,LongAccumulator builds,LongAccumulator reuses,LongAccumulator nanos,
            LongAccumulator candidates,LongAccumulator singlePointCandidates,LongAccumulator pairCandidates,LongAccumulator zChecks,LongAccumulator distanceChecks,CollectionAccumulator<Long> taskTimesMs,
            LongAccumulator projectedCandidates,LongAccumulator projectedCountHits,LongAccumulator projectedBoundHits) {
        super(blocks.context(),deps(blocks.rdd(),plan.group,pieces),ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));
        parent=blocks.rdd();this.dc=dc;this.cellSize=cellSize;this.qx=qx;this.qy=qy;this.density=density;
        this.builds=builds;this.reuses=reuses;buildNanos=nanos;this.candidates=candidates;this.singlePointCandidates=singlePointCandidates;this.pairCandidates=pairCandidates;this.zChecks=zChecks;this.distanceChecks=distanceChecks;this.taskTimesMs=taskTimesMs;this.projectedCandidates=projectedCandidates;this.projectedCountHits=projectedCountHits;this.projectedBoundHits=projectedBoundHits;
        int n=0;for(int s:pieces)n+=s;queries=new Partition[n];int next=0;Partition[] parents=parent.partitions();
        for(int p=0;p<pieces.length;p++)for(int s=0;s<pieces[p];s++)
            queries[next]=new QueryPartition(next++,p,plan.slot[p],s,pieces[p],parents[plan.group[p]]);
    }
    public Partition[] getPartitions(){return queries;}
    public scala.collection.Iterator<HashMap<Double,Circle>> compute(Partition split,TaskContext context) {
        long taskStart=System.nanoTime();
        QueryPartition p=(QueryPartition)split;
        scala.collection.Iterator<SharedNeighborhoodRDD.Block> it=parent.iterator(p.parent,context);
        if(!it.hasNext())throw new IllegalStateException("missing block");
        SharedNeighborhoodRDD.Block block=it.next();
        PreparedNeighborhood prepared;
        synchronized(block) {
            if(block.prepared==null) {
                long start=System.nanoTime();block.prepared=new PreparedNeighborhood(block.bySlot,dc,cellSize,qx,qy);
                builds.add(1);buildNanos.add(System.nanoTime()-start);
            } else reuses.add(1);
            prepared=block.prepared;
        }
        if(prepared.dc!=dc||prepared.cellSize!=cellSize||prepared.qx!=qx||prepared.qy!=qy)throw new IllegalStateException("incompatible index reuse");
        IndexedEMCS emcs=new IndexedEMCS(dc);emcs.q.x=qx;emcs.q.y=qy;emcs.density_k=density;emcs.part_id=p.owner;emcs.setCellConfig(cellSize);
        emcs.usePrepared(prepared.views[p.slot],p.piece,p.pieces);emcs.method(dc);
        candidates.add(emcs.candidateCount);singlePointCandidates.add(emcs.singlePointCandidateCount);pairCandidates.add(emcs.pairCandidateCount);zChecks.add(emcs.zWindowChecks);distanceChecks.add(emcs.pointDistanceChecks);
        projectedCandidates.add(emcs.projectedCandidates);projectedCountHits.add(emcs.projectedCountHits);projectedBoundHits.add(emcs.projectedBoundHits);
        taskTimesMs.add((System.nanoTime()-taskStart)/1000000L);
        return JavaConverters.asScalaIteratorConverter(Collections.singletonList(emcs.skymap).iterator()).asScala();
    }
    public JavaRDD<HashMap<Double,Circle>> asJava(){return JavaRDD.fromRDD(this,ClassTag$.MODULE$.<HashMap<Double,Circle>>apply(HashMap.class));}
}
