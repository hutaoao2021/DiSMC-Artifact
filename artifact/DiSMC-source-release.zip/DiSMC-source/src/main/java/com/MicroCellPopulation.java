package com;

/** Exact original owner populations for the cell-based micro input router. */
public final class MicroCellPopulation {
    private MicroCellPopulation() { }
    /** Same recipient set as the point router; no packet materialization or sorting. */
    static int recipients(DistributedSMCGridbaseRebuilt.CellOwnerIndex owners,long cell,int x,int y,
            int[] offsetX,int[] offsetY,DestinationAccumulator targets,int ownerCount) {
        int encoded=owners.getEncodedOrDefault(cell,-1);
        if(encoded==-1)throw new IllegalStateException("missing core owner");
        int core=encoded < -1 ? -encoded-2 : encoded;
        if(core<0||core>=ownerCount)throw new IllegalStateException("core owner outside population");
        targets.clear();targets.add(core);
        if(encoded>=0)for(int offset=0;offset<offsetX.length;offset++){
            int owner=owners.getOrDefault(Point.pack(x+offsetX[offset],y+offsetY[offset]),-1);
            if(owner>=ownerCount)throw new IllegalStateException("halo owner outside population");
            if(owner>=0)targets.add(owner);
        }
        return core;
    }
    public static long[] assigned(long[] keys,long[] counts,
            DistributedSMCGridbaseRebuilt.CellOwnerIndex owners,
            int[] offsetX,int[] offsetY,int ownerCount) {
        if(keys==null||counts==null||keys.length!=counts.length||owners==null
                ||offsetX==null||offsetY==null||offsetX.length!=offsetY.length||ownerCount<1)
            throw new IllegalArgumentException("invalid cell population metadata");
        long[] assigned=new long[ownerCount];
        DestinationAccumulator targets=new DestinationAccumulator(ownerCount);
        for(int cell=0;cell<keys.length;cell++){
            if(counts[cell]<0)throw new IllegalArgumentException("negative cell population");
            if(counts[cell]==0)continue;
            recipients(owners,keys[cell],(int)(keys[cell]>>32),(int)keys[cell],offsetX,offsetY,targets,ownerCount);
            for(int target=0;target<targets.size();target++){
                int owner=targets.valueAt(target);
                assigned[owner]=Math.addExact(assigned[owner],counts[cell]);
            }
        }
        return assigned;
    }
}
