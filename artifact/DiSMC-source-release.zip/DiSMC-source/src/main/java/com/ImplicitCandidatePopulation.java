package com;
import java.util.*;
/** Experimental metadata-only candidate populations; no anchor coordinates are collected. */
public final class ImplicitCandidatePopulation {
 public static final class Result{
  public final long dependencyCellChecks;public final long[]originalInputs,core;public final double[]work;public final ImplicitMicroPlanner.Candidate[]candidates;
  Result(long[]inputs,long[]core,double[]work,List<ImplicitMicroPlanner.Candidate>c,long checks){dependencyCellChecks=checks;originalInputs=inputs.clone();this.core=core.clone();this.work=work.clone();candidates=c.toArray(new ImplicitMicroPlanner.Candidate[0]);}
 }
 public static Result observe(CompactCellHashStatistics.Batch metadata,DistributedSMCGridbaseRebuilt.CellOwnerIndex owners,int[]dx,int[]dy,int ownerCount,double radius,double cellSize,Map<Long,Double>weights){
  return observe(metadata,owners,dx,dy,ownerCount,radius,cellSize,weights,"dependency");
 }
 public static Result observe(CompactCellHashStatistics.Batch metadata,DistributedSMCGridbaseRebuilt.CellOwnerIndex owners,int[]dx,int[]dy,int ownerCount,double radius,double cellSize,Map<Long,Double>weights,String mode){
  if(!Arrays.asList("none","hash_full","dependency").contains(mode))throw new IllegalArgumentException("unsupported candidate family");
  boolean spatial=mode.equals("dependency"),hashes=!mode.equals("none");long dependencyChecks=0;
  if(metadata==null||owners==null||dx==null||dy==null||dx.length!=dy.length||ownerCount<1||weights==null)throw new IllegalArgumentException("invalid population metadata");
  List<List<long[]>>coreCells=new ArrayList<>(),parentCells=new ArrayList<>();for(int o=0;o<ownerCount;o++){coreCells.add(new ArrayList<>());parentCells.add(new ArrayList<>());}
  long[]original=new long[ownerCount],core=new long[ownerCount];double[]work=new double[ownerCount];long[][]hashCore=new long[ownerCount][4];double[][]hashWork=new double[ownerCount][4];DestinationAccumulator targets=new DestinationAccumulator(ownerCount);
  for(int i=0;i<metadata.size();i++){long key=metadata.keyAt(i);int x=(int)(key>>32),y=(int)key;long[]bins=metadata.binsAt(i);long n=0;for(long v:bins)n=Math.addExact(n,v);if(n<=0)throw new IllegalArgumentException("empty metadata cell");int o=MicroCellPopulation.recipients(owners,key,x,y,dx,dy,targets,ownerCount);double weight=weights.getOrDefault(key,0.);if(!Double.isFinite(weight)||weight<0)throw new IllegalArgumentException("invalid cell weight");if(spatial)coreCells.get(o).add(new long[]{x,y,n});core[o]=Math.addExact(core[o],n);work[o]+=n*weight;
   if(hashes)for(int b=0;b<4;b++){hashCore[o][b]=Math.addExact(hashCore[o][b],bins[b]);hashWork[o][b]+=bins[b]*weight;}
   for(int t=0;t<targets.size();t++){int dest=targets.valueAt(t);original[dest]=Math.addExact(original[dest],n);if(spatial)parentCells.get(dest).add(new long[]{x,y,n});}
  }
  List<ImplicitMicroPlanner.Candidate>candidates=new ArrayList<>();for(int o=0;o<ownerCount;o++){if(!Double.isFinite(work[o]))throw new IllegalArgumentException("work overflow");if(core[o]==0||mode.equals("none"))continue;
   for(int k:new int[]{2,4}){
    if(spatial&&coreCells.get(o).size()>=k){dependencyChecks=Math.addExact(dependencyChecks,Math.multiplyExact((long)parentCells.get(o).size(),k));ImplicitResponsibility rule=ImplicitResponsibility.cells(coreCells.get(o).toArray(new long[0][]),k,radius,cellSize);long[]inputs=new long[k];double[]cost=new double[k];
     for(long[]cell:parentCells.get(o))for(int l=0;l<k;l++)if(rule.retainsCell(l,(int)cell[0],(int)cell[1]))inputs[l]=Math.addExact(inputs[l],cell[2]);
     for(long[]cell:coreCells.get(o)){int l=rule.laneOf(0,(int)cell[0],(int)cell[1]);cost[l]+=cell[2]*weights.getOrDefault(Point.pack((int)cell[0],(int)cell[1]),0.);}
     candidates.add(new ImplicitMicroPlanner.Candidate(o,rule,rule.coreCounts(),inputs,cost));
    }
    long[]counts=new long[k],inputs=new long[k];double[]cost=new double[k];for(int b=0;b<4;b++){counts[b%k]=Math.addExact(counts[b%k],hashCore[o][b]);cost[b%k]+=hashWork[o][b];}boolean nonempty=true;for(int l=0;l<k;l++){inputs[l]=original[o];nonempty&=counts[l]>0;}if(nonempty)candidates.add(new ImplicitMicroPlanner.Candidate(o,ImplicitResponsibility.hash(k,radius),counts,inputs,cost));
   }
  }return new Result(original,core,work,candidates,dependencyChecks);
 }
 public static Result reweight(Result source,double[]original,double[]adjusted){
  if(source==null||original==null||adjusted==null||original.length!=source.core.length||adjusted.length!=original.length)throw new IllegalArgumentException("invalid calibration dimensions");
  for(int o=0;o<original.length;o++)if(!Double.isFinite(original[o])||!Double.isFinite(adjusted[o])||original[o]<0||adjusted[o]<0)throw new IllegalArgumentException("invalid owner work");
  List<ImplicitMicroPlanner.Candidate>cs=new ArrayList<>();for(ImplicitMicroPlanner.Candidate c:source.candidates){if(original[c.owner]<=0||adjusted[c.owner]<=0)throw new IllegalArgumentException("invalid owner scale");double scale=adjusted[c.owner]/original[c.owner];double[]work=c.work();for(int l=0;l<work.length;l++)work[l]*=scale;cs.add(new ImplicitMicroPlanner.Candidate(c.owner,c.rule,c.coreCounts(),c.inputCounts(),work));}
  return new Result(source.originalInputs,source.core,adjusted,cs,source.dependencyCellChecks);
 }
 private ImplicitCandidatePopulation(){}
}
