package com;

import java.util.*;
import java.util.concurrent.atomic.AtomicIntegerArray;

/** Executor-local derived state. Geometry is read-only; count caches belong to an exact owner view. */
public final class PreparedNeighborhood {
    public static final class IndexedPoint extends Point {
        final int ordinal;
        final long baselineOrderX,baselineOrderY;
        final double queryDistance,projectedX,projectedY,projectedDistance;
        IndexedPoint(Point p,int ordinal,double qx,double qy,double dc) {
            super(p);this.ordinal=ordinal;
            baselineOrderX=BaselinePointOrder.roundedCoordinate(p.x);
            baselineOrderY=BaselinePointOrder.roundedCoordinate(p.y);
            double dx=p.x-qx,dy=p.y-qy;queryDistance=Math.sqrt(dx*dx+dy*dy);
            // Preserve the exact expression order of IndexedEMCS.projectTowardQuery.
            if (queryDistance <= dc) projectedX=qx;
            else if (p.x > qx) projectedX=qx+((queryDistance-dc)/queryDistance)*Math.abs(p.x-qx);
            else if (p.x == qx) projectedX=qx;
            else projectedX=qx-((queryDistance-dc)/queryDistance)*Math.abs(p.x-qx);
            if (queryDistance <= dc) projectedY=qy;
            else if (p.y > qy) projectedY=qy+((queryDistance-dc)/queryDistance)*Math.abs(p.y-qy);
            else if (p.y == qy) projectedY=qy;
            else projectedY=qy-((queryDistance-dc)/queryDistance)*Math.abs(p.y-qy);
            double px=projectedX-qx,py=projectedY-qy;
            projectedDistance=(double)Math.round(Math.sqrt(px*px+py*py)*100)/100;
        }
    }
    public static final class CellBucket {
        final Point[] points;
        final double minX,maxX,minY,maxY;
        CellBucket(Point[] points) {
            this.points=points;
            double lx=Double.POSITIVE_INFINITY,hx=Double.NEGATIVE_INFINITY,ly=lx,hy=hx;
            for(Point p:points){lx=Math.min(lx,p.x);hx=Math.max(hx,p.x);ly=Math.min(ly,p.y);hy=Math.max(hy,p.y);}
            minX=lx;maxX=hx;minY=ly;maxY=hy;
        }
    }
    public static final class View {
        final IndexedPoint[] points;
        final AtomicIntegerArray anchorCounts,projectedCounts,projectedUpperBounds;
        private final long[] keys;
        private final CellBucket[] buckets;
        private final int mask;
        @SuppressWarnings("unchecked")
        View(IndexedPoint[] points,int unionSize,Map<Long,CellBucket> sharedBuckets) {
            this.points=points;anchorCounts=new AtomicIntegerArray(unionSize);projectedCounts=new AtomicIntegerArray(unionSize);projectedUpperBounds=new AtomicIntegerArray(unionSize);
            LinkedHashMap<Long,List<Point>> cellLists=new LinkedHashMap<>();
            for(Point p:points)cellLists.computeIfAbsent(p.packedCellId,k->new ArrayList<Point>()).add(p);
            int capacity=4;while(capacity<2L*cellLists.size())capacity<<=1;
            keys=new long[capacity];buckets=new CellBucket[capacity];mask=capacity-1;
            for(Map.Entry<Long,List<Point>> entry:cellLists.entrySet()) {
                long key=entry.getKey();Point[] pointsInCell=entry.getValue().toArray(new Point[0]);
                CellBucket bucket=sharedBuckets.get(key);
                if(bucket==null || !Arrays.equals(bucket.points,pointsInCell)) {
                    bucket=new CellBucket(pointsInCell);sharedBuckets.put(key,bucket);
                }
                int at=hash(key)&mask;while(buckets[at]!=null)at=(at+1)&mask;
                keys[at]=key;buckets[at]=bucket;
            }
        }
        CellBucket bucket(long key) {
            int at=hash(key)&mask;
            while(buckets[at]!=null){if(keys[at]==key)return buckets[at];at=(at+1)&mask;}
            return null;
        }
    }
    final View[] views;
    private final IndexedPoint[] unionPoints;
    private volatile View union;
    final double dc,cellSize,qx,qy;
    private static int hash(long h){h^=h>>>33;h*=0xff51afd7ed558ccdL;h^=h>>>33;return (int)h;}
    public PreparedNeighborhood(Point[][] input,double dc,double cellSize,double qx,double qy) {
        this.dc=dc;this.cellSize=cellSize;this.qx=qx;this.qy=qy;
        LinkedHashMap<Long,IndexedPoint> unique=new LinkedHashMap<>();IndexedPoint[][] ordered=new IndexedPoint[input.length][];
        for(int s=0;s<input.length;s++) {
            ordered[s]=new IndexedPoint[input[s].length];
            for(int i=0;i<input[s].length;i++) {
                Point p=input[s][i];IndexedPoint indexed=unique.get(p.id);
                if(indexed==null){indexed=new IndexedPoint(p,unique.size(),qx,qy,dc);unique.put(p.id,indexed);}
                else if(indexed.x!=p.x||indexed.y!=p.y||indexed.packedCellId!=p.packedCellId||indexed.ownerPartitionId!=p.ownerPartitionId)
                    throw new IllegalArgumentException("inconsistent point identity");
                ordered[s][i]=indexed;
            }
        }
        views=new View[input.length];HashMap<Long,CellBucket> sharedBuckets=new HashMap<>();
        for(int s=0;s<input.length;s++)views[s]=new View(ordered[s],unique.size(),sharedBuckets);
        unionPoints=unique.values().toArray(new IndexedPoint[0]);
    }

    /** Builds only the union view for a bundle-level query task. */
    public PreparedNeighborhood(Point[] input,double dc,double cellSize,double qx,double qy) {
        this.dc=dc;this.cellSize=cellSize;this.qx=qx;this.qy=qy;
        LinkedHashMap<Long,IndexedPoint> unique=new LinkedHashMap<>();
        for(Point point:input) {
            IndexedPoint previous=unique.get(point.id);
            if(previous==null) unique.put(point.id,new IndexedPoint(point,unique.size(),qx,qy,dc));
            else if(previous.x!=point.x||previous.y!=point.y||
                    previous.packedCellId!=point.packedCellId||
                    previous.ownerPartitionId!=point.ownerPartitionId)
                throw new IllegalArgumentException("inconsistent point identity");
        }
        unionPoints=unique.values().toArray(new IndexedPoint[0]);
        union=new View(unionPoints,unique.size(),new HashMap<Long,CellBucket>());
        views=new View[]{union};
    }

    /** One immutable view containing each point identity once across all owner slots. */
    public View unionView() {
        View current=union;
        if(current!=null)return current;
        synchronized(this) {
            if(union==null)union=new View(unionPoints,unionPoints.length,new HashMap<Long,CellBucket>());
            return union;
        }
    }
}
