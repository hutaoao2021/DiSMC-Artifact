package com;
import java.util.*;
/** A bounded second pass prevents raw top-owner ranking from being the only observation gate. */
public final class ProbeCoverageCalibration {
    public static int[] uncovered(long[] core,SampledAnchorCostProbe.Probe[] probes){
        boolean[] seen=new boolean[core.length];for(SampledAnchorCostProbe.Probe p:probes){
            if(p.owner<0||p.owner>=core.length||seen[p.owner])throw new IllegalArgumentException("invalid primary probe identity");seen[p.owner]=true;
        }
        return java.util.stream.IntStream.range(0,core.length).filter(o -> core[o]>0&&!seen[o]).toArray();
    }
    public static SampledAnchorCostProbe.Result merge(double[] proxy,long[] core,
            SampledAnchorCostProbe.Result primary,SampledAnchorCostProbe.Result coverage,boolean spatial){
        SampledAnchorCostProbe.Probe[] all=Arrays.copyOf(primary.probes,primary.probes.length+coverage.probes.length);
        System.arraycopy(coverage.probes,0,all,primary.probes.length,coverage.probes.length);
        uncovered(core,all);
        SampledAnchorCostProbe.Calibration calibration=spatial?SpatialProbeCostModel.calibrate(proxy,core,all):SampledAnchorCostProbe.calibrate(proxy,core,all);
        return new SampledAnchorCostProbe.Result(calibration,all,primary.wallSeconds+coverage.wallSeconds,primary.population);
    }
    private ProbeCoverageCalibration(){ }
}
