package com;
import java.io.Serializable;import java.util.Arrays;
/** Owner-local bounded flat probe statistics. Capacities are charged at 12 bytes/checkpoint,
 * 29 bytes/call and 128 fixed bytes; accounting is not a JVM heap measurement.
 * On overflow the whole record is discarded; sealed records are immutable. */
public final class BoundedProbeCountTrace implements Serializable {
 private static final long serialVersionUID=2L;
 private final long limit;
 private int[] upper=new int[0],starts=new int[0],lengths=new int[0],required=new int[0];
 private long[] checks=new long[0],original=new long[0];private double[] distance=new double[0];private byte[] kind=new byte[0];
 private int calls,points,activeCall,activeKind,lastUpper;private long lastChecks,anchorChecks;
 private boolean open,failed,sealed;
 public BoundedProbeCountTrace(long byteLimit){if(byteLimit<1||byteLimit>Integer.MAX_VALUE)throw new IllegalArgumentException("invalid cap");limit=byteLimit;failed=limit<128;}
 public void begin(int category,int needed,double objective){
  if(category<0||category>2||needed<0||!Double.isFinite(objective)||objective<0)throw new IllegalArgumentException("invalid call");
  if(failed)return;if(open||sealed)throw new IllegalStateException("open or sealed trace");
  if(category!=0){if(calls==kind.length&&!growCalls(calls==0?8:calls*2))return;activeCall=calls++;kind[activeCall]=(byte)category;required[activeCall]=needed;distance[activeCall]=objective;starts[activeCall]=points;}
  else activeCall=-1;
  open=true;activeKind=category;lastUpper=Integer.MAX_VALUE;lastChecks=0;
 }
 public void checkpoint(int bound,long work){
  if(failed)return;if(!open)throw new IllegalStateException("no call");if(bound<0||bound>lastUpper||work<lastChecks)throw new IllegalArgumentException("nonmonotone checkpoint");lastUpper=bound;lastChecks=work;if(activeKind==0)return;
  int last=points-1;if(last>=starts[activeCall]&&upper[last]==bound)return;
  if(last>=starts[activeCall]&&checks[last]==work){upper[last]=bound;return;}
  if(points==upper.length&&!growPoints(points==0?8:points*2))return;upper[points]=bound;checks[points++]=work;
 }
 public void end(long work){if(failed)return;if(!open)throw new IllegalStateException("no call");if(work<lastChecks)throw new IllegalArgumentException("work below prefix");if(activeKind==0)anchorChecks=Math.addExact(anchorChecks,work);else{original[activeCall]=work;lengths[activeCall]=points-starts[activeCall];}open=false;}
 private boolean allow(int pointCapacity,int callCapacity){if(pointCapacity<0||callCapacity<0||128+12L*pointCapacity+29L*callCapacity>limit){failed=true;open=false;points=calls=0;anchorChecks=0;upper=starts=lengths=required=new int[0];checks=original=new long[0];distance=new double[0];kind=new byte[0];return false;}return true;}
 private boolean growCalls(int capacity){if(!allow(upper.length,capacity))return false;starts=Arrays.copyOf(starts,capacity);lengths=Arrays.copyOf(lengths,capacity);required=Arrays.copyOf(required,capacity);original=Arrays.copyOf(original,capacity);distance=Arrays.copyOf(distance,capacity);kind=Arrays.copyOf(kind,capacity);return true;}
 private boolean growPoints(int capacity){if(!allow(capacity,kind.length))return false;upper=Arrays.copyOf(upper,capacity);checks=Arrays.copyOf(checks,capacity);return true;}
 public void seal(){if(failed)return;if(open)throw new IllegalStateException("open trace");if(sealed)return;upper=Arrays.copyOf(upper,points);checks=Arrays.copyOf(checks,points);starts=Arrays.copyOf(starts,calls);lengths=Arrays.copyOf(lengths,calls);required=Arrays.copyOf(required,calls);original=Arrays.copyOf(original,calls);distance=Arrays.copyOf(distance,calls);kind=Arrays.copyOf(kind,calls);sealed=true;}
 public long[] estimate(ProbeDominanceFrontier frontier,int density){
  if(frontier==null||density<0)throw new IllegalArgumentException("invalid frontier");if(failed)return null;if(open)throw new IllegalStateException("open trace");long[] totals={anchorChecks,0,0};
  for(int c=0;c<calls;c++){int threshold=Math.max(required[c],frontier.minimumRequiredCount(distance[c],density));int low=starts[c],end=low+lengths[c],high=end;while(low<high){int middle=(low+high)>>>1;if(upper[middle]<threshold)high=middle;else low=middle+1;}totals[kind[c]]=Math.addExact(totals[kind[c]],low<end?checks[low]:original[c]);}return totals;
 }
 public boolean complete(){return !failed&&!open;}public long retainedBytes(){return failed?0:128+12L*upper.length+29L*kind.length;}public int checkpointCount(){return points;}
}
