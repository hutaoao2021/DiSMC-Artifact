package com;

/** Single membership contract for repaired counting and export paths.
 * strictfp keeps the directed-rounding certificates in binary64 on Java 8.
 */
public strictfp final class NumericalCoverage {
    private NumericalCoverage() {}
    public static double squaredRadius(double radius) {
        double effective=Math.nextDown(radius+0.005);
        return effective*effective;
    }
    public static boolean covers(double x,double y,double px,double py,double radius) {
        double dx=x-px,dy=y-py;
        return dx*dx+dy*dy<=squaredRadius(radius);
    }
    private static double addUp(double a,double b){return Math.nextUp(a+b);}
    private static double squareUp(double a){return Math.nextUp(a*a);}
    /** Real coordinate-distance bound for every point accepted by the squared predicate.
     * Undo sum/product rounding, then undo both coordinate subtractions.
     * Non-normal/overflow cases deliberately receive no finite certificate.
     */
    public static double envelope(double radius) {
        double rr=squaredRadius(radius);
        if(!Double.isFinite(rr)||rr<Double.MIN_NORMAL)return Double.POSITIVE_INFINITY;
        double s=addUp(Math.nextUp(rr),2*Math.ulp(Math.nextUp(rr)));
        double h=Math.nextUp(Math.sqrt(s));
        return addUp(h,2*Math.ulp(Math.nextUp(h)));
    }
    /** Query-independent anchor-count radius; extra width is only a fast-path choice.
     * Safety comes from containsCandidate(), never from assuming the added width suffices.
     */
    public static double anchorRadius(double radius){return Math.nextUp(2*radius+0.005);}
    public static boolean containsCandidate(double ax,double ay,double cx,double cy,
                                            double radius,double anchorRadius) {
        double rr=squaredRadius(anchorRadius),outer=envelope(radius);
        double dx=Math.nextUp(Math.abs(cx-ax)),dy=Math.nextUp(Math.abs(cy-ay));
        double offset=Math.nextUp(Math.sqrt(addUp(squareUp(dx),squareUp(dy))));
        double reach=addUp(offset,outer);
        // Bound the norm of rounded anchor-coordinate differences, then the rounded sum
        // of their products. A failed/nonfinite certificate means keep the candidate.
        double norm=addUp(reach,2*Math.ulp(Math.nextUp(reach)));
        double sq=squareUp(norm);
        double computedUpper=addUp(sq,4*Math.ulp(Math.nextUp(sq)));
        return Double.isFinite(computedUpper)&&Double.isFinite(rr)&&computedUpper<=rr;
    }
}
