package com;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.collection.JavaConverters;
import scala.reflect.ClassTag$;
import scala.runtime.AbstractFunction1;

/** Changes only the order of one cache-materializing action, not RDD partitions. */
public final class CostOrderedMaterializer {
    private CostOrderedMaterializer() {}

    public static int[] order(final double[] work, int slots, String policy) {
        return order(work,slots,policy,false);
    }

    public static int[] order(final double[] work, int slots, String policy, boolean parentSkewed) {
        if (!"index".equals(policy) && !"work".equals(policy))
            throw new IllegalArgumentException("executionOrder must be index or work");
        if ("index".equals(policy) || work==null || work.length<=Math.max(1,slots)) return null;
        double total=0,max=0;
        for (double w:work) {
            if (!(w>=0) || !Double.isFinite(w)) throw new IllegalArgumentException("invalid work");
            total+=w;max=Math.max(max,w);
        }
        // A fixed skew guard avoids changing scheduling for nearly uniform estimated work.
        // Splitting can reduce the largest proxy below the skew threshold. That must
        // not cancel the ordering selected for the originally skewed parent plan.
        if (!parentSkewed && max<=1.5*total/work.length) return null;
        Integer[] indices=new Integer[work.length];
        for(int i=0;i<work.length;i++) indices[i]=i;
        Arrays.sort(indices,new Comparator<Integer>() {
            public int compare(Integer a,Integer b) {
                int c=Double.compare(work[b],work[a]);return c!=0?c:Integer.compare(a,b);
            }
        });
        int[] result=new int[indices.length];
        for(int i=0;i<indices.length;i++)result[i]=indices[i];
        return result;
    }

    private static final class Consume<T> extends AbstractFunction1<scala.collection.Iterator<T>,Long>
            implements Serializable {
        public Long apply(scala.collection.Iterator<T> iterator) {
            long count=0;while(iterator.hasNext()){iterator.next();count++;}return count;
        }
    }

    public static <T> void materialize(JavaSparkContext sc,JavaRDD<T> rdd,int[] order) {
        if(order.length!=rdd.getNumPartitions())throw new IllegalArgumentException("incomplete order");
        materializeSelected(sc, rdd, order);
    }

    public static <T> void materializeSelected(
            JavaSparkContext sc, JavaRDD<T> rdd, int[] selected) {
        if (sc == null || rdd == null || selected == null)
            throw new IllegalArgumentException("missing materialization input");
        boolean[] seen=new boolean[rdd.getNumPartitions()];
        ArrayList<Object> partitions=new ArrayList<Object>(selected.length);
        for(int p:selected) {
            if(p<0 || p>=seen.length || seen[p])
                throw new IllegalArgumentException("invalid selected partition");
            seen[p]=true;partitions.add(p);
        }
        if (partitions.isEmpty()) return;
        sc.sc().runJob(rdd.rdd(),new Consume<T>(),JavaConverters.asScalaBufferConverter(partitions).asScala().toSeq(),
                ClassTag$.MODULE$.<Long>apply(Long.class));
    }
}
