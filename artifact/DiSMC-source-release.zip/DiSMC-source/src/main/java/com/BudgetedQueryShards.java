package com;

import java.io.Serializable;
import java.util.Arrays;

/** Bounded extra full-neighbourhood reads to reduce indivisible-grid task skew. */
public final class BudgetedQueryShards {
    public static final class Plan implements Serializable {
        public final int[] pieces;
        public final long extraRecords,recordBudget;
        public final double originalMaximum,residualMaximum;
        public final int tasks,splitPartitions;
        Plan(int[] pieces,long extra,long budget,double original,double residual,int tasks,int splitPartitions) {
            this.pieces=pieces;this.extraRecords=extra;this.recordBudget=budget;
            this.originalMaximum=original;this.residualMaximum=residual;this.tasks=tasks;this.splitPartitions=splitPartitions;
        }
    }
    public static Plan plan(double[] work,long[] core,long[] assigned,double fraction,int maxPieces) {
        if(work.length!=core.length || work.length!=assigned.length || !(fraction>=0 && fraction<=1) || maxPieces<1)
            throw new IllegalArgumentException("invalid shard budget");
        int[] pieces=new int[work.length];Arrays.fill(pieces,1);
        long records=0;double sum=0,original=0;
        for(int i=0;i<work.length;i++) {
            if(!Double.isFinite(work[i]) || work[i]<0 || core[i]<0 || assigned[i]<core[i])
                throw new IllegalArgumentException("invalid partition statistics");
            records=Math.addExact(records,assigned[i]);sum+=work[i];original=Math.max(original,work[i]);
        }
        long budget=(long)Math.floor(fraction*records),extra=0;
        double target=work.length==0?0:1.5*sum/work.length;
        // O(P*maxPieces*P), with small P and fixed maxPieces. No grid/point scans.
        for(;;) {
            int best=-1;double worst=target;
            for(int i=0;i<work.length;i++) {
                if(pieces[i]>=maxPieces || core[i]<2L*(pieces[i]+1) || assigned[i]>budget-extra)continue;
                double residual=work[i]/pieces[i];
                if(residual>worst){best=i;worst=residual;}
            }
            if(best<0)break;
            pieces[best]++;extra+=assigned[best];
        }
        int tasks=0,split=0;double residual=0;
        for(int i=0;i<work.length;i++) {
            tasks+=pieces[i];if(pieces[i]>1)split++;residual=Math.max(residual,work[i]/pieces[i]);
        }
        return new Plan(pieces,extra,budget,original,residual,tasks,split);
    }
    public static int shard(long pointId,int pieces) {
        // Point ids are stable before partition planning; complete, disjoint anchor assignment.
        if (pieces < 1) throw new IllegalArgumentException("pieces must be >= 1");
        if (pieces == 1) return 0;
        long z=pointId;z=(z^(z>>>33))*0xff51afd7ed558ccdL;z=(z^(z>>>33))*0xc4ceb9fe1a85ec53L;
        z^=z>>>33;return (int)((z&Long.MAX_VALUE)%pieces);
    }
}
