package com;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.List;

public final class RunMetrics {
    private RunMetrics() { }
    private static long number(Map<String, Object> metrics, String key, long fallback) {
        Object value = metrics.get(key);
        return value instanceof Number ? ((Number) value).longValue() : fallback;
    }
    private static double decimal(Map<String, Object> metrics, String key, double fallback) {
        Object value = metrics.get(key);
        return value instanceof Number ? ((Number) value).doubleValue() : fallback;
    }
    private static String text(Map<String,Object> metrics,String key,String fallback){
        Object value=metrics.get(key);return value==null?fallback:String.valueOf(value);
    }
    private static long percentile(long[] values, double quantile) {
        if (values == null || values.length == 0) return 0L;
        long[] copy = Arrays.copyOf(values, values.length);
        Arrays.sort(copy);
        int index = (int) Math.ceil(quantile * copy.length) - 1;
        return copy[Math.max(0, Math.min(copy.length - 1, index))];
    }
    private static String seconds(long millis) {
        return String.format(java.util.Locale.ROOT, "%.3f", millis / 1000.0);
    }
    private static long[] taskTimes(Map<String,Object> metrics) {
        return taskTimes(metrics,"task_times_ms");
    }
    private static long[] taskTimes(Map<String,Object> metrics, String key) {
        Object value=metrics.get(key);
        if(!(value instanceof List))return new long[0];
        List<?> list=(List<?>)value;long[] result=new long[list.size()];
        for(int i=0;i<result.length;i++)result[i]=((Number)list.get(i)).longValue();
        return result;
    }
    public static void write(BufferedWriter out, long totalMs, long comparableMs,
            long s1, long s2, long s3, long s4, long s5, long s6,
            Map<String, Object> metrics, long[] core, long[] assigned,
            int ownerCount, String fingerprint) throws IOException {
        out.write("method_profile: " + text(metrics, "method_profile", "unavailable") + "\r\n");
        out.write("method_composition: " + text(metrics, "method_composition", "unavailable") + "\r\n");
        out.write("partitioning_strategy: " + text(metrics, "partitioning_strategy", "unavailable") + "\r\n");
        out.write("cell_ordering: " + text(metrics, "cell_ordering", "morton") + "\r\n");
        out.write("local_engine_class: " + text(metrics, "local_engine_class", "unavailable") + "\r\n");
        out.write("time_s: " + seconds(totalMs) + "\r\n");
        out.write("comparable_query_time_s: " + seconds(comparableMs) + "\r\n");
        out.write("s1_s: " + seconds(s1) + "\r\n");
        out.write("s2_s: " + seconds(s2) + "\r\n");
        out.write("s3_s: " + seconds(s3) + "\r\n");
        out.write("s4_s: " + seconds(s4) + "\r\n");
        out.write("s5_s: " + seconds(s5) + "\r\n");
        out.write("s6_s: " + seconds(s6) + "\r\n");
        out.write("original_points: " + number(metrics, "original_points", 0L) + "\r\n");
        out.write("assigned_points: " + number(metrics, "assigned_points", 0L) + "\r\n");
        out.write("clone_points: " + number(metrics, "clone_points", 0L) + "\r\n");
        long original = number(metrics, "original_points", 0L);
        long assignedRecords = number(metrics, "assigned_points", 0L);
        out.write("replication_multiplier: " + (original == 0L ? 0.0
                : (double) assignedRecords / original) + "\r\n");
        out.write("shared_physical_records: " + number(metrics, "bundle_shared_records", number(metrics, "assigned_points", 0L)) + "\r\n");
        out.write("routing_batch_records: " + number(metrics, "routing_batch_records", 0L) + "\r\n");
        out.write("m2_route_mode: " + text(metrics, "m2_route_mode", "unavailable") + "\r\n");
        out.write("m2_range_plan_ms: " + decimal(metrics, "m2_range_plan_ms", 0.0) + "\r\n");
        out.write("m2_exact_driver_route_lookups: " + number(metrics, "m2_exact_driver_route_lookups", 0L) + "\r\n");
        out.write("m2_executor_neighbor_lookups: " + number(metrics, "m2_executor_neighbor_lookups", 0L) + "\r\n");
        out.write("m2_estimated_assigned_records: " + number(metrics, "m2_estimated_assigned_records", 0L) + "\r\n");
        out.write("m2_actual_core_records: " + number(metrics, "m2_actual_core_records", 0L) + "\r\n");
        out.write("m2_actual_assigned_records: " + number(metrics, "m2_actual_assigned_records", 0L) + "\r\n");
        out.write("m2_actual_saved_records: " + number(metrics, "m2_actual_saved_records", 0L) + "\r\n");
        out.write("core_min: " + percentile(core, 0.0) + "\r\n");
        out.write("core_p50: " + percentile(core, 0.50) + "\r\n");
        out.write("core_p95: " + percentile(core, 0.95) + "\r\n");
        out.write("core_max: " + percentile(core, 1.0) + "\r\n");
        out.write("assigned_min: " + percentile(assigned, 0.0) + "\r\n");
        out.write("assigned_p50: " + percentile(assigned, 0.50) + "\r\n");
        out.write("assigned_p95: " + percentile(assigned, 0.95) + "\r\n");
        out.write("assigned_max: " + percentile(assigned, 1.0) + "\r\n");
        long[] taskTimes=taskTimes(metrics);
        out.write("task_time_min_s: " + (taskTimes.length==0?"unavailable":seconds(percentile(taskTimes,0.0))) + "\r\n");
        out.write("task_time_p50_s: " + (taskTimes.length==0?"unavailable":seconds(percentile(taskTimes,0.50))) + "\r\n");
        out.write("task_time_p95_s: " + (taskTimes.length==0?"unavailable":seconds(percentile(taskTimes,0.95))) + "\r\n");
        out.write("task_time_max_s: " + (taskTimes.length==0?"unavailable":seconds(percentile(taskTimes,1.0))) + "\r\n");
        long[] bundleTimes=taskTimes(metrics,"m2_v2_bundle_task_times_ms");
        out.write("m2_v2_bundle_task_count: " + number(metrics,"m2_v2_bundle_task_count",bundleTimes.length) + "\r\n");
        out.write("m2_v2_bundle_task_min_s: " + (bundleTimes.length==0?"unavailable":seconds(percentile(bundleTimes,0.0))) + "\r\n");
        out.write("m2_v2_bundle_task_p95_s: " + (bundleTimes.length==0?"unavailable":seconds(percentile(bundleTimes,0.95))) + "\r\n");
        out.write("m2_v2_bundle_task_max_s: " + (bundleTimes.length==0?"unavailable":seconds(percentile(bundleTimes,1.0))) + "\r\n");
        out.write("candidate_count: " + number(metrics, "candidate_count", -1L) + "\r\n");
        out.write("single_point_candidates: " + number(metrics, "single_point_candidates", -1L) + "\r\n");
        out.write("pair_candidates: " + number(metrics, "pair_candidates", -1L) + "\r\n");
        out.write("z_window_checks: " + number(metrics, "z_window_checks", -1L) + "\r\n");
        out.write("point_distance_checks: " + number(metrics, "point_distance_checks", -1L) + "\r\n");
        out.write("owner_neighborhood_fingerprint: " + text(metrics,"owner_neighborhood_fingerprint","not_collected") + "\r\n");
        out.write("anchor_responsibility_fingerprint: " + text(metrics,"anchor_responsibility_fingerprint","not_collected") + "\r\n");
        out.write("anchor_responsibility_count: " + number(metrics,"anchor_responsibility_count",-1L) + "\r\n");
        out.write("index_builds: " + number(metrics, "index_builds", 0L) + "\r\n");
        out.write("index_reuses: " + number(metrics, "index_reuses", 0L) + "\r\n");
        out.write("projected_count_hits: " + number(metrics, "projected_count_hits", 0L) + "\r\n");
        out.write("projected_bound_hits: " + number(metrics, "projected_bound_hits", 0L) + "\r\n");
        out.write("shard_tasks: " + number(metrics, "shard_tasks", ownerCount) + "\r\n");
        out.write("shard_split_partitions: " + number(metrics, "shard_split_partitions", 0L) + "\r\n");
        out.write("shard_extra_records: " + number(metrics, "shard_extra_records", 0L) + "\r\n");
        out.write("m4_physical_tasks: " + number(metrics, "m4_physical_tasks", 0L) + "\r\n");
        out.write("m4_split_bundles: " + number(metrics, "m4_split_bundles", 0L) + "\r\n");
        out.write("m4_extra_prepared_reads: " + number(metrics, "m4_extra_prepared_reads", 0L) + "\r\n");
        out.write("m4_prepared_reads: " + number(metrics, "m4_prepared_reads", 0L) + "\r\n");
        out.write("m4_prewarmed_split_parents: " + number(metrics, "m4_prewarmed_split_parents", 0L) + "\r\n");
        out.write("m4_predicted_saving_s: " + decimal(metrics, "m4_predicted_saving_s", 0.0) + "\r\n");
        out.write("m4_rejected_by_budget: " + number(metrics, "m4_rejected_by_budget", 0L) + "\r\n");
        out.write("m4_rejected_by_cost: " + number(metrics, "m4_rejected_by_cost", 0L) + "\r\n");
        out.write("m4_target_factor: " + decimal(metrics, "m4_target_factor", 1.20) + "\r\n");
        out.write("m4_extra_task_ms: " + decimal(metrics, "m4_extra_task_ms", 1.0) + "\r\n");
        out.write("m4_extra_map_ms: " + decimal(metrics, "m4_extra_map_ms", 0.1) + "\r\n");
        out.write("m4_physical_execution: " + number(metrics, "m4_physical_execution", 0L) + "\r\n");
        out.write("m2_candidate_pairs: " + number(metrics, "m2_candidate_pairs", 0L) + "\r\n");
        out.write("m2_accepted_pairs: " + number(metrics, "m2_accepted_pairs", 0L) + "\r\n");
        out.write("m2_rejected_pairs: " + number(metrics, "m2_rejected_pairs", 0L) + "\r\n");
        out.write("m2_rejected_low_overlap: " + number(metrics, "m2_rejected_low_overlap", 0L) + "\r\n");
        out.write("m2_rejected_memory_cap: " + number(metrics, "m2_rejected_memory_cap", 0L) + "\r\n");
        out.write("m2_rejected_negative_benefit: " + number(metrics, "m2_rejected_negative_benefit", 0L) + "\r\n");
        out.write("m2_estimated_saved_records: " + number(metrics, "m2_estimated_saved_records", 0L) + "\r\n");
        out.write("m2_estimated_saved_bytes: " + decimal(metrics, "m2_estimated_saved_bytes", 0.0) + "\r\n");
        out.write("m2_estimated_index_saved: " + decimal(metrics, "m2_estimated_index_saved", 0.0) + "\r\n");
        out.write("m2_estimated_bundle_cost: " + decimal(metrics, "m2_estimated_bundle_cost", 0.0) + "\r\n");
        out.write("m2_max_group_records: " + number(metrics, "m2_max_group_records", 0L) + "\r\n");
        out.write("m2_max_group_owners: " + number(metrics, "m2_max_group_owners", 0L) + "\r\n");
        out.write("m2_v2_enabled: " + number(metrics, "m2_v2_enabled", 0L) + "\r\n");
        out.write("m2_v2_query_enabled: " + number(metrics, "m2_v2_query_enabled", 0L) + "\r\n");
        out.write("m2_v2_rejected_work: " + number(metrics, "m2_v2_rejected_work", 0L) + "\r\n");
        out.write("m2_v2_rejected_records: " + number(metrics, "m2_v2_rejected_records", 0L) + "\r\n");
        out.write("m2_v2_max_bundle_work: " + decimal(metrics, "m2_v2_max_bundle_work", 0.0) + "\r\n");
        out.write("m2_v2_max_bundle_records: " + number(metrics, "m2_v2_max_bundle_records", 0L) + "\r\n");
        out.write("m2_v2_owner_query_maps: " + number(metrics, "m2_v2_owner_query_maps", 0L) + "\r\n");
        out.write("m2_v3_enabled: " + number(metrics, "m2_v3_enabled", 0L) + "\r\n");
        out.write("masked_union_points: " + number(metrics, "masked_union_points", 0L) + "\r\n");
        out.write("masked_logical_records: " + number(metrics, "masked_logical_records", 0L) + "\r\n");
        out.write("m2_v3_mask_checks: " + number(metrics, "m2_v3_mask_checks", 0L) + "\r\n");
        out.write("m2_v3_mask_filtered: " + number(metrics, "m2_v3_mask_filtered", 0L) + "\r\n");
        out.write("m2_v3_rejected_work: " + number(metrics, "m2_v3_rejected_work", 0L) + "\r\n");
        out.write("m2_v3_predicted_benefit_ms: " + decimal(metrics, "m2_v3_predicted_benefit_ms", 0.0) + "\r\n");
        out.write("m2_v3_predicted_shuffle_saved_ms: " + decimal(metrics, "m2_v3_predicted_shuffle_saved_ms", 0.0) + "\r\n");
        out.write("m2_v3_predicted_index_saved_ms: " + decimal(metrics, "m2_v3_predicted_index_saved_ms", 0.0) + "\r\n");
        out.write("m2_v3_predicted_query_saved_ms: " + decimal(metrics, "m2_v3_predicted_query_saved_ms", 0.0) + "\r\n");
        out.write("m2_v3_predicted_block_build_ms: " + decimal(metrics, "m2_v3_predicted_block_build_ms", 0.0) + "\r\n");
        out.write("m2_v3_predicted_long_tail_ms: " + decimal(metrics, "m2_v3_predicted_long_tail_ms", 0.0) + "\r\n");
        out.write("m2_v3_shuffle_ms_per_record: " + decimal(metrics, "m2_v3_shuffle_ms_per_record", 0.0) + "\r\n");
        out.write("m2_v3_index_ms_per_record: " + decimal(metrics, "m2_v3_index_ms_per_record", 0.0) + "\r\n");
        out.write("m2_v3_query_ms_per_work: " + decimal(metrics, "m2_v3_query_ms_per_work", 0.0) + "\r\n");
        out.write("m2_v3_block_build_ms_per_record: " + decimal(metrics, "m2_v3_block_build_ms_per_record", 0.0) + "\r\n");
        out.write("m2_v3_long_tail_ms_per_work: " + decimal(metrics, "m2_v3_long_tail_ms_per_work", 0.0) + "\r\n");
        out.write("m2_v3_min_benefit_ms: " + decimal(metrics, "m2_v3_min_benefit_ms", 0.0) + "\r\n");
        for (String key : new String[]{"joint_refine_ms", "joint_boundary_before", "joint_boundary_after",
                "joint_span_before", "joint_span_after", "joint_moves",
                "query_x", "query_y", "experiment_enabled", "experiment_partition_strategy", "experiment_organization",
                "experiment_transport_encoding", "experiment_shard_strategy", "experiment_prepared_mode",
                "experiment_projection_cache", "experiment_geometric_bounds", "owner_threads",
                "owner_layout_sha256", "bundle_layout_sha256", "shard_layout_sha256"}) {
            if (metrics.containsKey(key)) out.write(key + ": " + metrics.get(key) + "\r\n");
        }
        out.write("result_fingerprint: " + fingerprint + "\r\n");
    }
}
