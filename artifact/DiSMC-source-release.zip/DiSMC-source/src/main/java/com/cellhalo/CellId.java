package com.cellhalo;

import com.Zorder;

import java.io.Serializable;
import java.util.Objects;

public final class CellId implements Serializable {
    public final int x;
    public final int y;
    private transient String zValue;
    private transient boolean zCodeComputed;
    private transient long zCode;

    public CellId(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public static CellId fromPoint(double px, double py, double cellSize) {
        int cellX = (int) Math.floor(px / cellSize);
        int cellY = (int) Math.floor(py / cellSize);
        return new CellId(cellX, cellY);
    }

    public String zValue() {
        if (zValue == null) {
            zValue = Zorder.valueOf(2, new int[]{Math.max(0, x), Math.max(0, y)});
        }
        return zValue;
    }

    public long zCode() {
        if (!zCodeComputed) {
            zCode = zCode(x, y);
            zCodeComputed = true;
        }
        return zCode;
    }

    public static long zCode(int x, int y) {
        return mortonCode(Math.max(0, x), Math.max(0, y));
    }

    private static long mortonCode(int x, int y) {
        // Match Zorder.valueOf's bit order: x bit first, then y bit.
        return (spreadBits(x) << 1) | spreadBits(y);
    }

    private static long spreadBits(int value) {
        long bits = value & 0xffffffffL;
        bits = (bits | (bits << 16)) & 0x0000ffff0000ffffL;
        bits = (bits | (bits << 8)) & 0x00ff00ff00ff00ffL;
        bits = (bits | (bits << 4)) & 0x0f0f0f0f0f0f0f0fL;
        bits = (bits | (bits << 2)) & 0x3333333333333333L;
        bits = (bits | (bits << 1)) & 0x5555555555555555L;
        return bits;
    }

    public long packed() {
        return (((long) x) << 32) ^ (y & 0xffffffffL);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CellId)) {
            return false;
        }
        CellId that = (CellId) other;
        return x == that.x && y == that.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }

    @Override
    public String toString() {
        return "(" + x + "," + y + ")";
    }
}
