package com.cellhalo;

import java.io.Serializable;

public final class PartitionMetrics implements Serializable {
    public final int partitionId;
    public final long corePoints;
    public final long haloPoints;
    public final long uniqueSourcePartitions;

    public PartitionMetrics(int partitionId, long corePoints, long haloPoints, long uniqueSourcePartitions) {
        this.partitionId = partitionId;
        this.corePoints = corePoints;
        this.haloPoints = haloPoints;
        this.uniqueSourcePartitions = uniqueSourcePartitions;
    }
}
