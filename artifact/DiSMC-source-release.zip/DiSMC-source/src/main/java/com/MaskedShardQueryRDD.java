package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import org.apache.spark.Dependency;
import org.apache.spark.NarrowDependency;
import org.apache.spark.Partition;
import org.apache.spark.TaskContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.util.CollectionAccumulator;
import org.apache.spark.util.LongAccumulator;
import scala.collection.JavaConverters;
import scala.collection.Seq;
import scala.reflect.ClassTag$;

/** Executes each M4 bundle round as a separate Spark partition. */
public final class MaskedShardQueryRDD extends RDD<HashMap<Double, Circle>> {
    private static final ThreadLocal<ExecutorService> OWNER_POOL =
            new ThreadLocal<ExecutorService>() {
                protected ExecutorService initialValue() {
                    return Executors.newFixedThreadPool(2, new ThreadFactory() {
                        public Thread newThread(Runnable runnable) {
                            Thread thread = new Thread(runnable, "masked-owner-query");
                            thread.setDaemon(true);
                            return thread;
                        }
                    });
                }
            };
    private static final class ShardPartition implements Partition {
        final int id;
        final int groupId;
        final Partition parent;

        ShardPartition(int id, int groupId, Partition parent) {
            this.id = id;
            this.groupId = groupId;
            this.parent = parent;
        }

        public int index() { return id; }
        public boolean org$apache$spark$Partition$$super$equals(Object other) {
            return super.equals(other);
        }
        public boolean equals(Object other) {
            return other instanceof ShardPartition && ((ShardPartition) other).id == id;
        }
        public int hashCode() { return id; }
    }

    private static final class ShardDependency
            extends NarrowDependency<MaskedPreparedNeighborhood> {
        private final int[] groups;

        ShardDependency(RDD<MaskedPreparedNeighborhood> parent, BundleShardLayout layout) {
            super(parent);
            groups = new int[layout.taskCount()];
            for (int child = 0; child < groups.length; child++) {
                groups[child] = layout.parentGroup(child);
            }
        }

        public Seq<Object> getParents(int child) {
            return JavaConverters.asScalaBufferConverter(
                    Collections.<Object>singletonList(groups[child])).asScala().toSeq();
        }
    }

    private static Seq<Dependency<?>> dependency(
            RDD<MaskedPreparedNeighborhood> parent, BundleShardLayout layout) {
        return JavaConverters.asScalaBufferConverter(Collections.<Dependency<?>>singletonList(
                new ShardDependency(parent, layout))).asScala().toSeq();
    }

    private final RDD<MaskedPreparedNeighborhood> parent;
    private final BundleShardLayout layout;
    private final double dc;
    private final double cellSize;
    private final double qx;
    private final double qy;
    private final int density;
    private final LongAccumulator preparedReads;
    private final LongAccumulator candidates;
    private final LongAccumulator singlePointCandidates;
    private final LongAccumulator pairCandidates;
    private final LongAccumulator zChecks;
    private final LongAccumulator distanceChecks;
    private final LongAccumulator projectedCandidates;
    private final LongAccumulator projectedCountHits;
    private final LongAccumulator projectedBoundHits;
    private final LongAccumulator maskChecks;
    private final LongAccumulator maskFiltered;
    private final CollectionAccumulator<Long> taskTimesMs;
    private final CollectionAccumulator<Long> bundleTaskTimesMs;
    private final ShardPartition[] partitions;
    private final EngineOptions options;
    private final int ownerThreads;
    private final TaskObservation.Collector observer;
    private final MaskedLaneQuery.Metrics metrics;

    public MaskedShardQueryRDD(JavaRDD<MaskedPreparedNeighborhood> prepared,
            BundleShardLayout layout,
            double dc, double cellSize, double qx, double qy, int density,
            LongAccumulator preparedReads,
            LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks,
            LongAccumulator distanceChecks, CollectionAccumulator<Long> taskTimesMs,
            CollectionAccumulator<Long> bundleTaskTimesMs,
            LongAccumulator projectedCandidates, LongAccumulator projectedCountHits,
            LongAccumulator projectedBoundHits, LongAccumulator maskChecks,
            LongAccumulator maskFiltered) {
        this(prepared, layout, dc, cellSize, qx, qy, density, preparedReads,
                candidates, singlePointCandidates, pairCandidates, zChecks, distanceChecks,
                taskTimesMs, bundleTaskTimesMs,
                projectedCandidates, projectedCountHits, projectedBoundHits,
                maskChecks, maskFiltered, EngineOptions.FULL);
    }

    public MaskedShardQueryRDD(JavaRDD<MaskedPreparedNeighborhood> prepared,
            BundleShardLayout layout,
            double dc, double cellSize, double qx, double qy, int density,
            LongAccumulator preparedReads,
            LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks,
            LongAccumulator distanceChecks, CollectionAccumulator<Long> taskTimesMs,
            CollectionAccumulator<Long> bundleTaskTimesMs,
            LongAccumulator projectedCandidates, LongAccumulator projectedCountHits,
            LongAccumulator projectedBoundHits, LongAccumulator maskChecks,
            LongAccumulator maskFiltered, EngineOptions options) {
        this(prepared, layout, dc, cellSize, qx, qy, density, preparedReads,
                candidates, singlePointCandidates, pairCandidates, zChecks, distanceChecks,
                taskTimesMs, bundleTaskTimesMs, projectedCandidates, projectedCountHits,
                projectedBoundHits, maskChecks, maskFiltered, options, 2);
    }

    public MaskedShardQueryRDD(JavaRDD<MaskedPreparedNeighborhood> prepared,
            BundleShardLayout layout, double dc, double cellSize, double qx, double qy, int density,
            LongAccumulator preparedReads, LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks, LongAccumulator distanceChecks,
            CollectionAccumulator<Long> taskTimesMs, CollectionAccumulator<Long> bundleTaskTimesMs,
            LongAccumulator projectedCandidates, LongAccumulator projectedCountHits,
            LongAccumulator projectedBoundHits, LongAccumulator maskChecks,
            LongAccumulator maskFiltered, EngineOptions options, int ownerThreads) {
        this(prepared, layout, dc, cellSize, qx, qy, density, preparedReads, candidates,
                singlePointCandidates, pairCandidates, zChecks, distanceChecks, taskTimesMs,
                bundleTaskTimesMs, projectedCandidates, projectedCountHits, projectedBoundHits,
                maskChecks, maskFiltered, options, ownerThreads, null);
    }

    public MaskedShardQueryRDD(JavaRDD<MaskedPreparedNeighborhood> prepared,
            BundleShardLayout layout, double dc, double cellSize, double qx, double qy, int density,
            LongAccumulator preparedReads, LongAccumulator candidates, LongAccumulator singlePointCandidates,
            LongAccumulator pairCandidates, LongAccumulator zChecks, LongAccumulator distanceChecks,
            CollectionAccumulator<Long> taskTimesMs, CollectionAccumulator<Long> bundleTaskTimesMs,
            LongAccumulator projectedCandidates, LongAccumulator projectedCountHits,
            LongAccumulator projectedBoundHits, LongAccumulator maskChecks,
            LongAccumulator maskFiltered, EngineOptions options, int ownerThreads, TaskObservation.Collector observer) {
        super(prepared.context(), dependency(prepared.rdd(), layout),
                ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
        if (ownerThreads != 1 && ownerThreads != 2) throw new IllegalArgumentException("ownerThreads must be 1 or 2");
        this.ownerThreads = ownerThreads;
        if (observer != null && ownerThreads != 1) throw new IllegalArgumentException("local observation requires serial owner lanes");
        this.observer = observer;
        this.metrics = new MaskedLaneQuery.Metrics(candidates, singlePointCandidates, pairCandidates, zChecks,
                distanceChecks, projectedCandidates, projectedCountHits, projectedBoundHits, maskChecks, maskFiltered);
        if (prepared.getNumPartitions() != layout.groupCount()) {
            throw new IllegalArgumentException("prepared parent/group count mismatch");
        }
        this.parent = prepared.rdd();
        this.layout = layout;
        this.dc = dc;
        this.cellSize = cellSize;
        this.qx = qx;
        this.qy = qy;
        this.density = density;
        this.preparedReads = preparedReads;
        this.candidates = candidates;
        this.singlePointCandidates = singlePointCandidates;
        this.pairCandidates = pairCandidates;
        this.zChecks = zChecks;
        this.distanceChecks = distanceChecks;
        this.taskTimesMs = taskTimesMs;
        this.bundleTaskTimesMs = bundleTaskTimesMs;
        this.projectedCandidates = projectedCandidates;
        this.projectedCountHits = projectedCountHits;
        this.projectedBoundHits = projectedBoundHits;
        this.maskChecks = maskChecks;
        this.maskFiltered = maskFiltered;
        this.options = options;
        Partition[] parents = parent.partitions();
        partitions = new ShardPartition[layout.taskCount()];
        for (int child = 0; child < partitions.length; child++) {
            int group = layout.parentGroup(child);
            partitions[child] = new ShardPartition(child, group, parents[group]);
        }
    }

    public Partition[] getPartitions() { return partitions; }

    public scala.collection.Iterator<HashMap<Double, Circle>> compute(
            Partition split, TaskContext context) {
        long taskStart = System.nanoTime();
        ShardPartition shard = (ShardPartition) split;
        scala.collection.Iterator<MaskedPreparedNeighborhood> input =
                parent.iterator(shard.parent, context);
        if (!input.hasNext()) {
            throw new IllegalStateException("missing prepared bundle index");
        }
        MaskedPreparedNeighborhood prepared = input.next();
        if (input.hasNext()) {
            throw new IllegalStateException("multiple prepared bundle indexes");
        }
        long parentNanos = System.nanoTime() - taskStart;
        preparedReads.add(1L);
        BundleShardLayout.Task task = layout.task(shard.id);
        List<HashMap<Double, Circle>> results;
        if (observer == null) {
            results = usesBundleParallelism(task, ownerThreads)
                    ? executeLegacyBundle(prepared, task) : executePhysicalRound(prepared, task);
        } else {
            results = new ArrayList<HashMap<Double, Circle>>(task.owners.length);
            long kernelNanos = 0;
            long[] observedCounters = new long[10];
            for (int lane = 0; lane < task.owners.length; lane++) {
                MaskedLaneQuery.Evaluation evaluated = MaskedLaneQuery.evaluate(prepared, task.slots[lane],
                        task.owners[lane], task.round, task.pieces[lane], dc, cellSize, qx, qy, density, options);
                metrics.add(evaluated);
                results.add(evaluated.skyline);
                kernelNanos = Math.addExact(kernelNanos, evaluated.kernelNanos);
                for (int index = 0; index < observedCounters.length; index++) observedCounters[index] = Math.addExact(observedCounters[index], evaluated.counters[index]);
            }
            boolean builtHere = prepared.preparedTaskAttemptId == context.taskAttemptId();
            long prepareNanos = builtHere ? prepared.preparationNanos : 0;
            observer.record(context, task, Math.max(0, parentNanos - prepareNanos), prepareNanos,
                    kernelNanos, System.nanoTime() - taskStart, prepared.pointCount(),
                    builtHere ? prepared.pointCount() : 0, builtHere ? 1 : 0, observedCounters);
        }
        long elapsed = (System.nanoTime() - taskStart) / 1000000L;
        taskTimesMs.add(elapsed);
        bundleTaskTimesMs.add(elapsed);
        return JavaConverters.asScalaIteratorConverter(results.iterator()).asScala();
    }

    static boolean usesLegacyBundleParallelism(BundleShardLayout.Task task) {
        if (task == null || task.round != 0 || task.owners.length < 2) return false;
        for (int pieces : task.pieces) if (pieces != 1) return false;
        return true;
    }

    static boolean usesBundleParallelism(BundleShardLayout.Task task, int ownerThreads) {
        return ownerThreads == 2 && usesLegacyBundleParallelism(task);
    }

    private List<HashMap<Double, Circle>> executePhysicalRound(
            MaskedPreparedNeighborhood prepared, BundleShardLayout.Task task) {
        ArrayList<HashMap<Double, Circle>> results =
                new ArrayList<HashMap<Double, Circle>>(task.owners.length);
        for (int i = 0; i < task.owners.length; i++) {
            results.add(executeJob(prepared, task, i));
        }
        return results;
    }

    private List<HashMap<Double, Circle>> executeLegacyBundle(
            final MaskedPreparedNeighborhood prepared, final BundleShardLayout.Task task) {
        ExecutorService pool = OWNER_POOL.get();
        try {
            ArrayList<Future<HashMap<Double, Circle>>> futures =
                    new ArrayList<Future<HashMap<Double, Circle>>>(task.owners.length);
            for (int i = 0; i < task.owners.length; i++) {
                final int job = i;
                futures.add(pool.submit(new Callable<HashMap<Double, Circle>>() {
                    public HashMap<Double, Circle> call() {
                        return executeJob(prepared, task, job);
                    }
                }));
            }
            ArrayList<HashMap<Double, Circle>> results =
                    new ArrayList<HashMap<Double, Circle>>(task.owners.length);
            for (Future<HashMap<Double, Circle>> future : futures) results.add(future.get());
            return results;
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("masked legacy bundle query interrupted", exception);
        } catch (ExecutionException exception) {
            Throwable cause = exception.getCause();
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            throw new RuntimeException("masked legacy bundle query failed", cause);
        }
    }

    private HashMap<Double, Circle> executeJob(MaskedPreparedNeighborhood prepared,
            BundleShardLayout.Task task, int job) {
        MaskedLaneQuery.Evaluation evaluated = MaskedLaneQuery.evaluate(prepared, task.slots[job],
                task.owners[job], task.round, task.pieces[job], dc, cellSize, qx, qy, density, options);
        metrics.add(evaluated);
        return evaluated.skyline;
    }

    public JavaRDD<HashMap<Double, Circle>> asJava() {
        return JavaRDD.fromRDD(this,
                ClassTag$.MODULE$.<HashMap<Double, Circle>>apply(HashMap.class));
    }
}
