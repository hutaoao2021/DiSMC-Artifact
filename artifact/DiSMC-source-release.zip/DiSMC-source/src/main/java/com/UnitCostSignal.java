package com;

import java.util.ArrayList;
import java.util.List;

/** Same-information control: preserve responsibility and inputs, assign unit anchor work. */
public final class UnitCostSignal {
    private UnitCostSignal() {}
    public static MicroPartitionPopulation.Statistics apply(MicroPartitionPopulation.Statistics source,
            double[] originalWork) {
        MicroPartitionPopulation.Statistics result = SampledAnchorCostProbe.reweight(source,originalWork,originalWork);
        for (int i=0;i<source.candidates.length;i++) {
            MicroPartitionLayout.Candidate candidate=source.candidates[i];
            List<MicroPartitionLayout.Anchor> anchors=new ArrayList<>();
            for (int lane=0;lane<candidate.pieces;lane++)
                for (MicroPartitionLayout.Anchor anchor:candidate.anchors(lane))
                    anchors.add(new MicroPartitionLayout.Anchor(anchor.id,anchor.x,anchor.y,1));
            result.candidates[i]=new MicroPartitionLayout.Candidate(candidate.owner,candidate.responsibility,
                    candidate.pieces,anchors.toArray(new MicroPartitionLayout.Anchor[0]),candidate.radius,
                    candidate.splitAxis,candidate.dependencyInputsEnabled);
            if(!candidate.signature().equals(result.candidates[i].signature()))
                throw new IllegalStateException("unit signal changed responsibility");
        }
        return result;
    }
}
