package com;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

public final class MicroPartitionLayout {
    public static final class Anchor implements Serializable {
        public final long id;
        public final double x, y, work;
        public Anchor(long id, double x, double y, double work) {
            if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(work) || work < 0)
                throw new IllegalArgumentException("invalid anchor");
            this.id = id; this.x = x; this.y = y; this.work = work;
        }
    }

    public static final class Candidate implements Serializable {
        public final int owner, pieces;
        public final int splitAxis;
        public final String responsibility;
        public final double radius;
        public final boolean dependencyInputsEnabled;
        private final Anchor[][] lanes;
        private SampledPointRule pointRule;private long[] exactCounts;
        private final double[] physicalWork;
        private final Map<Long, Integer> laneById = new HashMap<>();
        private final double[][] envelopes;
        private final boolean[] safeEnvelopes;

        public Candidate(int owner, String responsibility, int pieces, Anchor[] anchors, double radius) {
            this(owner,responsibility,pieces,anchors,radius,-1);
        }

        public Candidate(int owner, String responsibility, int pieces, Anchor[] anchors, double radius, int splitAxis) {
            this(owner,responsibility,pieces,anchors,radius,splitAxis,true);
        }

        public Candidate(int owner, String responsibility, int pieces, Anchor[] anchors, double radius, int splitAxis,
                boolean dependencyInputsEnabled) {
            if (splitAxis < -1 || splitAxis > 1 || splitAxis >= 0 && (!responsibility.equals("spatial") || pieces != 2))
                throw new IllegalArgumentException("invalid split axis");
            this.splitAxis = splitAxis;
            this.physicalWork = null;
            if (owner < 0 || anchors == null || !Double.isFinite(radius) || radius <= 0
                    || !(pieces >= 1 && pieces <= 64 && (pieces & (pieces-1)) == 0)
                    || !(responsibility.equals("hash") || responsibility.equals("spatial"))
                    || pieces > 1 && anchors.length < pieces)
                throw new IllegalArgumentException("invalid responsibility layout");
            this.owner = owner; this.responsibility = responsibility; this.pieces = pieces; this.radius = radius;
            this.dependencyInputsEnabled = dependencyInputsEnabled;
            Anchor[] sorted = anchors.clone();
            Arrays.sort(sorted, Comparator.comparingLong(anchor -> anchor.id));
            for (int index = 1; index < sorted.length; index++)
                if (sorted[index - 1].id == sorted[index].id) throw new IllegalArgumentException("duplicate anchor ID");
            lanes = new Anchor[pieces][];
            if (responsibility.equals("hash")) {
                List<List<Anchor>> lists = new ArrayList<>();
                for (int lane = 0; lane < pieces; lane++) lists.add(new ArrayList<>());
                for (Anchor anchor : sorted) lists.get(BudgetedQueryShards.shard(anchor.id, pieces)).add(anchor);
                for (int lane = 0; lane < pieces; lane++) lanes[lane] = lists.get(lane).toArray(new Anchor[0]);
            } else split(sorted, 0, pieces);
            envelopes = dependencyInputsEnabled ? new double[pieces][4] : null;
            safeEnvelopes = dependencyInputsEnabled ? new boolean[pieces] : null;
            for (int lane = 0; lane < pieces; lane++) {
                double[] bounds = dependencyInputsEnabled ? envelopes[lane] : null;
                if (dependencyInputsEnabled) {
                    bounds[0] = bounds[1] = Double.POSITIVE_INFINITY;
                    bounds[2] = bounds[3] = Double.NEGATIVE_INFINITY;
                    safeEnvelopes[lane] = radius >= 0.01 && radius <= 100000;
                }
                for (Anchor anchor : lanes[lane]) {
                    laneById.put(anchor.id, lane);
                    if (dependencyInputsEnabled) {
                        safeEnvelopes[lane] &= safeCoordinate(anchor.x) && safeCoordinate(anchor.y);
                        bounds[0] = Math.min(bounds[0], anchor.x); bounds[1] = Math.min(bounds[1], anchor.y);
                        bounds[2] = Math.max(bounds[2], anchor.x); bounds[3] = Math.max(bounds[3], anchor.y);
                    }
                }
            }
        }

        private Candidate(int owner,SampledPointRule rule,long[] counts,double[][] bounds,double[] work,double radius){
            if(owner<0||counts.length!=rule.pieces||bounds.length!=rule.pieces||work.length!=rule.pieces)throw new IllegalArgumentException("sampled point dimensions");
            this.owner=owner;pieces=rule.pieces;splitAxis=-1;responsibility="spatial";this.radius=radius;dependencyInputsEnabled=true;
            pointRule=rule;exactCounts=counts.clone();physicalWork=work.clone();lanes=new Anchor[pieces][];envelopes=new double[pieces][4];safeEnvelopes=new boolean[pieces];
            for(int l=0;l<pieces;l++){if(counts[l]<0||!Double.isFinite(work[l])||work[l]<0)throw new IllegalArgumentException("invalid exact point population");lanes[l]=new Anchor[0];envelopes[l]=bounds[l].clone();safeEnvelopes[l]=radius>=.01&&radius<=100000;for(double v:bounds[l])safeEnvelopes[l]&=safeCoordinate(v);}
        }
        public static Candidate sampledPoint(int owner,SampledPointRule rule,long[] counts,double[][] bounds,double[] work,double radius){return new Candidate(owner,rule,counts,bounds,work,radius);}
        public boolean isSampledPoint(){return pointRule!=null;}
        public long anchorCount(int lane){return pointRule==null?lanes[lane].length:exactCounts[lane];}
        public int laneOf(Point p){return pointRule==null?laneOf(p.id):pointRule.lane(p.id,p.x,p.y);}
        private Candidate(Candidate source, double[] taskWork) {
            owner = source.owner; pieces = source.pieces; splitAxis = source.splitAxis;pointRule=source.pointRule;exactCounts=source.exactCounts;
            responsibility = source.responsibility; radius = source.radius;
            dependencyInputsEnabled = source.dependencyInputsEnabled;
            // Geometry/responsibility are immutable after construction. Cost does not repartition anchors.
            lanes = source.lanes; envelopes = source.envelopes; safeEnvelopes = source.safeEnvelopes;
            laneById.putAll(source.laneById);
            physicalWork = taskWork.clone();
        }

        /** A physical task can pay first-touch work in addition to its anchors' additive weight. */
        public Candidate withPhysicalWork(double[] taskWork) {
            if (taskWork == null || taskWork.length != pieces)
                throw new IllegalArgumentException("physical cost dimensions");
            for (double value : taskWork) if (!Double.isFinite(value) || value < 0)
                throw new IllegalArgumentException("invalid physical task cost");
            return new Candidate(this,taskWork);
        }

        private void split(Anchor[] anchors, int start, int count) {
            if (count == 1) { lanes[start] = anchors; return; }
            double minX = Double.POSITIVE_INFINITY, minY = minX, maxX = Double.NEGATIVE_INFINITY, maxY = maxX;
            for (Anchor anchor : anchors) {
                minX = Math.min(minX, anchor.x); maxX = Math.max(maxX, anchor.x);
                minY = Math.min(minY, anchor.y); maxY = Math.max(maxY, anchor.y);
            }
            final boolean byX = splitAxis < 0 ? maxX - minX >= maxY - minY : splitAxis == 0;
            Arrays.sort(anchors, Comparator.<Anchor>comparingDouble(anchor -> byX ? anchor.x : anchor.y)
                    .thenComparingDouble(anchor -> byX ? anchor.y : anchor.x).thenComparingLong(anchor -> anchor.id));
            int middle = anchors.length / 2;
            split(Arrays.copyOfRange(anchors, 0, middle), start, count / 2);
            split(Arrays.copyOfRange(anchors, middle, anchors.length), start + count / 2, count / 2);
        }

        public long[] anchorIds(int lane) {
            long[] ids = new long[lanes[lane].length];
            for (int index = 0; index < ids.length; index++) ids[index] = lanes[lane][index].id;
            Arrays.sort(ids);
            return ids;
        }
        public Anchor[] anchors(int lane) { return lanes[lane].clone(); }
        public int laneOf(long id) { return laneById.getOrDefault(id, -1); }
        public double work(int lane) {
            if (physicalWork != null) return physicalWork[lane];
            double total = 0; for (Anchor anchor : lanes[lane]) total += anchor.work; return total;
        }
        public String signature() {
            if(pointRule!=null)return digest("point-rule:"+owner+":"+Double.toHexString(radius)+":"+pointRule.signature());
            StringBuilder value = new StringBuilder("micro-v1:").append(owner).append(':').append(responsibility)
                    .append(':').append(pieces).append(':').append(Double.toHexString(radius));
            for (int lane = 0; lane < pieces; lane++) {
                Anchor[] sorted = lanes[lane].clone(); Arrays.sort(sorted, Comparator.comparingLong(anchor -> anchor.id));
                value.append('|').append(lane);
                for (Anchor anchor : sorted) value.append(':').append(anchor.id).append(',')
                        .append(Double.toHexString(anchor.x)).append(',').append(Double.toHexString(anchor.y));
            }
            return digest(value.toString());
        }
    }

    public static boolean matches(Candidate candidate, int lane, Point point, boolean dependencyInputs) {
        if (!dependencyInputs) return true;
        if (!candidate.dependencyInputsEnabled) throw new IllegalStateException("dependency inputs disabled for this candidate");
        if (candidate.anchorCount(lane) == 0) return false;
        if (!safeCoordinate(point.x) || !safeCoordinate(point.y)) return true;
        if (!candidate.safeEnvelopes[lane]) return true;
        double[] bounds = candidate.envelopes[lane];
        double deltaX = Math.max(0, Math.max(Math.nextDown(bounds[0]) - point.x, point.x - Math.nextUp(bounds[2])));
        double deltaY = Math.max(0, Math.max(Math.nextDown(bounds[1]) - point.y, point.y - Math.nextUp(bounds[3])));
        return Math.hypot(deltaX, deltaY) <= Math.nextUp(2 * candidate.radius + 0.02);
    }

    static boolean safeCoordinate(double coordinate) { return Double.isFinite(coordinate) && Math.abs(coordinate) <= 10000000; }
    static String digest(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder text = new StringBuilder(); for (byte octet : hash) text.append(String.format("%02x", octet & 255));
            return text.toString();
        } catch (java.security.NoSuchAlgorithmException error) { throw new IllegalStateException(error); }
    }
    private MicroPartitionLayout() { }
}
