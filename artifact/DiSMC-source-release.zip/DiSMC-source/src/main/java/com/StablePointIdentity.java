package com;

import java.util.ArrayList;
import java.util.List;
import org.apache.spark.api.java.JavaRDD;
import scala.Tuple2;

public final class StablePointIdentity {
    private StablePointIdentity() {}

    public static JavaRDD<Tuple2<Double, Double>> coordinates(JavaRDD<Tuple2<Double, Double>> input) {
        return input.mapPartitions(iterator -> {
            List<Tuple2<Double, Double>> ordered = new ArrayList<>();
            iterator.forEachRemaining(ordered::add);
            ordered.sort((left, right) -> {
                int horizontal = Double.compare(left._1(), right._1());
                return horizontal != 0 ? horizontal : Double.compare(left._2(), right._2());
            });
            return ordered.iterator();
        });
    }
}
