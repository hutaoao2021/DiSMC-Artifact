package com;

import java.util.ArrayList;
import java.util.List;

public enum MethodProfile {
    SINGLE_ESMC("single_esmc", false, false, false, false, false, false),
    Z_D0("z_d0", false, false, false, false, false, false),
    HILBERT_D0("hilbert_d0", false, false, false, false, false, false),
    GRID_D0("grid_d0", false, false, false, false, false, false),
    FULL("full", true, true, true, true, true, true),
    HILBERT_FULL("hilbert_full", true, true, true, true, true, true),
    HILBERT_WO_PLANNER("hilbert_wo_planner", false, false, true, false, true, true),
    HILBERT_WO_ENGINE("hilbert_wo_engine", true, true, false, true, false, false),
    WO_PLANNER("wo_planner", false, false, true, false, true, true),
    WO_ENGINE("wo_engine", true, true, false, true, false, false),
    WO_DEPENDENCY_PARTITION("wo_dependency_partition", false, true, true, true, true, true),
    WO_SHARING("wo_sharing", true, false, true, true, true, true),
    WO_REFINEMENT("wo_refinement", true, true, true, false, true, true),
    WO_NEW_BOUNDS("wo_new_bounds", true, true, true, true, false, true),
    WO_PREPARED_REUSE("wo_prepared_reuse", true, true, true, true, true, false);

    private final String id;
    public final boolean dependencyPartition;
    public final boolean sharedNeighborhood;
    public final boolean reusableEngine;
    public final boolean refinement;
    public final boolean newBounds;
    public final boolean preparedReuse;

    MethodProfile(String id, boolean dependencyPartition, boolean sharedNeighborhood,
            boolean reusableEngine, boolean refinement, boolean newBounds,
            boolean preparedReuse) {
        this.id = id;
        this.dependencyPartition = dependencyPartition;
        this.sharedNeighborhood = sharedNeighborhood;
        this.reusableEngine = reusableEngine;
        this.refinement = refinement;
        this.newBounds = newBounds;
        this.preparedReuse = preparedReuse;
    }

    public String id() {
        return id;
    }

    public boolean isStandaloneBaseline() {
        return this == SINGLE_ESMC || this == Z_D0 || this == HILBERT_D0 || this == GRID_D0;
    }

    public boolean usesHilbertCellOrder() {
        return this == HILBERT_FULL
                || this == HILBERT_WO_PLANNER
                || this == HILBERT_WO_ENGINE;
    }

    public String composition() {
        if (this == SINGLE_ESMC) return "single_machine_esmc";
        if (this == Z_D0) return "z_interval+independent+baseline+single_task";
        if (this == HILBERT_D0) return "hilbert_interval+mbr_halo+baseline+single_task";
        if (this == GRID_D0) return "grid_point_count+exact_halo+baseline+single_task";
        return "partition=" + (dependencyPartition ? "dependency" : "point_count")
                + ",routing=" + (sharedNeighborhood ? "shared_masked" : "independent")
                + ",engine=" + (reusableEngine ? "reusable" : "baseline")
                + ",layout=" + (refinement ? "budgeted_shards" : "one_owner")
                + ",bounds=" + (newBounds ? "enabled" : "disabled")
                + ",prepared_reuse=" + (preparedReuse ? "enabled" : "disabled")
                + ",cell_order=" + (usesHilbertCellOrder() ? "hilbert" : "morton");
    }

    public static MethodProfile parse(String value) {
        if (value != null) {
            for (MethodProfile profile : values()) {
                if (profile.id.equalsIgnoreCase(value.trim())) return profile;
            }
        }
        List<String> names = new ArrayList<String>();
        for (MethodProfile profile : values()) names.add(profile.id);
        throw new IllegalArgumentException("unknown profile '" + value
                + "'; valid profiles: " + names);
    }
}
