package com;

import java.io.Serializable;
import java.util.HashMap;
import org.apache.spark.util.LongAccumulator;

public final class MaskedLaneQuery {
    // nanoTime values are comparable only within this executor JVM/class-loader domain.
    private static final String KERNEL_CLOCK_ID = java.util.UUID.randomUUID().toString();
    public static final class Evaluation {
        public final AnchorCostObservation[] anchorObservations;
        public final long geometricBucketClassifications;
        public final long setupNanos,denseBoundaryBuildNanos;
        public final HashMap<Double, Circle> skyline;
        public final long[] counters;
        public final long kernelNanos;
        public final long kernelStartNanos, kernelEndNanos;
        public final String kernelClockId;
        public final long frontierPrunedAnchors,frontierBoundLookups,projectionDuplicatesSkipped;
        public final long anchorBoundaryCalls;
        public final long pairCirclesCreated,candidateBatchFlushes;
        public final long countWindowRequests,countWindowHits,countWindowBucketLookups;
        public final long countWindowEntriesPeak,countWindowReferencesPeak,countWindowEvictions;

        private Evaluation(MaskedIndexedEMCS query, long kernelStartNanos, long kernelEndNanos,long setupNanos) {
            this.setupNanos=setupNanos;denseBoundaryBuildNanos=query.denseBoundaryBuildNanos;
            anchorObservations=query.anchorObservations==null?new AnchorCostObservation[0]:query.anchorObservations.toArray(new AnchorCostObservation[0]);
            geometricBucketClassifications=query.geometricBucketClassifications;
            skyline = query.skymap;
            counters = new long[]{query.candidateCount, query.singlePointCandidateCount,
                    query.pairCandidateCount, query.zWindowChecks, query.pointDistanceChecks,
                    query.projectedCandidates, query.projectedCountHits, query.projectedBoundHits,
                    query.maskChecks, query.maskFiltered};
            this.kernelStartNanos = kernelStartNanos;
            this.kernelEndNanos = kernelEndNanos;
            this.kernelNanos = kernelEndNanos - kernelStartNanos;
            this.kernelClockId = KERNEL_CLOCK_ID;
            this.frontierPrunedAnchors=query.frontierPrunedAnchors;
            this.frontierBoundLookups=query.frontierBoundLookups;
            this.projectionDuplicatesSkipped=query.projectionDuplicatesSkipped;
            this.anchorBoundaryCalls=query.anchorBoundaryCalls;
            this.pairCirclesCreated=query.logicalPairCirclesCreated();this.candidateBatchFlushes=query.candidateBatchFlushes;
            countWindowRequests=query.countWindowRequests;this.countWindowHits=query.countWindowHits;
            this.countWindowBucketLookups=query.countWindowBucketLookups;this.countWindowEntriesPeak=query.countWindowEntriesPeak;
            this.countWindowReferencesPeak=query.countWindowReferencesPeak;this.countWindowEvictions=query.countWindowEvictions;
        }
    }

    public static final class Metrics implements Serializable {
        private final LongAccumulator[] counters;

        public Metrics(LongAccumulator... counters) {
            if (counters.length != 10) throw new IllegalArgumentException("ten kernel counters required");
            for (LongAccumulator counter : counters) {
                if (counter == null) throw new IllegalArgumentException("missing kernel counter");
            }
            this.counters = counters.clone();
        }

        public void add(Evaluation evaluation) {
            for (int index = 0; index < counters.length; index++) counters[index].add(evaluation.counters[index]);
        }
    }

    private MaskedLaneQuery() {
    }

    public static Evaluation evaluate(MaskedPreparedNeighborhood prepared, int slot, int owner,
            int piece, int pieces, double radius, double cellSize, double queryX, double queryY,
            int density, EngineOptions options) {
        return evaluate(prepared,slot,owner,piece,pieces,radius,cellSize,queryX,queryY,density,options,ProbeDominanceFrontier.EMPTY);
    }

    public static Evaluation evaluate(MaskedPreparedNeighborhood prepared, int slot, int owner,
            int piece, int pieces, double radius, double cellSize, double queryX, double queryY,
            int density, EngineOptions options, ProbeDominanceFrontier frontier) {
        return evaluate(prepared,slot,owner,piece,pieces,radius,cellSize,queryX,queryY,density,options,frontier,false);
    }

    public static Evaluation evaluate(MaskedPreparedNeighborhood prepared, int slot, int owner,
            int piece, int pieces, double radius, double cellSize, double queryX, double queryY,
            int density, EngineOptions options, ProbeDominanceFrontier frontier, boolean probeAnchorBounds) {
        return evaluate(prepared,slot,owner,piece,pieces,radius,cellSize,queryX,queryY,density,options,frontier,probeAnchorBounds,false);
    }

    public static Evaluation evaluate(MaskedPreparedNeighborhood prepared, int slot, int owner,
            int piece, int pieces, double radius, double cellSize, double queryX, double queryY,
            int density, EngineOptions options, ProbeDominanceFrontier frontier, boolean probeAnchorBounds,
            boolean coarseAnchorBounds) {
        return evaluateInternal(prepared,slot,owner,piece,pieces,radius,cellSize,queryX,queryY,density,options,frontier,probeAnchorBounds,coarseAnchorBounds,false);
    }
    public static Evaluation evaluateProfiled(MaskedPreparedNeighborhood prepared,int slot,int owner,
            int piece,int pieces,double radius,double cellSize,double queryX,double queryY,int density,EngineOptions options) {
        return evaluateProfiled(prepared,slot,owner,piece,pieces,radius,cellSize,queryX,queryY,density,options,ProbeDominanceFrontier.EMPTY);
    }
    public static Evaluation evaluateProfiled(MaskedPreparedNeighborhood prepared,int slot,int owner,
            int piece,int pieces,double radius,double cellSize,double queryX,double queryY,int density,EngineOptions options,ProbeDominanceFrontier frontier) {
        return evaluateInternal(prepared,slot,owner,piece,pieces,radius,cellSize,queryX,queryY,density,options,frontier,false,false,true);
    }
    private static Evaluation evaluateInternal(MaskedPreparedNeighborhood prepared,int slot,int owner,
            int piece,int pieces,double radius,double cellSize,double queryX,double queryY,int density,EngineOptions options,
            ProbeDominanceFrontier frontier,boolean probeAnchorBounds,boolean coarseAnchorBounds,boolean profileAnchors) {
        long start = System.nanoTime();
        MaskedIndexedEMCS query = new MaskedIndexedEMCS(radius);
        if(profileAnchors)query.enableAnchorObservations();
        query.q.x = queryX;
        query.q.y = queryY;
        query.density_k = density;
        query.part_id = owner;
        query.setCellConfig(cellSize);
        query.usePrepared(prepared, slot, owner, piece, pieces, options);
        query.useProbeFrontier(frontier);
        if(probeAnchorBounds)query.pruneProbeDominatedAnchors(coarseAnchorBounds);
        long setup=System.nanoTime()-start;
        query.method(radius);
        return new Evaluation(query, start, System.nanoTime(),setup);
    }
}
