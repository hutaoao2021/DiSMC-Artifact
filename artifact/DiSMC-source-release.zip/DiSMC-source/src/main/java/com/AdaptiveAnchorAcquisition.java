package com;
import java.io.Serializable;
import java.util.*;
import org.apache.spark.api.java.*;
import org.apache.spark.broadcast.Broadcast;
import scala.Tuple2;

/** Scale/memory bounded coordinate acquisition, preserving the original point candidate family. */
public final class AdaptiveAnchorAcquisition {
 private AdaptiveAnchorAcquisition(){}
 public static long budget(long n,long available,double rho,long minimum,double share,long bytesPerAnchor){
  if(n<0||available<0||!Double.isFinite(rho)||rho<0||minimum<4||!Double.isFinite(share)||share<=0||share>1||bytesPerAnchor<64)throw new IllegalArgumentException("invalid acquisition budget");
  long memory=(long)Math.floor(available*share/bytesPerAnchor);
  if(memory<4)throw new IllegalStateException("driver memory acquisition budget cannot hold a bounded split sample");
  return Math.min(memory,Math.max(minimum,(long)Math.ceil(rho*n)));
 }
 public static int coverageOwnerLimit(long cap,int requested,int partitions){
  if(cap<0||requested<1||partitions<1)throw new IllegalArgumentException("invalid coverage guard");
  long capacity=cap/Math.multiplyExact(4L,partitions);
  if(capacity<1)throw new IllegalStateException("coordinate budget cannot hold a distributed cut sample");
  return (int)Math.min(requested,capacity);
 }
 private static long rank(long id){long z=id+0x9e3779b97f4a7c15L;z=(z^(z>>>30))*0xbf58476d1ce4e5b9L;z=(z^(z>>>27))*0x94d049bb133111ebL;return z^(z>>>31);}
 private static int sampleCompare(MicroPartitionLayout.Anchor a,MicroPartitionLayout.Anchor b){int c=Long.compareUnsigned(rank(a.id),rank(b.id));return c==0?Long.compare(a.id,b.id):c;}
 private static final class Exact implements Serializable {
  final long[][]counts;final double[][]work;final double[][][]bounds;
  Exact(int n,int max){counts=new long[n][max];work=new double[n][max];bounds=new double[n][max][4];for(double[][] bs:bounds)for(double[] b:bs){b[0]=b[1]=Double.POSITIVE_INFINITY;b[2]=b[3]=Double.NEGATIVE_INFINITY;}}
 }
 public static MicroPartitionPopulation.Statistics refresh(JavaSparkContext sc,JavaRDD<Point> points,
   Broadcast<DistributedSMCGridbaseRebuilt.CellOwnerIndex> owners,int[]dx,int[]dy,
   double[]raw,double[]calibrated,Map<Long,Double> cellWeights,double radius,String mode,MicroPartitionPopulation.Statistics census){
  if(!mode.equals("dependency")&&!mode.equals("spatial_full")&&!mode.equals("hash_full"))throw new IllegalArgumentException("unsupported adaptive acquisition mode");
  long started=System.nanoTime(),n=0;for(long c:census.core)n=Math.addExact(n,c);
  Runtime vm=Runtime.getRuntime();long available=vm.maxMemory()-(vm.totalMemory()-vm.freeMemory());
  long cap=budget(n,available,sc.getConf().getDouble("spark.skyline.microAcquisitionFraction",.01),sc.getConf().getLong("spark.skyline.microAcquisitionMinimum",50000),sc.getConf().getDouble("spark.skyline.microAcquisitionMemoryShare",.15),sc.getConf().getLong("spark.skyline.microAcquisitionBytesPerAnchor",2048));
  boolean coverageFirst=sc.getConf().getBoolean("spark.skyline.microAcquisitionCoverageFirst",false);
  int ownerLimit=sc.getConf().getInt("spark.skyline.microAcquisitionOwnerLimit",coverageFirst?raw.length:32),partitions=points.getNumPartitions();
  if(ownerLimit<1||ownerLimit>256)throw new IllegalArgumentException("owner acquisition guard must be 1..256");
  int requestedOwnerLimit=ownerLimit;
  if(coverageFirst)ownerLimit=coverageOwnerLimit(cap,ownerLimit,partitions);
  final int maximumPieces=sc.getConf().getInt("spark.skyline.microDiagnosticMaxPieces",4);
  if(maximumPieces<4||maximumPieces>64||(maximumPieces&(maximumPieces-1))!=0)throw new IllegalArgumentException("diagnostic maximum pieces must be 4/8/16/32/64");
  int[]legacy=MicroPartitionPopulation.selectOwners(calibrated,census.core);
  boolean[] full=new boolean[raw.length],sampled=new boolean[raw.length];long fullCount=0;
  List<Integer> selected=new ArrayList<>(),order=new ArrayList<>();
  final int quota;
  if(coverageFirst){
   CoverageAcquisitionAllocation allocation=CoverageAcquisitionAllocation.allocate(census.core,calibrated,legacy,cap,ownerLimit,partitions);
   full=allocation.full;sampled=allocation.sampled;quota=allocation.quota;
   for(int o:allocation.selected)selected.add(o);
  }else{
  for(int o:legacy)if(selected.size()<ownerLimit&&census.core[o]>=2&&census.core[o]<=cap-fullCount){full[o]=true;selected.add(o);fullCount=Math.addExact(fullCount,census.core[o]);}
  for(int o=0;o<raw.length;o++)if(census.core[o]>=2&&!full[o])order.add(o);
  order.sort(Comparator.<Integer>comparingDouble(o->-calibrated[o]).thenComparingInt(o->o));
  int additional=Math.min(Math.max(0,ownerLimit-selected.size()),order.size());
  long remaining=cap-fullCount;
  additional=(int)Math.min(additional,remaining/(4L*partitions));
  quota=additional==0?0:(int)Math.min(Math.max(4,(2048+partitions-1)/partitions),remaining/(additional*(long)partitions));
  for(int i=0;i<additional;i++){int o=order.get(i);long reserve=(long)(additional-i-1)*quota*partitions;
   if(census.core[o]<=remaining-reserve){full[o]=true;fullCount=Math.addExact(fullCount,census.core[o]);remaining-=census.core[o];}
   else {sampled[o]=true;remaining-=(long)quota*partitions;}
   selected.add(o);
  }
  if(!order.isEmpty()&&additional==0&&calibrated[order.get(0)]>0&&census.core[order.get(0)]>cap)throw new IllegalStateException("no bounded-sample allowance for heavy owner; increase acquisition budget");
  }
  final boolean[] fullOwners=full,sampleOwners=sampled;
  Broadcast<Map<Long,Double>> weights=sc.broadcast(new HashMap<>(cellWeights));
  List<Tuple2<Integer,MicroPartitionLayout.Anchor>> collected;long collectionStart=System.nanoTime();
  try{collected=points.mapPartitions(input->{
   List<Tuple2<Integer,MicroPartitionLayout.Anchor>> result=new ArrayList<>();Map<Integer,PriorityQueue<MicroPartitionLayout.Anchor>> heaps=new HashMap<>();
   while(input.hasNext()){Point p=input.next();int o=owners.value().getOrDefault(p.packedCellId,-1);if(o<0||!fullOwners[o]&&!sampleOwners[o])continue;
    MicroPartitionLayout.Anchor a=new MicroPartitionLayout.Anchor(p.id,p.x,p.y,weights.value().getOrDefault(p.packedCellId,0.));
    if(fullOwners[o]){result.add(new Tuple2<>(o,a));if(result.size()>cap)throw new IllegalStateException("partition coordinate budget exceeded");}
    else {PriorityQueue<MicroPartitionLayout.Anchor> h=heaps.computeIfAbsent(o,k->new PriorityQueue<>((u,v)->sampleCompare(v,u)));if(h.size()<quota)h.add(a);else if(sampleCompare(a,h.peek())<0){h.remove();h.add(a);}}
   }
   for(Map.Entry<Integer,PriorityQueue<MicroPartitionLayout.Anchor>> e:heaps.entrySet())for(MicroPartitionLayout.Anchor a:e.getValue())result.add(new Tuple2<>(e.getKey(),a));
   if(result.size()>cap)throw new IllegalStateException("partition coordinate budget exceeded");return result.iterator();
  }).collect();}finally{weights.destroy();}
  if(collected.size()>cap)throw new IllegalStateException("global coordinate acquisition exceeded memory/scale budget");
  double collectMs=(System.nanoTime()-collectionStart)/1e6;
  Map<Integer,List<MicroPartitionLayout.Anchor>> byOwner=new HashMap<>();for(Tuple2<Integer,MicroPartitionLayout.Anchor> a:collected)byOwner.computeIfAbsent(a._1(),k->new ArrayList<>()).add(a._2());
  List<MicroPartitionLayout.Candidate> candidates=new ArrayList<>();List<SampledPointRule> rules=new ArrayList<>();List<Integer> ruleOwners=new ArrayList<>();
  for(int o:selected){MicroPartitionLayout.Anchor[] a=byOwner.getOrDefault(o,Collections.emptyList()).toArray(new MicroPartitionLayout.Anchor[0]);
   if(full[o]){if(a.length!=census.core[o])throw new IllegalStateException("complete owner coordinate count mismatch");
    for(String responsibility:new String[]{"spatial","hash"})for(int pieces:new int[]{2,4})if(a.length>=pieces)candidates.add(new MicroPartitionLayout.Candidate(o,responsibility,pieces,a,radius,-1,mode.equals("dependency")));
    for(int pieces=8;pieces<=maximumPieces;pieces*=2)if(a.length>=pieces)candidates.add(new MicroPartitionLayout.Candidate(o,"spatial",pieces,a,radius,-1,mode.equals("dependency")));
    for(int axis=0;axis<2;axis++){MicroPartitionLayout.Candidate c=new MicroPartitionLayout.Candidate(o,"spatial",2,a,radius,axis,mode.equals("dependency"));boolean duplicate=false;for(MicroPartitionLayout.Candidate e:candidates)if(e.owner==o&&e.signature().equals(c.signature())){duplicate=true;break;}if(!duplicate)candidates.add(c);}
   }else{
    if(a.length<4)throw new IllegalStateException("heavy owner sample insufficient for original candidate family");
    Arrays.sort(a,AdaptiveAnchorAcquisition::sampleCompare);if(a.length>2048)a=Arrays.copyOf(a,2048);
    for(int pieces=2;pieces<=maximumPieces&&pieces<=a.length;pieces*=2){rules.add(SampledPointRule.build(a,pieces,-1));ruleOwners.add(o);}
    for(int axis=0;axis<2;axis++){rules.add(SampledPointRule.build(a,2,axis));ruleOwners.add(o);}
   }
  }
  if(!rules.isEmpty()){
   final SampledPointRule[] descriptors=rules.toArray(new SampledPointRule[0]);final int[] ruleOwner=ruleOwners.stream().mapToInt(v->v).toArray();final int[][] indices=new int[raw.length][];
   for(int o=0;o<raw.length;o++){List<Integer> ids=new ArrayList<>();for(int i=0;i<ruleOwner.length;i++)if(ruleOwner[i]==o)ids.add(i);indices[o]=ids.stream().mapToInt(v->v).toArray();}
   Broadcast<Map<Long,Double>> w=sc.broadcast(new HashMap<>(cellWeights));List<Exact> partials;
   try{partials=points.mapPartitions(input->{Exact e=new Exact(descriptors.length,maximumPieces);while(input.hasNext()){Point p=input.next();int o=owners.value().getOrDefault(p.packedCellId,-1);if(o<0)continue;for(int i:indices[o]){int l=descriptors[i].lane(p.id,p.x,p.y);e.counts[i][l]++;e.work[i][l]+=w.value().getOrDefault(p.packedCellId,0.);double[] b=e.bounds[i][l];b[0]=Math.min(b[0],p.x);b[1]=Math.min(b[1],p.y);b[2]=Math.max(b[2],p.x);b[3]=Math.max(b[3],p.y);}}return Collections.singletonList(e).iterator();}).collect();}finally{w.destroy();}
   Exact total=new Exact(descriptors.length,maximumPieces);for(Exact e:partials)for(int i=0;i<descriptors.length;i++)for(int l=0;l<descriptors[i].pieces;l++){total.counts[i][l]=Math.addExact(total.counts[i][l],e.counts[i][l]);total.work[i][l]+=e.work[i][l];double[] b=total.bounds[i][l],v=e.bounds[i][l];b[0]=Math.min(b[0],v[0]);b[1]=Math.min(b[1],v[1]);b[2]=Math.max(b[2],v[2]);b[3]=Math.max(b[3],v[3]);}
   for(int i=0;i<descriptors.length;i++){int o=ruleOwner[i],pieces=descriptors[i].pieces;long[] counts=Arrays.copyOf(total.counts[i],pieces);if(Arrays.stream(counts).sum()!=census.core[o])throw new IllegalStateException("sampled cut does not cover complete owner");candidates.add(MicroPartitionLayout.Candidate.sampledPoint(o,descriptors[i],counts,Arrays.copyOf(total.bounds[i],pieces),Arrays.copyOf(total.work[i],pieces),radius));}
  }
  MicroPartitionLayout.Candidate[] descriptions=candidates.toArray(new MicroPartitionLayout.Candidate[0]);long[][] inputs=new long[descriptions.length][];for(int i=0;i<inputs.length;i++)inputs[i]=new long[descriptions[i].pieces];
  if(mode.equals("dependency")){
   final int[][] indices=new int[raw.length][];for(int o=0;o<raw.length;o++){List<Integer> ids=new ArrayList<>();for(int i=0;i<descriptions.length;i++)if(descriptions[i].owner==o)ids.add(i);indices[o]=ids.stream().mapToInt(v->v).toArray();}
   Broadcast<MicroPartitionLayout.Candidate[]> description=sc.broadcast(descriptions);List<long[][]> partials;
   try{partials=points.mapPartitions(input->{MicroPartitionLayout.Candidate[] local=description.value();long[][] count=new long[local.length][];for(int i=0;i<local.length;i++)count[i]=new long[local[i].pieces];DestinationAccumulator targets=new DestinationAccumulator(raw.length);while(input.hasNext()){Point p=input.next();MicroCellPopulation.recipients(owners.value(),p.packedCellId,p.cellX,p.cellY,dx,dy,targets,raw.length);for(int t=0;t<targets.size();t++)for(int i:indices[targets.valueAt(t)])for(int l=0;l<local[i].pieces;l++)if(MicroPartitionLayout.matches(local[i],l,p,true))count[i][l]++;}return Collections.singletonList(count).iterator();}).collect();}finally{description.destroy();}
   for(long[][] part:partials)for(int i=0;i<inputs.length;i++)for(int l=0;l<inputs[i].length;l++)inputs[i][l]=Math.addExact(inputs[i][l],part[i][l]);
  }else for(int i=0;i<inputs.length;i++)Arrays.fill(inputs[i],census.originalAssigned[descriptions[i].owner]);
  MicroPartitionPopulation.Statistics result=new MicroPartitionPopulation.Statistics(census.originalAssigned,census.core,descriptions,inputs);
  result=SampledAnchorCostProbe.reweight(result,raw,calibrated);result.collectMs=collectMs;result.originalPopulationMs=census.originalPopulationMs;result.populationMs=census.originalPopulationMs+(System.nanoTime()-started)/1e6;result.populationFromCells=census.populationFromCells;result.populationDirect=true;result.dependencyPopulationScans=mode.equals("dependency")?1:0;
  result.sourceRecordsScanned=Math.multiplyExact(n,rules.isEmpty()?2:3);
  List<Integer> fullList=new ArrayList<>(),sampleList=new ArrayList<>();for(int o:selected)if(full[o])fullList.add(o);else sampleList.add(o);
  result.fallbacks.add("adaptive_point_acquisition:coverage_first="+coverageFirst+",cap="+cap+",driver_available="+available+",requested_owner_limit="+requestedOwnerLimit+",owner_limit="+ownerLimit+",selected="+selected+",full="+fullList+",sampled="+sampleList+",collected="+collected.size()+",sample_partition_quota="+quota);
  return result;
 }
}
