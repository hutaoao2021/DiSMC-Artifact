package com;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.apache.spark.TaskContext;

public final class MicroPartitionObservation implements Serializable {
    public final int stage, stageAttempt, task, owner, lane;
    public final long attempt, input, anchors, accessNanos, prepareNanos, kernelNanos, wallNanos;
    public final long[] counters;
    public final long frontierPrunedAnchors, frontierBoundLookups, projectionDuplicatesSkipped;
    public final long anchorBoundaryCalls;
    public final long pairCirclesCreated,candidateBatchFlushes;
    public final long countWindowRequests,countWindowHits,countWindowBucketLookups;
    public final long countWindowEntriesPeak,countWindowReferencesPeak,countWindowEvictions;
    public final double candidateCellSize, countingCellSize;
    public final int candidateBuckets, countingBuckets;
    public final String countingLookupMode;
    public final long countingLookupBytes,countingLookupBudget;
    public final String executorId, kernelClockId;
    public final long kernelStartNanos, kernelEndNanos;
    public MicroPartitionObservation(int task, int owner, int lane, MaskedSharedBlock block,
            long access, long prepare, MaskedLaneQuery.Evaluation evaluation, long wall) {
        this(task,owner,lane,block,access,prepare,evaluation,wall,null);
    }
    public MicroPartitionObservation(int task, int owner, int lane, MaskedSharedBlock block,
            long access, long prepare, MaskedLaneQuery.Evaluation evaluation, long wall,
            MaskedPreparedNeighborhood index) {
        TaskContext context = TaskContext.get(); stage = context.stageId(); stageAttempt = context.stageAttemptNumber();
        attempt = context.taskAttemptId(); this.task = task; this.owner = owner; this.lane = lane;
        input = block.unionPoints.length; anchors = block.ownerAnchorOrdinals[0].length;
        accessNanos = access; prepareNanos = prepare; kernelNanos = evaluation.kernelNanos; wallNanos = wall;
        counters = evaluation.counters.clone();
        frontierPrunedAnchors=evaluation.frontierPrunedAnchors; frontierBoundLookups=evaluation.frontierBoundLookups;
        projectionDuplicatesSkipped=evaluation.projectionDuplicatesSkipped;
        anchorBoundaryCalls=evaluation.anchorBoundaryCalls;
        pairCirclesCreated=evaluation.pairCirclesCreated;candidateBatchFlushes=evaluation.candidateBatchFlushes;
        countWindowRequests=evaluation.countWindowRequests;countWindowHits=evaluation.countWindowHits;
        countWindowBucketLookups=evaluation.countWindowBucketLookups;countWindowEntriesPeak=evaluation.countWindowEntriesPeak;
        countWindowReferencesPeak=evaluation.countWindowReferencesPeak;countWindowEvictions=evaluation.countWindowEvictions;
        candidateCellSize=index==null?Double.NaN:index.cellSize;
        countingCellSize=index==null?Double.NaN:index.countCellSize;
        candidateBuckets=index==null?-1:index.bucketCount();
        countingBuckets=index==null?-1:index.countingBucketCount();
        countingLookupMode=index==null?"unknown":index.countingLookupMode();
        countingLookupBytes=index==null?0:index.countingLookupAccountedBytes();
        countingLookupBudget=index==null?0:index.countingLookupOriginalBudget();
        org.apache.spark.SparkEnv environment = org.apache.spark.SparkEnv.get();
        executorId = environment == null ? "local" : environment.executorId();
        kernelClockId = evaluation.kernelClockId;
        kernelStartNanos = evaluation.kernelStartNanos;
        kernelEndNanos = evaluation.kernelEndNanos;
    }
    public static void write(Path path, List<MicroPartitionObservation> rows) throws IOException {
        List<MicroPartitionObservation> sorted = new ArrayList<>(rows);
        sorted.sort(Comparator.comparingInt((MicroPartitionObservation row) -> row.stage).thenComparingInt(row -> row.task).thenComparingLong(row -> row.attempt));
        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW)) {
            writer.write("stage_id,stage_attempt,partition_id,task_attempt_id,owner,lane,input_records,anchors,parent_access_ns,prepare_ns,kernel_ns,local_wall_ns,candidate_count,single_point_candidates,pair_candidates,z_window_checks,distance_checks,projected_candidates,projected_count_hits,projected_bound_hits,mask_checks,mask_filtered,candidate_cell_size,counting_cell_size,candidate_buckets,counting_buckets,frontier_pruned_anchors,frontier_bound_lookups,projection_duplicates_skipped,count_window_requests,count_window_hits,count_window_bucket_lookups,count_window_entries_peak,count_window_references_peak,count_window_evictions,anchor_boundary_calls,pair_circles_created,candidate_batch_flushes,count_index_mode,count_index_accounted_bytes,count_index_original_budget_bytes,executor_id,kernel_clock_id,kernel_start_ns,kernel_end_ns\n");
            for (MicroPartitionObservation row : sorted) {
                List<Object> values = new ArrayList<>(Arrays.asList(row.stage,row.stageAttempt,row.task,row.attempt,row.owner,row.lane,
                        row.input,row.anchors,row.accessNanos,row.prepareNanos,row.kernelNanos,row.wallNanos));
                for (long counter : row.counters) values.add(counter);
                values.add(row.candidateCellSize);values.add(row.countingCellSize);
                values.add(row.candidateBuckets);values.add(row.countingBuckets);
                values.add(row.frontierPrunedAnchors);values.add(row.frontierBoundLookups);values.add(row.projectionDuplicatesSkipped);
                values.add(row.countWindowRequests);values.add(row.countWindowHits);values.add(row.countWindowBucketLookups);
                values.add(row.countWindowEntriesPeak);values.add(row.countWindowReferencesPeak);values.add(row.countWindowEvictions);values.add(row.anchorBoundaryCalls);values.add(row.pairCirclesCreated);values.add(row.candidateBatchFlushes);
                values.add(row.countingLookupMode);values.add(row.countingLookupBytes);values.add(row.countingLookupBudget);
                values.add(row.executorId);values.add(row.kernelClockId);values.add(row.kernelStartNanos);values.add(row.kernelEndNanos);
                writer.write(TaskObservation.csv(values));
            }
        }
    }
}
