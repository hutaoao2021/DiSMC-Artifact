package com;

import java.util.ArrayList;
import java.util.Arrays;

/** Applies v2 work/record caps while preserving singleton fallback semantics. */
public final class M2V2BundleGuard {
    private M2V2BundleGuard() { }

    public static final class Result {
        public final int[] group;
        public final int[] slot;
        public final int[][] members;
        public final long originalRecords;
        public final long sharedRecords;
        public final int rejectedWork;
        public final int rejectedRecords;

        public Result(int[] group, int[] slot, int[][] members, long originalRecords,
                long sharedRecords, int rejectedWork, int rejectedRecords) {
            this.group=group;this.slot=slot;this.members=members;
            this.originalRecords=originalRecords;this.sharedRecords=sharedRecords;
            this.rejectedWork=rejectedWork;this.rejectedRecords=rejectedRecords;
        }
    }

    public static Result apply(int[] baseGroup, int[] baseSlot, int[][] baseMembers,
            long[] assigned, double[] work, long[][] overlap,
            double maxBundleWork, long maxBundleRecords) {
        validate(baseGroup,baseSlot,baseMembers,assigned,work,overlap,maxBundleWork,maxBundleRecords);
        int n=assigned.length;long original=0L;for(long value:assigned)original=Math.addExact(original,value);
        ArrayList<int[]> kept=new ArrayList<int[]>();int rejectedWork=0,rejectedRecords=0;
        for(int[] bundle:baseMembers) {
            long records=0L;double totalWork=0.0;
            for(int owner:bundle){records=Math.addExact(records,assigned[owner]);totalWork+=work[owner];}
            boolean workExceeded=bundle.length>1 && totalWork>maxBundleWork;
            boolean recordsExceeded=bundle.length>1 && records>maxBundleRecords;
            if(bundle.length>1 && (workExceeded||recordsExceeded)) {
                if(workExceeded)rejectedWork++;
                if(recordsExceeded)rejectedRecords++;
                for(int owner:bundle)kept.add(new int[]{owner});
            } else kept.add(bundle.clone());
        }
        int[] group=new int[n],slot=new int[n];Arrays.fill(group,-1);Arrays.fill(slot,-1);
        int[][] members=new int[kept.size()][];long saved=0L;
        for(int groupId=0;groupId<kept.size();groupId++) {
            int[] bundle=kept.get(groupId);members[groupId]=bundle;
            for(int position=0;position<bundle.length;position++) {
                int owner=bundle[position];group[owner]=groupId;slot[owner]=position;
            }
            if(bundle.length==2) {
                int left=bundle[0],right=bundle[1];
                saved=Math.addExact(saved, overlap[Math.min(left,right)][Math.max(left,right)]);
            }
        }
        return new Result(group,slot,members,original,original-saved,rejectedWork,rejectedRecords);
    }

    private static void validate(int[] baseGroup,int[] baseSlot,int[][] baseMembers,
            long[] assigned,double[] work,long[][] overlap,double maxBundleWork,long maxBundleRecords) {
        if(baseGroup==null||baseSlot==null||baseMembers==null||assigned==null||work==null||overlap==null
                ||baseGroup.length!=assigned.length||baseSlot.length!=assigned.length
                ||work.length!=assigned.length||overlap.length!=assigned.length
                ||!Double.isFinite(maxBundleWork)||maxBundleWork<0.0||maxBundleRecords<1L)
            throw new IllegalArgumentException("invalid v2 bundle guard inputs");
        boolean[] seen=new boolean[assigned.length];
        for(int i=0;i<assigned.length;i++) {
            if(assigned[i]<0L||!Double.isFinite(work[i])||work[i]<0.0||overlap[i]==null
                    ||overlap[i].length!=assigned.length)throw new IllegalArgumentException("invalid owner stats");
        }
        for(int[] bundle:baseMembers) {
            if(bundle==null||bundle.length<1||bundle.length>2)throw new IllegalArgumentException("invalid base bundle");
            for(int owner:bundle) {
                if(owner<0||owner>=assigned.length||seen[owner])throw new IllegalArgumentException("duplicate owner");
                seen[owner]=true;
            }
        }
        for(boolean value:seen)if(!value)throw new IllegalArgumentException("missing owner");
    }
}
