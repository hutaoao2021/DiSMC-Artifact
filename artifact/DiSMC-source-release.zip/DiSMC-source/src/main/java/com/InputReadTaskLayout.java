package com;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
/** Coalesce only input tasks, retaining the legacy global dedup partition count. */
public final class InputReadTaskLayout {
 public final JavaRDD<String> lines;
 public final boolean enabled;
 public final int originalReadPartitions,readPartitions,dedupPartitions;
 private InputReadTaskLayout(JavaRDD<String> lines,boolean enabled,int original,int dedup){this.lines=lines;this.enabled=enabled;originalReadPartitions=original;readPartitions=lines.getNumPartitions();dedupPartitions=dedup;}
 public static InputReadTaskLayout prepare(JavaSparkContext sc,JavaRDD<String> lines){
  SparkConf conf=sc.getConf();boolean enabled=conf.getBoolean("spark.skyline.coalesceInputTasks",false);int original=lines.getNumPartitions();
  // The coordinate map has no partitioner: Spark's legacy default is explicit
  // default.parallelism when present, otherwise the raw RDD partition count.
  int dedup=conf.contains("spark.default.parallelism")?sc.defaultParallelism():original;
  if(!enabled)return new InputReadTaskLayout(lines,false,original,dedup);
  if(!conf.getBoolean("spark.skyline.stableInputIds",false))throw new IllegalArgumentException("coalesced input tasks require stableInputIds");
  int slots=Integer.parseInt(conf.get("spark.cores.max",Integer.toString(sc.defaultParallelism())));if(slots<1)throw new IllegalArgumentException("positive input task capacity required");
  return new InputReadTaskLayout(lines.coalesce(Math.min(original,slots)),true,original,dedup);
 }
 private InputReadTaskLayout(){throw new AssertionError();}
}
