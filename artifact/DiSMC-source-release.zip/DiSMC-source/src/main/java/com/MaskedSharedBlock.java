package com;

import java.io.Serializable;

/** One physical union of points plus per-owner logical visibility. */
public final class MaskedSharedBlock implements Serializable {
    public final int[] ownerIds;
    public final Point[] unionPoints;
    public final byte[] visibilityMasks;
    public final int[][] ownerAnchorOrdinals;
    public final long[] ownerAssignedCounts;
    public final long[] ownerCoreCounts;
    public final int[] ownerSourceCounts;

    MaskedSharedBlock(
            int[] ownerIds,
            Point[] unionPoints,
            byte[] visibilityMasks,
            int[][] ownerAnchorOrdinals,
            long[] ownerAssignedCounts,
            long[] ownerCoreCounts,
            int[] ownerSourceCounts) {
        this.ownerIds = ownerIds;
        this.unionPoints = unionPoints;
        this.visibilityMasks = visibilityMasks;
        this.ownerAnchorOrdinals = ownerAnchorOrdinals;
        this.ownerAssignedCounts = ownerAssignedCounts;
        this.ownerCoreCounts = ownerCoreCounts;
        this.ownerSourceCounts = ownerSourceCounts;
    }
}
