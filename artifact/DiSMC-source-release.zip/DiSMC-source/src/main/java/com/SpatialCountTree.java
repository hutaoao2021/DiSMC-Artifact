package com;
import java.util.*;
/** Standalone exact multiplicity-preserving counting hierarchy. */
public final class SpatialCountTree{
 static final int LEAF_SIZE=8;
 static final class P{final double x,y;P(double x,double y){this.x=x;this.y=y;}}
 static final class Node{final int start,end;final double minX,maxX,minY,maxY;final Node left,right;Node(int start,int end,double minX,double maxX,double minY,double maxY,Node left,Node right){this.start=start;this.end=end;this.minX=minX;this.maxX=maxX;this.minY=minY;this.maxY=maxY;this.left=left;this.right=right;}}
 private final P[] points;private final Node root;public long lastPointChecks,lastNodeVisits;public final int nodeCount;
 private int nodes;
 private Node[] boundaryLeaves;
 private int boundaryUsed,covered;
 public int lastUpperBound=-1;
 public SpatialCountTree(double[]x,double[]y){if(x==null||y==null||x.length!=y.length)throw new IllegalArgumentException("coordinate dimensions");points=new P[x.length];for(int i=0;i<x.length;i++){if(!Double.isFinite(x[i])||!Double.isFinite(y[i]))throw new IllegalArgumentException("nonfinite point");points[i]=new P(x[i],y[i]);}root=points.length==0?null:build(0,points.length,0);nodeCount=nodes;}
 private Node build(int start,int end,int axis){nodes++;double minX=Double.POSITIVE_INFINITY,minY=minX,maxX=Double.NEGATIVE_INFINITY,maxY=maxX;for(int i=start;i<end;i++){P p=points[i];minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}Node left=null,right=null;if(end-start>LEAF_SIZE){Arrays.sort(points,start,end,axis==0?Comparator.comparingDouble(p->p.x):Comparator.comparingDouble(p->p.y));int middle=(start+end)>>>1;left=build(start,middle,1-axis);right=build(middle,end,1-axis);}return new Node(start,end,minX,maxX,minY,maxY,left,right);}
 public int count(double x,double y,double squaredRadius){lastUpperBound=-1;lastPointChecks=lastNodeVisits=0;if(root==null||Double.isNaN(x)||Double.isNaN(y)||Double.isNaN(squaredRadius)||squaredRadius<0)return 0;return count(root,x,y,squaredRadius);}
 /** Return an exact count, or a partial count with a sound upper certificate below required. */
 public int count(double x,double y,double squaredRadius,int required){
  lastUpperBound=-1;
  if(required<=0)return count(x,y,squaredRadius);
  lastPointChecks=lastNodeVisits=0;
  if(root==null||Double.isNaN(x)||Double.isNaN(y)||Double.isNaN(squaredRadius)||squaredRadius<0)return 0;
  if(boundaryLeaves==null)boundaryLeaves=new Node[nodeCount];
  boundaryUsed=covered=0;collect(root,x,y,squaredRadius);
  int remaining=0;for(int i=0;i<boundaryUsed;i++)remaining+=boundaryLeaves[i].end-boundaryLeaves[i].start;
  int count=covered;
  if(remaining>0 && count+remaining<required){lastUpperBound=count+remaining;return count;}
  for(int leaf=0;leaf<boundaryUsed;leaf++){
   Node n=boundaryLeaves[leaf];remaining-=n.end-n.start;lastPointChecks+=n.end-n.start;
   for(int i=n.start;i<n.end;i++){P p=points[i];double dx=x-p.x,dy=y-p.y;if(dx*dx+dy*dy<=squaredRadius)count++;}
   if(remaining>0 && count+remaining<required){lastUpperBound=count+remaining;return count;}
  }
  return count;
 }
 private void collect(Node n,double x,double y,double r2){
  lastNodeVisits++;
  double nearX=x<n.minX?n.minX-x:x>n.maxX?x-n.maxX:0,nearY=y<n.minY?n.minY-y:y>n.maxY?y-n.maxY:0;
  if(nearX*nearX+nearY*nearY>r2)return;
  double farX=Math.max(Math.abs(x-n.minX),Math.abs(x-n.maxX)),farY=Math.max(Math.abs(y-n.minY),Math.abs(y-n.maxY));
  if(farX*farX+farY*farY<=r2){covered+=n.end-n.start;return;}
  if(n.left!=null){collect(n.left,x,y,r2);collect(n.right,x,y,r2);}else boundaryLeaves[boundaryUsed++]=n;
 }
 private int count(Node n,double x,double y,double r2){lastNodeVisits++;double nearX=x<n.minX?n.minX-x:x>n.maxX?x-n.maxX:0,nearY=y<n.minY?n.minY-y:y>n.maxY?y-n.maxY:0;if(nearX*nearX+nearY*nearY>r2)return 0;double farX=Math.max(Math.abs(x-n.minX),Math.abs(x-n.maxX)),farY=Math.max(Math.abs(y-n.minY),Math.abs(y-n.maxY));if(farX*farX+farY*farY<=r2)return n.end-n.start;if(n.left!=null)return count(n.left,x,y,r2)+count(n.right,x,y,r2);int count=0;lastPointChecks+=n.end-n.start;for(int i=n.start;i<n.end;i++){P p=points[i];double dx=x-p.x,dy=y-p.y;if(dx*dx+dy*dy<=r2)count++;}return count;}
}
