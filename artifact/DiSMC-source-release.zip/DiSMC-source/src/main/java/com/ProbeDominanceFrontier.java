package com;

import java.io.Serializable;
import java.util.*;

/** Immutable dominance thresholds from valid completed candidates, never output candidates.
 * Counts may be conservative lower bounds from a subset of the input. Their centers,
 * query distances and radius must belong to this query; callers supply real probe results.
 * Strictly smaller objective distance is required, preserving equal-distance representatives.
 */
public final class ProbeDominanceFrontier implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final ProbeDominanceFrontier EMPTY = fromCircles(Collections.<Circle>emptyList());
    private final double[] distances;
    private final int[] prefixCounts;
    private ProbeDominanceFrontier(double[] distances,int[] counts){this.distances=distances;this.prefixCounts=counts;}

    public static ProbeDominanceFrontier fromCircles(Collection<Circle> circles) {
        if(circles==null)throw new IllegalArgumentException("missing probe frontier");
        TreeMap<Double,Integer> counts=new TreeMap<>();
        for(Circle c:circles){
            if(c==null||!Double.isFinite(c.discenq)||c.discenq<0||c.cirnum<0)
                throw new IllegalArgumentException("invalid probe witness");
            Integer previous=counts.get(c.discenq);
            if(previous==null||previous<c.cirnum)counts.put(c.discenq,c.cirnum);
        }
        // Neutral sentinels also avoid an empty-frontier branch in the count hot path.
        double[] d=new double[counts.size()+2];int[] n=new int[d.length];
        n[0]=-1;
        d[0]=Double.NEGATIVE_INFINITY;d[d.length-1]=Double.POSITIVE_INFINITY;
        int at=1,max=-1;
        for(Map.Entry<Double,Integer> entry:counts.entrySet()){
            d[at]=entry.getKey();max=Math.max(max,entry.getValue());n[at++]=max;
        }
        n[at]=max;return new ProbeDominanceFrontier(d,n);
    }

    public int minimumRequiredCount(double candidateDistance,int density) {
        int low=0,high=distances.length;
        while(low<high){int middle=(low+high)>>>1;
            if(Double.compare(distances[middle],candidateDistance)<0)low=middle+1;else high=middle;
        }
        int count=prefixCounts[Math.max(0,low-1)];
        return Math.max(density,count==Integer.MAX_VALUE?Integer.MAX_VALUE:count+1);
    }
    public int witnessDistances(){return distances.length-2;}
}
