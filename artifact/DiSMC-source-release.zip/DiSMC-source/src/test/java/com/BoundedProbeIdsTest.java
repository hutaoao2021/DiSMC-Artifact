package com;
import java.io.*;import java.lang.reflect.*;import java.util.*;
public final class BoundedProbeIdsTest {
 public static void main(String[]args)throws Exception{
  Class<?> c;try{c=Class.forName("com.BoundedProbeIds");}catch(ClassNotFoundException e){throw new AssertionError("bounded exact ID selector missing",e);}
  Method add=c.getMethod("add",long.class),ids=c.getMethod("ids"),merge=c.getMethod("merge",long[].class),size=c.getMethod("size");
  Random random=new Random(20261003);for(int limit:new int[]{1,3,24})for(int n:new int[]{0,1,2,24,10000}){
   Object full=c.getConstructor(int.class).newInstance(limit);Object[]p={c.getConstructor(int.class).newInstance(limit),c.getConstructor(int.class).newInstance(limit),c.getConstructor(int.class).newInstance(limit)};List<MicroPartitionLayout.Anchor>a=new ArrayList<>();Set<Long>seen=new HashSet<>();
   for(int i=0;i<n;i++){long id=i==0?Long.MIN_VALUE:i==1?Long.MAX_VALUE:random.nextLong();if(!seen.add(id))throw new AssertionError("fixture duplicate");a.add(new MicroPartitionLayout.Anchor(id,0,0,1));add.invoke(full,id);add.invoke(p[i%3],id);if((Integer)size.invoke(full)>limit)throw new AssertionError("unbounded memory");}
   long[]expected=SampledAnchorCostProbe.sampleIds(a.toArray(new MicroPartitionLayout.Anchor[0]),limit);if(!Arrays.equals((long[])ids.invoke(full),expected))throw new AssertionError("existing sample IDs changed");
   for(boolean reverse:new boolean[]{false,true}){Object merged=c.getConstructor(int.class).newInstance(limit);for(int i=0;i<3;i++)merge.invoke(merged,(Object)(long[])ids.invoke(p[reverse?2-i:i]));if(!Arrays.equals((long[])ids.invoke(merged),expected))throw new AssertionError("partition merge changes selection");}
   ByteArrayOutputStream bytes=new ByteArrayOutputStream();new ObjectOutputStream(bytes).writeObject(full);Object restored=new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray())).readObject();if(!Arrays.equals((long[])ids.invoke(restored),expected))throw new AssertionError("serialization changed samples");
  }
  System.out.println("PASS exact signed-mix selection, bounds, empty/small inputs, merge order and serialization");
 }
}
