package com;
import java.util.*;
import java.math.BigDecimal;
public final class NumericalSafetyRegressionTest {
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static TreeMap<Double,Integer> skyline(List<Circle> cs){TreeMap<Double,Integer> m=new TreeMap<>();for(Circle c:cs)m.put(c.discenq,Math.max(m.getOrDefault(c.discenq,0),c.cirnum));int best=-1;for(Iterator<Integer> i=m.values().iterator();i.hasNext();){int n=i.next();if(n<=best)i.remove();else best=n;}return m;}
 static List<Circle> candidates(List<Point> ps,ReferenceCandidateGeometry g,double r){List<Circle> cs=new ArrayList<>();for(Point p:ps)cs.add(g.single(p));for(int i=0;i<ps.size();i++)for(int j=i+1;j<ps.size();j++){Circle c=g.pair(ps.get(i),ps.get(j));if(c!=null)cs.add(c);}for(Circle c:cs){for(Point p:ps)if(ReferenceCandidateGeometry.covers(c,p,r))c.cirnum++;}return cs;}
 public static void main(String[] a){Random random=new Random(71296013);long certified=0,accepted=0;int runs=0;
  for(int i=0;i<100000;i++){
   double r=Math.pow(10,-2+7*random.nextDouble()),origin=(random.nextDouble()-.5)*2e7;
   double angle=2*Math.PI*random.nextDouble(),ax=origin,ay=-origin,cx=ax+r*Math.cos(angle),cy=ay+r*Math.sin(angle);
   double t=2*Math.PI*random.nextDouble(),rad=Math.nextDown(r+.005),px=cx+rad*Math.cos(t),py=cy+rad*Math.sin(t);
   if((i&3)==0)px=Math.nextUp(px);if((i&3)==1)px=Math.nextDown(px);
   boolean cert=NumericalCoverage.containsCandidate(ax,ay,cx,cy,r,NumericalCoverage.anchorRadius(r));if(cert)certified++;
   if(NumericalCoverage.covers(cx,cy,px,py,r)){
    accepted++;
    BigDecimal dx=new BigDecimal(cx).subtract(new BigDecimal(px)),dy=new BigDecimal(cy).subtract(new BigDecimal(py)),e=new BigDecimal(NumericalCoverage.envelope(r));
    check(dx.multiply(dx).add(dy.multiply(dy)).compareTo(e.multiply(e))<=0,"envelope misses accepted point");
    check(!cert||NumericalCoverage.covers(ax,ay,px,py,NumericalCoverage.anchorRadius(r)),"false enclosure certificate");
   }
  }
  check(certified>90000&&accepted>10000,"certificate or membership checks vacuous");
  check(!NumericalCoverage.containsCandidate(0,0,100,100,.1,NumericalCoverage.anchorRadius(.1)),"outside candidate certified");
  check(!NumericalCoverage.containsCandidate(0,0,Double.NaN,0,.1,1),"nonfinite must keep");
  for(int f=0;f<80;f++){
   double r=f%2==0?.1:.01,origin=f<40?9999816.7:10,qx=-9999750.839,qy=.123;
   List<Point> ps=new ArrayList<>();MaskedBlockBuilder b=new MaskedBlockBuilder(new int[]{0});
   for(int i=0;i<8;i++){Point p=new Point(origin+Math.rint(random.nextDouble()*4*r*1000)/1000,Math.rint(random.nextDouble()*4*r*1000)/1000);p.id=i+1;p.ownerPartitionId=0;p.is_core=true;p.isCore=true;p.setCell((int)Math.floor(p.x/r),(int)Math.floor(p.y/r));ps.add(p);b.add(p,1);}
   List<Circle> cs=candidates(ps,new ReferenceCandidateGeometry(r,qx,qy),r);cs.removeIf(c->c.cirnum<2);TreeMap<Double,Integer> expected=skyline(cs);MaskedSharedBlock block=b.build();
   for(boolean boundary:new boolean[]{false,true})for(int mode=0;mode<5;mode++){
    EngineOptions op=new EngineOptions(mode!=0,false,mode==2||mode==4,mode>0,mode==1,boundary,mode>0,mode==3,mode==4);
    MaskedPreparedNeighborhood prepared=new MaskedPreparedNeighborhood(block,r,r,qx,qy,true);
    MaskedLaneQuery.Evaluation e=MaskedLaneQuery.evaluate(prepared,0,0,0,1,r,r,qx,qy,2,op);
    check(skyline(new ArrayList<>(e.skyline.values())).equals(expected),"finite candidate frontier f="+f+" mode="+mode+" boundary="+boundary+" expected="+expected+" got="+e.skyline);
    ProbeTracingEMCS probe=new ProbeTracingEMCS(r);probe.q.x=qx;probe.q.y=qy;probe.density_k=2;probe.setCellConfig(r);probe.usePrepared(new MaskedPreparedNeighborhood(block,r,r,qx,qy,true),0,0,0,1,op);probe.method(r);
    check(skyline(new ArrayList<>(probe.skymap.values())).equals(expected),"tracing finite frontier f="+f+" mode="+mode);runs+=2;
   }
  }
  System.out.println("PASS certificates="+certified+" accepted-boundary-points="+accepted+" formal/tracing finite-frontier variants="+runs);
 }
}
