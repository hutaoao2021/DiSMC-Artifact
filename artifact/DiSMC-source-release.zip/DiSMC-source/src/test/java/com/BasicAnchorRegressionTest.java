package com;
import java.util.*;
public final class BasicAnchorRegressionTest {
 public static void main(String[] a){double r=.1,qx=-9999750.839;EMCS e=new EMCS(r);e.q.x=qx;e.q.y=0;e.density_k=2;e.part_id=0;e.setCellConfig(r);double[] xs={9999816.700,9999816.495};for(int i=0;i<xs.length;i++){Point p=new Point(xs[i],0);p.id=i+1;p.is_core=true;p.ownerPartitionId=0;p.setCell((int)Math.floor(p.x/r),0);e.plist.add(p);}e.method(r);if(e.skymap.size()!=1||e.skymap.values().iterator().next().cirnum!=2)throw new AssertionError("EMCS lost valid finite candidate: "+e.skymap);System.out.println("PASS basic engine anchor boundary");}
}
