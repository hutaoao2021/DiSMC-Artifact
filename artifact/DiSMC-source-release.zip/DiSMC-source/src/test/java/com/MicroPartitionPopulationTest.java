package com;

import java.util.*;

public final class MicroPartitionPopulationTest {
    static void check(boolean condition, String label) { if (!condition) throw new AssertionError(label); }
    static Point point(long id, double x, double y, int owner) {
        Point point = new Point(x, y); point.id = id; point.ownerPartitionId = owner; point.setCell(0, 0); return point;
    }
    public static void main(String[] arguments) {
        double[] work = {5, 7, 7, 1};
        check(Arrays.equals(MicroPartitionPopulation.selectOwners(work, new long[]{2, 40000, 20000, 1}),
                new int[]{1, 0, 3}), "bounded selection skips over-cap owner before collection");
        MicroPartitionLayout.Anchor[] anchors = {
                new MicroPartitionLayout.Anchor(1, 0, 0, 1), new MicroPartitionLayout.Anchor(2, 20, 0, 1)};
        MicroPartitionLayout.Candidate candidate = new MicroPartitionLayout.Candidate(0, "spatial", 2, anchors, 2);
        Point ownOther = point(2, 20, 0, 0), halo = point(3, 3.9, 0, 1);
        check(MicroPartitionLayout.matches(candidate, 0, halo, true), "halo count point remains");
        check(!MicroPartitionLayout.matches(candidate, 0, ownOther, true), "unneeded own point can be omitted");
        check(MicroPartitionLayout.matches(candidate, 0, point(4, 0, 4.019999, 1), true), "outward counting margin");
        check(MicroPartitionLayout.matches(candidate, 0, point(5, 1e9, 0, 1), true), "unsafe coordinates retain full input");
        Random random = new Random(18);
        for (int sample = 0; sample < 1000; sample++) {
            double angle = random.nextDouble() * 2 * Math.PI;
            double centerX = 2 * Math.cos(angle), centerY = 2 * Math.sin(angle);
            double memberAngle = random.nextDouble() * 2 * Math.PI;
            Point member = point(sample + 50, centerX + 2.004 * Math.cos(memberAngle),
                    centerY + 2.004 * Math.sin(memberAngle), 1);
            check(MicroPartitionLayout.matches(candidate, 0, member, true), "responsible circle count dependency");
        }
        System.out.println("MicroPartitionPopulationTest passed");
    }
}
