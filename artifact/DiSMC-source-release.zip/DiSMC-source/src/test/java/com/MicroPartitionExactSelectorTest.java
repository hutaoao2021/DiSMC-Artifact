package com;

import java.util.*;

/** Tests coordinated peak reduction and compares real selection with exhaustive plans. */
public final class MicroPartitionExactSelectorTest {
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    static MicroPartitionLayout.Candidate candidate(int owner, double[] weights) {
        MicroPartitionLayout.Anchor[] a = new MicroPartitionLayout.Anchor[weights.length];
        for (int i=0;i<a.length;i++) a[i]=new MicroPartitionLayout.Anchor(owner*100+i, i*20,0,weights[i]);
        return new MicroPartitionLayout.Candidate(owner,"spatial",2,a,2);
    }
    static double[] optimum;
    static void enumerate(int owner, double peak, long charge, long budget, double[] work,
            MicroPartitionPopulation.Statistics pop) {
        if (charge>budget) return;
        if (owner==work.length) {
            if (peak<optimum[0] || peak==optimum[0] && charge<optimum[1]) optimum=new double[]{peak,charge};
            return;
        }
        enumerate(owner+1,Math.max(peak,work[owner]),charge,budget,work,pop);
        for(int i=0;i<pop.candidates.length;i++) if(pop.candidates[i].owner==owner) {
            double p=0; long sum=0;
            for(int j=0;j<pop.candidates[i].pieces;j++) {p=Math.max(p,pop.candidates[i].work(j));sum+=pop.dependencyInputs[i][j];}
            enumerate(owner+1,Math.max(peak,p),charge+Math.max(0,sum-pop.originalAssigned[owner]),budget,work,pop);
        }
    }
    public static void main(String[] args) {
        MicroPartitionLayout.Candidate[] tied={candidate(0,new double[]{5,5}),candidate(1,new double[]{5,5})};
        MicroPartitionPopulation.Statistics pop=new MicroPartitionPopulation.Statistics(
            new long[]{100,100},new long[]{2,2},tied,new long[][]{{50,50},{50,50}});
        MicroPartitionPlanner.Plan p=MicroPartitionPlanner.select(new double[]{10,10},pop,0,2,"dependency");
        check(p.peak==5 && p.taskCount()==4,"coordinated tied owners must reach peak 5; actual="+p.peak);
        Random random=new Random(20261004);
        int checked=0;
        for(int trial=0;trial<100;trial++) {
            double[] work=new double[4];long[] original={100,100,100,100},core={2,2,2,2};
            MicroPartitionLayout.Candidate[] cs=new MicroPartitionLayout.Candidate[8];long[][] inputs=new long[8][];
            for(int o=0;o<4;o++) {
                work[o]=10+random.nextInt(50);
                for(int k=0;k<2;k++) {
                    cs[2*o+k]=candidate(o,new double[]{1+random.nextInt(30),1+random.nextInt(30)});
                    inputs[2*o+k]=new long[]{40+random.nextInt(61),40+random.nextInt(61)};
                }
            }
            pop=new MicroPartitionPopulation.Statistics(original,core,cs,inputs);
            for(double fraction:new double[]{0,.01,.1,.5}) {
                long budget=(long)Math.floor(400*fraction);
                optimum=new double[]{Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY};
                enumerate(0,0,0,budget,work,pop);
                p=MicroPartitionPlanner.select(work,pop,fraction,3,"dependency");
                check(p.peak==optimum[0],"exhaustive peak mismatch trial="+trial);
                check(p.extraRecords==optimum[1],"minimum charge mismatch trial="+trial);
                check(p.extraRecords<=budget,"budget exceeded");
                // Input enumeration order must not change the selected responsibility geometry.
                MicroPartitionLayout.Candidate[] reversed=cs.clone();long[][] reversedInputs=inputs.clone();
                for(int i=0;i<cs.length;i++){reversed[i]=cs[cs.length-1-i];reversedInputs[i]=inputs[cs.length-1-i];}
                MicroPartitionPlanner.Plan permuted=MicroPartitionPlanner.select(work,
                    new MicroPartitionPopulation.Statistics(original,core,reversed,reversedInputs),fraction,3,"dependency");
                check(p.responsibilitySignature().equals(permuted.responsibilitySignature()),"unstable alternative ordering");
                checked++;
            }
        }
        System.out.println("MicroPartitionExactSelectorTest passed: tied peak + "+checked+" exhaustive families and permutations");
    }
}
