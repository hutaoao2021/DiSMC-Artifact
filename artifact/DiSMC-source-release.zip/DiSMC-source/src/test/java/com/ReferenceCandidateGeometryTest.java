package com;
public final class ReferenceCandidateGeometryTest {
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
 static Point point(long id,double x,double y){Point p=new Point(x,y);p.id=id;return p;}
 static void near(double a,double b){check(Math.abs(a-b)<1e-9,"coordinate "+a+" vs "+b);}
 public static void main(String[] args){
  ReferenceCandidateGeometry g=new ReferenceCandidateGeometry(1,0,0);
  Circle single=g.single(point(1,3,0));near(single.centerX,2);near(single.centerY,0);near(single.discenq,2);
  Circle inside=g.single(point(2,.5,.5));near(inside.centerX,0);near(inside.centerY,0);
  Circle tangent=g.pair(point(1,2,1),point(2,2,3));check(tangent!=null,"diameter pair missing");near(tangent.centerX,2);near(tangent.centerY,2);
  check(g.pair(point(1,2,0),point(2,2,0))==null,"zero-distance pair eligible");
  check(g.pair(point(1,0,0),point(2,3,0))==null,"outside2r pair eligible");
  check(g.pair(point(1,0,0),point(1,1,0))==null,"same identity pair eligible");
  Circle projected=g.pair(point(1,3,0),point(2,2,0));near(projected.centerX,2);near(projected.centerY,0);
  check(ReferenceCandidateGeometry.covers(tangent,point(3,2,3),1),"exact boundary excluded");
  check(!ReferenceCandidateGeometry.covers(tangent,point(3,2,3.01),1),"outside counted");
  check(ReferenceCandidateGeometry.covers(tangent,point(3,2,3.004),1),"rounded coverage slack excluded");
  check(!ReferenceCandidateGeometry.covers(tangent,point(3,2,3.006),1),"beyond rounding slack counted");
  Circle forward=g.pair(point(7,2,1),point(8,1,2)),reverse=g.pair(point(8,1,2),point(7,2,1));
  near(forward.centerX,reverse.centerX);near(forward.centerY,reverse.centerY);
  System.out.println("PASS singleton, projected/tangent pairs, zero/same-ID/outside exclusions, exact coverage boundary");
 }
}
