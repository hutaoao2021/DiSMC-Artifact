package com;
import java.util.*;
import java.lang.reflect.*;

/** Split-context measurements must not overwrite a differently measured unsplit task. */
public final class PrivateLaneProbeCostTest {
 public static void main(String[] args)throws Exception {
  MicroPartitionLayout.Anchor[] cuts=new MicroPartitionLayout.Anchor[8];for(int i=0;i<8;i++)cuts[i]=new MicroPartitionLayout.Anchor(i+1,i<4?i-4:i-3,0,1);
  MicroPartitionLayout.Candidate guide=MicroPartitionLayout.Candidate.sampledPoint(0,SampledPointRule.build(cuts,2,-1),new long[]{90,10},new double[][]{{-10,-1,0,1},{1,-1,10,1}},new double[]{90000,10000},1);
  MicroPartitionPopulation.Statistics source=new MicroPartitionPopulation.Statistics(new long[]{1000},new long[]{100},new MicroPartitionLayout.Candidate[]{guide},new long[][]{{920,160}});
  SampledAnchorCostProbe.Probe p=new SampledAnchorCostProbe.Probe(0,8,0,40030);p.setupNanos=30;p.prepareNanos=300;
  p.anchorIds=new long[8];p.observations=new AnchorCostObservation[8];
  for(int i=0;i<8;i++){Point a=new Point(i<4?-2:2,0);a.id=100+i;a.ownerPartitionId=0;p.anchorIds[i]=a.id;p.observations[i]=new AnchorCostObservation(a,i<4?1000:9000,0,1,1);}
  try{
   p.getClass().getField("privateLaneCosts").setBoolean(p,true);
   p.getClass().getField("laneInputRecords").set(p,new long[]{920,160});
   p.getClass().getField("laneFixedNanos").set(p,new double[]{110,220});
  }catch(NoSuchFieldException e){throw new AssertionError("No private task context recorded for lane calibration",e);}
  LaneProbeRefinement.Target target=new LaneProbeRefinement.Target(guide,new int[]{4,4},new long[0]);
  LaneProbeRefinement.Update u=LaneProbeRefinement.update(source,source,new double[]{100000},new LaneProbeRefinement.Target[]{target},new SampledAnchorCostProbe.Probe[]{p});
  if(u.ownerWork[0]!=100000)throw new AssertionError("Private split skyline costs contaminated unsplit owner calibration");
  if(Math.abs(u.population.candidates[0].work(0)-90110)>1e-8||Math.abs(u.population.candidates[0].work(1)-90220)>1e-8)throw new AssertionError("Measured guide must pay each private input setup exactly once");
  p.laneInputRecords[1]=159;
  boolean rejected=false;
  try { LaneProbeRefinement.update(source,source,new double[]{100000},new LaneProbeRefinement.Target[]{target},new SampledAnchorCostProbe.Probe[]{p}); }
  catch(IllegalStateException expected){rejected=true;}
  if(!rejected)throw new AssertionError("Private measurements must match exact planned dependency input counts");
  System.out.println("PASS distinct unsplit/split cost conditions and measured private lane fixed costs");
 }
}
