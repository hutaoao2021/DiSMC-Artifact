package com;
import java.util.*;import java.lang.reflect.*;
/** Parent/private costs must compare identical responsibilities without transferring hot-lane work. */
public final class PairedLaneProbeCostTest {
 public static void main(String[] args)throws Exception{
  MicroPartitionLayout.Anchor[] cuts=new MicroPartitionLayout.Anchor[8];for(int i=0;i<8;i++)cuts[i]=new MicroPartitionLayout.Anchor(i+1,i<4?i-4:i-3,0,1);
  MicroPartitionLayout.Candidate guide=MicroPartitionLayout.Candidate.sampledPoint(0,SampledPointRule.build(cuts,2,-1),new long[]{90,10},new double[][]{{-10,-1,0,1},{1,-1,10,1}},new double[]{90000,10000},1);
  MicroPartitionPopulation.Statistics source=new MicroPartitionPopulation.Statistics(new long[]{1000},new long[]{100},new MicroPartitionLayout.Candidate[]{guide},new long[][]{{920,160}});
  SampledAnchorCostProbe.Probe split=new SampledAnchorCostProbe.Probe(0,8,0,48030),parent=new SampledAnchorCostProbe.Probe(0,8,0,16030);
  split.privateLaneCosts=true;split.laneInputRecords=new long[]{920,160};split.laneFixedNanos=new double[]{110,220};parent.prepareNanos=300;parent.setupNanos=30;
  for(SampledAnchorCostProbe.Probe p:new SampledAnchorCostProbe.Probe[]{split,parent}){p.anchorIds=new long[8];p.observations=new AnchorCostObservation[8];}
  for(int i=0;i<8;i++){Point a=new Point(i<4?-2:2,0);a.id=100+i;a.ownerPartitionId=0;split.anchorIds[i]=parent.anchorIds[i]=a.id;
   split.observations[i]=new AnchorCostObservation(a,i<3?1000:9000,0,1,1);parent.observations[i]=new AnchorCostObservation(a,2000,0,1,1);}
  LaneProbeRefinement.Target[] targets={new LaneProbeRefinement.Target(guide,new int[]{4,4},new long[0])};SampledAnchorCostProbe.Probe[] splits={split},parents={parent};
  LaneProbeRefinement.Update measured=LaneProbeRefinement.update(source,source,new double[]{999999},targets,splits);
  if(Math.abs(measured.population.candidates[0].work(0)-270110)>1e-8||Math.abs(measured.population.candidates[0].work(1)-90220)>1e-8)
   throw new AssertionError("Directly measured hot-lane work redistributed by shrinkage: "+measured.population.candidates[0].work(0));
  Method paired;
  try{paired=LaneProbeRefinement.class.getMethod("updatePaired",MicroPartitionPopulation.Statistics.class,MicroPartitionPopulation.Statistics.class,double[].class,LaneProbeRefinement.Target[].class,SampledAnchorCostProbe.Probe[].class,SampledAnchorCostProbe.Probe[].class);}
  catch(NoSuchMethodException e){throw new AssertionError("Missing same-identity independent parent calibration",e);}
  LaneProbeRefinement.Update u=(LaneProbeRefinement.Update)paired.invoke(null,source,source,new double[]{999999},targets,splits,parents);
  if(u.ownerWork[0]!=200330)throw new AssertionError("Independent parent preparation must be charged once: "+u.ownerWork[0]);
  if(u.population.candidates[0].work(0)!=270110||u.population.candidates[0].work(1)!=90220)throw new AssertionError("Parent context overwrote private lane costs");
  parent.anchorIds[0]=999;reject(paired,source,targets,splits,parents);parent.anchorIds[0]=100;
  parent.privateLaneCosts=true;reject(paired,source,targets,splits,parents);parent.privateLaneCosts=false;
  reject(paired,source,targets,splits,new SampledAnchorCostProbe.Probe[]{parent,parent});
  System.out.println("PASS paired identical responsibilities, independent parent fixed cost, measured hot-lane preservation, mismatched identity/context guards");
 }
 static void reject(Method m,MicroPartitionPopulation.Statistics s,LaneProbeRefinement.Target[] t,SampledAnchorCostProbe.Probe[] split,SampledAnchorCostProbe.Probe[] parent)throws Exception{
  try{m.invoke(null,s,s,new double[]{999999},t,split,parent);throw new AssertionError("Invalid paired context accepted");}
  catch(InvocationTargetException e){if(!(e.getCause() instanceof IllegalArgumentException))throw e;}
 }
}