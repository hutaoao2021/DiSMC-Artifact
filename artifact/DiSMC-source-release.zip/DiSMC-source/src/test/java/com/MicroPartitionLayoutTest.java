package com;

import java.util.*;

public final class MicroPartitionLayoutTest {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    private static void rejected(Runnable operation) {
        try { operation.run(); } catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("expected rejection");
    }
    public static void main(String[] arguments) {
        MicroPartitionLayout.Anchor[] anchors = new MicroPartitionLayout.Anchor[9];
        for (int index = 0; index < anchors.length; index++)
            anchors[index] = new MicroPartitionLayout.Anchor(index + 10, index < 5 ? -3 : 5, 2, index + 1);
        MicroPartitionLayout.Candidate candidate = new MicroPartitionLayout.Candidate(3, "spatial", 4, anchors, 2);
        Set<Long> seen = new HashSet<>();
        double work = 0;
        for (int lane = 0; lane < 4; lane++) {
            check(candidate.anchorIds(lane).length >= 2, "balanced nonempty lanes");
            for (long anchor : candidate.anchorIds(lane)) check(seen.add(anchor), "disjoint responsibility");
            work += candidate.work(lane);
        }
        check(seen.size() == 9 && work == 45, "complete responsibility and work");
        List<MicroPartitionLayout.Anchor> reordered = Arrays.asList(anchors.clone());
        Collections.reverse(reordered);
        MicroPartitionLayout.Candidate reverse = new MicroPartitionLayout.Candidate(3, "spatial", 4,
                reordered.toArray(new MicroPartitionLayout.Anchor[0]), 2);
        check(candidate.signature().equals(reverse.signature()), "input order independent");
        long[] leaked = candidate.anchorIds(0); leaked[0] = -100;
        check(candidate.anchorIds(0)[0] != -100, "defensive responsibility copy");
        Point counter = new Point(-3, 5.99);
        check(MicroPartitionLayout.matches(candidate, 0, counter, true), "count input within dependency");
        check(!MicroPartitionLayout.matches(candidate, 0, new Point(-3, 20), true), "far point filtered");
        check(MicroPartitionLayout.matches(candidate, 0, new Point(-3, 20), false), "full input comparator");
        MicroPartitionLayout.Candidate empty = new MicroPartitionLayout.Candidate(0, "spatial", 1,
                new MicroPartitionLayout.Anchor[0], 2);
        check(empty.anchorIds(0).length == 0 && !MicroPartitionLayout.matches(empty, 0, counter, true), "empty envelope");
        rejected(() -> new MicroPartitionLayout.Candidate(0, "spatial", 4,
                new MicroPartitionLayout.Anchor[]{anchors[0]}, 2));
        rejected(() -> new MicroPartitionLayout.Candidate(0, "spatial", 2,
                new MicroPartitionLayout.Anchor[]{anchors[0], anchors[0]}, 2));
        rejected(() -> new MicroPartitionLayout.Anchor(1, Double.NaN, 1, 1));
        rejected(() -> new MicroPartitionLayout.Anchor(1, 1, 1, -1));
        MicroPartitionLayout.Candidate hash = new MicroPartitionLayout.Candidate(0, "hash", 4, anchors, 2);
        for (MicroPartitionLayout.Anchor anchor : anchors)
            check(hash.laneOf(anchor.id) == BudgetedQueryShards.shard(anchor.id, 4), "legacy hash unchanged");
        System.out.println("MicroPartitionLayoutTest passed");
    }
}
