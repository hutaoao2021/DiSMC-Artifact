package com;

public final class MicroPartitionPlannerTest {
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    static void rejected(Runnable operation) {
        try { operation.run(); } catch (IllegalArgumentException | ArithmeticException expected) { return; }
        throw new AssertionError("expected invalid plan rejection");
    }
    public static void main(String[] arguments) throws Exception {
        MicroPartitionLayout.Anchor[] anchors = new MicroPartitionLayout.Anchor[4];
        for (int index = 0; index < 4; index++) anchors[index] = new MicroPartitionLayout.Anchor(index, index * 20, 0, 25);
        MicroPartitionLayout.Candidate candidate = new MicroPartitionLayout.Candidate(0, "spatial", 4, anchors, 2);
        MicroPartitionPopulation.Statistics population = new MicroPartitionPopulation.Statistics(
                new long[]{11555, 3253761}, new long[]{4, 0}, new MicroPartitionLayout.Candidate[]{candidate},
                new long[][]{{9919,10110,10011,10275}});
        MicroPartitionPlanner.Plan full = MicroPartitionPlanner.select(new double[]{100, 10}, population, .01, 40, "spatial_full");
        MicroPartitionPlanner.Plan trimmed = MicroPartitionPlanner.select(new double[]{100, 10}, population, .01, 40, "dependency");
        check(full.taskCount() == 2 && full.extraRecords == 0, "old four pieces exceed budget");
        check(trimmed.taskCount() == 5 && trimmed.extraRecords == 28760 && trimmed.budgetRecords == 32653,
                "MBR four pieces fit fixed budget");
        check(trimmed.originalAssigned == 3265316, "frozen denominator");
        check(trimmed.peak == 25 && trimmed.makespan >= 25, "peak and LPT prediction");
        check(MicroPartitionPlanner.extra(new long[]{10, 10}, 20) == 0, "no negative credit");
        MicroPartitionPlanner.Plan zero = MicroPartitionPlanner.select(new double[]{100,10}, population, 0, 40, "dependency");
        check(zero.taskCount() == 2, "zero budget rejects replication");
        rejected(() -> MicroPartitionPlanner.extra(new long[]{Long.MAX_VALUE, 1}, 0));
        rejected(() -> MicroPartitionPlanner.select(new double[]{Double.NaN, 10}, population, .01, 40, "dependency"));
        rejected(() -> MicroPartitionPlanner.select(new double[]{100, 10}, population, -.01, 40, "dependency"));
        MicroPartitionPlanner.Plan none = MicroPartitionPlanner.select(new double[]{100,10}, population, .01, 40, "none");
        check(none.taskCount() == 2 && none.extraRecords == 0, "none preserved");
        java.nio.file.Path replay = java.nio.file.Files.createTempFile("micro-plan", ".tsv"); java.nio.file.Files.delete(replay);
        trimmed.write(replay,"owner-input-context");
        MicroPartitionPlanner.Plan replayed = MicroPartitionPlanner.replay(replay,"owner-input-context",population,
                new double[]{100,10},.01,40,"spatial_full");
        check(replayed.taskCount() == trimmed.taskCount() && replayed.extraRecords == 34665,
                "same responsibility full-input mechanism control may exceed budget");
        check(replayed.responsibilitySignature().equals(trimmed.responsibilitySignature()), "replayed responsibility fingerprint");
        String artifactHash = MicroPartitionLayout.digest(new String(java.nio.file.Files.readAllBytes(replay),java.nio.charset.StandardCharsets.UTF_8));
        check(MicroPartitionPlanner.replay(replay,"owner-input-context",population,new double[]{100,10},.01,40,"dependency",artifactHash)
                .responsibilitySignature().equals(trimmed.responsibilitySignature()), "replay content hash verified");
        try {
            MicroPartitionPlanner.replay(replay,"owner-input-context",population,new double[]{100,10},.01,40,"dependency","wrong");
            throw new AssertionError("changed replay accepted");
        } catch (IllegalArgumentException expected) { }
        java.nio.file.Files.delete(replay);
        remainingBudgetReducesAlreadySplitTail();
        spareBudgetDoesNotWorsenSchedule();
        measuredTailKeepsBudgetFromUnverifiedUpgrade();
        smallSchedulingOrderNoiseDoesNotBlockTail();
        spareBudgetDoesNotInflateCpuWithIdleSlots();
        aggregateCostOverflowDoesNotDisableCpuGuard();
        schedulingSlackDoesNotCompoundAcrossUpgrades();
        System.out.println("MicroPartitionPlannerTest passed");
    }
    static MicroPartitionLayout.Candidate physical(int owner, int pieces, double[] costs) {
        MicroPartitionLayout.Anchor[] anchors = new MicroPartitionLayout.Anchor[4];
        for (int i=0;i<4;i++) anchors[i]=new MicroPartitionLayout.Anchor(i,i*20,0,1);
        return new MicroPartitionLayout.Candidate(owner,"spatial",pieces,anchors,2).withPhysicalWork(costs);
    }
    // A fixed owner sets peak=100. The measured split tail can still shrink
    // 80 -> 35 using 100 additional reads, without adding short-task splits.
    static void remainingBudgetReducesAlreadySplitTail() {
        MicroPartitionLayout.Candidate two=physical(0,2,new double[]{80,20});
        MicroPartitionLayout.Candidate four=physical(0,4,new double[]{35,25,20,20});
        MicroPartitionLayout.Candidate shortSplit=physical(2,2,new double[]{10,10});
        MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000,1000},new long[]{4,0,4},
            new MicroPartitionLayout.Candidate[]{two,four,shortSplit},
            new long[][]{{550,550},{300,300,300,300},{510,510}});
        MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(new double[]{160,100,20},population,.10,40,"dependency",java.util.Collections.singleton(0));
        check(plan.selected[0]!=null && plan.selected[0].pieces==4,
            "affordable deeper split must reduce a residual long tail even when global peak is fixed");
        check(plan.selected[2]==null,"spare allocation must not fragment unsplit short owners");
        check(plan.peak==100 && plan.makespan==100 && plan.extraRecords==200,
            "retain primary peak and schedule within the original budget");
        MicroPartitionPopulation.Statistics reversed=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000,1000},new long[]{4,0,4},
            new MicroPartitionLayout.Candidate[]{shortSplit,four,two},
            new long[][]{{510,510},{300,300,300,300},{550,550}});
        MicroPartitionPlanner.Plan reordered=MicroPartitionPlanner.select(new double[]{160,100,20},reversed,.10,40,"dependency",java.util.Collections.singleton(0));
        check(plan.responsibilitySignature().equals(reordered.responsibilitySignature()),
            "mixed-depth secondary allocation must be independent of candidate order");
        MicroPartitionLayout.Candidate shortFour=physical(2,4,new double[]{5,5,5,5});
        MicroPartitionPopulation.Statistics splitShort=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000,1000},new long[]{4,0,4},
            new MicroPartitionLayout.Candidate[]{two,four,shortSplit,shortFour},
            new long[][]{{550,550},{300,300,300,300},{510,510},{260,260,260,260}});
        MicroPartitionPlanner.Plan protectedShort=MicroPartitionPlanner.select(new double[]{160,100,120},splitShort,.10,40,"dependency",new java.util.HashSet<Integer>(java.util.Arrays.asList(0,2)));
        check(protectedShort.selected[0].pieces==4 && protectedShort.selected[2].pieces==2
            && protectedShort.extraRecords==220,"do not deepen an already-split short owner with spare budget");
        MicroPartitionPlanner.Plan tight=MicroPartitionPlanner.select(new double[]{160,100,20},population,.05,40,"dependency",java.util.Collections.singleton(0));
        check(tight.selected[0].pieces==2 && tight.extraRecords==100,"no upgrade beyond available records");
    }
    static void spareBudgetDoesNotWorsenSchedule() {
        MicroPartitionLayout.Candidate two=physical(0,2,new double[]{8,1});
        MicroPartitionLayout.Candidate four=physical(0,4,new double[]{5,5,5,5});
        MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000},new long[]{4,0},new MicroPartitionLayout.Candidate[]{two,four},
            new long[][]{{550,550},{300,300,300,300}});
        MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(new double[]{16,10},population,.10,2,"dependency",java.util.Collections.singleton(0));
        check(plan.selected[0].pieces==2 && plan.makespan==10,
            "local peak reduction must be rejected when added CPU worsens the schedule");
    }

    static void measuredTailKeepsBudgetFromUnverifiedUpgrade() {
        MicroPartitionLayout.Candidate hotTwo=physical(0,2,new double[]{80,20});
        MicroPartitionLayout.Candidate hotFour=physical(0,4,new double[]{35,25,20,20});
        MicroPartitionLayout.Candidate verifiedTwo=physical(1,2,new double[]{70,30});
        MicroPartitionLayout.Candidate verifiedFour=physical(1,4,new double[]{30,30,20,20});
        MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000,1000},new long[]{4,4,0},
            new MicroPartitionLayout.Candidate[]{hotTwo,hotFour,verifiedTwo,verifiedFour},
            new long[][]{{550,550},{300,300,300,300},{550,550},{310,310,310,310}});
        MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(new double[]{160,140,100},population,.12,40,"dependency",
            java.util.Collections.singleton(1));
        check(plan.selected[0].pieces==2 && plan.selected[1].pieces==4 && plan.extraRecords==340,
            "measured tail must keep remaining budget from an unverified deeper split");
        check(plan.peak==100 && plan.makespan==100,"evidence gate must retain primary optimum and schedule");
        MicroPartitionPlanner.Plan noEvidence=MicroPartitionPlanner.select(new double[]{160,140,100},population,.12,40,"dependency",
            java.util.Collections.<Integer>emptySet());
        check(noEvidence.selected[0].pieces==2 && noEvidence.selected[1].pieces==2 && noEvidence.extraRecords==200,
            "no private calibration means no speculative residual budget spending");
    }

    static void smallSchedulingOrderNoiseDoesNotBlockTail() {
        MicroPartitionLayout.Candidate two=physical(0,2,new double[]{80,20});
        MicroPartitionLayout.Candidate four=physical(0,4,new double[]{35,25,20,20});
        MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000,1000,1000,1000,1000},new long[]{4,0,0,0,0,0},
            new MicroPartitionLayout.Candidate[]{two,four},new long[][]{{550,550},{300,300,300,300}});
        MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(new double[]{160,100,29,17,50,3},population,.05,3,"dependency",java.util.Collections.singleton(0));
        check(plan.selected[0].pieces==4 && plan.extraRecords==200,
            "constant CPU tail improvement must survive one-percent LPT ordering noise");
        check(plan.peak==100 && plan.makespan==101,"bounded schedule estimate may vary while primary peak stays optimal");
    }
    static void spareBudgetDoesNotInflateCpuWithIdleSlots() {
        MicroPartitionLayout.Candidate two=physical(0,2,new double[]{80,20});
        MicroPartitionLayout.Candidate four=physical(0,4,new double[]{35,35,35,35});
        MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000},new long[]{4,0},new MicroPartitionLayout.Candidate[]{two,four},
            new long[][]{{550,550},{300,300,300,300}});
        MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(new double[]{160,100},population,.10,40,"dependency",java.util.Collections.singleton(0));
        check(plan.selected[0].pieces==2 && plan.extraRecords==100,
            "unchanged LPT with idle slots must not hide a large total CPU increase");
    }

    static void aggregateCostOverflowDoesNotDisableCpuGuard() {
        MicroPartitionLayout.Candidate two=physical(0,2,new double[]{8e307,2e307});
        MicroPartitionLayout.Candidate four=physical(0,4,new double[]{5e307,5e307,5e307,5e307});
        MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(
            new long[]{1000,1000},new long[]{4,0},new MicroPartitionLayout.Candidate[]{two,four},
            new long[][]{{550,550},{300,300,300,300}});
        MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(new double[]{1.6e308,1e308},population,.10,40,"dependency",java.util.Collections.singleton(0));
        check(plan.selected[0].pieces==2 && plan.extraRecords==100,
            "aggregate overflow must fail closed instead of disabling the CPU envelope");
    }

    static void schedulingSlackDoesNotCompoundAcrossUpgrades() {
        MicroPartitionLayout.Candidate a2=physical(0,2,new double[]{80,20});
        MicroPartitionLayout.Candidate a4=physical(0,4,new double[]{35,25,20,20});
        MicroPartitionLayout.Candidate b2=physical(1,2,new double[]{79,21});
        MicroPartitionLayout.Candidate b4=physical(1,4,new double[]{34,26,20,20});
        long[] inputs=new long[15],core=new long[15];java.util.Arrays.fill(inputs,1000);core[0]=core[1]=4;
        MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(inputs,core,
            new MicroPartitionLayout.Candidate[]{a2,a4,b2,b4},new long[][]{{550,550},{300,300,300,300},{550,550},{300,300,300,300}});
        MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(
            new double[]{160,158,100,57,14,51,13,53,56,20,45,12,36,30,36},population,.04,3,"dependency",
            new java.util.HashSet<Integer>(java.util.Arrays.asList(0,1)));
        // Initial LPT243; first upgrade245; both upgrades247. A rolling1% bound
        // would accept247, exceeding the fixed initial envelope245.43.
        check(plan.selected[0].pieces==4 && plan.selected[1].pieces==2 && plan.makespan==245,
            "schedule slack must stay anchored to the original plan across upgrades");
    }

}
