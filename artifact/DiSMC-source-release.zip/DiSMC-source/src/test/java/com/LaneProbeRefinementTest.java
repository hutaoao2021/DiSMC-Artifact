package com;
import java.util.*;
public final class LaneProbeRefinementTest {
 static Point point(long id,double x){Point p=new Point();p.id=id;p.x=x;p.y=0;p.ownerPartitionId=0;p.packedCellId=0;return p;}
 static MicroPartitionLayout.Candidate guide(int pieces,int n){MicroPartitionLayout.Anchor[] a=new MicroPartitionLayout.Anchor[n];for(int i=0;i<n;i++)a[i]=new MicroPartitionLayout.Anchor(i+1,i,0,1);return new MicroPartitionLayout.Candidate(0,"spatial",pieces,a,1);}
 public static void main(String[] args){
  MicroPartitionLayout.Candidate c=guide(16,512);int[] q=new int[16];Arrays.fill(q,4);
  long[] done={1,2,3,4,5,6,7,8};LaneProbeRefinement.Target t=new LaneProbeRefinement.Target(c,q,done);
  MaskedBlockBuilder builder=new MaskedBlockBuilder(new int[]{0});for(int i=0;i<512;i++)builder.add(point(i+1,i),1);MaskedSharedBlock block=builder.build();
  long[] ids=LaneProbeRefinement.selectIds(block,t);if(ids.length!=64)throw new AssertionError("Need four fresh observations per region");
  int[] actual=new int[16];for(long id:ids){if(Arrays.binarySearch(done,id)>=0)throw new AssertionError("Repeated already completed initiation");actual[c.laneOf(id)]++;}
  if(!Arrays.equals(q,actual))throw new AssertionError("Stratum coverage differs");
  MaskedBlockBuilder reverse=new MaskedBlockBuilder(new int[]{0});for(int i=511;i>=0;i--)reverse.add(point(i+1,i),1);
  if(!Arrays.equals(ids,LaneProbeRefinement.selectIds(reverse.build(),t)))throw new AssertionError("Input order changes selected identities");
  SampledAnchorCostProbe.Probe initial=new SampledAnchorCostProbe.Probe(0,8,0,8020);initial.anchorIds=done;
  initial.observations=new AnchorCostObservation[8];for(int i=0;i<8;i++)initial.observations[i]=new AnchorCostObservation(point(i+1,i),1000,0,0,0);
  long[][] inputs={new long[16]};Arrays.fill(inputs[0],38);
  MicroPartitionPopulation.Statistics s=new MicroPartitionPopulation.Statistics(new long[]{608},new long[]{512},new MicroPartitionLayout.Candidate[]{c},inputs);
  MicroPartitionPlanner.Plan plan=MicroPartitionPlanner.select(new double[]{512},s,.03,2,"dependency");
  LaneProbeRefinement.Target[] selected=LaneProbeRefinement.targets(s,plan,new SampledAnchorCostProbe.Probe[]{initial},256,4,4,8);
  if(selected.length!=1||selected[0].sampleCount()<64||selected[0].sampleCount()>256)throw new AssertionError("Deep selected split lacks bounded coverage");
  if(LaneProbeRefinement.targets(s,plan,new SampledAnchorCostProbe.Probe[]{initial},32,4,4,8).length!=0)throw new AssertionError("Global sample budget must take precedence");
  System.out.println("PASS bounded lane coverage, no repeated completion, input-order invariance, selected deep split and insufficient sample budget");
 }
}
