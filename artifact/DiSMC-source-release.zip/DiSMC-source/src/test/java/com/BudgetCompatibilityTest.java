package com;
import org.apache.spark.SparkConf;
public final class BudgetCompatibilityTest {
 static SparkConf config(boolean micro,String budget,boolean diagnostic){
  SparkConf c=new SparkConf(false);
  if(budget!=null)c.set("spark.skyline.shardReadBudget",budget);
  c.set("spark.skyline.budgetDiagnostic",Boolean.toString(diagnostic));
  if(micro){String p="spark.skyline.experiment.";c.set(p+"enabled","true").set(p+"partitionStrategy","workload").set(p+"organization","independent_owner").set(p+"shardStrategy","none").set(p+"microPartition","true").set(p+"microPartitionMode","dependency");}
  return c;
 }
 static boolean accepts(boolean micro,String budget,boolean diagnostic){try{ExperimentConfig.from(config(micro,budget,diagnostic),MethodProfile.HILBERT_FULL);return true;}catch(IllegalArgumentException ex){return false;}}
 static void expect(boolean micro,String budget,boolean diagnostic,boolean expected){boolean got=accepts(micro,budget,diagnostic);System.out.println("CONFIG micro="+micro+" budget="+budget+" diagnostic="+diagnostic+" accepted="+got);if(got!=expected)throw new AssertionError("budget compatibility mismatch: "+budget);}
 public static void main(String[] args){
  expect(true,"0.10",true,true);
  expect(true,null,false,true);expect(true,"0.01",false,true);
  for(String x:new String[]{"0.02","0.03","0.05","0.10"}){expect(true,x,true,true);expect(true,x,false,false);}
  for(String x:new String[]{"0","-0.01","0.099999999999","0.100000000001","0.2","1","NaN","Infinity","-Infinity"})expect(true,x,true,false);
  // This validator historically imposes no budget whitelist on non-micro profiles.
  // Record that behavior explicitly rather than extending this fix's scope.
  for(String x:new String[]{"0","0.01","0.05","0.10","0.2","1","-0.01","NaN","Infinity"})expect(false,x,true,true);
  MicroPartitionLayout.Anchor[] a=new MicroPartitionLayout.Anchor[4];for(int i=0;i<4;i++)a[i]=new MicroPartitionLayout.Anchor(i,i*20,0,25);
  MicroPartitionLayout.Candidate c=new MicroPartitionLayout.Candidate(0,"spatial",4,a,2);
  MicroPartitionPopulation.Statistics s=new MicroPartitionPopulation.Statistics(new long[]{11555,3253761},new long[]{4,0},new MicroPartitionLayout.Candidate[]{c},new long[][]{{9919,10110,10011,10275}});
  for(double b:new double[]{0,.01,.05,.10,1}){MicroPartitionPlanner.Plan q=MicroPartitionPlanner.select(new double[]{100,10},s,b,40,"dependency");if(q.budgetRecords!=(long)Math.floor(3265316*b)||q.extraRecords>q.budgetRecords)throw new AssertionError("cap");System.out.println("PLANNER fraction="+b+" cap="+q.budgetRecords+" extra="+q.extraRecords);}
  for(double b:new double[]{-.01,1.00001,Double.NaN,Double.POSITIVE_INFINITY}){try{MicroPartitionPlanner.select(new double[]{100,10},s,b,40,"dependency");throw new AssertionError("invalid accepted");}catch(IllegalArgumentException expected){}}
  System.out.println("BudgetCompatibilityTest passed");
 }
}
