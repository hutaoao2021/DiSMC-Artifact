package com;
import java.nio.file.*;
import java.util.*;
// Four R/W combinations on the actual serialized captured-state representation.
public final class FrozenReplayControlsTest {
 private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 private static FrozenPlannerState fixture(){
  MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(
    new long[]{4},new long[]{4},new MicroPartitionLayout.Candidate[0],new long[0][]);
  Circle witness=new Circle(1.0,2.0);witness.discenq=3.0;witness.cirnum=4;
  HashMap<Double,Circle> skyline=new HashMap<>();skyline.put(witness.discenq,witness);
  Map<Integer,long[]> completed=new HashMap<>();completed.put(0,new long[]{7,11});
  return new FrozenPlannerState(population,new double[]{10.0},
    ProbeDominanceFrontier.fromCircles(Collections.singletonList(witness)),
    completed,Collections.singletonList(skyline),new long[10]);
 }
 public static void main(String[] args)throws Exception{
  FrozenPlannerState original=fixture();
  Path temporary=Files.createTempFile("dismc-frozen-switches-", ".bin");
  try{
   Files.delete(temporary);
   original.write(temporary,"fixed-source-query-layout");
   FrozenPlannerState frozen=FrozenPlannerState.read(temporary,"fixed-source-query-layout");
   check(!FrozenPlannerState.sha256(temporary).isEmpty(),"frozen checksum");
   int checked=0;
   for(boolean reuse:new boolean[]{false,true})for(boolean transfer:new boolean[]{false,true}){
    Map<Integer,long[]> selected=frozen.replayCompletedAnchors(reuse);
    ProbeDominanceFrontier witnesses=frozen.replayProbeFrontier(transfer);
    check(selected.containsKey(0)==reuse,"R must independently control completed-anchor skipping");
    check(witnesses.witnessDistances()==(transfer?1:0),"W must independently control transferred witnesses");
    check(frozen.completedAnchors.get(0).length==2,"frozen completed IDs must remain intact");
    check(frozen.frontier.witnessDistances()==1,"frozen witness state must remain intact");
    check(frozen.probeSkylines.size()==1,"final reduction keeps completed probe results");
    if(reuse){selected.get(0)[0]=1000;check(frozen.completedAnchors.get(0)[0]==7,"replay must not alias frozen IDs");}
    checked++;
   }
   check(checked==4,"all R/W combinations tested");
   boolean mismatch=false;try{FrozenPlannerState.read(temporary,"other-context");}catch(java.io.IOException expected){mismatch=true;}
   check(mismatch,"frozen identity guard must remain enforced");
   System.out.println("FrozenReplayControlsTest passed: four R/W combinations, snapshot isolation, and context guard");
  }finally{Files.deleteIfExists(temporary);}
 }
}
