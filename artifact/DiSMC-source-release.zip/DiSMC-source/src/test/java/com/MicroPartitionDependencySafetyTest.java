package com;

import java.lang.reflect.Method;
import java.util.*;

public final class MicroPartitionDependencySafetyTest {
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    public static void main(String[] arguments) throws Exception {
        Method pair = MaskedIndexedEMCS.class.getDeclaredMethod("buildCandidateCircle",MaskedPreparedNeighborhood.IndexedPoint.class,
                MaskedPreparedNeighborhood.IndexedPoint.class,double.class); pair.setAccessible(true);
        for (double[] partner : new double[][]{{1,0},{1e-8,1e-8},{1.999999999,0},{0,1.5}}) {
            List<Point> input = new ArrayList<>(); input.add(MicroPartitionPopulationTest.point(1,4,4,0));
            input.add(MicroPartitionPopulationTest.point(2,4+partner[0],4+partner[1],1));
            Random random = new Random(81);
            for (int index = 0; index < 500; index++) input.add(MicroPartitionPopulationTest.point(index+10,
                    random.nextDouble()*8,random.nextDouble()*8,1));
            input.add(MicroPartitionPopulationTest.point(1001,6.004999,4,1));
            for (Point point : input) point.setCell((int)Math.floor(point.x),(int)Math.floor(point.y));
            MicroPartitionLayout.Candidate candidate = new MicroPartitionLayout.Candidate(0,"spatial",1,
                    new MicroPartitionLayout.Anchor[]{new MicroPartitionLayout.Anchor(1,4,4,1)},1);
            MaskedSharedBlock block = MicroPartitionExecution.block(0,candidate,0,input);
            MaskedPreparedNeighborhood prepared = new MaskedPreparedNeighborhood(block,1,1,15,15);
            MaskedIndexedEMCS kernel = new MaskedIndexedEMCS(1); kernel.q.x=15; kernel.q.y=15; kernel.setCellConfig(1);
            kernel.usePrepared(prepared,0,0,0,1,new EngineOptions(true,false,false));
            Circle circle = (Circle)pair.invoke(kernel,prepared.point(0),prepared.point(1),partner[0]*partner[0]+partner[1]*partner[1]);
            if (circle == null) continue;
            for (Point point : input) {
                double deltaX = point.x-circle.centerX, deltaY = point.y-circle.centerY;
                if (Math.hypot(deltaX,deltaY) <= Math.nextDown(1.005))
                    check(MicroPartitionLayout.matches(candidate,0,point,true),"actual reference pair-circle member retained");
            }
            List<Point> trimmed = new ArrayList<>(); for (Point point : input)
                if (MicroPartitionLayout.matches(candidate,0,point,true)) trimmed.add(point);
            HashMap<Double,Circle> reference = MaskedLaneQuery.evaluate(prepared,0,0,0,1,1,1,15,15,2,new EngineOptions(true,false,false)).skyline;
            HashMap<Double,Circle> actual = MaskedLaneQuery.evaluate(new MaskedPreparedNeighborhood(MicroPartitionExecution.block(0,candidate,0,trimmed),1,1,15,15),
                    0,0,0,1,1,1,15,15,2,new EngineOptions(true,false,false)).skyline;
            check(reference.keySet().equals(actual.keySet()),"small-fixture target front retained");
            for (Double distance : reference.keySet()) check(reference.get(distance).cirnum == actual.get(distance).cirnum,"small-fixture coverage count retained");
        }
        System.out.println("MicroPartitionDependencySafetyTest passed");
    }
}
