package com;
import java.util.*;
import java.lang.reflect.*;
public final class SpatialProbeCostModelTest {
 static void check(boolean b,String msg){if(!b)throw new AssertionError(msg);}
 public static void main(String[] args)throws Exception{
  Class<?> model;
  try{model=Class.forName("com.SpatialProbeCostModel");}
  catch(ClassNotFoundException e){throw new AssertionError("Production planner cannot assign spatial probe work to lanes",e);}
  Class<?> observation=Class.forName("com.AnchorCostObservation");
  Constructor<?> create=observation.getConstructor(Point.class,long.class,long.class,long.class,long.class);
  MicroPartitionLayout.Anchor[] anchors=new MicroPartitionLayout.Anchor[16];
  Map<Long,Double> cellWork=new HashMap<>();
  Object rows=java.lang.reflect.Array.newInstance(observation,8);
  for(int i=0;i<16;i++){
   anchors[i]=new MicroPartitionLayout.Anchor(i,i,0,1);
   Point p=new Point(i,0);p.id=i;p.setCell(i,0);cellWork.put(p.packedCellId,1.0);
   if(i<4||i>=8&&i<12)java.lang.reflect.Array.set(rows,i<4?i:i-4,create.newInstance(p,i<4?10L:100L,0L,5L,20L));
  }
  SampledAnchorCostProbe.Probe probe=new SampledAnchorCostProbe.Probe(0,8,0,440);
  SampledAnchorCostProbe.Probe.class.getField("observations").set(probe,rows);
  MicroPartitionLayout.Candidate candidate=new MicroPartitionLayout.Candidate(0,"spatial",2,anchors,1);
  MicroPartitionPopulation.Statistics population=new MicroPartitionPopulation.Statistics(new long[]{40},new long[]{16},new MicroPartitionLayout.Candidate[]{candidate},new long[][]{{24,24}});
  SampledAnchorCostProbe.Calibration cal=(SampledAnchorCostProbe.Calibration)model.getMethod("calibrate",double[].class,long[].class,SampledAnchorCostProbe.Probe[].class).invoke(null,new double[]{16},population.core,new SampledAnchorCostProbe.Probe[]{probe});
  check(cal.work[0]==880&&cal.secondsPerWork==1e-9,"Zero point checks must still include bucket/candidate CPU work");
  SampledAnchorCostProbe.Probe setupProbe=new SampledAnchorCostProbe.Probe(0,8,0,640);
  Field setup;try{setup=SampledAnchorCostProbe.Probe.class.getField("setupNanos");}catch(NoSuchFieldException e){throw new AssertionError("Task-fixed cache allocation is still extrapolated as anchor work",e);}
  setup.setLong(setupProbe,200);
  SampledAnchorCostProbe.Calibration setupCal=(SampledAnchorCostProbe.Calibration)model.getMethod("calibrate",double[].class,long[].class,SampledAnchorCostProbe.Probe[].class).invoke(null,new double[]{16},population.core,new SampledAnchorCostProbe.Probe[]{setupProbe});
  check(setupCal.work[0]==1080,"Charge setup once, extrapolate only recurring anchor work");
  MicroPartitionPopulation.Statistics scaled=SampledAnchorCostProbe.reweight(population,new double[]{16},cal.work);
  Method reweight=model.getMethod("reweight",MicroPartitionPopulation.Statistics.class,SampledAnchorCostProbe.Probe[].class,Map.class);
  MicroPartitionPopulation.Statistics adjusted=(MicroPartitionPopulation.Statistics)reweight.invoke(null,scaled,new SampledAnchorCostProbe.Probe[]{probe},cellWork);
  MicroPartitionLayout.Candidate c=adjusted.candidates[0];
  check(c.work(1)>2*c.work(0),"Equal raw population lanes must expose the measured hotspot");
  check(Math.abs(c.work(0)+c.work(1)-880)<1e-9,"Keep owner totals comparable across alternatives");
  check(candidate.signature().equals(c.signature())&&Arrays.equals(candidate.anchorIds(0),c.anchorIds(0)),"Cost calibration must not alter point-coordinate responsibilities");
  check(Arrays.deepEquals(population.dependencyInputs,adjusted.dependencyInputs),"Keep exact dependency fees and replication budget unchanged");
  // Deep candidates with too few observations retain their proxy shares.
  MicroPartitionLayout.Candidate four=new MicroPartitionLayout.Candidate(0,"spatial",4,anchors,1);
  MicroPartitionPopulation.Statistics sparse=SampledAnchorCostProbe.reweight(new MicroPartitionPopulation.Statistics(new long[]{40},new long[]{16},new MicroPartitionLayout.Candidate[]{four},new long[][]{{15,15,15,15}}),new double[]{16},cal.work);
  MicroPartitionLayout.Candidate fallback=((MicroPartitionPopulation.Statistics)reweight.invoke(null,sparse,new SampledAnchorCostProbe.Probe[]{probe},cellWork)).candidates[0];
  check(fallback.work(1)>0&&fallback.work(3)>0,"Unsampled responsibility must never be assigned zero work");
  System.out.println("PASS spatial hotspot weighting, zero-check CPU costs, exact layout/fees and sparse fallback");
 }
}
