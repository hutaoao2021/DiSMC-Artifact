package com;
import java.util.*;
public class AnchorRegressionTest {
 public static void main(String[] args){
  double r=.1,qx=-9999750.839;double[] xs={9999816.700,9999816.495};
  MaskedBlockBuilder b=new MaskedBlockBuilder(new int[]{0});List<Point> input=new ArrayList<>();
  for(int i=0;i<xs.length;i++){Point p=new Point(xs[i],0);p.id=i+1;p.ownerPartitionId=0;p.is_core=true;p.isCore=true;p.setCell((int)Math.floor(p.x/r),0);input.add(p);b.add(p,1);}
  ReferenceCandidateGeometry g=new ReferenceCandidateGeometry(r,qx,0);
  TreeMap<Double,Integer> ref=new TreeMap<>();
  for(Point p:input){Circle c=g.single(p);int count=0;for(Point v:input)if(ReferenceCandidateGeometry.covers(c,v,r))count++;
   System.out.printf("single anchor=%.17g center=%.17g center-to-anchor=%.17g distance=%.17g full-count=%d%n",p.x,c.centerX,Math.abs(p.x-c.centerX),c.discenq,count);
   if(count>=2)ref.put(c.discenq,count);
  }
  System.out.println("pair="+g.pair(input.get(0),input.get(1)));
  MaskedSharedBlock block=b.build();
  for(boolean bounds:new boolean[]{false,true}){
   MaskedLaneQuery.Evaluation e=MaskedLaneQuery.evaluate(new MaskedPreparedNeighborhood(block,r,r,qx,0),0,0,0,1,r,r,qx,0,2,new EngineOptions(bounds,false,false));
   TreeMap<Double,Integer> actual=new TreeMap<>();for(Circle c:e.skyline.values())actual.put(c.discenq,c.cirnum);
   if(!ref.equals(actual))throw new AssertionError("bounds="+bounds+" expected="+ref+" actual="+actual);
  }
  MaskedLaneQuery.Evaluation e=MaskedLaneQuery.evaluate(new MaskedPreparedNeighborhood(block,r,r,qx,0),0,0,0,1,r,r,qx,0,2,EngineOptions.FULL);
  TreeMap<Double,Integer> actual=new TreeMap<>();for(Circle c:e.skyline.values())actual.put(c.discenq,c.cirnum);
  if(!ref.equals(actual))throw new AssertionError("FULL expected="+ref+" actual="+actual);System.out.println("PASS anchor regression");
 }
}
