package com;
import java.util.*;
import java.nio.file.*;
import java.lang.reflect.Method;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.*;
public final class NumericalMemberSparkRegressionTest {
 static Circle circle(){Circle c=new Circle(0,0);c.cirnum=2;return c;}
 public static void main(String[] args)throws Exception{
  SparkConf conf=new SparkConf(false).setMaster("local[2]").setAppName("NumericalMemberRegression").set("spark.ui.enabled","false").set("spark.driver.host","127.0.0.1").set("spark.driver.bindAddress","127.0.0.1");
  List<String> failures=new ArrayList<>();
  try(JavaSparkContext sc=new JavaSparkContext(conf)){
   sc.setLogLevel("ERROR");double r=.1;List<Point> ps=new ArrayList<>();
   for(int i=0;i<2;i++){Point p=new Point(i==0?0:.105,0);p.id=i+1;p.setCell((int)Math.floor(p.x/r),0);ps.add(p);}
   JavaRDD<Point> input=sc.parallelize(ps,2);Circle c=circle();
   for(Point p:ps)if(!ReferenceCandidateGeometry.covers(c,p,r))throw new AssertionError("fixture is not fully counted");
   Map<Long,List<double[]>> lookup=new HashMap<>();for(Point p:ps)lookup.put(p.packedCellId,Collections.singletonList(new double[]{0,0,0}));
   Path directory=Files.createTempDirectory("dismc-member-regression-");
   try{PartitionedMemberWriter.Result result=PartitionedMemberWriter.write(sc,input,lookup,r,Collections.singletonList(c),directory.toAbsolutePath().toString(),directory.resolve("manifest.tsv").toString());if(result.records!=2)failures.add("partitioned exported="+result.records);}
   catch(Exception e){failures.add("partitioned: "+e.getMessage());}
   DistributedSMCGridbaseRebuilt driver=new DistributedSMCGridbaseRebuilt();driver.sortedSkymapList=new ArrayList<>();driver.sortedSkymapList.add(circle());
   Method m=DistributedSMCGridbaseRebuilt.class.getDeclaredMethod("materializeFinalCircleMembers",JavaSparkContext.class,JavaRDD.class,double.class,double.class);m.setAccessible(true);m.invoke(driver,sc,input,r,r);
   if(driver.sortedSkymapList.get(0).p.size()!=2)failures.add("driver exported="+driver.sortedSkymapList.get(0).p.size());
   List<Circle> circles=Collections.singletonList(circle());SpatialOperatorPipeline.materializeMembers(sc,input,circles,r);
   if(circles.get(0).p.size()!=2)failures.add("operator exported="+circles.get(0).p.size());
  }
  if(!failures.isEmpty())throw new AssertionError(failures.toString());
  System.out.println("PASS actual local Spark partitioned/driver/operator member exports: 2 counted = 2 exported");
 }
}
