#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
if command -v mvn >/dev/null 2>&1; then
  mvn -q -DskipTests package
else
  : "${SPARK_HOME:?Set SPARK_HOME to Spark 3.2.0 when using the non-Maven build path}"
  rm -rf target/classes
  mkdir -p target/classes target/build
  find src/main/java -name '*.java' -print > target/build/main-sources.list
  javac -encoding UTF-8 -source 8 -target 8 \
    -cp "$SPARK_HOME/jars/*" \
    -d target/classes @target/build/main-sources.list
  printf 'Main-Class: com.DistributedSMC\n' > target/build/MANIFEST.MF
  jar cfm target/dismc-unified-1.0.0.jar target/build/MANIFEST.MF -C target/classes .
fi
mkdir -p target/build
JAVA_SOURCE_HASH=$(find src/main/java -type f -name '*.java' -print0 | LC_ALL=C sort -z | xargs -0 sha256sum | sha256sum | cut -d ' ' -f1)
JAR_HASH=$(sha256sum target/dismc-unified-1.0.0.jar | cut -d ' ' -f1)
PROVENANCE_TEMP=$(mktemp target/build/provenance.XXXXXX)
printf '{"jar_sha256":"%s","java_source_sha256":"%s"}\n' "$JAR_HASH" "$JAVA_SOURCE_HASH" > "$PROVENANCE_TEMP"
mv "$PROVENANCE_TEMP" target/build/provenance.json
printf '%s\n' "$PWD/target/dismc-unified-1.0.0.jar"
