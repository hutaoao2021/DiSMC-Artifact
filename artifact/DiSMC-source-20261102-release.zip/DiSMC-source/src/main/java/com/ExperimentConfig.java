package com;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.apache.spark.SparkConf;
import scala.Tuple2;

public final class ExperimentConfig implements Serializable {
    private static final String PREFIX = "spark.skyline.experiment.";
    private static final Set<String> KEYS = new HashSet<String>(Arrays.asList(
            "enabled", "partitionStrategy", "organization", "transportEncoding", "shardStrategy", "preparedMode",
            "projectionCache", "geometricBounds", "microDenseBoundaryCounting", "ownerThreads", "maxPieces", "observe", "taskDetails", "runId", "outputPrefix",
            "microPartition", "microPartitionMode", "microPartitionReplay", "microCostModel", "microCostSignal", "microFixedProbeSlots", "microTaskOrder", "microPlannerPolicy", "microRefinedCounting", "microCountingCellMultiplier", "microCompletionReuse", "microPopulationFromCells", "microPopulationDirect", "microPopulationInProbe", "microProbeFrontier", "microProbeAnchorBounds", "microProjectedDedup", "microCountWindowCache", "microAnchorBoundary", "microDeferredCircleAllocation", "microSpatialCountTree", "microAdaptiveCountIndex", "microProbeTrace", "microProbeSelectedRouting", "microProbeAnchorBoundGrid"));
    public final boolean enabled, dependencyPartition, interiorRouting, projectionCache, observe, taskDetails;
    public final String partitionStrategy;
    public final boolean geometricBounds;
    public final boolean microDenseBoundaryCounting;
    public final String organization, transportEncoding, shardStrategy, preparedMode, runId, outputPrefix;
    public final int ownerThreads, maxPieces;
    public final boolean microPartition;
    public final String microCostSignal;
    public final int microFixedProbeSlots;
    public final boolean microRefinedCounting;
    public final boolean microCompletionReuse;
    public final double microCountingCellMultiplier;
    public final boolean microAdaptiveCountIndex;
    public final boolean microPopulationFromCells;
    public final boolean microPopulationDirect;
    public final boolean microPopulationInProbe;
    public final boolean microProbeFrontier;
    public final boolean microProbeAnchorBounds;
    public final String microProbeAnchorBoundGrid;
    public final boolean microProjectedDedup;
    public final boolean microCountWindowCache;
    public final boolean microAnchorBoundary;
    public final boolean microDeferredCircleAllocation;
    public final boolean microSpatialCountTree;
    public final boolean microProbeTrace;
    public final boolean microProbeSelectedRouting;
    public final String microPartitionMode, microPartitionReplay, microCostModel, microTaskOrder, microPlannerPolicy;

    private ExperimentConfig(SparkConf conf, MethodProfile profile) {
        for (Tuple2<String, String> entry : conf.getAll()) {
            if (entry._1().startsWith(PREFIX) && !KEYS.contains(entry._1().substring(PREFIX.length()))) {
                throw new IllegalArgumentException("unknown experiment key: " + entry._1());
            }
        }
        enabled = bool(conf, "enabled", false);
        geometricBounds = bool(conf, "geometricBounds", false);
        microDenseBoundaryCounting=bool(conf,"microDenseBoundaryCounting",false);
        if(microDenseBoundaryCounting&&!geometricBounds)throw new IllegalArgumentException("dense boundary refinement requires geometric bounds");
        if (geometricBounds && !enabled) {
            throw new IllegalArgumentException("geometricBounds requires experimental enabled=true");
        }
        partitionStrategy = choice(conf, "partitionStrategy", profile.dependencyPartition ? "dependency" : "point_count",
                "dependency", "workload", "point_count");
        if (!enabled && conf.contains(PREFIX + "partitionStrategy")) {
            throw new IllegalArgumentException("partitionStrategy requires experimental enabled=true");
        }
        dependencyPartition = partitionStrategy.equals("dependency");
        interiorRouting = enabled || profile.dependencyPartition;
        observe = bool(conf, "observe", false);
        taskDetails = bool(conf, "taskDetails", false);
        organization = choice(conf, "organization", "shared_bundle", "shared_bundle", "independent_owner");
        transportEncoding = choice(conf, "transportEncoding", "deduplicated_union", "deduplicated_union", "owner_copies");
        shardStrategy = choice(conf, "shardStrategy", "cost_model", "none", "uniform", "cost_model");
        preparedMode = choice(conf, "preparedMode", "shared_bundle_index", "shared_bundle_index", "private_owner_index");
        projectionCache = choice(conf, "projectionCache", "on", "on", "off").equals("on");
        ownerThreads = conf.getInt(PREFIX + "ownerThreads", enabled ? 1 : 2);
        maxPieces = conf.getInt(PREFIX + "maxPieces", 4);
        runId = conf.get(PREFIX + "runId", "").trim();
        outputPrefix = conf.get(PREFIX + "outputPrefix", "").trim();
        microPartition = bool(conf, "microPartition", false);
        microPartitionMode = choice(conf, "microPartitionMode", "none", "none", "hash_full", "spatial_full", "dependency");
        microPartitionReplay = conf.get(PREFIX + "microPartitionReplay", "").trim();
        microCostModel = choice(conf, "microCostModel", "linear", "linear", "cell_quadratic");
        microTaskOrder = choice(conf, "microTaskOrder", "owner", "owner", "cost");
        microPlannerPolicy = choice(conf, "microPlannerPolicy", "peak", "peak", "completion", "sampled_peak");
        microRefinedCounting = bool(conf, "microRefinedCounting", false);
        microCostSignal = choice(conf,"microCostSignal","sampled","sampled","static","unit");
        if (!microCostSignal.equals("sampled") && (!microPartition || !microPlannerPolicy.equals("sampled_peak")
                || conf.getBoolean("spark.skyline.microImplicitFamily",false)))
            throw new IllegalArgumentException("cost signal controls require explicit sampled_peak execution");
        microFixedProbeSlots = conf.getInt(PREFIX + "microFixedProbeSlots", 0);
        if (microFixedProbeSlots < 0 || (microFixedProbeSlots > 0 && (!microPartition
                || !microPlannerPolicy.equals("sampled_peak") || microPartitionReplay.isEmpty()
                || outputPrefix.isEmpty() || conf.getBoolean("spark.skyline.microImplicitFamily",false))))
            throw new IllegalArgumentException("fixed probe eligibility requires explicit sampled replay and outputPrefix");
        microCompletionReuse = bool(conf, "microCompletionReuse", true);
        microCountingCellMultiplier = conf.getDouble(PREFIX + "microCountingCellMultiplier", 1.0);
        if (!Double.isFinite(microCountingCellMultiplier) || microCountingCellMultiplier <= 0)
            throw new IllegalArgumentException("invalid counting cell multiplier");
        if (microCountingCellMultiplier != 1.0 && (!microPartition || !microRefinedCounting))
            throw new IllegalArgumentException("counting cell multiplier requires refined micro counting");
        microAdaptiveCountIndex=bool(conf,"microAdaptiveCountIndex",false);
        microPopulationFromCells = bool(conf, "microPopulationFromCells", false);
        microPopulationDirect = bool(conf, "microPopulationDirect", false);
        microPopulationInProbe = bool(conf, "microPopulationInProbe", false);
        microProbeFrontier = bool(conf,"microProbeFrontier",false);
        microProbeAnchorBounds = bool(conf,"microProbeAnchorBounds",false);
        microProbeAnchorBoundGrid = choice(conf,"microProbeAnchorBoundGrid","fine","fine","coarse");
        if (microProbeAnchorBoundGrid.equals("coarse") && !microProbeAnchorBounds)
            throw new IllegalArgumentException("coarse anchor certificate requires anchor bounds");
        microProjectedDedup=bool(conf,"microProjectedDedup",false);
        microCountWindowCache=bool(conf,"microCountWindowCache",false);
        microAnchorBoundary=bool(conf,"microAnchorBoundary",false);
        microDeferredCircleAllocation=bool(conf,"microDeferredCircleAllocation",false);
        microSpatialCountTree=bool(conf,"microSpatialCountTree",false);
        microProbeTrace=bool(conf,"microProbeTrace",false);
        microProbeSelectedRouting=bool(conf,"microProbeSelectedRouting",false);
        if (microProbeSelectedRouting && (!microPartition || microPlannerPolicy.equals("peak")))
            throw new IllegalArgumentException("selected probe routing requires sampled micro execution");
        if(microProbeTrace && (!microPartition || !microPlannerPolicy.equals("sampled_peak")
                || !microProbeFrontier || !projectionCache))
            throw new IllegalArgumentException("observation-only tracing requires cached sampled_peak execution with probe frontier");
        if(microSpatialCountTree && (!microPartition || geometricBounds || microCountWindowCache))
            throw new IllegalArgumentException("spatial tree requires micro execution without alternative counting backend");
        if(geometricBounds && microCountWindowCache)throw new IllegalArgumentException("geometric bounds and count-window caching are alternative counting backends");
        if(microDeferredCircleAllocation && !microPartition)throw new IllegalArgumentException("deferred circles require micro execution");
        if(microAnchorBoundary && !microPartition)throw new IllegalArgumentException("anchor boundary requires micro execution");
        if(microCountWindowCache && !microPartition)
            throw new IllegalArgumentException("count-window reuse requires micro execution");
        if(microProjectedDedup && !microPartition)
            throw new IllegalArgumentException("projected candidate dedup requires micro execution");
        if(microProbeAnchorBounds && !microProbeFrontier)
            throw new IllegalArgumentException("probe anchor bounds require probe frontier");
        if(microProbeFrontier && (!microPartition || microPlannerPolicy.equals("peak")))
            throw new IllegalArgumentException("probe frontier requires sampled micro execution");
        if (microPopulationInProbe && (!microPartition || !microPartitionMode.equals("dependency")
                || !microPlannerPolicy.equals("sampled_peak") || microPopulationDirect || microPopulationFromCells))
            throw new IllegalArgumentException("probe population requires sampled-peak dependency execution without alternative population paths");
        if(microPopulationDirect && (!microPartition || microPopulationFromCells))
            throw new IllegalArgumentException("direct population requires micro execution without cell metadata path");
        if (microPopulationFromCells && !microPartition)
            throw new IllegalArgumentException("cell population metadata requires micro execution");
        // Probe and formal execution now receive the same counting-grid option.
        if(microAdaptiveCountIndex && (!microPartition || !microRefinedCounting || microSpatialCountTree))
            throw new IllegalArgumentException("adaptive count index requires refined micro execution without tree backend");
        if (microRefinedCounting && !microPartition)
            throw new IllegalArgumentException("refined counting requires micro execution");
        if (!microPlannerPolicy.equals("peak") && (!microPartition || !microCostModel.equals("cell_quadratic")
                || (!microTaskOrder.equals("cost") && conf.get("spark.skyline.microFrozenStateLoad", "").isEmpty())))
            throw new IllegalArgumentException("sampled planners require online quadratic micro execution in cost order");
        if (microPlannerPolicy.equals("completion") && !microPartitionReplay.isEmpty())
            throw new IllegalArgumentException("completion planner responsibility replay is unsupported");
        if (microPartition && (!enabled || !(partitionStrategy.equals("workload") || partitionStrategy.equals("point_count"))
                || !organization.equals("independent_owner") || !shardStrategy.equals("none")
                || !transportEncoding.equals("deduplicated_union") || maxPieces != 4))
            throw new IllegalArgumentException("micro partition requires workload-or-point_count/independent/none/union/maxPieces=4");
        double diagnosticBudget = conf.getDouble("spark.skyline.shardReadBudget", 0.01);
        boolean budgetDiagnostic = conf.getBoolean("spark.skyline.budgetDiagnostic", false);
        if (microPartition && diagnosticBudget != 0.01
                && !(budgetDiagnostic && (diagnosticBudget == 0.02 || diagnosticBudget == 0.03 || diagnosticBudget == 0.05)))
            throw new IllegalArgumentException("micro default budget is 0.01; explicit diagnostics permit 0.02/0.03/0.05");
        if (!microPartition && (conf.contains(PREFIX + "microPartitionMode") || !microPartitionReplay.isEmpty()
                || conf.contains(PREFIX + "microCostModel") || conf.contains(PREFIX + "microTaskOrder") || conf.contains(PREFIX + "microPlannerPolicy")))
            throw new IllegalArgumentException("micro mode/replay requires microPartition=true");
        if (!microPartitionReplay.isEmpty() && !(microPartitionMode.equals("spatial_full") || microPartitionMode.equals("dependency")))
            throw new IllegalArgumentException("responsibility replay requires a spatial mode");
        if (enabled && profile != MethodProfile.HILBERT_FULL) {
            throw new IllegalArgumentException("experimental layout requires hilbert_full");
        }
        if (enabled && ownerThreads != 1) {
            throw new IllegalArgumentException("controlled experiments require ownerThreads=1");
        }
        if (maxPieces < 1 || maxPieces > 4) throw new IllegalArgumentException("maxPieces must be 1..4");
        if (observe && (runId.isEmpty() || outputPrefix.isEmpty())) {
            throw new IllegalArgumentException("observation requires runId and outputPrefix");
        }
        if (taskDetails && !observe) throw new IllegalArgumentException("taskDetails requires observe=true");
    }

    public static ExperimentConfig from(SparkConf conf, MethodProfile profile) {
        return new ExperimentConfig(conf, profile);
    }

    /** Keep the same geometric count contract in online probing and formal execution. */
    public EngineOptions microProbeEngineOptions() {
        return new EngineOptions(projectionCache, false, geometricBounds,false,false,false,false,false,microDenseBoundaryCounting);
    }

    public EngineOptions microEngineOptions() {
        return new EngineOptions(projectionCache, false, geometricBounds,
                microProjectedDedup, microCountWindowCache, microAnchorBoundary,
                microDeferredCircleAllocation, microSpatialCountTree,microDenseBoundaryCounting);
    }

    public double microCellCost(double pairWork, long count) {
        return microCostModel.equals("cell_quadratic") ? pairWork * pairWork / Math.max(1L, count) : pairWork;
    }

    public void requireSupportedExecution() {
        if (taskDetails && !enabled) throw new IllegalArgumentException("local task details require experimental hilbert_full");
    }

    private static boolean bool(SparkConf conf, String key, boolean fallback) {
        String value = conf.get(PREFIX + key, Boolean.toString(fallback));
        if (!value.equals("true") && !value.equals("false")) {
            throw new IllegalArgumentException(key + " must be true or false");
        }
        return Boolean.parseBoolean(value);
    }

    private static String choice(SparkConf conf, String key, String fallback, String... values) {
        String value = conf.get(PREFIX + key, fallback);
        for (String allowed : values) if (allowed.equals(value)) return value;
        throw new IllegalArgumentException("unsupported " + key + ": " + value);
    }
}
