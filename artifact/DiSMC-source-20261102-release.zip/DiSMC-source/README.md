# DiSMC source release — 2026-11-02

This release integrates the experimentally bound server source with the numerical repair. It retains the server planner, probe and frozen-state replay code; only the recorded numerical patch is applied to production code. It is a new source release, not the original experiment executable.

## Requirements and build

JDK 8, Spark 3.2.0 / Scala 2.12, Bash. Set JAVA_HOME, PATH and SPARK_HOME to your installations.

```bash
bash build.sh
bash scripts/check_selected.sh
bash scripts/run_small_online.sh /absolute/new/output/result.txt
```

The last command runs a synthetic five-point correctness example on local[2], with full member export and a 5% record budget. Use a new output path. Real datasets and historical result files are intentionally excluded.

## Cluster launcher

Set SPARK_HOME, SPARK_MASTER, TOTAL_EXECUTOR_CORES, EXECUTOR_CORES, EXECUTOR_MEMORY, DRIVER_MEMORY, QUERY_X and QUERY_Y explicitly. The public launcher has no private cluster address default: set `SPARK_MASTER` for distributed profiles (not needed for `single_esmc`). Resource options retain portable fallback values, so override them explicitly to reproduce a specific experiment. Its arguments are PROFILE INPUT OUTPUT PARTITIONS RADIUS DENSITY CELL_FACTOR, followed by `--` and Spark options. Supply `--conf spark.skyline.shardReadBudget=0.05` for the manuscript's ordinary 5% budget; no historical defaults are silently changed.

## Numerical changes

Counting and member export share NumericalCoverage.covers. Anchor-count pruning additionally requires a conservative actual-candidate-center inclusion certificate; failure bypasses that pruning. Source provenance and verification are recorded in SOURCE_MANIFEST.json and VERIFICATION.json. The historical Legacy comparator retains its own numerical rules.

## Scope

The package contains production source dependencies, mechanism/boundary regression tests, build and launch files and one synthetic fixture. It excludes datasets, performance logs, compiled binaries, caches, manuscript files and superseded source trees. Tests do not constitute a universal floating-point proof. This integrated build has not rerun the paper's large performance suite; old timings are not relabelled as measurements of this build.
