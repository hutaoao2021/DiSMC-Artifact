import pathlib,json,hashlib,csv,collections
r=pathlib.Path(__file__).resolve().parent
for ds in ['geolife','tdrive']:
 d=r/ds;manifest=json.load(open(d/'raw_record_manifest.json'));a=json.load(open(d/'accounting.json'))
 for name,meta in manifest['files'].items():assert hashlib.sha256((d/name).read_bytes()).hexdigest()==meta['sha256'],(ds,name)
 assert hashlib.sha256((d/'result.txt.micro_plan.tsv').read_bytes()).hexdigest()==a['plan_sha256']
 parent={int(v['owner']):int(v['input_records']) for v in csv.DictReader(open(d/'result.txt.all_candidates.csv')) if v['kind']=='original'}
 task=list(csv.DictReader(open(d/'result.txt.micro_cost_predictions.csv')));groups=collections.defaultdict(list)
 for v in task:groups[int(v['owner'])].append(v)
 dep=sum(max(0,sum(int(v['input_records']) for v in groups[o])-n) for o,n in parent.items())
 full=sum((len(groups[o])-1)*n for o,n in parent.items())
 assert sum(parent.values())==a['R0'] and dep==a['dependency_fee'] and full==a['full_fee']
 actual=collections.defaultdict(set)
 for v in csv.DictReader(open(d/'result.txt.micro_tasks.csv')):actual[(int(v['owner']),int(v['lane']))].add(int(v['input_records']))
 predicted={(int(v['owner']),int(v['lane'])):int(v['input_records']) for v in task}
 assert set(actual)==set(predicted) and all(actual[k]=={v} for k,v in predicted.items())
 print(ds,'PASS: file hashes, responsibility ID, per-owner fees and actual task-input counts')
