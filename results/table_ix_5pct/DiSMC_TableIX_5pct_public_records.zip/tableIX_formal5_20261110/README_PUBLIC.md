# Public Table IX evidence subset

This subset was derived from the original DiSMC_TableIX_5pct_raw_records_20261110.zip (SHA-256: d7479212e63386e68cd4050cf4eb8ca221c13d603a96416b289a400f7f60ebb2).

It includes the original numeric evidence (including complete owner/task-level candidates and cost predictions), source accounting, and original verifier unchanged. It intentionally excludes the original commands, run logs, runtime manifests, and observation payloads that contain private server paths or intranet addresses. The contents here are **not a substitute for full executable provenance**; the public command templates are in configs/run-commands.md.

The raw_record_manifest.json files have been regenerated over the included public files, so the original verify_records.py checks their SHA-256 and the plan/task/fee arithmetic. No selected numeric data, plan data or accounting values have been altered.

To verify: unzip this ZIP; then python tableIX_formal5_20261110/verify_records.py.

This package corresponds only to the supplement Table IX 5% fixed-responsibility feasibility diagnostic: one completed Dependency run per dataset, not a timed Full-parent control.
